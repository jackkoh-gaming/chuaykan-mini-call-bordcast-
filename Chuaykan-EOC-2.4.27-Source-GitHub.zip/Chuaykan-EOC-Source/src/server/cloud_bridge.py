"""Authenticated outbound EOC synchronization; voice stays bounded and off the GUI thread."""
from collections import deque
from dataclasses import fields
from pathlib import Path
import base64
import json
import ssl
import struct
import threading
import time
import urllib.request
from src.core.config import RECORDINGS_DIR
from src.core.models import SosCase


class CloudBridge:
    def __init__(self, server, url, officer_token, certificate):
        self.server = server
        self.url = url.rstrip('/')
        if not self.url.startswith('https://'):
            raise ValueError('Cloud gateway requires HTTPS')
        self.officer_token = officer_token
        self.context = ssl.create_default_context(cafile=str(certificate))
        # Trust only the explicitly provisioned gateway certificate; address is public IP.
        self.context.check_hostname = False
        self.stop_event = threading.Event()
        self.condition = threading.Condition()
        self.controls = deque()
        self.audio = deque(maxlen=4)
        self.call_audio = deque(maxlen=4)
        self.remote_status = {}
        self.sync_lock = threading.RLock()
        self.last_message = ''

    @classmethod
    def configured(cls, server):
        path = server.security.directory / 'cloud.json'
        if not path.exists():
            return None
        config = json.loads(path.read_text())
        certificate = server.security.directory / 'cloud-ca.pem'
        return cls(server, config['url'], server.security.officer_token, certificate if certificate.exists() else server.security.cert)

    def request(self, path, payload=None):
        body = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
        req = urllib.request.Request(self.url + path, data=body, headers={
            'X-Officer-Key': self.officer_token,
            'Content-Type': 'application/json',
        })
        with urllib.request.urlopen(req, timeout=5, context=self.context) as response:
            raw = response.read(16 * 1024 * 1024 + 1)
            if len(raw) > 16 * 1024 * 1024:
                raise ValueError('Cloud response too large')
            return json.loads(raw)

    def status(self, message):
        if message != self.last_message:
            self.last_message = message
            callback = getattr(self.server, 'on_cloud_status', None)
            if callback:
                callback(message)

    def start(self):
        for name, target in [('EOC-Cloud-Sync', self.sync_loop), ('EOC-Cloud-Voice', self.voice_loop), ('EOC-Cloud-Call-Receive', self.call_receive_loop)]:
            threading.Thread(target=target, daemon=True, name=name).start()

    def stop(self):
        self.stop_event.set()
        with self.condition:
            self.condition.notify_all()

    def publish(self, action, payload=None):
        with self.condition:
            if action == 'call_audio':
                self.call_audio.append(payload)
            elif action == 'audio':
                self.audio.append(payload)
            else:
                if action in ('start', 'stop'):
                    self.audio.clear()
                self.controls.append((action, payload))
            self.condition.notify()

    def voice_loop(self):
        while not self.stop_event.is_set():
            with self.condition:
                self.condition.wait_for(lambda: self.controls or self.audio or self.call_audio or self.stop_event.is_set(), timeout=1)
                if self.stop_event.is_set():
                    return
                if self.controls:
                    action, payload = self.controls.popleft()
                elif self.audio:
                    action, payload = 'chunk', {'pcm_base64': base64.b64encode(b''.join(self.audio)).decode()}
                    self.audio.clear()
                elif self.call_audio:
                    action, payload = 'call_audio', {'pcm_base64': base64.b64encode(b''.join(self.call_audio)).decode()}
                    self.call_audio.clear()
                else:
                    continue
            try:
                self.request('/api/call/officer/voice' if action == 'call_audio' else '/api/announcement/' + action, payload or {})
            except Exception as exc:
                self.status('Oracle ส่งเสียงไม่ได้: ' + type(exc).__name__)
                # Start/end are idempotent and must not be lost to a transient connection failure.
                if action in ('start', 'stop'):
                    with self.condition:
                        self.controls.appendleft((action, payload))
                    self.stop_event.wait(1)

    def call_receive_loop(self):
        while not self.stop_event.is_set():
            try:
                request = urllib.request.Request(self.url + '/api/call/officer/stream', headers={'X-Officer-Key': self.officer_token})
                with urllib.request.urlopen(request, context=self.context, timeout=5) as response:
                    while not self.stop_event.is_set():
                        header = response.read(5)
                        if len(header) != 5:
                            break
                        kind, size = struct.unpack('!BI', header)
                        if size > 64000:
                            raise ValueError('Call frame too large')
                        data = response.read(size)
                        if len(data) != size:
                            break
                        if kind == 0x31 and self.server.call_session.state == 'CONNECTED' and self.server.on_citizen_voice:
                            self.server.on_citizen_voice(data)
            except Exception:
                self.stop_event.wait(1)

    def sync_call_status(self):
        with self.server.call_lock:
            self._sync_call_status_locked()

    def _sync_call_status_locked(self):
        status = self.request('/api/call/status')
        previous = self.server.call_session.state
        state = status.get('state', 'IDLE')
        self.server.call_session.state = state
        self.server.call_session.target_device_id = status.get('target_device_id', '')
        if state == 'RINGING' and previous != state and status.get('caller_id') != 'EOC' and self.server.on_call_incoming:
            self.server.on_call_incoming(status.get('caller_name', ''), status.get('target_phone', ''), status.get('caller_id', ''))
        elif state == 'CONNECTED' and previous != state and self.server.on_call_answered:
            self.server.on_call_answered('', self.server.call_session.target_device_id)
        elif state == 'IDLE' and previous != state and self.server.on_call_ended:
            self.call_audio.clear()
            self.server.on_call_ended()

    def complete_case(self, case_id):
        with self.sync_lock:
            self.server.db.request_completion(case_id)
            reply = self.request('/api/sos/complete', {'case_id': case_id})
            if reply.get('status') != 'SUCCESS':
                raise ValueError('Cloud completion not acknowledged')
            self.server.complete_case(case_id, count=True)
            self.remote_status.pop(case_id, None)

    def sync_once(self):
        with self.sync_lock:
            self._sync_once()

    def _sync_once(self):
        for cid in self.server.db.pending_completions():
            self.complete_case(cid)
            if self.server.on_sos_updated:
                self.server.on_sos_updated(cid, 'RESCUED_SAFE')
        local = {case.case_id: case for case in self.server.db.get_all_sos_cases()}
        uploads = []
        updates = []
        for cid, case in local.items():
            if cid not in self.remote_status:
                data = case.to_dict()
                for field, key in [('photo_file', 'photo_base64'), ('audio_file', 'audio_base64')]:
                    name = getattr(case, field)
                    if name and Path(name).name == name and (RECORDINGS_DIR / name).is_file():
                        data[key] = base64.b64encode((RECORDINGS_DIR / name).read_bytes()).decode()
                uploads.append(data)
            elif (case.status, case.assigned_team) != self.remote_status[cid]:
                updates.append({'case_id': cid, 'status': case.status, 'team': case.assigned_team})
        result = self.request('/api/cloud/sync', {
            'zones': [zone.to_dict() for zone in self.server.db.get_active_zones()],
            'sites': [site.to_dict() for site in self.server.db.get_all_evacuation_sites()],
            'uploads': uploads, 'updates': updates,
            'deleted': [cid for cid in self.remote_status if cid not in local],
        })
        if result.get('status') != 'SUCCESS':
            raise ValueError('Cloud synchronization rejected')
        remote = result['cases']
        remote_ids = {case['case_id'] for case in remote}
        for cid in set(self.remote_status) - remote_ids:
            if self.server.db.finish_sos_case(cid) and self.server.on_sos_updated:
                self.server.on_sos_updated(cid, 'REMOVED')
        allowed = {field.name for field in fields(SosCase)}
        next_status = {}
        for data in remote:
            case = SosCase(**{key: value for key, value in data.items() if key in allowed})
            for field in ('photo_file', 'audio_file'):
                name = getattr(case, field)
                if name and Path(name).name == name and not (RECORDINGS_DIR / name).exists():
                    from urllib.parse import quote
                    attachment = self.request('/api/cloud/attachment?name=' + quote(name))
                    raw = base64.b64decode(attachment['data'], validate=True)
                    if len(raw) > 10 * 1024 * 1024:
                        raise ValueError('Attachment too large')
                    temporary = RECORDINGS_DIR / (name + '.part')
                    temporary.write_bytes(raw)
                    temporary.replace(RECORDINGS_DIR / name)
            old = local.get(case.case_id)
            current = self.server.db.get_sos_case(case.case_id)
            next_status[case.case_id] = (case.status, case.assigned_team)
            if old is not None:
                # Apply only to the unchanged local revision. Never reinsert an officer-deleted case.
                with self.server.db._get_conn() as connection:
                    updated = connection.execute(
                        "UPDATE sos_cases SET status=?, assigned_team=?, dispatched_at=?, rescued_at=? WHERE case_id=? AND status=? AND assigned_team=?",
                        (case.status, case.assigned_team, case.dispatched_at, case.rescued_at,
                         case.case_id, old.status, old.assigned_team)).rowcount
                if updated and old.status != case.status and self.server.on_sos_updated:
                    self.server.on_sos_updated(case.case_id, case.status)
            elif current is None:
                self.server.db.save_sos_case(case)
                if self.server.on_new_sos:
                    self.server.on_new_sos(case)
        self.remote_status = next_status
        self.status('Oracle เชื่อมต่อแล้ว • รับส่งเคสและพื้นที่คุมผ่าน HTTPS')

    def sync_loop(self):
        while not self.stop_event.is_set():
            try:
                self.sync_once()
                self.sync_call_status()
            except Exception as exc:
                self.status('Oracle ยังซิงก์ไม่ได้: ' + type(exc).__name__)
            self.stop_event.wait(1)
