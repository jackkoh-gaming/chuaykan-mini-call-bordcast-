package com.rescue.alert.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast

/**
 * Reliable web link launcher with URL sanitization, package visibility fallback,
 * chooser support, and clipboard copy as ultimate guarantee.
 */
object WebLinkHelper {

    private const val TAG = "WebLinkHelper"

    fun openUrl(context: Context, rawUrl: String) {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            Toast.makeText(context, "ไม่พบที่อยู่เว็บไซต์ (URL ว่างเปล่า)", Toast.LENGTH_SHORT).show()
            return
        }

        val url = when {
            trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            else -> "https://$trimmed"
        }

        Log.i(TAG, "Attempting to open verified URL: $url")

        try {
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.w(TAG, "Direct launch failed: ${e.message}, trying Intent.createChooser", e)
            try {
                val chooserIntent = Intent.createChooser(
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    },
                    "เปิดอ่านข่าวสารทางการผ่านเว็บเบราว์เซอร์"
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooserIntent)
            } catch (e2: Exception) {
                Log.e(TAG, "All launch attempts failed: ${e2.message}", e2)
                copyToClipboard(context, url)
                Toast.makeText(
                    context,
                    "ไม่สามารถเปิดเบราว์เซอร์ได้ (คัดลอกลิงก์ไปยังคลิปบอร์ดแล้ว)",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun copyToClipboard(context: Context, url: String) {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = ClipData.newPlainText("Official News Link", url)
            cm?.setPrimaryClip(clip)
            Toast.makeText(context, "คัดลอกลิงก์เรียบร้อย: $url", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy to clipboard", e)
        }
    }
}
