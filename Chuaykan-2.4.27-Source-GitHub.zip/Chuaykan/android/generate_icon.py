#!/usr/bin/env python3
"""Generate simple launcher icons for RescueAlert app."""
from PIL import Image, ImageDraw, ImageFont
import os

BASE = os.path.dirname(__file__)
SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

for folder, size in SIZES.items():
    out_dir = os.path.join(BASE, "app/src/main/res", folder)
    os.makedirs(out_dir, exist_ok=True)
    
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Red circle
    margin = size // 10
    draw.ellipse([margin, margin, size - margin, size - margin], fill=(204, 0, 0, 255))
    
    # White exclamation mark (!)
    font_size = size // 2
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    text = "!"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = (size - tw) // 2
    ty = (size - th) // 2 - size // 12
    draw.text((tx, ty), text, fill=(255, 255, 255, 255), font=font)
    
    out_path = os.path.join(out_dir, "ic_launcher.png")
    img.save(out_path)
    print(f"  {folder}/ic_launcher.png ({size}x{size})")

print("Done! All icons generated.")
