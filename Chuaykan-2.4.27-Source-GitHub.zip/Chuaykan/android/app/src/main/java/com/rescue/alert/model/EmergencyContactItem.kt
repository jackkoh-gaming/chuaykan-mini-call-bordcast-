package com.rescue.alert.model

enum class ContactCategory(val displayName: String) {
    ALL("ทั้งหมด"),
    GOVERNMENT("หน่วยงานรัฐ"),
    FOUNDATION("มูลนิธิและกู้ภัย")
}

data class EmergencyContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val category: ContactCategory,
    val province: String,
    val description: String,
    val subDistrict: String? = null
)
