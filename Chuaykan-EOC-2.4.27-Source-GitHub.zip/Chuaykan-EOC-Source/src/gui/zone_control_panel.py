#!/usr/bin/env python3
"""
ZoneControlPanel: manages operator-defined active risk areas AND evacuation/parking sites.
Tab 1: ควบคุมพื้นที่เสี่ยง (Risk Areas) - Up to 10 operator-defined disaster zones.
Tab 2: ศูนย์ช่วยเหลือ / อพยพ & ที่จอดรถ (Evacuation & Parking Sites) - Up to 10 safe sites.
Supports direct map click-to-place coordinates for both risk areas and evacuation sites.
"""
from __future__ import annotations

import time
from typing import Dict, Iterable, List, Optional

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QDoubleSpinBox, QSpinBox, QComboBox, QTextEdit, QPushButton, QFrame,
    QCheckBox, QScrollArea, QTabWidget
)

from src.core.config import COLOR_EMERGENCY_RED, COLOR_FLOOD_CYAN, ICONS_DIR
from src.core.models import DisasterZone, EvacuationSite


class ZoneControlPanel(QWidget):
    """Operator-defined risk areas and evacuation/shelter/parking sites."""

    zone_broadcast_requested = Signal(object)  # list[DisasterZone], max 10
    zone_removal_requested = Signal(object)  # update remaining areas without alerts
    evacuation_sites_updated = Signal(object)  # list[EvacuationSite]

    MAX_RISK_AREAS = 10
    MAX_EVAC_SITES = 10

    def __init__(self, db=None, parent=None):
        super().__init__(parent)
        self.db = db
        self.setMinimumWidth(350)
        self._active_zones: Dict[int, DisasterZone] = {}
        self._active_sites: Dict[int, EvacuationSite] = {}
        self._init_ui()
        self._load_slot(1)
        self._load_initial_sites_from_db()
        self._load_site_slot(1)

    def _init_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(4)

        # Tab Widget separating Risk Areas and Evacuation/Parking Sites
        self.tab_widget = QTabWidget(self)
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #1E293B;
                background-color: #0F172A;
                border-radius: 6px;
            }
            QTabBar::tab {
                background: #1E293B;
                color: #94A3B8;
                font-weight: bold;
                font-size: 11.5px;
                padding: 7px 12px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background: #0F172A;
                color: #38BDF8;
                border: 1px solid #1E293B;
                border-bottom-color: #0F172A;
            }
        """)

        # -----------------------------------------------------------------
        # TAB 1: RISK AREAS
        # -----------------------------------------------------------------
        self.tab_risk = QWidget()
        risk_layout = QVBoxLayout(self.tab_risk)
        risk_layout.setContentsMargins(4, 4, 4, 4)

        scroll_risk = QScrollArea()
        scroll_risk.setWidgetResizable(True)
        scroll_risk.setFrameShape(QFrame.Shape.NoFrame)
        scroll_risk.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        content_risk = QWidget()
        scroll_risk.setWidget(content_risk)
        c_risk_layout = QVBoxLayout(content_risk)
        c_risk_layout.setContentsMargins(6, 6, 6, 6)
        c_risk_layout.setSpacing(7)

        # Header Card
        header = QFrame()
        header.setObjectName("elevatedCard")
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(9, 7, 9, 7)
        row = QHBoxLayout()
        icon = QLabel()
        icon_path = ICONS_DIR / "shield_alert.svg"
        if icon_path.exists():
            icon.setPixmap(QIcon(str(icon_path)).pixmap(18, 18))
        row.addWidget(icon)
        title = QLabel("ควบคุมพื้นที่เสี่ยง (RISK AREAS)")
        title.setObjectName("headerTitle")
        row.addWidget(title)
        row.addStretch()
        header_layout.addLayout(row)
        subtitle = QLabel("กำหนดเองได้ 10 จุด • แสดงและส่งเฉพาะจุดที่เปิดเป็นพื้นที่เสี่ยง")
        subtitle.setObjectName("subText")
        subtitle.setWordWrap(True)
        header_layout.addWidget(subtitle)
        c_risk_layout.addWidget(header)

        # Slot Selector
        slot_row = QHBoxLayout()
        slot_row.addWidget(QLabel("เลือกจุดพื้นที่:"))
        self.cb_slot = QComboBox()
        for slot in range(1, self.MAX_RISK_AREAS + 1):
            self.cb_slot.addItem(f"จุดที่ {slot}", slot)
        self.cb_slot.currentIndexChanged.connect(self._on_slot_changed)
        slot_row.addWidget(self.cb_slot, 1)
        c_risk_layout.addLayout(slot_row)

        # Form Card
        card = QFrame()
        card.setObjectName("panelCard")
        form = QVBoxLayout(card)
        form.setContentsMargins(9, 8, 9, 8)
        form.setSpacing(6)

        self.chk_risk = QCheckBox("เปิดเป็นพื้นที่เสี่ยง และส่งแจ้งเตือนออนไลน์")
        self.chk_risk.setStyleSheet(f"color: {COLOR_EMERGENCY_RED}; font-weight: bold;")
        form.addWidget(self.chk_risk)

        form.addWidget(QLabel("ชื่อพื้นที่ / เหตุการณ์:"))
        self.txt_title = QLineEdit()
        self.txt_title.setPlaceholderText("เช่น จุดเสี่ยงริมแม่น้ำกก")
        form.addWidget(self.txt_title)

        coords = QHBoxLayout()
        lat_box = QVBoxLayout()
        lat_box.addWidget(QLabel("ละติจูด (Lat):"))
        self.spin_lat = QDoubleSpinBox()
        self.spin_lat.setRange(-90.0, 90.0)
        self.spin_lat.setDecimals(5)
        self.spin_lat.setSingleStep(0.0001)
        lat_box.addWidget(self.spin_lat)
        coords.addLayout(lat_box)

        lng_box = QVBoxLayout()
        lng_box.addWidget(QLabel("ลองจิจูด (Lng):"))
        self.spin_lng = QDoubleSpinBox()
        self.spin_lng.setRange(-180.0, 180.0)
        self.spin_lng.setDecimals(5)
        self.spin_lng.setSingleStep(0.0001)
        lng_box.addWidget(self.spin_lng)
        coords.addLayout(lng_box)
        form.addLayout(coords)

        radius_row = QHBoxLayout()
        radius_row.addWidget(QLabel("รัศมีครอบคลุม (กม.):"))
        self.spin_radius = QDoubleSpinBox()
        self.spin_radius.setRange(0.1, 100.0)
        self.spin_radius.setValue(3.0)
        self.spin_radius.setDecimals(1)
        self.spin_radius.setSingleStep(0.5)
        self.spin_radius.setStyleSheet(f"color: {COLOR_FLOOD_CYAN}; font-weight: bold;")
        radius_row.addWidget(self.spin_radius)
        form.addLayout(radius_row)

        form.addWidget(QLabel("ระดับความรุนแรง:"))
        self.cb_severity = QComboBox()
        self.cb_severity.addItem("วิกฤตสูงสุด (CRITICAL)", "CRITICAL")
        self.cb_severity.addItem("เฝ้าระวังพิเศษ (WARNING)", "WARNING")
        form.addWidget(self.cb_severity)

        form.addWidget(QLabel("ข้อความถึงประชาชนในพื้นที่:"))
        self.txt_instruction = QTextEdit()
        self.txt_instruction.setFixedHeight(54)
        self.txt_instruction.setPlaceholderText("เช่น หลีกเลี่ยงพื้นที่ลุ่มต่ำและเตรียมอพยพ")
        form.addWidget(self.txt_instruction)
        c_risk_layout.addWidget(card)

        self.btn_save = QPushButton("บันทึกจุดนี้ และส่งเฉพาะพื้นที่เสี่ยง")
        icon_path = ICONS_DIR / "broadcast.svg"
        if icon_path.exists():
            self.btn_save.setIcon(QIcon(str(icon_path)))
            self.btn_save.setIconSize(QSize(18, 18))
        self.btn_save.setObjectName("btnEmergency")
        self.btn_save.setFixedHeight(42)
        self.btn_save.clicked.connect(self._save_current_slot)
        c_risk_layout.addWidget(self.btn_save)

        self.btn_disable = QPushButton("ปิดความเสี่ยงของจุดนี้ (ลบหมุด / ไม่แจ้งเตือน)")
        self.btn_disable.setFixedHeight(34)
        self.btn_disable.clicked.connect(self._disable_current_slot)
        c_risk_layout.addWidget(self.btn_disable)

        self.status_card = QFrame()
        self.status_card.setObjectName("dangerCard")
        status_layout = QVBoxLayout(self.status_card)
        status_layout.setContentsMargins(10, 8, 10, 8)
        self.lbl_active_title = QLabel()
        self.lbl_active_title.setStyleSheet("color: #F87171; font-weight: bold; font-size: 12px;")
        status_layout.addWidget(self.lbl_active_title)
        self.lbl_active_details = QLabel()
        self.lbl_active_details.setObjectName("subText")
        self.lbl_active_details.setWordWrap(True)
        status_layout.addWidget(self.lbl_active_details)
        c_risk_layout.addWidget(self.status_card)
        c_risk_layout.addStretch()

        risk_layout.addWidget(scroll_risk)
        self.tab_widget.addTab(self.tab_risk, "พื้นที่เสี่ยง (Risk Areas)")

        # -----------------------------------------------------------------
        # TAB 2: EVACUATION & PARKING SITES
        # -----------------------------------------------------------------
        self.tab_sites = QWidget()
        sites_layout = QVBoxLayout(self.tab_sites)
        sites_layout.setContentsMargins(4, 4, 4, 4)

        scroll_sites = QScrollArea()
        scroll_sites.setWidgetResizable(True)
        scroll_sites.setFrameShape(QFrame.Shape.NoFrame)
        scroll_sites.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        content_sites = QWidget()
        scroll_sites.setWidget(content_sites)
        c_sites_layout = QVBoxLayout(content_sites)
        c_sites_layout.setContentsMargins(6, 6, 6, 6)
        c_sites_layout.setSpacing(7)

        # Header Card for Evacuation Sites
        header_s = QFrame()
        header_s.setObjectName("elevatedCard")
        header_s_layout = QVBoxLayout(header_s)
        header_s_layout.setContentsMargins(9, 7, 9, 7)
        row_s = QHBoxLayout()
        icon_s = QLabel()
        ico_s_path = ICONS_DIR / "shield_alert.svg"
        if ico_s_path.exists():
            icon_s.setPixmap(QIcon(str(ico_s_path)).pixmap(18, 18))
        row_s.addWidget(icon_s)
        title_s = QLabel("ศูนย์อพยพ / ที่จอดรถปลอดภัย")
        title_s.setObjectName("headerTitle")
        row_s.addWidget(title_s)
        row_s.addStretch()
        header_s_layout.addLayout(row_s)
        sub_s = QLabel("คลิกบนแผนที่เพื่อระบุพิกัด • กระจายข้อมูลสู่มือถือประชาชนใกล้เคียง")
        sub_s.setObjectName("subText")
        sub_s.setWordWrap(True)
        header_s_layout.addWidget(sub_s)
        c_sites_layout.addWidget(header_s)

        # Slot Selector for Evacuation Sites
        slot_s_row = QHBoxLayout()
        slot_s_row.addWidget(QLabel("เลือกจุดที่:"))
        self.cb_site_slot = QComboBox()
        for slot in range(1, self.MAX_EVAC_SITES + 1):
            self.cb_site_slot.addItem(f"จุดที่ {slot}", slot)
        self.cb_site_slot.currentIndexChanged.connect(self._on_site_slot_changed)
        slot_s_row.addWidget(self.cb_site_slot, 1)
        c_sites_layout.addLayout(slot_s_row)

        # Form Card for Evacuation Sites
        card_s = QFrame()
        card_s.setObjectName("panelCard")
        form_s = QVBoxLayout(card_s)
        form_s.setContentsMargins(9, 8, 9, 8)
        form_s.setSpacing(6)

        self.chk_site_active = QCheckBox("เปิดใช้งานจุดนี้ และส่งเข้ามือถือประชาชน")
        self.chk_site_active.setStyleSheet("color: #10B981; font-weight: bold;")
        form_s.addWidget(self.chk_site_active)

        form_s.addWidget(QLabel("ประเภทสถานที่:"))
        self.cb_site_type = QComboBox()
        self.cb_site_type.addItem("ศูนย์อพยพ / พักพิงชั่วคราว (SHELTER)", "SHELTER")
        self.cb_site_type.addItem("จุดจอดรถปลอดภัย น้ำไม่ท่วม (PARKING)", "PARKING")
        self.cb_site_type.addItem("ศูนย์ช่วยเหลือ / แจกถุงยังชีพ (RELIEF)", "RELIEF")
        form_s.addWidget(self.cb_site_type)

        form_s.addWidget(QLabel("ชื่อศูนย์ / สถานที่:"))
        self.txt_site_name = QLineEdit()
        self.txt_site_name.setPlaceholderText("เช่น โรงเรียนเทศบาล 6 (ศูนย์อพยพหลัก)")
        form_s.addWidget(self.txt_site_name)

        coords_s = QHBoxLayout()
        lat_s_box = QVBoxLayout()
        lat_s_box.addWidget(QLabel("ละติจูด (Lat):"))
        self.spin_site_lat = QDoubleSpinBox()
        self.spin_site_lat.setRange(-90.0, 90.0)
        self.spin_site_lat.setDecimals(5)
        self.spin_site_lat.setSingleStep(0.0001)
        lat_s_box.addWidget(self.spin_site_lat)
        coords_s.addLayout(lat_s_box)

        lng_s_box = QVBoxLayout()
        lng_s_box.addWidget(QLabel("ลองจิจูด (Lng):"))
        self.spin_site_lng = QDoubleSpinBox()
        self.spin_site_lng.setRange(-180.0, 180.0)
        self.spin_site_lng.setDecimals(5)
        self.spin_site_lng.setSingleStep(0.0001)
        lng_s_box.addWidget(self.spin_site_lng)
        coords_s.addLayout(lng_s_box)
        form_s.addLayout(coords_s)

        cap_phone_row = QHBoxLayout()
        cap_box = QVBoxLayout()
        cap_box.addWidget(QLabel("ความจุ (คน/คัน):"))
        self.spin_site_capacity = QSpinBox()
        self.spin_site_capacity.setRange(10, 50000)
        self.spin_site_capacity.setValue(1000)
        self.spin_site_capacity.setSingleStep(100)
        cap_box.addWidget(self.spin_site_capacity)
        cap_phone_row.addLayout(cap_box)

        phone_box = QVBoxLayout()
        phone_box.addWidget(QLabel("เบอร์ติดต่อศูนย์:"))
        self.txt_site_phone = QLineEdit()
        self.txt_site_phone.setPlaceholderText("เช่น 053-711718")
        phone_box.addWidget(self.txt_site_phone)
        cap_phone_row.addLayout(phone_box)
        form_s.addLayout(cap_phone_row)

        form_s.addWidget(QLabel("รายละเอียด / สิ่งอำนวยความสะดวก:"))
        self.txt_site_notes = QTextEdit()
        self.txt_site_notes.setFixedHeight(50)
        self.txt_site_notes.setPlaceholderText("เช่น จุดดอนสูง มีอาหาร น้ำดื่ม แพทย์สนาม และเต็นท์พักแรม")
        form_s.addWidget(self.txt_site_notes)
        c_sites_layout.addWidget(card_s)

        self.btn_site_save = QPushButton("บันทึกจุดนี้ และกระจายสู่มือถือประชาชน")
        self.btn_site_save.setFixedHeight(40)
        self.btn_site_save.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_site_save.setStyleSheet("""
            QPushButton {
                background-color: #047857;
                border: 1.5px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 12.5px;
                border-radius: 6px;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background-color: #059669;
            }
        """)
        self.btn_site_save.clicked.connect(self._save_current_site_slot)
        c_sites_layout.addWidget(self.btn_site_save)

        self.btn_site_disable = QPushButton("ปิดการใช้งาน / ลบจุดนี้")
        self.btn_site_disable.setFixedHeight(32)
        self.btn_site_disable.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_site_disable.setStyleSheet("""
            QPushButton {
                background-color: #334155;
                border: 1px solid #475569;
                color: #CBD5E1;
                font-size: 11.5px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #475569;
                color: #FFFFFF;
            }
        """)
        self.btn_site_disable.clicked.connect(self._delete_current_site_slot)
        c_sites_layout.addWidget(self.btn_site_disable)

        # Status Card for Sites
        self.status_s_card = QFrame()
        self.status_s_card.setObjectName("elevatedCard")
        status_s_layout = QVBoxLayout(self.status_s_card)
        status_s_layout.setContentsMargins(10, 8, 10, 8)
        self.lbl_site_status_title = QLabel()
        self.lbl_site_status_title.setStyleSheet("color: #34D399; font-weight: bold; font-size: 12px;")
        status_s_layout.addWidget(self.lbl_site_status_title)
        self.lbl_site_status_details = QLabel()
        self.lbl_site_status_details.setObjectName("subText")
        self.lbl_site_status_details.setWordWrap(True)
        status_s_layout.addWidget(self.lbl_site_status_details)
        c_sites_layout.addWidget(self.status_s_card)
        c_sites_layout.addStretch()

        sites_layout.addWidget(scroll_sites)
        self.tab_widget.addTab(self.tab_sites, "ศูนย์อพยพ / ที่จอดรถ")

        root.addWidget(self.tab_widget)

    # =========================================================================
    # TAB 1 LOGIC (RISK AREAS)
    # =========================================================================
    def _slot_number(self) -> int:
        return int(self.cb_slot.currentData() or 1)

    def _on_slot_changed(self, _index: int):
        self._load_slot(self._slot_number())

    def _load_slot(self, slot: int):
        zone = self._active_zones.get(slot)
        self.chk_risk.setChecked(zone is not None)
        if zone:
            self.txt_title.setText(zone.title)
            self.spin_lat.setValue(zone.center_lat)
            self.spin_lng.setValue(zone.center_lng)
            self.spin_radius.setValue(zone.radius_km)
            self.cb_severity.setCurrentIndex(0 if zone.severity == "CRITICAL" else 1)
            self.txt_instruction.setPlainText(zone.instruction)
        else:
            self.txt_title.clear()
            self.spin_lat.setValue(0.0)
            self.spin_lng.setValue(0.0)
            self.spin_radius.setValue(3.0)
            self.cb_severity.setCurrentIndex(0)
            self.txt_instruction.clear()
        self._update_status()

    def _save_current_slot(self):
        slot = self._slot_number()
        if not self.chk_risk.isChecked():
            self._active_zones.pop(slot, None)
        else:
            self._active_zones[slot] = DisasterZone(
                zone_id=f"RISK_POINT_{slot:02d}",
                title=self.txt_title.text().strip() or f"พื้นที่เสี่ยง จุดที่ {slot}",
                hazard_type="FLOOD",
                severity=str(self.cb_severity.currentData() or "CRITICAL"),
                center_lat=self.spin_lat.value(),
                center_lng=self.spin_lng.value(),
                radius_km=self.spin_radius.value(),
                instruction=self.txt_instruction.toPlainText().strip() or "โปรดติดตามคำแนะนำจากศูนย์ EOC",
                agency="ศูนย์ปฏิบัติการสถานการณ์ภัยพิบัติ (EOC)",
                created_at=time.time(),
                is_active=True,
            )
        self._update_status()
        self.zone_broadcast_requested.emit(self.active_zones())

    def _disable_current_slot(self):
        slot = self._slot_number()
        self._active_zones.pop(slot, None)
        self._load_slot(slot)
        self.zone_removal_requested.emit(self.active_zones())

    def selected_slot_number(self) -> int:
        return self._slot_number()

    def active_zones(self) -> List[DisasterZone]:
        return [self._active_zones[slot] for slot in sorted(self._active_zones)]

    def set_active_zones(self, zones: Iterable[DisasterZone]):
        self._active_zones = {}
        for zone in zones:
            try:
                slot = int(str(zone.zone_id).rsplit("_", 1)[-1])
            except (ValueError, TypeError):
                continue
            if 1 <= slot <= self.MAX_RISK_AREAS and zone.is_active:
                self._active_zones[slot] = zone
        self._load_slot(self._slot_number())

    def update_active_zone_ui(self, zone: Optional[DisasterZone], in_zone_count: int = 0):
        if zone is None:
            self.set_active_zones([])
        else:
            self.set_active_zones([zone])

    def _update_status(self):
        active = self.active_zones()
        if not active:
            self.lbl_active_title.setText("ไม่มีพื้นที่เสี่ยงที่เปิดใช้งาน")
            self.lbl_active_details.setText(
                "แผนที่จะไม่แสดงจุด และแอปมือถือจะไม่ได้รับการแจ้งเตือนจาก EOC"
            )
            return
        current = self._active_zones.get(self._slot_number())
        self.lbl_active_title.setText(
            f"กำลังส่ง/แสดงพื้นที่เสี่ยง {len(active)} จาก {self.MAX_RISK_AREAS} จุด"
        )
        if current:
            self.lbl_active_details.setText(
                f"จุดที่ {self._slot_number()}: {current.center_lat:.5f}, "
                f"{current.center_lng:.5f} • รัศมี {current.radius_km:.1f} กม."
            )
        else:
            self.lbl_active_details.setText("จุดที่เลือกยังไม่เปิดเป็นพื้นที่เสี่ยง")

    # =========================================================================
    # TAB 2 LOGIC (EVACUATION & PARKING SITES)
    # =========================================================================
    def _site_slot_number(self) -> int:
        return int(self.cb_site_slot.currentData() or 1)

    def _on_site_slot_changed(self, _index: int):
        self._load_site_slot(self._site_slot_number())

    def _load_initial_sites_from_db(self):
        if not self.db:
            return
        try:
            sites = self.db.get_all_evacuation_sites()
            for s in sites:
                try:
                    slot = int(str(s.site_id).rsplit("_", 1)[-1])
                    if 1 <= slot <= self.MAX_EVAC_SITES:
                        self._active_sites[slot] = s
                except Exception:
                    pass
        except Exception as e:
            print(f"[ZoneControlPanel] Failed to load sites from DB: {e}")

    def _load_site_slot(self, slot: int):
        site = self._active_sites.get(slot)
        if site:
            self.chk_site_active.setChecked(site.is_active)
            idx = 0
            if site.site_type == "PARKING":
                idx = 1
            elif site.site_type == "RELIEF":
                idx = 2
            self.cb_site_type.setCurrentIndex(idx)
            self.txt_site_name.setText(site.name)
            self.spin_site_lat.setValue(site.latitude)
            self.spin_site_lng.setValue(site.longitude)
            self.spin_site_capacity.setValue(site.capacity)
            self.txt_site_phone.setText(site.contact_phone)
            self.txt_site_notes.setPlainText(site.notes)
        else:
            self.chk_site_active.setChecked(False)
            self.cb_site_type.setCurrentIndex(0)
            self.txt_site_name.clear()
            self.spin_site_lat.setValue(0.0)
            self.spin_site_lng.setValue(0.0)
            self.spin_site_capacity.setValue(1000)
            self.txt_site_phone.clear()
            self.txt_site_notes.clear()
        self._update_site_status()

    def _save_current_site_slot(self):
        slot = self._site_slot_number()
        site_id = f"SITE_{slot:02d}"
        if not self.chk_site_active.isChecked():
            self._active_sites.pop(slot, None)
            if self.db:
                self.db.delete_evacuation_site(site_id)
        else:
            site_type = str(self.cb_site_type.currentData() or "SHELTER")
            default_name = "ศูนย์อพยพ / พักพิง" if site_type == "SHELTER" else ("จุดจอดรถปลอดภัย" if site_type == "PARKING" else "ศูนย์ช่วยเหลือ")
            name = self.txt_site_name.text().strip() or f"{default_name} จุดที่ {slot}"
            site = EvacuationSite(
                site_id=site_id,
                name=name,
                site_type=site_type,
                latitude=self.spin_site_lat.value(),
                longitude=self.spin_site_lng.value(),
                capacity=self.spin_site_capacity.value(),
                contact_phone=self.txt_site_phone.text().strip(),
                notes=self.txt_site_notes.toPlainText().strip(),
                is_active=True,
                created_at=time.time()
            )
            self._active_sites[slot] = site
            if self.db:
                self.db.upsert_evacuation_site(site)

        self._update_site_status()
        self.evacuation_sites_updated.emit(self.active_sites())

    def _delete_current_site_slot(self):
        slot = self._site_slot_number()
        site_id = f"SITE_{slot:02d}"
        self.chk_site_active.setChecked(False)
        self._active_sites.pop(slot, None)
        if self.db:
            self.db.delete_evacuation_site(site_id)
        self._update_site_status()
        self.evacuation_sites_updated.emit(self.active_sites())

    def selected_site_slot_number(self) -> int:
        return self._site_slot_number()

    def selected_site_type(self) -> str:
        return str(self.cb_site_type.currentData() or "SHELTER")

    def active_sites(self) -> List[EvacuationSite]:
        return [self._active_sites[slot] for slot in sorted(self._active_sites) if self._active_sites[slot].is_active]

    def _update_site_status(self):
        active = self.active_sites()
        shelter_count = sum(1 for s in active if s.site_type == "SHELTER")
        parking_count = sum(1 for s in active if s.site_type == "PARKING")
        relief_count = sum(1 for s in active if s.site_type == "RELIEF")

        if not active:
            self.lbl_site_status_title.setText("ยังไม่มีศูนย์อพยพ/ที่จอดรถที่เปิดใช้งาน")
            self.lbl_site_status_details.setText("กำหนดจุดที่ตั้งและกดบันทึก เพื่อกระจายข้อมูลสู่มือถือประชาชน")
            return

        self.lbl_site_status_title.setText(
            f"เปิดใช้งาน {len(active)} จุด (ศูนย์อพยพ {shelter_count} • ที่จอดรถ {parking_count} • ช่วยเหลือ {relief_count})"
        )
        current = self._active_sites.get(self._site_slot_number())
        if current:
            label = "ศูนย์อพยพ" if current.site_type == "SHELTER" else ("ที่จอดรถ" if current.site_type == "PARKING" else "ศูนย์ช่วยเหลือ")
            self.lbl_site_status_details.setText(
                f"จุดที่ {self._site_slot_number()} ({label}): {current.name} • "
                f"พิกัด {current.latitude:.5f}, {current.longitude:.5f} • ความจุ {current.capacity}"
            )
        else:
            self.lbl_site_status_details.setText(f"จุดที่ {self._site_slot_number()} ยังไม่ได้เปิดใช้งาน")

    # =========================================================================
    # MAP INTERACTION DISPATCHER
    # =========================================================================
    def current_mode(self) -> str:
        """Returns 'ZONE' for risk areas tab, or 'SITE' for evacuation/parking sites tab."""
        return "SITE" if self.tab_widget.currentIndex() == 1 else "ZONE"

    def set_coordinates_from_map(self, lat: float, lng: float):
        """Dispatches map click to currently selected tab and slot."""
        if self.current_mode() == "SITE":
            self.spin_site_lat.setValue(lat)
            self.spin_site_lng.setValue(lng)
            self.chk_site_active.setChecked(True)
            slot = self._site_slot_number()
            site_type = self.selected_site_type()
            label = "ศูนย์อพยพ" if site_type == "SHELTER" else ("ที่จอดรถ" if site_type == "PARKING" else "ศูนย์ช่วยเหลือ")
            self.lbl_site_status_details.setText(
                f"เลือกพิกัดจุดที่ {slot} ({label}) แล้ว: {lat:.5f}, {lng:.5f} • กด “บันทึกจุดนี้” เพื่อส่งข้อมูล"
            )
        else:
            self.spin_lat.setValue(lat)
            self.spin_lng.setValue(lng)
            self.chk_risk.setChecked(True)
            self.lbl_active_details.setText(
                f"เลือกพิกัดจุดที่ {self._slot_number()} แล้ว: {lat:.5f}, {lng:.5f} • กดบันทึกจุดนี้เพื่อเปิดพื้นที่เสี่ยง"
            )
