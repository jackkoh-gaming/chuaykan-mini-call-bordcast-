package com.rescue.alert.model

import android.content.Context
import com.rescue.alert.engine.GeoFilterEngine
import com.rescue.alert.source.area.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Manages the disaster alert state across the app.
 * In normal situations, isDisasterActive is false.
 * When a critical disaster alert is triggered, it becomes true.
 * The SOS voice button is shown ONLY if the device is in the disaster risk area.
 */
object DisasterStateManager {
    private const val PREFS_NAME = "disaster_state_prefs"
    private const val KEY_IS_ACTIVE = "is_disaster_active"
    private const val KEY_TITLE = "disaster_title"
    private const val KEY_INSTRUCTION = "disaster_instruction"
    private const val KEY_ALERT_ID = "disaster_alert_id"
    private const val KEY_TRIGGERED_AT = "disaster_triggered_at"
    private const val KEY_EXPIRES_AT = "disaster_expires_at"
    private const val KEY_CENTER_LAT = "disaster_center_lat"
    private const val KEY_CENTER_LNG = "disaster_center_lng"
    private const val KEY_RADIUS_KM = "disaster_radius_km"
    private const val KEY_POLYGON = "disaster_polygon"
    private const val KEY_TARGET_PROVINCES = "disaster_target_provinces"
    private const val KEY_TARGET_AREAS = "disaster_target_areas"
    private const val KEY_AREA_DESC = "disaster_area_desc"

    // Lifeline active window: Extended to 72 hours for multi-day crisis survival (HIGH-2)
    private const val MAX_ACTIVE_WINDOW_MS = 72 * 60 * 60 * 1000L // 72 hours safety cutoff

    fun isDisasterActive(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isActive = prefs.getBoolean(KEY_IS_ACTIVE, false)
        if (!isActive) return false

        val now = System.currentTimeMillis()
        val triggeredAt = prefs.getLong(KEY_TRIGGERED_AT, 0L)
        val expiresAt = prefs.getLong(KEY_EXPIRES_AT, 0L)

        if (expiresAt > 0L && now > expiresAt) {
            setDisasterResolved(context)
            return false
        }

        // Auto-resolve only when the 72-hour emergency window expires without new alerts
        if (triggeredAt == 0L || (now - triggeredAt) > MAX_ACTIVE_WINDOW_MS) {
            setDisasterResolved(context)
            return false
        }
        return true
    }

    /**
     * Checks if the device's coordinates are inside the active disaster's risk area.
     */
    fun isDeviceInRiskArea(context: Context, deviceLat: Double, deviceLng: Double): Boolean {
        if (!isDisasterActive(context)) return false

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val officialAreas = prefs.getString(KEY_TARGET_AREAS, null)
        if (officialAreas != null) {
            val device = AreaLocation.cached(context) ?: return false
            return try {
                val rows = JSONArray(officialAreas)
                (0 until rows.length()).any { i ->
                    val row = rows.getJSONObject(i)
                    AreaAlertPolicy.matches(AlertArea(row.getString("level"), row.getString("province"),
                        row.getString("district"), row.getString("subdistrict")), device)
                }
            } catch (_: Exception) { false }
        }
        // Do not revive official state accepted by the old nationwide bypass.
        if (prefs.getString(KEY_ALERT_ID, "").orEmpty().startsWith("DPM_")) return false

        // 1. Circle Geofence Check
        val centerLat = if (prefs.contains(KEY_CENTER_LAT)) prefs.getString(KEY_CENTER_LAT, null)?.toDoubleOrNull() else null
        val centerLng = if (prefs.contains(KEY_CENTER_LNG)) prefs.getString(KEY_CENTER_LNG, null)?.toDoubleOrNull() else null
        val radiusKm = if (prefs.contains(KEY_RADIUS_KM)) prefs.getString(KEY_RADIUS_KM, null)?.toDoubleOrNull() else null

        if (centerLat != null && centerLng != null && radiusKm != null && radiusKm > 0) {
            return GeoFilterEngine.isInsideCircle(deviceLat, deviceLng, centerLat, centerLng, radiusKm)
        }

        // 2. Polygon Geofence Check
        val polygonStr = prefs.getString(KEY_POLYGON, null)
        if (!polygonStr.isNullOrBlank()) {
            val points = polygonStr.split(";").mapNotNull {
                val parts = it.split(",")
                if (parts.size == 2) {
                    val lat = parts[0].toDoubleOrNull()
                    val lng = parts[1].toDoubleOrNull()
                    if (lat != null && lng != null) Point(lat, lng) else null
                } else null
            }
            if (points.isNotEmpty()) {
                return GeoFilterEngine.isInsidePolygon(deviceLat, deviceLng, points)
            }
        }

        // 3. Target Province Check (Fast offline centroid matching to avoid blocking main thread)
        val userProvince = com.rescue.alert.data.ProvinceEmergencyHotlinesRepository.detectProvince(
            deviceLat, deviceLng, null
        )

        val targetProvinces = prefs.getString(KEY_TARGET_PROVINCES, null)
        if (!targetProvinces.isNullOrBlank()) {
            val provList = targetProvinces.split(",").map { it.trim() }
            return provList.any { it.isNotBlank() && (it.contains(userProvince) || userProvince.contains(it)) }
        }

        // 4. Area description or Alert text parsing fallback
        val areaDesc = prefs.getString(KEY_AREA_DESC, "").orEmpty()
        val instruction = prefs.getString(KEY_INSTRUCTION, "").orEmpty()
        val title = prefs.getString(KEY_TITLE, "").orEmpty()
        val combinedText = "$areaDesc $instruction $title"

        val allProvinces = com.rescue.alert.data.ProvinceEmergencyHotlinesRepository.getAllProvinces()
        val matchedProvinces = allProvinces.filter { combinedText.contains(it) }
        if (matchedProvinces.isNotEmpty()) {
            return matchedProvinces.contains(userProvince)
        }

        // Fallback: If no geographic area was specified, only show if nationwide critical was active
        return false
    }

    fun setDisasterActive(
        context: Context,
        alertId: String,
        title: String,
        instruction: String,
        expiresAt: Long = 0L,
        centerLat: Double? = null,
        centerLng: Double? = null,
        radiusKm: Double? = null,
        polygonStr: String? = null,
        targetProvinces: String? = null,
        areaDesc: String? = null,
        targetAreas: List<AlertArea>? = null
    ) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putBoolean(KEY_IS_ACTIVE, true)
            .putString(KEY_ALERT_ID, alertId)
            .putString(KEY_TITLE, title)
            .putString(KEY_INSTRUCTION, instruction)
            .putLong(KEY_TRIGGERED_AT, System.currentTimeMillis())
            .putLong(KEY_EXPIRES_AT, expiresAt)

        if (centerLat != null) editor.putString(KEY_CENTER_LAT, centerLat.toString()) else editor.remove(KEY_CENTER_LAT)
        if (centerLng != null) editor.putString(KEY_CENTER_LNG, centerLng.toString()) else editor.remove(KEY_CENTER_LNG)
        if (radiusKm != null) editor.putString(KEY_RADIUS_KM, radiusKm.toString()) else editor.remove(KEY_RADIUS_KM)
        if (polygonStr != null) editor.putString(KEY_POLYGON, polygonStr) else editor.remove(KEY_POLYGON)
        if (targetProvinces != null) editor.putString(KEY_TARGET_PROVINCES, targetProvinces) else editor.remove(KEY_TARGET_PROVINCES)
        if (areaDesc != null) editor.putString(KEY_AREA_DESC, areaDesc) else editor.remove(KEY_AREA_DESC)

        if (targetAreas != null) {
            val rows = JSONArray()
            targetAreas.forEach { rows.put(JSONObject().put("level", it.level).put("province", it.province)
                .put("district", it.district).put("subdistrict", it.subdistrict)) }
            editor.putString(KEY_TARGET_AREAS, rows.toString())
        } else editor.remove(KEY_TARGET_AREAS)
        editor.apply()
    }

    fun setDisasterResolved(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_ACTIVE, false)
            .remove(KEY_ALERT_ID)
            .remove(KEY_TITLE)
            .remove(KEY_INSTRUCTION)
            .remove(KEY_TRIGGERED_AT)
            .remove(KEY_EXPIRES_AT)
            .remove(KEY_CENTER_LAT)
            .remove(KEY_CENTER_LNG)
            .remove(KEY_RADIUS_KM)
            .remove(KEY_POLYGON)
            .remove(KEY_TARGET_PROVINCES)
            .remove(KEY_TARGET_AREAS)
            .remove(KEY_AREA_DESC)
            .apply()
    }

    fun getDisasterInstruction(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_INSTRUCTION, "ตรวจพบสถานการณ์ภัยพิบัติในพื้นที่ แตะเพื่อบันทึกข้อความเสียงส่งให้เจ้าหน้าที่พร้อมพิกัด")
            ?: "ตรวจพบสถานการณ์ภัยพิบัติในพื้นที่ แตะเพื่อบันทึกข้อความเสียงส่งให้เจ้าหน้าที่พร้อมพิกัด"
    }

    fun getDisasterTitle(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_TITLE, "ตรวจพบสถานการณ์ภัยพิบัติในพื้นที่")
            ?: "ตรวจพบสถานการณ์ภัยพิบัติในพื้นที่"
    }

    fun getAlertId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ALERT_ID, "ACTIVE_DISASTER_SOS") ?: "ACTIVE_DISASTER_SOS"
    }
}
