"""Local disclosures and an inspectable export without operational/personnel data."""
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget,
                              QTextBrowser, QPushButton, QFileDialog, QMessageBox)

ROOT = Path(__file__).resolve().parents[2]
DOCUMENT = ROOT / 'docs/TERMS_PRIVACY_TRANSPARENCY_TH.md'
SCAN = ROOT / 'docs/SECURITY_SCAN.json'


def snapshot():
    paths = [ROOT / 'main.py', DOCUMENT]
    paths += sorted((ROOT / 'src').rglob('*.py'))
    paths += sorted((ROOT / 'assets/icons').glob('*.svg'))
    paths += [ROOT / 'assets/icons/disaster_icon.png', ROOT / 'assets/ringtone.wav']
    paths += [ROOT / 'assets/web' / name for name in
              ('map.html', 'leaflet.js', 'leaflet.css', 'thailand.json')]
    files = {}
    for path in paths:
        relative = path.relative_to(ROOT).as_posix()
        if path.is_symlink() or path.resolve() != ROOT.resolve() / relative:
            raise ValueError('ไม่ส่งออกไฟล์เชื่อมโยง: ' + relative)
        if re.search(r'(?i)(secret|credential|service.?account|private.?key|\.env)', relative):
            raise ValueError('พบชื่อไฟล์ที่อาจมีข้อมูลลับ: ' + relative)
        content = path.read_bytes()
        if (b'PRIVATE' + b' KEY' + b'-----') in content or re.search(rb'"private_key"\s*:\s*"', content):
            raise ValueError('พบรูปแบบกุญแจลับ ไม่สามารถส่งออกได้: ' + relative)
        files[relative] = content
    return files


def hashes(files):
    return {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}


def scan_state(files):
    if not SCAN.exists():
        return {'status': 'UNVERIFIED', 'message': 'ยังไม่มีผลสแกนไวรัส'}, None
    report = json.loads(SCAN.read_text(encoding='utf-8'))
    current = hashes(files)
    matches = current == report.get('file_sha256')
    clean = report.get('exit_code') == 0 and report.get('infected_files') == 0
    message = ('ClamAV ไม่พบไวรัสในไฟล์ที่สแกน และแฮชตรงกับไฟล์ปัจจุบัน'
               if matches and clean else
               'ไฟล์ปัจจุบันเปลี่ยนจากชุดที่สแกน ต้องสแกนใหม่' if not matches else
               'ผลสแกนไม่ยืนยันว่าปลอดภัย กรุณาตรวจรายละเอียด')
    return {'status': 'MATCH' if matches else 'CHANGED', 'message': message,
            'clean_scan': clean, 'checked_at': report.get('checked_at'),
            'scanner': report.get('scanner'), 'summary': report.get('summary'),
            'limitations': report.get('limitations', []),
            'scope': 'เฉพาะไฟล์ในชุดตรวจสอบ ไม่รวม dependency หรือระบบปฏิบัติการ'}, report


def export_bundle(destination):
    files = snapshot()
    state, report = scan_state(files)
    if report is not None:
        files['SECURITY_SCAN.json'] = json.dumps(report, ensure_ascii=False, indent=2).encode()
    manifest = {'exported_at': datetime.now(timezone.utc).isoformat(), 'scan_state': state,
                'excluded': ['case databases', 'recordings', 'credentials', 'environment files',
                             'private keys', 'installed dependencies'],
                'file_sha256': hashes(files)}
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            archive.writestr(name, content)
        archive.writestr('MANIFEST_SHA256.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    return manifest


class TransparencyDialog(QDialog):
    def __init__(self, parent=None, require_acceptance=False):
        super().__init__(parent)
        self.setWindowTitle('ข้อตกลง • ข้อมูลส่วนบุคคล • ความโปร่งใส')
        self.resize(920, 700)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        self.document_view = QTextBrowser()
        self.document_view.setOpenExternalLinks(True)
        self.document_view.setMarkdown(DOCUMENT.read_text(encoding='utf-8'))
        tabs.addTab(self.document_view, 'ข้อตกลงและข้อมูลส่วนบุคคล')
        self.audit_view = QTextBrowser()
        try:
            files = snapshot()
            state, _ = scan_state(files)
            self.audit_view.setPlainText(state['message'] + '\n\n' +
                'SHA-256 ตรวจความตรงกันของไฟล์ ไม่ใช่การรับรองว่าปลอดไวรัส 100%\n\n' +
                json.dumps({'scan': state, 'file_sha256': hashes(files)}, ensure_ascii=False, indent=2))
        except (OSError, ValueError, KeyError) as error:
            self.audit_view.setPlainText('ยังยืนยันผลตรวจไม่ได้: ' + str(error))
        tabs.addTab(self.audit_view, 'ผลตรวจและไฟล์')
        layout.addWidget(tabs)
        buttons = QHBoxLayout()
        actions = [('บันทึกเอกสาร (.md)', self.save_document),
                   ('ดาวน์โหลดชุดตรวจสอบ (.zip)', self.save_bundle)]
        if require_acceptance:
            actions += [('ไม่ยอมรับ / ออกจากแอป', self.reject),
                        ('ยอมรับและเข้าใช้งาน', self.accept)]
        else:
            actions += [('ปิด', self.accept)]
        for label, callback in actions:
            button = QPushButton(label)
            button.clicked.connect(callback)
            buttons.addWidget(button)
        layout.addLayout(buttons)

    def save_document(self):
        path, _ = QFileDialog.getSaveFileName(self, 'บันทึกเอกสาร',
                    'TERMS_PRIVACY_TRANSPARENCY_TH.md', 'Markdown (*.md)')
        if not path:
            return
        try:
            Path(path).write_bytes(DOCUMENT.read_bytes())
            QMessageBox.information(self, 'บันทึกสำเร็จ', 'บันทึกเอกสารแล้ว')
        except OSError as error:
            QMessageBox.warning(self, 'บันทึกไม่สำเร็จ', str(error))

    def save_bundle(self):
        path, _ = QFileDialog.getSaveFileName(self, 'บันทึกชุดตรวจสอบ',
                    'ThaiDisasterMonitor-Transparency.zip', 'ZIP (*.zip)')
        if not path:
            return
        try:
            export_bundle(path)
            QMessageBox.information(self, 'บันทึกสำเร็จ',
                'บันทึกชุดตรวจสอบแล้ว มีเอกสาร โค้ด ผลตรวจ และ SHA-256\nไม่รวมข้อมูลผู้ประสบภัยหรือกุญแจลับ')
        except (OSError, ValueError, KeyError) as error:
            QMessageBox.warning(self, 'บันทึกไม่สำเร็จ', str(error))
