package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.widget.*
import com.rescue.alert.R
import com.rescue.alert.bluetooth.BluetoothMeshManager
import com.rescue.alert.model.MeshNode
import com.rescue.alert.model.MeshNodeType
import androidx.core.view.ViewCompat

/**
 * Controller for Bluetooth Mesh Voice & Calling dialog.
 * Enables offline peer-to-peer walkie-talkie and multi-hop relay between houses.
 */
class BluetoothMeshCallDialog(private val context: Context) {

    companion object {
        private var activeDialogInstance: Dialog? = null

        fun isShowing(): Boolean = activeDialogInstance?.isShowing == true

        fun dismissActive() {
            try {
                if (activeDialogInstance?.isShowing == true) {
                    activeDialogInstance?.dismiss()
                }
            } catch (e: Exception) {}
            activeDialogInstance = null
        }
    }

    private val dialog: Dialog = Dialog(context)
    private val meshManager = BluetoothMeshManager.getInstance(context)
    private var vibrator: Vibrator? = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    private fun styleCallButton(button: Button, hangup: Boolean = false, isEoc: Boolean = false) {
        val (normal, pressed) = when {
            hangup -> "#B91C1C" to "#991B1B"
            isEoc -> "#1D4ED8" to "#1E40AF"
            else -> "#047857" to "#065F46"
        }
        ViewCompat.setBackgroundTintList(button, ColorStateList(
            arrayOf(
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf(android.R.attr.state_pressed),
                intArrayOf()
            ),
            intArrayOf(Color.parseColor("#475569"), Color.parseColor(pressed), Color.parseColor(normal))
        ))
        button.setTextColor(Color.WHITE)
        androidx.core.widget.TextViewCompat.setCompoundDrawableTintList(button, ColorStateList.valueOf(Color.WHITE))
    }

    fun show() {
        if (isShowing()) {
            return
        }
        val activity = context as? android.app.Activity
        if (activity != null && (activity.isFinishing || activity.isDestroyed)) {
            return
        }
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_bt_mesh_call, null)
        dialog.setContentView(dialogView)
        dialog.setCanceledOnTouchOutside(false)

        // View bindings
        val btnTabPtt = dialogView.findViewById<Button>(R.id.btnTabPtt)
        val btnTabTopology = dialogView.findViewById<Button>(R.id.btnTabTopology)
        val layoutTabPtt = dialogView.findViewById<LinearLayout>(R.id.layoutTabPttContent)
        val layoutTabTopology = dialogView.findViewById<LinearLayout>(R.id.layoutTabTopologyContent)

        val tvMeshStatusHeader = dialogView.findViewById<TextView>(R.id.tvMeshStatusHeader)
        val tvMeshRelayRouteDesc = dialogView.findViewById<TextView>(R.id.tvMeshRelayRouteDesc)
        val spnTargetPeer = dialogView.findViewById<Spinner>(R.id.spnTargetPeer)
        val pbAudioLevel = dialogView.findViewById<ProgressBar>(R.id.pbAudioLevel)
        val btnDirectCall = dialogView.findViewById<Button>(R.id.btnDirectCall)
        val tvMeshLogConsole = dialogView.findViewById<TextView>(R.id.tvMeshLogConsole)

        val layoutMeshNodeList = dialogView.findViewById<LinearLayout>(R.id.layoutMeshNodeList)
        val btnScanBleNodes = dialogView.findViewById<Button>(R.id.btnScanBleNodes)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseBtMeshDialog)
        styleCallButton(btnDirectCall)

        // Switch Tabs
        fun switchTab(tabIndex: Int) {
            if (tabIndex == 0) {
                layoutTabPtt.visibility = View.VISIBLE
                layoutTabTopology.visibility = View.GONE

                btnTabPtt.setBackgroundResource(R.drawable.bg_legal_tab_active)
                btnTabPtt.setTextColor(Color.WHITE)

                btnTabTopology.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                btnTabTopology.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            } else {
                layoutTabPtt.visibility = View.GONE
                layoutTabTopology.visibility = View.VISIBLE

                btnTabPtt.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                btnTabPtt.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))

                btnTabTopology.setBackgroundResource(R.drawable.bg_legal_tab_active)
                btnTabTopology.setTextColor(Color.WHITE)
            }
        }

        btnTabPtt.setOnClickListener { switchTab(0) }
        btnTabTopology.setOnClickListener { switchTab(1) }

        var currentNodes: List<MeshNode> = meshManager.getNodes()

        fun refreshNodesAndSpinner(nodes: List<MeshNode>) {
            // 1. Sort: Pin EOC Gateway (RESCUE_POST) to the top, then sort neighbors by proximity
            val sortedNodes = nodes.sortedWith(
                compareByDescending<MeshNode> {
                    it.nodeType == MeshNodeType.RESCUE_POST ||
                    it.nodeId == "EOC_GATEWAY_HQ" ||
                    it.houseName.contains("EOC", ignoreCase = true)
                }.thenBy { it.distanceMeters }
            )
            currentNodes = sortedNodes

            // 2. Dynamic Status Header & Relay Route Telemetry via MeshTelemetryHelper (F-14)
            val (headerText, headerColor) = com.rescue.alert.bluetooth.MeshTelemetryHelper.formatStatusHeader(sortedNodes)
            tvMeshStatusHeader.text = if (meshManager.isCallConnecting()) {
                when (val position = meshManager.getCallQueuePosition()) {
                    null -> "กำลังรอเจ้าหน้าที่รับสาย"
                    0 -> "ถึงคิวแล้ว • รอเจ้าหน้าที่รับสาย"
                    else -> "กำลังรอคิวที่ $position"
                }
            } else headerText
            tvMeshStatusHeader.setTextColor(com.rescue.alert.util.ThemePalette.color(headerColor))

            val hasEocGateway = sortedNodes.any {
                it.nodeType == MeshNodeType.RESCUE_POST ||
                it.nodeId == "EOC_GATEWAY_HQ" ||
                it.houseName.contains("EOC", ignoreCase = true)
            }
            if (hasEocGateway) {
                tvMeshRelayRouteDesc.text = "เส้นทาง: เครื่องของคุณ -> ศูนย์สั่งการ EOC Gateway (ช่องสัญญาณตรง RFCOMM ช่อง 4 / GATT)"
                tvMeshRelayRouteDesc.setTextColor(com.rescue.alert.util.ThemePalette.color("#BAE6FD"))
            } else if (sortedNodes.isNotEmpty()) {
                tvMeshRelayRouteDesc.text = "เส้นทางส่งต่อ: เครื่องของคุณ -> อุปกรณ์เพื่อนบ้าน ${sortedNodes.size} เครื่อง (บลูทูธ P2P ตรง)"
                tvMeshRelayRouteDesc.setTextColor(com.rescue.alert.util.ThemePalette.color("#E2E8F0"))
            } else {
                tvMeshRelayRouteDesc.text = "ยังไม่พบอุปกรณ์เพื่อนบ้านหรือศูนย์สั่งการ EOC ในระยะบลูทูธ"
                tvMeshRelayRouteDesc.setTextColor(com.rescue.alert.util.ThemePalette.color("#64748B"))
            }

            // 3. Populate Target Dropdown with Pinned EOC Gateway
            val targetOptions = mutableListOf<String>()
            targetOptions.add("ทุกอุปกรณ์ในระยะบลูทูธ (BROADCAST ALL)")
            if (sortedNodes.isEmpty()) {
                targetOptions.add("(ยังไม่พบอุปกรณ์เพื่อนบ้าน - กำลังสแกน)")
            } else {
                sortedNodes.forEach { node ->
                    val hopDesc = if (node.hopCount == 1) "1 Hop ตรง" else "${node.hopCount} Hops รีเลย์"
                    val isEoc = node.nodeType == MeshNodeType.RESCUE_POST ||
                                node.nodeId == "EOC_GATEWAY_HQ" ||
                                node.houseName.contains("EOC", ignoreCase = true)
                    if (isEoc) {
                        targetOptions.add("[ศูนย์สั่งการ EOC] ${node.houseName} (~${node.distanceMeters} ม. / 1 Hop ตรง)")
                    } else {
                        targetOptions.add("${node.houseName} (~${node.distanceMeters} ม. / $hopDesc)")
                    }
                }
            }

            val spinnerAdapter = ArrayAdapter(
                context,
                android.R.layout.simple_spinner_dropdown_item,
                targetOptions
            )
            spnTargetPeer.adapter = spinnerAdapter

            // 4. Populate Topology Nodes List in Tab 2
            layoutMeshNodeList.removeAllViews()

            // 1. Add Self Node Card
            val selfCard = inflater.inflate(R.layout.item_mesh_node, layoutMeshNodeList, false)
            selfCard.findViewById<TextView>(R.id.tvNodeHouseName).text = meshManager.myHouseName
            selfCard.findViewById<TextView>(R.id.tvNodeHopBadge).apply {
                text = "เครื่องของคุณ"
                setTextColor(Color.WHITE)
                setBackgroundResource(R.drawable.bg_legal_tab_active)
            }
            selfCard.findViewById<TextView>(R.id.tvNodeDistanceRssi).text = "ตำแหน่ง: โหนดส่ง/รับสัญญาณตรง • สถานะ: ออนไลน์สแตนด์บาย"
            selfCard.findViewById<TextView>(R.id.tvNodeRelayPath).text = "ทำหน้าที่เป็นตัวส่งสัญญาณเสียงและสถานีรีเลย์ในเวลาเดียวกัน"
            selfCard.findViewById<Button>(R.id.btnNodeCallAction).visibility = View.GONE
            selfCard.setBackgroundResource(R.drawable.bg_bt_mesh_node_self)
            layoutMeshNodeList.addView(selfCard)

            // 2. Empty or Live Discovered Nodes
            if (sortedNodes.isEmpty()) {
                val emptyCard = TextView(context).apply {
                    text = "ยังไม่พบอุปกรณ์เพื่อนบ้านที่เปิดแอพในระยะบลูทูธ (10-30 ม.)\nกดปุ่ม 'สแกนบลูทูธรอบตัว' ด้านล่างเพื่อค้นหาและเชื่อมต่อโหนดจริง"
                    textSize = 13f
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                    gravity = android.view.Gravity.CENTER
                    setPadding(24, 48, 24, 48)
                }
                layoutMeshNodeList.addView(emptyCard)
            } else {
                sortedNodes.forEach { node ->
                    val nodeCard = inflater.inflate(R.layout.item_mesh_node, layoutMeshNodeList, false)
                    val ivNodeIcon = nodeCard.findViewById<ImageView>(R.id.ivNodeIcon)
                    val tvHouseName = nodeCard.findViewById<TextView>(R.id.tvNodeHouseName)
                    val tvHopBadge = nodeCard.findViewById<TextView>(R.id.tvNodeHopBadge)
                    val tvDistanceRssi = nodeCard.findViewById<TextView>(R.id.tvNodeDistanceRssi)
                    val tvRelayPath = nodeCard.findViewById<TextView>(R.id.tvNodeRelayPath)
                    val btnCall = nodeCard.findViewById<Button>(R.id.btnNodeCallAction)

                    tvHouseName.text = node.houseName

                    val isEoc = node.nodeType == MeshNodeType.RESCUE_POST ||
                                node.nodeId == "EOC_GATEWAY_HQ" ||
                                node.houseName.contains("EOC", ignoreCase = true)

                    if (isEoc) {
                        tvHopBadge.text = "ศูนย์สั่งการหลัก (EOC HQ)"
                        tvHopBadge.setTextColor(Color.WHITE)
                        tvHopBadge.setBackgroundResource(R.drawable.bg_legal_tab_active)
                        tvHopBadge.setPadding(12, 4, 12, 4)

                        ivNodeIcon.setColorFilter(com.rescue.alert.util.ThemePalette.color("#38BDF8"))

                        tvDistanceRssi.text = "ระยะห่าง: ~${node.distanceMeters} ม. • สัญญาณ: ${node.rssi} dBm • โหนดหลัก EOC"
                        tvRelayPath.text = "เส้นทาง: ลิงก์ตรง RFCOMM ช่อง 4 / GATT P2P แม่ข่ายกู้ภัย"
                        tvRelayPath.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))

                        nodeCard.setBackgroundResource(R.drawable.bg_bt_mesh_node_self)

                        btnCall.text = "โทร EOC"
                        btnCall.setBackgroundResource(R.drawable.bg_tactical_rect_btn_blue)
                        styleCallButton(btnCall, isEoc = true)
                    } else {
                        val hopText = if (node.hopCount == 1) "1 HOP (ตรง)" else "${node.hopCount} HOPS (รีเลย์)"
                        val hopColor = if (node.hopCount == 1) "#34D399" else "#F59E0B"
                        tvHopBadge.text = hopText
                        tvHopBadge.setTextColor(com.rescue.alert.util.ThemePalette.color(hopColor))
                        tvHopBadge.setBackgroundResource(R.drawable.bg_bt_mesh_badge_hop)
                        tvHopBadge.setPadding(8, 2, 8, 2)

                        ivNodeIcon.setColorFilter(com.rescue.alert.util.ThemePalette.color("#34D399"))

                        tvDistanceRssi.text = "ระยะห่าง: ~${node.distanceMeters} ม. • สัญญาณ: ${node.rssi} dBm • ที่อยู่: ${node.deviceAddress}"
                        tvRelayPath.text = if (node.hopCount == 1) {
                            "เส้นทาง: สัญญาณบลูทูธ P2P ตรง (Verified App Node)"
                        } else {
                            "เส้นทาง: ส่งต่อผ่าน ${node.relayVia ?: "โหนดรีเลย์"}"
                        }
                        tvRelayPath.setTextColor(com.rescue.alert.util.ThemePalette.color(hopColor))

                        nodeCard.setBackgroundResource(
                            if (node.hopCount == 1) R.drawable.bg_bt_mesh_node_neighbor else R.drawable.bg_bt_mesh_node_relay
                        )

                        btnCall.text = "โทร"
                        btnCall.setBackgroundResource(R.drawable.bg_legal_btn_verify_rect)
                        styleCallButton(btnCall)
                    }

                    btnCall.setOnClickListener {
                        switchTab(0)
                        spnTargetPeer.setSelection(currentNodes.indexOf(node) + 1)
                        meshManager.startDirectCall(node)
                        btnDirectCall.text = "วางสาย (HANG UP)"
                        btnDirectCall.setBackgroundResource(R.drawable.bg_legal_card_danger_rect)
                        styleCallButton(btnDirectCall, hangup = true)
                    }

                    layoutMeshNodeList.addView(nodeCard)
                }
            }
        }

        refreshNodesAndSpinner(currentNodes)

        // Helper to append logs
        fun appendLog(msg: String) {
            val prev = tvMeshLogConsole.text.toString()
            val lines = prev.split("\n").filter { it.isNotBlank() }.takeLast(4)
            val updated = (lines + "• $msg").joinToString("\n")
            tvMeshLogConsole.text = updated
        }

        // Sync initial in-call state
        if (meshManager.isInCall()) {
            btnDirectCall.text = "วางสาย (HANG UP)"
            btnDirectCall.setBackgroundResource(R.drawable.bg_legal_card_danger_rect)
            styleCallButton(btnDirectCall, hangup = true)
            val activeNode = meshManager.getActiveCallNode()
            val callerTitle = activeNode?.houseName ?: meshManager.getIncomingCallerName().ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
            tvMeshStatusHeader.text = if (meshManager.isCallConnecting()) meshManager.getCallQueuePosition()?.let { "กำลังรอคิวที่ $it" } ?: "กำลังรอรับสาย" else "กำลังสนทนา"
            appendLog(if (meshManager.isCallConnecting()) "กำลังรอ $callerTitle รับสาย" else "[สายตรง] กำลังสนทนาสายตรงกับ $callerTitle")
        }

        // Setup Callbacks with Chaining to prevent dropping MainActivity's listener
        val previousNodeListener = meshManager.onMeshNodesUpdated
        meshManager.onMeshNodesUpdated = { updatedList ->
            refreshNodesAndSpinner(updatedList)
            previousNodeListener?.invoke(updatedList)
        }

        val previousCallStateListener = meshManager.onCallStateChanged
        meshManager.onCallStateChanged = { inCall, callerName, callerId ->
            if (inCall) {
                btnDirectCall.text = "วางสาย (HANG UP)"
                btnDirectCall.setBackgroundResource(R.drawable.bg_legal_card_danger_rect)
                styleCallButton(btnDirectCall, hangup = true)
                appendLog(if (meshManager.isCallConnecting()) "กำลังรอ $callerName รับสาย" else "[สายตรง] เริ่มการสนทนากับ $callerName")
            } else {
                btnDirectCall.text = "โทรเชื่อมสายตรง (โทรออก)"
                btnDirectCall.setBackgroundResource(R.drawable.bg_legal_btn_verify_rect)
                styleCallButton(btnDirectCall)
                tvMeshStatusHeader.text = "พร้อมรับ/ส่งสัญญาณ"
                appendLog("[วางสาย] สิ้นสุดการสนทนาแล้ว")
            }
            previousCallStateListener?.invoke(inCall, callerName, callerId)
        }

        // BUG-13 FIX: Save previous listeners before overriding
        val previousLogListener = meshManager.onMeshLogMessage
        val previousAudioLevelListener = meshManager.onAudioLevelChanged
        val previousTransmissionListener = meshManager.onTransmissionStateChanged
        val previousVoiceListener = meshManager.onIncomingVoiceReceived

        meshManager.onMeshLogMessage = { logMsg ->
            appendLog(logMsg)
        }

        meshManager.onAudioLevelChanged = { level ->
            pbAudioLevel.progress = level
        }

        meshManager.onTransmissionStateChanged = { isTx, status ->
            if (!isTx) {
                pbAudioLevel.progress = 0
            }
            if (meshManager.isCallConnecting()) {
                tvMeshStatusHeader.text = status
            }
        }

        meshManager.onIncomingVoiceReceived = { sourceName, hopCount, isSos ->
            if (isSos) {
                appendLog("[ฉุกเฉิน SOS] รับเสียงจาก $sourceName ($hopCount Hops)")
            }
        }

        // Direct Call Button (Single Action Control)
        var lastDirectCallClickTime = 0L
        btnDirectCall.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastDirectCallClickTime < 1200L) return@setOnClickListener
            lastDirectCallClickTime = now

            if (meshManager.isInCall()) {
                meshManager.hangupCurrentCall()
                btnDirectCall.text = "โทรเชื่อมสายตรง (โทรออก)"
                btnDirectCall.setBackgroundResource(R.drawable.bg_legal_btn_verify_rect)
                styleCallButton(btnDirectCall)
            } else {
                if (currentNodes.isNotEmpty()) {
                    val selIndex = spnTargetPeer.selectedItemPosition
                    val targetNode = if (selIndex > 0 && selIndex <= currentNodes.size) currentNodes[selIndex - 1] else currentNodes[0]
                    meshManager.startDirectCall(targetNode)
                    btnDirectCall.text = "วางสาย (HANG UP)"
                    btnDirectCall.setBackgroundResource(R.drawable.bg_legal_card_danger_rect)
                    styleCallButton(btnDirectCall, hangup = true)
                } else {
                    Toast.makeText(context, "ยังไม่พบอุปกรณ์เพื่อนบ้านในระยะ กรุณากดสแกนบลูทูธ", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Scan BLE Nodes Button in Tab 2
        btnScanBleNodes.setOnClickListener {
            meshManager.startBleMeshScan()
            appendLog("เปิดสแกนเนอร์บลูทูธเมช ค้นหาอุปกรณ์รอบตัว...")
            Toast.makeText(context, "กำลังค้นหาอุปกรณ์บลูทูธใกล้เคียง...", Toast.LENGTH_SHORT).show()
        }

        // Close Button
        btnClose.setOnClickListener {
            // Closing this panel keeps the foreground call running.
            if (!meshManager.isInCall() && meshManager.isTransmitting()) {
                meshManager.stopPttTransmission()
            }
            dialog.dismiss()
        }

        dialog.setOnDismissListener {
            activeDialogInstance = null
            // BUG-13 FIX: Restore ALL overridden listeners, not just 2
            meshManager.onMeshNodesUpdated = previousNodeListener
            meshManager.onCallStateChanged = previousCallStateListener
            meshManager.onMeshLogMessage = previousLogListener
            meshManager.onAudioLevelChanged = previousAudioLevelListener
            meshManager.onTransmissionStateChanged = previousTransmissionListener
            meshManager.onIncomingVoiceReceived = previousVoiceListener
            previousNodeListener?.invoke(meshManager.getNodes())

            if (!meshManager.isInCall() && meshManager.isTransmitting()) {
                meshManager.stopPttTransmission()
            }
        }

        activeDialogInstance = dialog
        dialog.show()
    }
}
