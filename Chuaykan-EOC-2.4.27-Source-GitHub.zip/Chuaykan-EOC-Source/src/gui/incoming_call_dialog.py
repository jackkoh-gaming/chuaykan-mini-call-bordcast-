#!/usr/bin/env python3
"""
IncomingCallDialog: Visual & Audible Alert Dialog for Incoming Emergency Bluetooth Calls.
Provides prominent ringtone audio playback and a floating tactical alert dialog
BEFORE answering, notifying the operator that someone is calling in.
"""
from __future__ import annotations
import subprocess
import shutil
from typing import Optional

from PySide6.QtCore import Qt, Signal, Slot, QTimer
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QGridLayout, QSizePolicy
)

from src.core.config import RINGTONE_PATH


class IncomingCallDialog(QDialog):
    """
    Tactical EOC Incoming Call Alert Window.
    Played before the operator answers the call.
    Features:
    - Ringtone playback loop (ffplay / aplay)
    - Pulsing visual indicator
    - Large 'Answer Call' and 'Decline' buttons
    """
    call_answered = Signal(str, str)  # caller_name, node_id
    call_declined = Signal(str, str)  # caller_name, node_id

    def __init__(self, caller_name: str, node_id: str, audio_file: Optional[str] = None, parent=None):
        super().__init__(parent)
        self.caller_name = caller_name
        self.node_id = node_id
        self.audio_file = audio_file
        self._ringtone_proc: Optional[subprocess.Popen] = None

        self.setWindowTitle("แจ้งเตือน: มีสายเรียกเข้าฉุกเฉิน")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self.setMinimumSize(560, 360)
        self.resize(560, 360)

        self._init_ui()
        self._start_ringtone()

        # Pulsing banner timer (toggles color to grab attention)
        self._pulse_state = False
        self.pulse_timer = QTimer(self)
        self.pulse_timer.setInterval(600)
        self.pulse_timer.timeout.connect(self._toggle_pulse)
        self.pulse_timer.start()

    def _init_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0F172A;
                border: 2px solid #EF4444;
                border-radius: 12px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # 1. Glowing Header
        self.header_frame = QFrame()
        self.header_frame.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.header_frame.setObjectName("headerFrame")
        self.header_frame.setStyleSheet("""
            QFrame#headerFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #991B1B, stop:1 #B45309);
                border-radius: 8px;
            }
        """)
        hf_layout = QHBoxLayout(self.header_frame)
        hf_layout.setContentsMargins(14, 12, 14, 12)
        hf_layout.setSpacing(10)

        self.lbl_ring_icon = QLabel("[CALL]")
        self.lbl_ring_icon.setFixedSize(68, 40)
        self.lbl_ring_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_ring_icon.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFFFFF; background: #DC2626; border-radius: 4px; padding: 2px 6px;")
        hf_layout.addWidget(self.lbl_ring_icon)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        lbl_head = QLabel("มีสายเรียกเข้าฉุกเฉิน (INCOMING EMERGENCY CALL)")
        lbl_head.setWordWrap(True)
        lbl_head.setStyleSheet("color: rgb(255, 255, 255); font-size: 14px; font-weight: bold; background: transparent;")
        title_box.addWidget(lbl_head)

        self.lbl_ring_status = QLabel("สัญญาณเรียกเข้ากำลังดัง... รอเจ้าหน้าที่รับสาย")
        self.lbl_ring_status.setWordWrap(True)
        self.lbl_ring_status.setStyleSheet("color: #FEF08A; font-size: 11px; font-weight: bold; background: transparent;")
        title_box.addWidget(self.lbl_ring_status)
        hf_layout.addLayout(title_box, 1)

        layout.addWidget(self.header_frame)

        # 2. Caller Details Card
        detail_card = QFrame()
        detail_card.setObjectName("callerDetails")
        detail_card.setStyleSheet("""
            QFrame#callerDetails {
                background-color: #1E293B;
                border: 1px solid #334155;
                border-radius: 8px;
            }
            QLabel { background: transparent; }
        """)
        dc_layout = QGridLayout(detail_card)
        dc_layout.setContentsMargins(16, 14, 16, 14)
        dc_layout.setHorizontalSpacing(12)
        dc_layout.setVerticalSpacing(12)
        dc_layout.setColumnStretch(1, 1)

        lbl_n1 = QLabel("ผู้ติดต่อ / ผู้ประสบภัย:")
        lbl_n1.setStyleSheet("color: #94A3B8; font-size: 12px;")
        self.lbl_name_val = QLabel(self.caller_name)
        self.lbl_name_val.setStyleSheet("color: #38BDF8; font-size: 14px; font-weight: bold;")
        dc_layout.addWidget(lbl_n1, 0, 0)
        dc_layout.addWidget(self.lbl_name_val, 0, 1)

        lbl_i1 = QLabel("รหัสโหนด / อุปกรณ์:")
        lbl_i1.setStyleSheet("color: #94A3B8; font-size: 12px;")
        lbl_id_val = QLabel(self.node_id)
        lbl_id_val.setStyleSheet("font-family: monospace; color: #F59E0B; font-size: 12px; font-weight: bold;")
        dc_layout.addWidget(lbl_i1, 1, 0)
        dc_layout.addWidget(lbl_id_val, 1, 1)

        lbl_net1 = QLabel("ช่องทางสื่อสาร:")
        lbl_net1.setStyleSheet("color: #94A3B8; font-size: 12px;")
        lbl_net_val = QLabel("บลูทูธแมชไร้เสาสัญญาณ (Bluetooth Mesh P2P Direct)")
        lbl_net_val.setStyleSheet("color: #34D399; font-size: 11.5px; font-weight: bold;")
        dc_layout.addWidget(lbl_net1, 2, 0)
        dc_layout.addWidget(lbl_net_val, 2, 1)
        for label in (lbl_n1, lbl_i1, lbl_net1):
            label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        for value in (self.lbl_name_val, lbl_id_val, lbl_net_val):
            value.setTextFormat(Qt.TextFormat.PlainText)
            value.setWordWrap(True)
            value.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            value.setToolTip(value.text())
        # Keep long device identifiers inside the value column; the full ID
        # remains in the tooltip and in the unchanged call signal payload.
        lbl_id_val.setWordWrap(False)
        lbl_id_val.setText(lbl_id_val.fontMetrics().elidedText(
            self.node_id, Qt.TextElideMode.ElideMiddle, 340))

        layout.addWidget(detail_card, 1)

        # 3. Action Buttons Row (Large Answer & Decline)
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)

        self.btn_decline = QPushButton("ตัดสาย / ปฏิเสธ (DECLINE)")
        self.btn_decline.setFixedHeight(46)
        self.btn_decline.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_decline.setStyleSheet("""
            QPushButton {
                background-color: #7F1D1D;
                border: 1.5px solid #EF4444;
                color: #FFFFFF;
                font-size: 13px;
                font-weight: bold;
                border-radius: 8px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #991B1B;
                border-color: #F87171;
            }
        """)
        self.btn_decline.clicked.connect(self._on_decline_clicked)
        btn_row.addWidget(self.btn_decline, 1)

        self.btn_answer = QPushButton("รับสายทันที (ANSWER)")
        self.btn_answer.setFixedHeight(46)
        self.btn_answer.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_answer.setStyleSheet("""
            QPushButton {
                background-color: #047857;
                border: 1.5px solid #34D399;
                color: #FFFFFF;
                font-size: 13px;
                font-weight: bold;
                border-radius: 8px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #059669;
                border-color: #6EE7B7;
            }
        """)
        self.btn_answer.clicked.connect(self._on_answer_clicked)
        btn_row.addWidget(self.btn_answer, 1)

        layout.addLayout(btn_row)

    def _toggle_pulse(self):
        self._pulse_state = not self._pulse_state
        if self._pulse_state:
            self.header_frame.setStyleSheet("""
                QFrame#headerFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #DC2626, stop:1 #D97706);
                    border-radius: 8px;
                }
            """)
            self.lbl_ring_icon.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFFFFF; background: #DC2626; border-radius: 4px; padding: 2px 6px;")
        else:
            self.header_frame.setStyleSheet("""
                QFrame#headerFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #991B1B, stop:1 #B45309);
                    border-radius: 8px;
                }
            """)
            self.lbl_ring_icon.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFFFFF; background: #991B1B; border-radius: 4px; padding: 2px 6px;")

    def _start_ringtone(self):
        """Starts looping ringtone playback if not already playing."""
        if self.parent() and hasattr(self.parent(), "mesh_panel"):
            # MainWindow's mesh_panel handles ringtone playback centrally
            return
        if not RINGTONE_PATH.exists():
            return
        self._stop_ringtone()
        try:
            if shutil.which("ffplay"):
                self._ringtone_proc = subprocess.Popen(
                    ["ffplay", "-nodisp", "-loop", "0", "-loglevel", "quiet", str(RINGTONE_PATH)]
                )
            elif shutil.which("aplay"):
                self._ringtone_proc = subprocess.Popen(
                    ["aplay", "-q", str(RINGTONE_PATH)]
                )
        except Exception:
            pass

    def _stop_ringtone(self):
        """Terminates ringtone playback immediately."""
        if hasattr(self, "_ringtone_proc") and self._ringtone_proc:
            try:
                self._ringtone_proc.terminate()
                self._ringtone_proc.wait(timeout=0.2)
            except Exception:
                try:
                    self._ringtone_proc.kill()
                except Exception:
                    pass
            self._ringtone_proc = None

    def _on_answer_clicked(self):
        self._stop_ringtone()
        if hasattr(self, "pulse_timer") and self.pulse_timer.isActive():
            self.pulse_timer.stop()
        self.call_answered.emit(self.caller_name, self.node_id)
        self.accept()

    def _on_decline_clicked(self):
        self._stop_ringtone()
        if hasattr(self, "pulse_timer") and self.pulse_timer.isActive():
            self.pulse_timer.stop()
        self.call_declined.emit(self.caller_name, self.node_id)
        self.reject()

    def keyPressEvent(self, event):
        """Allow answering with Enter/Space or declining with Escape for rapid response."""
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self._on_answer_clicked()
        elif event.key() == Qt.Key_Escape:
            self._on_decline_clicked()
        else:
            super().keyPressEvent(event)

    def closeEvent(self, event):
        self._stop_ringtone()
        if hasattr(self, "pulse_timer") and self.pulse_timer.isActive():
            self.pulse_timer.stop()
        super().closeEvent(event)
