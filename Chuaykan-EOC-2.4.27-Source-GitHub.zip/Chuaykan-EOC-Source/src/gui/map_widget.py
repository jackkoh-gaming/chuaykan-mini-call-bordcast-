#!/usr/bin/env python3
"""
MapWidget: PySide6 WebEngine wrapper hosting interactive Leaflet tactical map.
Bridges Python Qt signals with in-browser Leaflet layers for real-time mobile pins.
"""
from __future__ import annotations
import json
import logging
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QUrl, Signal, Slot, QObject
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineSettings, QWebEngineProfile, QWebEnginePage
from PySide6.QtWebChannel import QWebChannel

from src.core.config import WEB_DIR
from src.core.models import SosCase, DisasterZone, EvacuationSite

logger = logging.getLogger("thai_disaster_monitor.gui.map_widget")


class MapBridge(QObject):
    """Bridge object exposed to JavaScript window.qtBridge."""
    map_clicked_signal = Signal(float, float)
    dispatch_rescue_signal = Signal(str)
    mark_rescued_signal = Signal(str)
    call_citizen_signal = Signal(str, str)
    adopt_official_area_signal = Signal(float, float, float, str, str)

    @Slot(float, float)
    def onMapClicked(self, lat: float, lng: float):
        self.map_clicked_signal.emit(lat, lng)

    @Slot(str)
    def onDispatchRescue(self, case_id: str):
        self.dispatch_rescue_signal.emit(case_id)

    @Slot(str)
    def onMarkRescued(self, case_id: str):
        self.mark_rescued_signal.emit(case_id)

    @Slot(str, str)
    def onCallCitizen(self, case_id: str, phone: str):
        self.call_citizen_signal.emit(case_id, phone)
        clean_phone = "".join(ch for ch in str(phone) if ch.isdigit() or ch == "+")
        if clean_phone:
            try:
                from PySide6.QtGui import QDesktopServices
                from PySide6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl(f"tel:{clean_phone}"))
            except Exception:
                pass

    @Slot(float, float, float, str, str)
    def onAdoptOfficialArea(self, lat: float, lng: float, radius: float, prov_title: str, alert_title: str):
        self.adopt_official_area_signal.emit(lat, lng, radius, prov_title, alert_title)


class MapWidget(QWebEngineView):
    """
    Tactical Leaflet Map Container.
    Displays the active flood circle, mobile GPS pins, and handles user interactions.
    """
    map_clicked = Signal(float, float)
    dispatch_requested = Signal(str)
    mark_safe_requested = Signal(str)
    call_citizen_requested = Signal(str, str)
    adopt_official_area_requested = Signal(float, float, float, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._is_loaded = False
        self._pending_zones: list[DisasterZone] = []
        self._pending_sites: list[EvacuationSite] = []
        self._pending_cases: list[SosCase] = []
        self._pending_official_alerts: Optional[list] = None
        self._pending_risk_point: Optional[tuple[float, float, int]] = None
        self._pending_site_point: Optional[tuple[float, float, int, str]] = None

        # A named profile keeps the HTTP tile cache across desktop sessions.
        self._map_profile = QWebEngineProfile("chuaykan-map", self)
        self._map_profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        self._map_profile.setHttpUserAgent(
            self._map_profile.httpUserAgent() + " Chuaykan-Desktop/1.0"
        )
        self.setPage(QWebEnginePage(self._map_profile, self))
        self._map_profile.setParent(self.page())

        # Configure WebEngine Settings
        settings = self.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)

        # Set up QWebChannel
        self.bridge = MapBridge()
        self.bridge.map_clicked_signal.connect(self.map_clicked)
        self.bridge.dispatch_rescue_signal.connect(self.dispatch_requested)
        self.bridge.mark_rescued_signal.connect(self.mark_safe_requested)
        self.bridge.call_citizen_signal.connect(self.call_citizen_requested.emit)
        self.bridge.adopt_official_area_signal.connect(self.adopt_official_area_requested.emit)

        self.web_channel = QWebChannel(self)
        self.web_channel.registerObject("qtBridge", self.bridge)
        self.page().setWebChannel(self.web_channel)

        # Load local HTML
        html_path = WEB_DIR / "map.html"
        self.loadFinished.connect(self._on_load_finished)
        self.load(QUrl.fromLocalFile(str(html_path.resolve())))

    def _on_load_finished(self, ok: bool):
        if ok:
            self._is_loaded = True
            from PySide6.QtWidgets import QApplication
            manager = getattr(QApplication.instance(), "theme_manager", None)
            if manager:
                manager.map_theme(self)
            logger.info("Leaflet Tactical Map loaded successfully.")
            # Inject QWebChannel setup script
            init_js = """
            if (typeof QWebChannel !== 'undefined' && typeof qt !== 'undefined') {
                new QWebChannel(qt.webChannelTransport, function(channel) {
                    window.qtBridge = channel.objects.qtBridge;
                    window.qtMapClicked = function(lat, lng) {
                        if (window.qtBridge && window.qtBridge.onMapClicked) {
                            window.qtBridge.onMapClicked(lat, lng);
                        }
                    };
                });
            }
            """
            self.page().runJavaScript(init_js)

            # Flush risk areas only when they are explicitly active.
            if self._pending_zones:
                self.set_disaster_zones(self._pending_zones)
                self._pending_zones = []
            if self._pending_sites:
                self.set_evacuation_sites(self._pending_sites)
                self._pending_sites = []
            if self._pending_risk_point:
                self.set_pending_risk_point(*self._pending_risk_point)
                self._pending_risk_point = None
            if self._pending_site_point:
                self.set_pending_site_point(*self._pending_site_point)
                self._pending_site_point = None
            for c in self._pending_cases:
                self.add_or_update_sos(c)
            self._pending_cases.clear()
            if self._pending_official_alerts is not None:
                self.set_official_alerts(self._pending_official_alerts)
                self._pending_official_alerts = None
        else:
            logger.error("Failed to load Leaflet map HTML")

    def set_pending_risk_point(self, lat: float, lng: float, slot: int):
        """Show the operator's clicked draft point; it is not an active risk area."""
        if not self._is_loaded:
            self._pending_risk_point = (lat, lng, slot)
            return
        self.page().runJavaScript(
            f"if (window.setPendingRiskPoint) {{ window.setPendingRiskPoint({float(lat)}, {float(lng)}, {int(slot)}); }}"
        )

    def clear_pending_risk_point(self):
        self._pending_risk_point = None
        if self._is_loaded:
            self.page().runJavaScript(
                "if (window.clearPendingRiskPoint) { window.clearPendingRiskPoint(); }"
            )

    def set_disaster_zones(self, zones: list[DisasterZone]):
        """Render only the currently enabled operator-defined risk areas."""
        active = [zone for zone in zones if zone.is_active][:10]
        if not self._is_loaded:
            self._pending_zones = active
            return
        zones_json = json.dumps([zone.to_dict() for zone in active], ensure_ascii=False)
        self.page().runJavaScript(
            f"if (window.setDisasterZones) {{ window.setDisasterZones({zones_json}); }}"
        )

    def set_evacuation_sites(self, sites: list[EvacuationSite]):
        """Render active relief shelters and safe parking locations."""
        active = [s for s in sites if s.is_active]
        if not self._is_loaded:
            self._pending_sites = active
            return
        sites_json = json.dumps([s.to_dict() for s in active], ensure_ascii=False)
        self.page().runJavaScript(
            f"if (window.setEvacuationSites) {{ window.setEvacuationSites({sites_json}); }}"
        )

    def set_pending_site_point(self, lat: float, lng: float, slot: int, site_type: str = "SHELTER"):
        """Show draft location for evacuation shelter / parking before saving."""
        if not self._is_loaded:
            self._pending_site_point = (lat, lng, slot, site_type)
            return
        safe_type = json.dumps(site_type)
        self.page().runJavaScript(
            f"if (window.setPendingSitePoint) {{ window.setPendingSitePoint({float(lat)}, {float(lng)}, {int(slot)}, {safe_type}); }}"
        )

    def clear_pending_site_point(self):
        self._pending_site_point = None
        if self._is_loaded:
            self.page().runJavaScript(
                "if (window.clearPendingSitePoint) { window.clearPendingSitePoint(); }"
            )

    def set_disaster_circle(self, zone: DisasterZone):
        """Compatibility wrapper for a single zone from the HTTP API."""
        self.set_disaster_zones([zone] if zone else [])

    def add_or_update_sos(self, case: SosCase):
        """Add or refresh a citizen mobile SOS pin on the map."""
        if not self._is_loaded:
            self._pending_cases.append(case)
            return

        case_json = json.dumps(case.to_dict(), ensure_ascii=False)
        js = f"if (window.addOrUpdateSosMarker) {{ window.addOrUpdateSosMarker({case_json}); }}"
        self.page().runJavaScript(js)

    def focus_case(self, case_id: str):
        """Fly camera to specific SOS case and open popup."""
        if self._is_loaded:
            case_id_js = json.dumps(str(case_id))
            js = f"if (window.focusSosCase) {{ window.focusSosCase({case_id_js}); }}"
            self.page().runJavaScript(js)

    def pan_to(self, lat: float, lng: float, zoom: int = 14):
        """Fly map to coordinates."""
        if self._is_loaded:
            js = f"if (window.panToLocation) {{ window.panToLocation({float(lat)}, {float(lng)}, {int(zoom)}); }}"
            self.page().runJavaScript(js)

    def clear_markers(self):
        """Remove all mobile SOS pins from map."""
        self._pending_cases.clear()
        if self._is_loaded:
            self.page().runJavaScript("if (window.clearAllSosMarkers) { window.clearAllSosMarkers(); }")

    def set_official_alerts(self, alerts: list):
        """Render official NDWC/DPM warning zones and centroid markers on Leaflet."""
        if not self._is_loaded:
            self._pending_official_alerts = alerts
            return
        serialized = []
        for a in (alerts or []):
            if hasattr(a, "to_dict"):
                serialized.append(a.to_dict())
            elif isinstance(a, dict):
                serialized.append(a)
        alerts_json = json.dumps(serialized, ensure_ascii=False)
        self.page().runJavaScript(f"if (window.setOfficialAlerts) {{ window.setOfficialAlerts({alerts_json}); }}")
