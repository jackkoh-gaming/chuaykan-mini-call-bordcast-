package com.rescue.alert.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager

/**
 * AppSettings: Manages user preferences for:
 * 1. Display Size / Scaling (ขนาดดิสเพลย์ / ตัวอักษรสำหรับผู้สูงอายุ)
 * 2. Ultra Power Saving & Blackout Mode (ประหยัดพลังงานขั้นสูงสุดยามไฟดับ)
 */
object AppSettings {

    private const val PREF_NAME = "rescue_alert_preferences"
    private const val KEY_DISPLAY_SCALE = "key_display_scale_index"
    private const val KEY_ULTRA_POWER_SAVE = "key_ultra_power_save"
    private const val KEY_AUTO_POWER_SAVE = "key_auto_power_save"
    private const val KEY_GATEWAY_URL = "key_gateway_base_url"
    private const val KEY_EARLY_WARNING_ENABLED = "key_early_warning_enabled"

    const val DEFAULT_GATEWAY_URL = com.rescue.alert.BuildConfig.GATEWAY_URL
    const val CLOUD_CERTIFICATE_SHA256 = com.rescue.alert.BuildConfig.GATEWAY_CERT_SHA256

    fun isEarlyWarningEnabled(context: Context?): Boolean {
        if (context == null) return true
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_EARLY_WARNING_ENABLED, true)
    }

    fun setEarlyWarningEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_EARLY_WARNING_ENABLED, enabled).apply()
    }

    fun getGatewayBaseUrl(context: Context?): String {
        if (context == null) return DEFAULT_GATEWAY_URL
        return DEFAULT_GATEWAY_URL
    }

    fun setGatewayBaseUrl(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_GATEWAY_URL, url.trim().trimEnd('/')).apply()
    }

    val DISPLAY_SCALES = listOf(
        DisplayScaleOption("ขนาดปกติ (Standard 100%)", 1.0f),
        DisplayScaleOption("ขนาดใหญ่ (Large 115%)", 1.15f),
        DisplayScaleOption("ใหญ่พิเศษ (Extra Large 130%)", 1.30f),
        DisplayScaleOption("ใหญ่สูงสุด (Maximum 145%)", 1.45f)
    )

    data class DisplayScaleOption(val label: String, val scaleFactor: Float)

    fun getDisplayScaleIndex(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_DISPLAY_SCALE, 0).coerceIn(0, DISPLAY_SCALES.size - 1)
    }

    fun setDisplayScaleIndex(context: Context, index: Int) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_DISPLAY_SCALE, index.coerceIn(0, DISPLAY_SCALES.size - 1)).apply()
    }

    fun getDisplayScaleFactor(context: Context): Float {
        val index = getDisplayScaleIndex(context)
        return DISPLAY_SCALES[index].scaleFactor
    }

    /**
     * Applies custom display scale to the given Context (called in attachBaseContext).
     */
    fun applyDisplayConfiguration(context: Context): Context {
        val scale = getDisplayScaleFactor(context)
        val config = Configuration(context.resources.configuration)
        config.fontScale = scale

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            context.createConfigurationContext(config)
        } else {
            @Suppress("DEPRECATION")
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
            context
        }
    }

    /**
     * Dynamically updates the activity configuration and metrics.
     */
    fun applyDisplayScaleToActivity(activity: Activity) {
        val scale = getDisplayScaleFactor(activity)
        val config = Configuration(activity.resources.configuration)
        config.fontScale = scale

        val metrics = activity.resources.displayMetrics
        metrics.scaledDensity = metrics.density * scale

        @Suppress("DEPRECATION")
        activity.resources.updateConfiguration(config, metrics)
    }

    // ==========================================
    // ULTRA POWER SAVING & BLACKOUT MANAGEMENT
    // ==========================================

    fun isUltraPowerSaving(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ULTRA_POWER_SAVE, false)
    }

    fun setUltraPowerSaving(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ULTRA_POWER_SAVE, enabled).apply()
    }

    fun isAutoPowerSaving(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_POWER_SAVE, true) // Enabled by default for disaster safety
    }

    fun setAutoPowerSaving(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_POWER_SAVE, enabled).apply()
    }

    /**
     * Determines whether power saving mode should be active right now.
     * Takes into account manual user toggle, Android system PowerSaveMode,
     * and low battery condition (< 20%).
     */
    fun isPowerSavingActive(context: Context): Boolean {
        if (isUltraPowerSaving(context)) return true

        if (isAutoPowerSaving(context)) {
            // Check Android system power save mode
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (powerManager?.isPowerSaveMode == true) return true

            // Check if battery is low (<= 20%)
            val batteryPct = getBatteryPercentage(context)
            if (batteryPct in 1..20) return true
        }

        return false
    }

    /**
     * Reads current battery percentage.
     */
    fun getBatteryPercentage(context: Context): Int {
        return try {
            val batteryStatus = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) {
                (level * 100 / scale)
            } else {
                -1
            }
        } catch (e: Exception) {
            -1
        }
    }

    /**
     * Apply window screen brightness optimization when in ultra power saving mode.
     */
    fun applyWindowPowerSaving(activity: Activity, active: Boolean) {
        try {
            val layoutParams = activity.window.attributes
            if (active) {
                // Dim display slightly to preserve precious battery during blackout
                layoutParams.screenBrightness = 0.25f
            } else {
                // Return to system default brightness
                layoutParams.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            activity.window.attributes = layoutParams
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
