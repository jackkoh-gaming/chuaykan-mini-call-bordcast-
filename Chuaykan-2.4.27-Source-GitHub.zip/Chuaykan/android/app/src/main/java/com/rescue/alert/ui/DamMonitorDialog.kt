package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.data.BridgeMonitorRepository
import com.rescue.alert.data.DamMonitorRepository
import com.rescue.alert.model.BridgeItem
import com.rescue.alert.model.DamItem
import com.rescue.alert.model.DamStatus
import com.rescue.alert.model.WaterLevelStatus
import java.util.Locale

object DamMonitorDialog {

    fun show(context: Context) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        dialog.setCanceledOnTouchOutside(false)

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_dam_monitor, null)
        dialog.setContentView(dialogView)

        dialog.window?.let { window ->
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            )
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.setDimAmount(0.75f)
        }

        // View Bindings
        val tvWaterHeaderTitle = dialogView.findViewById<TextView>(R.id.tvWaterHeaderTitle)
        val tvDamHeaderSubtitle = dialogView.findViewById<TextView>(R.id.tvDamHeaderSubtitle)
        val btnRefreshDamData = dialogView.findViewById<ImageButton>(R.id.btnRefreshDamData)
        val btnModeDams = dialogView.findViewById<Button>(R.id.btnModeDams)
        val btnModeBridges = dialogView.findViewById<Button>(R.id.btnModeBridges)

        val etSearchDam = dialogView.findViewById<EditText>(R.id.etSearchDam)
        val btnFilterProvince = dialogView.findViewById<Button>(R.id.btnFilterProvince)

        val btnTabAll = dialogView.findViewById<Button>(R.id.btnTabAllDams)
        val btnTabNorth = dialogView.findViewById<Button>(R.id.btnTabNorthDams)
        val btnTabNortheast = dialogView.findViewById<Button>(R.id.btnTabNortheastDams)
        val btnTabCentralWest = dialogView.findViewById<Button>(R.id.btnTabCentralWestDams)
        val btnTabEast = dialogView.findViewById<Button>(R.id.btnTabEastDams)
        val btnTabSouth = dialogView.findViewById<Button>(R.id.btnTabSouthDams)

        val tvDamSummaryCount = dialogView.findViewById<TextView>(R.id.tvDamSummaryCount)
        val pbDamLoading = dialogView.findViewById<ProgressBar>(R.id.pbDamLoading)
        val cardsContainer = dialogView.findViewById<LinearLayout>(R.id.layoutDamCardsContainer)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseDamDialog)

        // State (Instant initial render)
        var currentMode = "DAMS" // "DAMS" or "BRIDGES"
        var allDams: List<DamItem> = DamMonitorRepository.getCachedOrBaselineDams()
        var allBridges: List<BridgeItem> = BridgeMonitorRepository.getCachedOrBaselineBridges()
        var currentQuery = ""
        var selectedProvince = "ทุกจังหวัด"
        var selectedRegion = "ALL" // "ALL", "NORTH", "NORTHEAST", "CENTRAL_WEST", "EAST", "SOUTH"
        var damDisplayLimit = 80

        fun updateModeButtonsUi() {
            if (currentMode == "DAMS") {
                btnModeDams.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_active)
                btnModeDams.setTextColor(Color.WHITE)
                btnModeDams.setTypeface(null, Typeface.BOLD)

                btnModeBridges.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_inactive)
                btnModeBridges.setTextColor(ContextCompat.getColor(context, R.color.tactical_text_secondary))
                btnModeBridges.setTypeface(null, Typeface.NORMAL)

                etSearchDam.hint = "ค้นหาชื่อเขื่อน/อ่างเก็บน้ำ เช่น ภูมิพล, แม่ออน..."
            } else {
                btnModeBridges.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_active)
                btnModeBridges.setTextColor(Color.WHITE)
                btnModeBridges.setTypeface(null, Typeface.BOLD)

                btnModeDams.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_inactive)
                btnModeDams.setTextColor(ContextCompat.getColor(context, R.color.tactical_text_secondary))
                btnModeDams.setTypeface(null, Typeface.NORMAL)

                etSearchDam.hint = "ค้นหาชื่อสะพาน/แม่น้ำ เช่น นวรัฐ, เจ้าพระยา..."
            }
        }

        fun updateRegionTabsUi() {
            val tabs = listOf(
                Pair(btnTabAll, selectedRegion == "ALL"),
                Pair(btnTabNorth, selectedRegion == "NORTH"),
                Pair(btnTabNortheast, selectedRegion == "NORTHEAST"),
                Pair(btnTabCentralWest, selectedRegion == "CENTRAL_WEST"),
                Pair(btnTabEast, selectedRegion == "EAST"),
                Pair(btnTabSouth, selectedRegion == "SOUTH")
            )

            for ((button, isActive) in tabs) {
                if (isActive) {
                    button.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_active)
                    button.setTextColor(Color.WHITE)
                    button.setTypeface(null, Typeface.BOLD)
                } else {
                    button.background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_inactive)
                    button.setTextColor(ContextCompat.getColor(context, R.color.tactical_text_secondary))
                    button.setTypeface(null, Typeface.NORMAL)
                }
            }
        }

        fun renderCards() {
            cardsContainer.removeAllViews()

            if (currentMode == "DAMS") {
                val filtered = DamMonitorRepository.searchAndFilter(allDams, currentQuery, selectedProvince, selectedRegion)
                tvDamSummaryCount.text = "พบเขื่อน/อ่างเก็บน้ำ ${filtered.size} แห่ง (จากทั้งหมด ${allDams.size} แห่ง)"

                if (filtered.isEmpty()) {
                    val tvEmpty = TextView(context).apply {
                        text = "ไม่พบข้อมูลเขื่อนตรงตามเงื่อนไขที่ค้นหา\nกรุณาลองเปลี่ยนคำค้นหาหรือเลือกจังหวัดอื่น"
                        textSize = 13f
                        setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                        gravity = android.view.Gravity.CENTER
                        setPadding(0, 48, 0, 48)
                    }
                    cardsContainer.addView(tvEmpty)
                    return
                }

                val toDisplay = filtered.take(damDisplayLimit)
                for (dam in toDisplay) {
                    val cardView = inflater.inflate(R.layout.item_dam_card, cardsContainer, false)

                    val tvName = cardView.findViewById<TextView>(R.id.tvDamName)
                    val tvProvBadge = cardView.findViewById<TextView>(R.id.tvDamProvinceBadge)
                    val tvAgencyBadge = cardView.findViewById<TextView>(R.id.tvDamAgencyBadge)
                    val tvStatusBadge = cardView.findViewById<TextView>(R.id.tvDamStatusBadge)
                    val pbStorage = cardView.findViewById<ProgressBar>(R.id.pbDamStorage)
                    val tvStorage = cardView.findViewById<TextView>(R.id.tvDamStorage)
                    val tvPercent = cardView.findViewById<TextView>(R.id.tvDamPercent)
                    val tvInflow = cardView.findViewById<TextView>(R.id.tvDamInflow)
                    val tvReleased = cardView.findViewById<TextView>(R.id.tvDamReleased)
                    val tvFooter = cardView.findViewById<TextView>(R.id.tvDamFooter)

                    tvName.text = dam.name
                    tvProvBadge.text = "จ.${dam.province}"
                    tvAgencyBadge.text = dam.agency

                    val (badgeBgRes, progressDrawableRes, statusLabel) = when (dam.status) {
                        DamStatus.CRITICAL_HIGH -> Triple(
                            R.drawable.bg_badge_dam_status_red,
                            R.drawable.bg_tactical_dam_progress_red,
                            "วิกฤตน้ำหลาก"
                        )
                        DamStatus.WARNING_HIGH -> Triple(
                            R.drawable.bg_badge_dam_status_amber,
                            R.drawable.bg_tactical_dam_progress_amber,
                            "เฝ้าระวังสูง"
                        )
                        DamStatus.NORMAL -> Triple(
                            R.drawable.bg_badge_dam_status_green,
                            R.drawable.bg_tactical_dam_progress_green,
                            "เกณฑ์ปกติ"
                        )
                        DamStatus.CRITICAL_LOW -> Triple(
                            R.drawable.bg_badge_dam_status_blue,
                            R.drawable.bg_tactical_dam_progress_blue,
                            "วิกฤตน้ำน้อย"
                        )
                    }

                    tvStatusBadge.background = ContextCompat.getDrawable(context, badgeBgRes)
                    tvStatusBadge.text = "$statusLabel ${String.format(Locale.US, "%.1f", dam.percent)}%"

                    pbStorage.progressDrawable = ContextCompat.getDrawable(context, progressDrawableRes)
                    val progressVal = Math.min(100, Math.max(0, dam.percent.toInt()))
                    pbStorage.progress = progressVal

                    tvStorage.text = "น้ำกักเก็บ: ${String.format(Locale.US, "%,.2f", dam.storageMcm)} / ${String.format(Locale.US, "%,.0f", dam.capacityMcm)} ล้าน ลบ.ม."
                    tvPercent.text = "${String.format(Locale.US, "%.1f", dam.percent)}%"

                    val inflowStr = if (!dam.inflowMcm.isFinite()) "ไม่มีข้อมูล" else String.format(Locale.US, "%,.2f", dam.inflowMcm)
                    tvInflow.text = "ไหลเข้าวันนี้: $inflowStr ล้าน ลบ.ม."

                    val releasedStr = if (!dam.releasedMcm.isFinite()) "ไม่มีข้อมูล" else String.format(Locale.US, "%,.2f", dam.releasedMcm)
                    tvReleased.text = "ระบายออก: $releasedStr ล้าน ลบ.ม."

                    val dataSourceLabel = if (dam.isLiveTelemetry) "สด: กรมชลประทาน & กฟผ." else "ข้อมูลสำรองออฟไลน์ (Baseline)"
                    tvFooter.text = "แหล่งข้อมูล: $dataSourceLabel | ${dam.dateStr} | ${dam.region}"

                    cardsContainer.addView(cardView)
                }

                if (filtered.size > damDisplayLimit) {
                    val remaining = filtered.size - damDisplayLimit
                    val btnLoadMore = Button(context).apply {
                        text = "แสดงรายการที่เหลืออีก $remaining แห่ง (แตะเพื่อโหลดทั้งหมด)"
                        textSize = 12.5f
                        setTextColor(Color.WHITE)
                        background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_rect_btn_blue)
                        setPadding(24, 24, 24, 24)
                        val params = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply { setMargins(0, 16, 0, 24) }
                        layoutParams = params
                        setOnClickListener {
                            damDisplayLimit = filtered.size
                            renderCards()
                        }
                    }
                    cardsContainer.addView(btnLoadMore)
                }
            } else {
                // BRIDGES MODE
                val filtered = BridgeMonitorRepository.searchAndFilter(allBridges, currentQuery, selectedProvince, selectedRegion)
                tvDamSummaryCount.text = "พบสะพาน ${filtered.size} แห่ง (จากทั้งหมด ${allBridges.size} แห่ง)"

                if (filtered.isEmpty()) {
                    val tvEmpty = TextView(context).apply {
                        text = "ไม่พบข้อมูลสะพานตรงตามเงื่อนไขที่ค้นหา\nกรุณาลองเปลี่ยนคำค้นหาหรือเลือกจังหวัดอื่น"
                        textSize = 13f
                        setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                        gravity = android.view.Gravity.CENTER
                        setPadding(0, 48, 0, 48)
                    }
                    cardsContainer.addView(tvEmpty)
                    return
                }

                for (bridge in filtered) {
                    val cardView = inflater.inflate(R.layout.item_bridge_card, cardsContainer, false)

                    val tvName = cardView.findViewById<TextView>(R.id.tvBridgeName)
                    val tvProvBadge = cardView.findViewById<TextView>(R.id.tvBridgeProvinceBadge)
                    val tvRiverBadge = cardView.findViewById<TextView>(R.id.tvBridgeRiverBadge)
                    val tvStatusBadge = cardView.findViewById<TextView>(R.id.tvBridgeStatusBadge)
                    val pbLevel = cardView.findViewById<ProgressBar>(R.id.pbBridgeLevel)
                    val tvWaterLevel = cardView.findViewById<TextView>(R.id.tvBridgeWaterLevel)
                    val tvDiffBank = cardView.findViewById<TextView>(R.id.tvBridgeDiffBank)
                    val tvFooter = cardView.findViewById<TextView>(R.id.tvBridgeFooter)

                    tvName.text = bridge.name
                    tvProvBadge.text = "จ.${bridge.province}"
                    tvRiverBadge.text = bridge.river

                    val (badgeBgRes, progressDrawableRes, statusLabel) = when (bridge.status) {
                        WaterLevelStatus.CRITICAL_HIGH -> Triple(
                            R.drawable.bg_badge_dam_status_red,
                            R.drawable.bg_tactical_dam_progress_red,
                            "วิกฤตน้ำล้นตลิ่ง"
                        )
                        WaterLevelStatus.WARNING_HIGH -> Triple(
                            R.drawable.bg_badge_dam_status_amber,
                            R.drawable.bg_tactical_dam_progress_amber,
                            "เฝ้าระวังน้ำสูง"
                        )
                        WaterLevelStatus.NORMAL -> Triple(
                            R.drawable.bg_badge_dam_status_green,
                            R.drawable.bg_tactical_dam_progress_green,
                            "เกณฑ์ปกติ"
                        )
                        WaterLevelStatus.CRITICAL_LOW -> Triple(
                            R.drawable.bg_badge_dam_status_blue,
                            R.drawable.bg_tactical_dam_progress_blue,
                            "ระดับน้ำต่ำ"
                        )
                    }

                    tvStatusBadge.background = ContextCompat.getDrawable(context, badgeBgRes)
                    tvStatusBadge.text = statusLabel

                    pbLevel.progressDrawable = ContextCompat.getDrawable(context, progressDrawableRes)
                    // Visual fill calculation based on bank difference
                    val levelPercent = when {
                        bridge.diffBankM <= 0.0 -> 100
                        bridge.diffBankM < 1.0 -> 85
                        bridge.diffBankM < 2.5 -> 65
                        bridge.diffBankM < 5.0 -> 45
                        else -> 25
                    }
                    pbLevel.progress = levelPercent

                    tvWaterLevel.text = "ระดับน้ำ: ${String.format(Locale.US, "%,.2f", bridge.waterLevelMsl)} ม. (รทก.)"
                    tvDiffBank.text = bridge.diffBankText
                    if (bridge.diffBankM <= 0.0) {
                        tvDiffBank.setTextColor(ContextCompat.getColor(context, R.color.emergency_red_dark))
                    } else if (bridge.diffBankM < 1.0) {
                        tvDiffBank.setTextColor(com.rescue.alert.util.ThemePalette.color("#F59E0B"))
                    } else {
                        tvDiffBank.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
                    }

                    val bridgeSourceLabel = if (bridge.isLiveTelemetry) "สด: ThaiWater API" else "ข้อมูลสำรองออฟไลน์ (Baseline)"
                    tvFooter.text = "แหล่งข้อมูล: $bridgeSourceLabel | ${bridge.dateStr} | ${bridge.region}"

                    cardsContainer.addView(cardView)
                }
            }
        }

        fun loadData(forceRefresh: Boolean = false) {
            pbDamLoading.visibility = View.VISIBLE
            if (forceRefresh) {
                tvDamHeaderSubtitle.text = "กำลังดึงข้อมูลสดจาก กรมชลประทาน (RID) และ กฟผ. (EGAT)..."
            }

            var damDone = false
            var bridgeDone = false

            fun checkDone() {
                if (damDone && bridgeDone) {
                    pbDamLoading.visibility = View.GONE
                    tvDamHeaderSubtitle.text = "ข้อมูลโทรมาตรสด: กรมชลประทาน & กฟผ. (รวม ${allDams.size} เขื่อน/อ่างเก็บน้ำทั่วประเทศ, ${allBridges.size} สะพาน)"
                    btnModeDams.text = "เขื่อน/อ่างเก็บน้ำ (${allDams.size})"
                    btnModeBridges.text = "สะพานและลำน้ำ (${allBridges.size})"
                    renderCards()
                    if (forceRefresh) {
                        Toast.makeText(context, "อัพเดตข้อมูลระดับน้ำเขื่อนและสะพานเรียบร้อย", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            DamMonitorRepository.getDams(forceRefresh) { dams ->
                allDams = dams
                damDone = true
                checkDone()
            }

            BridgeMonitorRepository.getBridges(forceRefresh) { bridges ->
                allBridges = bridges
                bridgeDone = true
                checkDone()
            }
        }

        fun openProvincePicker() {
            val pickerDialog = Dialog(context)
            pickerDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

            val pickerView = inflater.inflate(R.layout.dialog_dam_province_picker, null)
            pickerDialog.setContentView(pickerView)

            pickerDialog.window?.let { w ->
                w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val wWidth = (context.resources.displayMetrics.widthPixels * 0.90).toInt()
                val wHeight = (context.resources.displayMetrics.heightPixels * 0.70).toInt()
                w.setLayout(wWidth, wHeight)
            }

            val container = pickerView.findViewById<LinearLayout>(R.id.layoutDamProvinceListContainer)
            val btnCancel = pickerView.findViewById<Button>(R.id.btnCancelDamProvincePicker)
            btnCancel.setOnClickListener { pickerDialog.dismiss() }

            val provinces = if (currentMode == "DAMS") {
                DamMonitorRepository.getAllDamProvinces(allDams)
            } else {
                BridgeMonitorRepository.getAllBridgeProvinces(allBridges)
            }

            for (prov in provinces) {
                val isSelected = (prov == selectedProvince)
                val countInProv = if (prov == "ทุกจังหวัด") {
                    if (currentMode == "DAMS") allDams.size else allBridges.size
                } else {
                    if (currentMode == "DAMS") allDams.count { it.province == prov } else allBridges.count { it.province == prov }
                }

                val itemBtn = Button(context).apply {
                    val unitLabel = if (currentMode == "DAMS") "แห่ง" else "สะพาน"
                    val countLabel = if (prov == "ทุกจังหวัด") "ทั้งหมด $countInProv $unitLabel" else "$countInProv $unitLabel"
                    text = if (prov == "ทุกจังหวัด") "ทุกจังหวัด ($countLabel)" else "จ.$prov ($countLabel)"
                    textSize = 13.5f
                    setTextColor(if (isSelected) Color.WHITE else com.rescue.alert.util.ThemePalette.color("#CBD5E1"))
                    background = ContextCompat.getDrawable(
                        context,
                        if (isSelected) R.drawable.bg_picker_item_selected else R.drawable.bg_picker_item_unselected
                    )
                    gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
                    setPadding(28, 20, 28, 20)
                    minHeight = 44
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 8) }

                    setOnClickListener {
                        selectedProvince = prov
                        damDisplayLimit = 80
                        btnFilterProvince.text = if (prov == "ทุกจังหวัด") "ทุกจังหวัด" else "จ.$prov"
                        pickerDialog.dismiss()
                        renderCards()
                    }
                }
                container.addView(itemBtn)
            }

            pickerDialog.show()
        }

        // Mode switch events
        btnModeDams.setOnClickListener {
            if (currentMode != "DAMS") {
                currentMode = "DAMS"
                damDisplayLimit = 80
                selectedProvince = "ทุกจังหวัด"
                btnFilterProvince.text = "ทุกจังหวัด"
                updateModeButtonsUi()
                renderCards()
            }
        }

        btnModeBridges.setOnClickListener {
            if (currentMode != "BRIDGES") {
                currentMode = "BRIDGES"
                damDisplayLimit = 80
                selectedProvince = "ทุกจังหวัด"
                btnFilterProvince.text = "ทุกจังหวัด"
                updateModeButtonsUi()
                renderCards()
            }
        }

        // Event Listeners
        btnRefreshDamData.setOnClickListener {
            loadData(forceRefresh = true)
        }

        btnFilterProvince.setOnClickListener {
            openProvincePicker()
        }

        etSearchDam.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString() ?: ""
                damDisplayLimit = 80
                renderCards()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Region Tab switches
        btnTabAll.setOnClickListener {
            selectedRegion = "ALL"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }
        btnTabNorth.setOnClickListener {
            selectedRegion = "NORTH"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }
        btnTabNortheast.setOnClickListener {
            selectedRegion = "NORTHEAST"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }
        btnTabCentralWest.setOnClickListener {
            selectedRegion = "CENTRAL_WEST"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }
        btnTabEast.setOnClickListener {
            selectedRegion = "EAST"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }
        btnTabSouth.setOnClickListener {
            selectedRegion = "SOUTH"
            damDisplayLimit = 80
            updateRegionTabsUi()
            renderCards()
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        // Instant initial render
        updateModeButtonsUi()
        updateRegionTabsUi()
        renderCards()

        // Background live fetch
        loadData(forceRefresh = false)

        dialog.show()
    }
}
