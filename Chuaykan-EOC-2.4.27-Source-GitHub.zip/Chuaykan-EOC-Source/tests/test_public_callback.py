import os, tempfile
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='eoc-flow-test-') as temporary:
    root=Path(temporary)
    os.environ['EOC_DATA_DIR']=str(root/'data');os.environ['EOC_RECORDINGS_DIR']=str(root/'recordings')
    import sys, secrets, json, ssl, urllib.request, urllib.error, base64, io
    sys.path.insert(0,os.environ.get('EOC_SOURCE',str(Path(__file__).resolve().parents[1])))
    from src.server.gateway_security import GatewaySecurity
    from src.server.dispatch_server import DispatchServer
    from src.server.cloud_bridge import CloudBridge
    from src.core.database import Database
    from src.core.models import DisasterZone
    security=GatewaySecurity(root/'security');security.officer_token=secrets.token_urlsafe(32)
    server=DispatchServer(Database(root/'remote.db'),port=0,security=security);server.start()
    import traceback
    server._server.handle_error=lambda *_:traceback.print_exc()
    origin='https://127.0.0.1:'+str(server._server.server_port)
    context=ssl.create_default_context(cafile=str(security.cert))
    def request(path,payload=None,token=None,officer=False):
        headers={'Content-Type':'application/json'}
        if token:headers['X-API-Key']=token
        if officer:headers['X-Officer-Key']=security.officer_token
        req=urllib.request.Request(origin+path,data=json.dumps(payload).encode() if payload is not None else None,headers=headers)
        try:
            with urllib.request.urlopen(req,context=context,timeout=5) as response:return response.status,json.load(response)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    client={'client_id':secrets.token_hex(16),'device_id':'isolated_device_a','proof':secrets.token_urlsafe(32)}
    code,reply=request('/api/device/register',client);assert code==200;token=reply['access_token']
    assert request('/api/device/register',client)[1]['access_token']==token
    assert request('/api/device/register',dict(client,proof=secrets.token_urlsafe(32)))[0]==403
    assert request('/api/device/register',dict(client,client_id=secrets.token_hex(16),proof=secrets.token_urlsafe(32)))[0]==403
    assert request('/api/health')[0]==401 and request('/api/health',token=token)[0]==200
    assert request('/api/sos/list',token=token)[0]==403
    assert request('/api/sos/report',{'device_id':'another'},token=token)[0]==403
    import threading, time, struct
    from queue import Empty
    data={'case_id':'ISOLATED_CALLBACK_CASE','case_type':'GENERAL','device_id':client['device_id'],'contact_name':'isolated','contact_phone':'isolated','lat':13,'lng':100}
    assert request('/api/sos/report',data,token=token)[0]==200
    other_id='ISOLATED_OTHER'
    other=request('/api/device/register',dict(client,client_id=secrets.token_hex(16),device_id=other_id,proof=secrets.token_urlsafe(32)))[1]['access_token']
    local=DispatchServer(Database(root/'local.db'),security=GatewaySecurity(root/'local-security'))
    local.security.officer_token=security.officer_token
    (local.security.directory/'cloud.json').write_text(json.dumps({'url':origin}))
    (local.security.directory/'cloud-ca.pem').write_text(security.cert.read_text())
    bridge=CloudBridge.configured(local);local.cloud_bridge=bridge
    bridge.sync_once()
    target=server.announcer.register_subscriber(None,None,client['device_id'])
    unrelated=server.announcer.register_subscriber(None,None,other_id)
    connected=threading.Event();ended=threading.Event();heard=threading.Event();received=[]
    local.on_call_answered=lambda *_:connected.set()
    local.on_call_ended=ended.set
    local.on_citizen_voice=lambda pcm:(received.append(pcm),heard.set())
    threading.Thread(target=bridge.call_receive_loop,daemon=True).start()
    threading.Thread(target=bridge.voice_loop,daemon=True).start()
    local.start_internet_call('isolated','isolated',data['case_id'])
    assert server.call_session.state=='RINGING'
    frame=target.queue.get(timeout=3);assert frame[0]==0x10 and unrelated.queue.empty()
    # A reconnect must recover ringing from the authenticated stream endpoint.
    req=urllib.request.Request(origin+'/api/announcement/stream',headers={'X-API-Key':token})
    with urllib.request.urlopen(req,context=context,timeout=5) as stream:
        header=stream.read(5);kind,size=struct.unpack('!BI',header)
        assert kind==0x10 and len(stream.read(size))==size
    assert request('/api/call/status',token=other)[1]=={'state':'IDLE'}
    assert request('/api/call/request',{},token=other)[0]==409
    assert request('/api/call/answer',{},token=other)[0]==403
    assert request('/api/call/hangup',{},token=other)[0]==403
    assert request('/api/call/start',{'case_id':data['case_id']},officer=True)[0]==409
    assert request('/api/call/answer',{'client_id':client['device_id']},token=token)[0]==200
    bridge.sync_call_status();assert connected.is_set() and local.call_session.state=='CONNECTED'
    local.feed_officer_call_voice(b'ISOLATED_OFFICER_PCM')
    frame=target.queue.get(timeout=5);assert frame[0]==0x11 and frame[5:]==b'ISOLATED_OFFICER_PCM'
    assert unrelated.queue.empty()
    def raw_voice(token_value):
        req=urllib.request.Request(origin+'/api/call/voice/send',data=b'ISOLATED_CITIZEN_PCM',headers={'X-API-Key':token_value,'Content-Type':'application/octet-stream'})
        try:
            with urllib.request.urlopen(req,context=context,timeout=5) as reply:return reply.status
        except urllib.error.HTTPError as error:return error.code
    assert raw_voice(other)==403 and raw_voice(token)==200
    assert heard.wait(5) and received==[b'ISOLATED_CITIZEN_PCM']
    assert request('/api/call/hangup',{},token=token)[0]==200
    assert target.queue.get(timeout=3)[0]==0x12 and unrelated.queue.empty()
    bridge.sync_call_status();assert ended.is_set() and local.call_session.state=='IDLE'
    assert local.db.get_sos_case(data['case_id']) and server.db.get_sos_case(data['case_id'])
    assert not server.call_session.target_phone and not server.call_session.target_device_id
    bridge.stop();server.stop()
    print('PASS: case callback crosses cloud, only target rings/receives audio, authenticated reconnect recovers ring, wrong device cannot answer/voice/hangup, staff/citizen audio both directions, answer/hangup reach desktop, cases unchanged')
