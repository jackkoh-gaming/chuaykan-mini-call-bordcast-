package com.rescue.alert.model

/**
 * Metadata for Thailand National Radio Stations (AM/FM PRD & NBTC Network).
 */
data class AmStation(
    val id: String,
    val name: String,
    val frequency: String,
    val modulation: String = "AM",
    val isLive: Boolean = true,
    val location: String = "ไม่ระบุ",
    var streamUrl: String? = null,
    val description: String = "",
    val isEmergencyPrimary: Boolean = false,
    val source: String = "สวท. / กสทช.",
    val callsign: String? = null,
    val licenseStatus: String = "ได้รับอนุญาตจาก กสทช.",
    val supportsStreamLookup: Boolean = false
)
