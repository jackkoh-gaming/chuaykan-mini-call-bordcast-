package com.rescue.alert.source.area

/** Source administrative codes, never a guessed radius around a province capital. */
data class AlertArea(val level: String, val province: String, val district: String, val subdistrict: String)
data class DeviceArea(val province: String, val district: String?, val subdistrict: String?, val label: String)
enum class BulletinKind { WARNING, INFORMATION, ALL_CLEAR, EXERCISE }

object AreaAlertPolicy {
    const val NOTIFICATION_WINDOW_MS = 4 * 60 * 60 * 1000L
    const val HISTORY_WINDOW_MS = 48 * 60 * 60 * 1000L

    fun canNotify(bulletin: AreaBulletin, device: DeviceArea?, now: Long, alreadySeen: Boolean): Boolean =
        !alreadySeen && device != null && bulletin.kind == BulletinKind.WARNING &&
            isCurrent(bulletin.issuedAt, now) && bulletin.isFor(device)

    fun matches(target: AlertArea, device: DeviceArea): Boolean {
        if (target.province.isBlank() || target.province != device.province) return false
        return when (target.level) {
            "province" -> true
            "amphoe" -> target.district.isNotBlank() && target.district == device.district
            "tambon" -> target.district.isNotBlank() && target.district == device.district &&
                target.subdistrict.isNotBlank() && target.subdistrict == device.subdistrict
            else -> false
        }
    }

    fun classify(event: String, title: String, message: String): BulletinKind {
        val heading = title.lowercase()
        val text = "$title $message".lowercase()
        if (listOf("ทดสอบ", "ฝึกซ้อม", "ซักซ้อม", "test message", "exercise", "ไม่ใช่สถานการณ์จริง").any { text.contains(it) }) {
            return BulletinKind.EXERCISE
        }
        if (event == "ALL") return BulletinKind.ALL_CLEAR
        if (listOf("ประชาสัมพันธ์", "แถลงข่าว", "จัดประชุม", "เยี่ยมชม", "มอบถุงยังชีพ").any { heading.contains(it) }) {
            return BulletinKind.INFORMATION
        }
        if (event in setOf("EXA", "ASA", "PRA")) return BulletinKind.WARNING
        // ACI includes actual flood/evacuation warnings. It is NOT synonymous with news.
        val actionableTitle = listOf("เตือน", "เฝ้าระวัง", "อพยพ", "ระวัง", "หลีกเลี่ยง").any { heading.contains(it) }
        val hazardTitle = listOf("น้ำท่วม", "น้ำป่า", "ล้นตลิ่ง", "ดินโคลนถล่ม", "แผ่นดินไหว", "สึนามิ", "ฝนตกหนัก", "พายุ", "กราดยิง", "ไฟไหม้", "สารเคมี", "pm2.5").any { heading.contains(it) }
        val protectiveInstruction = listOf("ขอให้", "ให้ประชาชน", "อพยพ", "ยกของ", "ยกสิ่งของ", "ระวัง", "หลีกเลี่ยง", "เคลื่อนย้าย", "เตือน").any { message.contains(it) }
        if (event == "ACI" && (actionableTitle || (hazardTitle && protectiveInstruction))) {
            return BulletinKind.WARNING
        }
        return BulletinKind.INFORMATION
    }

    fun isCurrent(issuedAt: Long, now: Long): Boolean = now - issuedAt in 0..NOTIFICATION_WINDOW_MS
}
