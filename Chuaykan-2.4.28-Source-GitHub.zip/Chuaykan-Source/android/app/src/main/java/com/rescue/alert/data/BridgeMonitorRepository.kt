package com.rescue.alert.data

import android.os.Handler
import android.os.Looper
import com.rescue.alert.model.BridgeItem
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Nationwide Bridge & River Hydrological Monitoring Repository.
 * Fetches real-time bridge water levels & bank telemetry from ThaiWater / HII
 * Shows only measurements supplied by the upstream stations.
 */
object BridgeMonitorRepository {

    private val cachedBridges = mutableListOf<BridgeItem>()
    private var lastFetchTime: Long = 0L

    fun getCachedOrBaselineBridges(): List<BridgeItem> {
        synchronized(cachedBridges) {
            if (cachedBridges.isNotEmpty()) {
                return cachedBridges.toList()
            }
        }
        return emptyList()
    }

    fun getBridges(forceRefresh: Boolean = false, callback: (List<BridgeItem>) -> Unit) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedBridges.isNotEmpty() && (now - lastFetchTime) < 120_000L) {
            callback(cachedBridges.toList())
            return
        }

        Thread {
            val liveItems = fetchRealtimeBridgesFromThaiWater()
            val finalItems = if (liveItems.isNotEmpty()) {
                liveItems
            } else {
                emptyList()
            }

            synchronized(cachedBridges) {
                cachedBridges.clear()
                cachedBridges.addAll(finalItems)
                lastFetchTime = System.currentTimeMillis()
            }

            Handler(Looper.getMainLooper()).post {
                callback(cachedBridges.toList())
            }
        }.start()
    }

    private fun fetchRealtimeBridgesFromThaiWater(): List<BridgeItem> {
        val results = mutableListOf<BridgeItem>()
        val seenNames = mutableSetOf<String>()
        try {
            val url = URL("https://api-v3.thaiwater.net/api/v1/thaiwater30/public/waterlevel")
            val conn = com.rescue.alert.network.PublicDataGateway.open(url) as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 5000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "RescueAlert-Tactical/2.0 (Android Go)")
            conn.setRequestProperty("Accept", "application/json")

            if (conn.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
                val response = reader.readText()
                reader.close()

                val root = JSONObject(response)
                val items = root.optJSONArray("data")

                if (items != null) {
                    for (i in 0 until items.length()) {
                        val it = items.getJSONObject(i)
                        val st = it.optJSONObject("station")
                        val geocode = it.optJSONObject("geocode")

                        val rawName = st?.optJSONObject("tele_station_name")?.optString("th", "")?.trim() ?: ""
                        val oldcode = st?.optString("tele_station_oldcode", "")?.trim() ?: ""
                        val prov = geocode?.optJSONObject("province_name")?.optString("th", "")?.trim() ?: ""
                        var reg = geocode?.optJSONObject("area_name")?.optString("th", "")?.trim() ?: ""
                        val river = it.optString("river_name", "ลำน้ำสาขา").trim()

                        if (!rawName.contains("สะพาน") || prov.isBlank() || prov.contains("เมียนมา")) {
                            continue
                        }

                        val cleanName = if (oldcode.isNotBlank() && !rawName.contains(oldcode)) {
                            "$rawName ($oldcode)"
                        } else {
                            rawName
                        }

                        if (seenNames.contains(cleanName)) continue
                        seenNames.add(cleanName)

                        val wlRaw = it.optDouble("waterlevel_msl", it.optDouble("waterlevel_m", Double.NaN))
                        val diffRaw = it.optDouble("diff_wl_bank", Double.NaN)
                        val sit = it.optInt("situation_level", 0)
                        val dt = it.optString("waterlevel_datetime", "ไม่ระบุเวลาตรวจวัด")
                        if (!wlRaw.isFinite() || !diffRaw.isFinite() || sit !in 1..5) continue

                        val diffText = when {
                            diffRaw > 0.0 -> "ต่ำกว่าตลิ่ง ${String.format(Locale.US, "%.2f", diffRaw)} ม."
                            diffRaw < 0.0 -> "ล้นตลิ่ง ${String.format(Locale.US, "%.2f", Math.abs(diffRaw))} ม."
                            else -> "เสมอระดับตลิ่ง"
                        }

                        reg = when {
                            reg.contains("ตะวันออกเฉียงเหนือ") -> "ภาคตะวันออกเฉียงเหนือ"
                            reg.contains("ตะวันตก") -> "ภาคตะวันตก"
                            reg.contains("ตะวันออก") -> "ภาคตะวันออก"
                            reg.contains("เหนือ") -> "ภาคเหนือ"
                            reg.contains("ใต้") -> "ภาคใต้"
                            reg.contains("กลาง") -> "ภาคกลาง"
                            else -> reg
                        }

                        results.add(
                            BridgeItem(
                                id = "BR_${st?.optInt("id", i)}",
                                name = cleanName,
                                province = prov,
                                region = reg,
                                river = if (river.isNotBlank()) river else "ลำน้ำสาขา",
                                waterLevelMsl = Math.round(wlRaw * 100.0) / 100.0,
                                diffBankM = Math.round(diffRaw * 100.0) / 100.0,
                                diffBankText = diffText,
                                situationLevel = sit,
                                dateStr = dt,
                                isLiveTelemetry = true
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Log & fallback
        }
        return results
    }

    fun searchAndFilter(
        allBridges: List<BridgeItem>,
        query: String,
        provinceFilter: String,
        regionFilter: String
    ): List<BridgeItem> {
        val q = query.trim().lowercase(Locale.ROOT)
        return allBridges.filter { bridge ->
            val matchQuery = if (q.isEmpty()) true else {
                bridge.name.lowercase(Locale.ROOT).contains(q) ||
                bridge.province.lowercase(Locale.ROOT).contains(q) ||
                bridge.river.lowercase(Locale.ROOT).contains(q) ||
                bridge.region.lowercase(Locale.ROOT).contains(q)
            }

            val matchProvince = if (provinceFilter == "ทุกจังหวัด" || provinceFilter.isEmpty()) true else {
                bridge.province == provinceFilter
            }

            val matchRegion = when (regionFilter) {
                "ALL" -> true
                "NORTH" -> bridge.region == "ภาคเหนือ"
                "NORTHEAST" -> bridge.region == "ภาคตะวันออกเฉียงเหนือ"
                "CENTRAL_WEST" -> bridge.region == "ภาคกลาง" || bridge.region == "ภาคตะวันตก"
                "EAST" -> bridge.region == "ภาคตะวันออก"
                "SOUTH" -> bridge.region == "ภาคใต้"
                else -> true
            }

            matchQuery && matchProvince && matchRegion
        }
    }

    fun getAllBridgeProvinces(allBridges: List<BridgeItem>): List<String> {
        val list = mutableListOf("ทุกจังหวัด")
        val unique = allBridges.map { it.province }.filter { it.isNotBlank() }.distinct().sorted()
        list.addAll(unique)
        return list
    }

    private fun getTodayDateStr(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
    }



}
