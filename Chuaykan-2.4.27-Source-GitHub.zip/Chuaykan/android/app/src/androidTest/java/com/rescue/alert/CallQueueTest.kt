package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.bluetooth.BluetoothMeshManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.atomic.AtomicBoolean

/** Isolated call-state fixtures: no Bluetooth connection, microphone or incident is sent. */
@RunWith(AndroidJUnit4::class)
class CallQueueTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private fun field(mesh: BluetoothMeshManager, name: String) =
        mesh.javaClass.getDeclaredField(name).apply { isAccessible = true }

    @Test fun queueCannotActivateIdlePhoneOrAcceptInvalidPosition() {
        val mesh = BluetoothMeshManager.getInstance(instrumentation.targetContext)
        mesh.handleCallQueuedByRemote("UNRELATED_TEST_PEER", 1)
        mesh.handleCallQueuedByRemote("UNRELATED_TEST_PEER", -1)
        mesh.handleCallQueuedByRemote("UNRELATED_TEST_PEER", 51)
        instrumentation.waitForIdleSync()
        assertNull(mesh.getCallQueuePosition())
        assertFalse(mesh.isInCall())
        assertFalse(mesh.isTransmitting())
    }

    @Test fun queueKeepsWaitingWithoutStartingMicrophoneAndClearsOnRemoteEnd() {
        val mesh = BluetoothMeshManager.getInstance(instrumentation.targetContext)
        val inCall = field(mesh, "isInCall").get(mesh) as AtomicBoolean
        val nodeField = field(mesh, "activeCallNode")
        // Use the real node model constructor through its Kotlin primary constructor below.
        val node = com.rescue.alert.model.MeshNode(
            nodeId = "QUEUE_TEST_PEER", houseName = "Queue test", hopCount = 0,
            distanceMeters = 1, rssi = -50, relayVia = null,
            nodeType = com.rescue.alert.model.MeshNodeType.RESCUE_POST
        )
        val watchdogHandler = field(mesh, "incomingCallWatchdogHandler").get(mesh) as android.os.Handler
        val timedOut = AtomicBoolean(false)
        val watchdog = Runnable { timedOut.set(true) }
        fun queuePacket(target: String, source: String, payload: String) {
            val packet = com.rescue.alert.model.MeshVoicePacket(
                packetId = "EOC_CALL_QUEUE_TEST_${System.nanoTime()}",
                sourceNodeId = source, sourceHouseName = "Queue test",
                targetNodeId = target, hopCount = 0, ttl = 1,
                audioData = payload.toByteArray(Charsets.UTF_8), isSosEmergency = false
            )
            mesh.javaClass.getDeclaredMethod("processIncomingPacketBytes", ByteArray::class.java, String::class.java)
                .apply { isAccessible = true }.invoke(mesh, BluetoothMeshManager.serializePacket(packet), null)
        }
        try {
            instrumentation.runOnMainSync {
                inCall.set(true)
                nodeField.set(mesh, node)
                field(mesh, "awaitingCallAnswer").setBoolean(mesh, true)
                field(mesh, "incomingCallWatchdogRunnable").set(mesh, watchdog)
                watchdogHandler.postDelayed(watchdog, 1000L)
            }
            queuePacket("BROADCAST", node.nodeId, "{\"position\":2}")
            queuePacket(mesh.myNodeId, "WRONG_PEER", "{\"position\":2}")
            queuePacket(mesh.myNodeId, node.nodeId, "{\"position\":51}")
            queuePacket(mesh.myNodeId, node.nodeId, "invalid-json")
            instrumentation.waitForIdleSync()
            assertNull(mesh.getCallQueuePosition())
            queuePacket(mesh.myNodeId, node.nodeId, "{\"position\":2}")
            instrumentation.waitForIdleSync()
            assertEquals(2, mesh.getCallQueuePosition())
            assertTrue(mesh.isCallConnecting())
            assertFalse(mesh.isTransmitting())
            Thread.sleep(1200L)
            assertFalse("Queue acknowledgment did not renew the waiting timeout", timedOut.get())
            mesh.handleCallQueuedByRemote(node.nodeId, 0)
            instrumentation.waitForIdleSync()
            assertEquals(0, mesh.getCallQueuePosition())
            instrumentation.runOnMainSync { mesh.handleOfficerCallEnded(node.nodeId, node.houseName) }
            instrumentation.waitForIdleSync()
            assertNull(mesh.getCallQueuePosition())
            assertNull(field(mesh, "queueRefreshRunnable").get(mesh))
            assertFalse(mesh.isInCall())
        } finally {
            instrumentation.runOnMainSync {
                watchdogHandler.removeCallbacks(watchdog)
                field(mesh, "incomingCallWatchdogRunnable").set(mesh, null)
                mesh.handleOfficerCallEnded(node.nodeId, node.houseName)
                inCall.set(false)
                nodeField.set(mesh, null)
                field(mesh, "awaitingCallAnswer").setBoolean(mesh, false)
            }
        }
    }
}
