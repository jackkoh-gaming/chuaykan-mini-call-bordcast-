package com.rescue.alert.model

import org.json.JSONObject

/**
 * Represents an emergency evacuation center, temporary shelter,
 * or safe parking area during flood/natural disasters.
 */
data class EvacuationSite(
    val siteId: String,
    val name: String,
    val siteType: String, // SHELTER (ศูนย์อพยพ/พักพิง), PARKING (ที่จอดรถปลอดภัย), RELIEF (ศูนย์ช่วยเหลือ)
    val latitude: Double,
    val longitude: Double,
    val capacity: Int = 100,
    val contactPhone: String = "",
    val notes: String = "",
    val isActive: Boolean = true
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("site_id", siteId)
            put("name", name)
            put("site_type", siteType)
            put("latitude", latitude)
            put("longitude", longitude)
            put("capacity", capacity)
            put("contact_phone", contactPhone)
            put("notes", notes)
            put("is_active", isActive)
        }
    }

    companion object {
        fun fromJsonObject(json: JSONObject): EvacuationSite {
            val id = json.getString("site_id").trim()
            val name = json.getString("name").trim()
            val lat = json.getDouble("latitude")
            val lng = json.getDouble("longitude")
            val type = json.optString("site_type", "SHELTER").uppercase(java.util.Locale.ROOT)
                .let { if (it == "RELIEF") "RELIEF_CENTER" else it }
            require(id.isNotEmpty() && name.isNotEmpty()) { "Missing site identity" }
            require(lat.isFinite() && lng.isFinite() && lat in -90.0..90.0 && lng in -180.0..180.0) { "Invalid site coordinates" }
            require(type in setOf("SHELTER", "PARKING", "RELIEF_CENTER")) { "Invalid site type" }
            return EvacuationSite(
                siteId = id,
                name = name,
                siteType = type,
                latitude = lat,
                longitude = lng,
                capacity = json.optInt("capacity", 0).coerceAtLeast(0),
                contactPhone = json.optString("contact_phone", ""),
                notes = json.optString("notes", ""),
                isActive = json.getBoolean("is_active")
            )
        }
    }
}
