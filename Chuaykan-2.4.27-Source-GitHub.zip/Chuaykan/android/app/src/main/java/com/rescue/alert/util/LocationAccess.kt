package com.rescue.alert.util

import android.location.Location
import android.location.LocationManager

object LocationAccess {
    fun lastKnown(manager: LocationManager?, provider: String): Location? = try {
        manager?.getLastKnownLocation(provider)
    } catch (_: SecurityException) {
        null
    } catch (_: IllegalArgumentException) {
        null
    }
}
