"""Shared public-source polling. No profiles, coordinates or arbitrary URLs accepted."""
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict

OFFICIAL = 'https://academicndwc.github.io/CBS-DashBoard/data/data.json'
SOURCES = {
    'official': OFFICIAL,
    'dam': 'https://app.rid.go.th/reservoir/api/dam/public',
    'reservoir': 'https://app.rid.go.th/reservoir/api/reservoir/public',
    'middle': 'https://app.rid.go.th/reservoir/api/rsvmiddles',
    'water': 'https://api-v3.thaiwater.net/api/v1/thaiwater30/public/waterlevel',
    'tmd': 'https://www5.tmd.go.th/api/xml/CAP',
    'radio': 'https://api-ott.prd.go.th/api/v1/radio/all',
    'radio_detail': 'https://api-ott.prd.go.th/api/v1/home/radio/detail',
    'nbtc': 'https://datacatalog.nbtc.go.th/api/3/action/datastore_search',
}

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old, new = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if new.scheme != 'https' or new.netloc != old.netloc:
            raise ValueError('Public source redirect refused')
        return super().redirect_request(req, fp, code, msg, headers, newurl)

class PublicDataCache:
    def __init__(self):
        self.lock = threading.Lock()
        self.fetch_locks = [threading.Lock() for _ in range(16)]
        self.fetch_slots = threading.BoundedSemaphore(4)
        self.entries = OrderedDict()
        self.errors = {}
        self.etags = {}
        self.stop_event = threading.Event()
        self.opener = urllib.request.build_opener(SafeRedirect())
        for name in ('official', 'dam', 'reservoir', 'water', 'tmd', 'radio'):
            self.entries[(name, '', b'')] = None

    def key(self, source, query='', body=b''):
        if source not in SOURCES or len(query) > 256 or len(body) > 256:
            raise ValueError('Unknown public source')
        params = urllib.parse.parse_qs(query, strict_parsing=True) if query else {}
        if source == 'nbtc':
            if set(params) != {'resource_id', 'limit', 'offset'} or any(len(v) != 1 for v in params.values()):
                raise ValueError('Invalid catalog query')
            if params['resource_id'][0] != 'fffc25e6-660f-4874-a874-a8f15e5303df':
                raise ValueError('Invalid catalog resource')
            if not 1 <= int(params['limit'][0]) <= 1000 or not 0 <= int(params['offset'][0]) <= 10000:
                raise ValueError('Invalid catalog page')
        elif params:
            raise ValueError('Public query refused')
        if body:
            if source == 'middle':
                if not re.fullmatch(rb'date=\d{4}-\d{2}-\d{2}', body):
                    raise ValueError('Only public report date allowed')
            elif source == 'radio_detail':
                obj = json.loads(body)
                if set(obj) != {'radio'} or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', str(obj['radio'])):
                    raise ValueError('Only public station ID allowed')
                body = json.dumps(obj, sort_keys=True).encode()
            else:
                raise ValueError('Public request body refused')
        elif source in ('middle', 'radio_detail'):
            raise ValueError('Public request body required')
        return source, urllib.parse.urlencode(sorted((k, v[0]) for k, v in params.items())), body

    def ttl(self, key):
        return 1 if key[0] == 'official' else 300

    def get(self, key):
        with self.fetch_locks[hash(key) % len(self.fetch_locks)]:
            with self.lock:
                entry = self.entries.get(key)
                if entry and time.monotonic() - entry[2] < self.ttl(key):
                    return entry
                if time.monotonic() - self.errors.get(key, -1000) < 15:
                    raise OSError('Public source unavailable')
            name, query, body = key
            url = SOURCES[name] + ('?' + query if query else '')
            content_type = 'application/json' if name == 'radio_detail' else 'application/x-www-form-urlencoded'
            request = urllib.request.Request(url, data=body or None, headers={
                'User-Agent': 'Chuaykan-public-data/1', 'Content-Type': content_type,
                'Accept': 'application/xml, text/xml' if name == 'tmd' else 'application/json',
            })
            if entry and key in self.etags:
                request.add_header('If-None-Match', self.etags[key])
            try:
                try:
                    with self.fetch_slots, self.opener.open(request, timeout=8) as response:
                        raw = response.read(8 * 1024 * 1024 + 1)
                        if len(raw) > 8 * 1024 * 1024 or not raw:
                            raise ValueError('Invalid public response size')
                        if name != 'tmd':
                            parsed = json.loads(raw)
                            if name == 'official' and not isinstance(parsed.get('fact_cb'), list):
                                raise ValueError('Missing official records')
                        entry = raw, response.headers.get('Content-Type', 'application/json'), time.monotonic()
                        tag = response.headers.get('ETag')
                        if tag:
                            self.etags[key] = tag
                except urllib.error.HTTPError as error:
                    if error.code != 304 or not entry:
                        raise
                    entry = entry[0], entry[1], time.monotonic()
            except Exception:
                with self.lock:
                    self.errors[key] = time.monotonic()
                    if len(self.errors) > 128:
                        self.errors.pop(next(iter(self.errors)))
                raise
            with self.lock:
                self.entries[key] = entry
                self.entries.move_to_end(key)
                self.errors.pop(key, None)
                while len(self.entries) > 64 or sum(len(v[0]) for v in self.entries.values() if v) > 32 * 1024 * 1024:
                    removed, _ = self.entries.popitem(last=False)
                    self.etags.pop(removed, None)
            return entry

    def start(self):
        def poll(source):
            while not self.stop_event.is_set():
                with self.lock:
                    keys = [key for key in self.entries if key[0] == source]
                if source in ('official', 'dam', 'reservoir', 'water', 'tmd', 'radio'):
                    keys.append(self.key(source))
                if source == 'middle':
                    from datetime import datetime
                    from zoneinfo import ZoneInfo
                    date = datetime.now(ZoneInfo('Asia/Bangkok')).strftime('%Y-%m-%d')
                    keys.append(self.key(source, body=('date=' + date).encode()))
                if source == 'nbtc':
                    keys.append(self.key(source, 'resource_id=fffc25e6-660f-4874-a874-a8f15e5303df&limit=300&offset=0'))
                for key in set(keys):
                    if self.stop_event.is_set():
                        return
                    try:
                        self.get(key)
                    except Exception:
                        pass  # API reports failure; no fabricated success or stale replacement.
                self.stop_event.wait(1)
        for source in SOURCES:
            threading.Thread(target=poll, args=(source,), name='Oracle-Public-' + source, daemon=True).start()
