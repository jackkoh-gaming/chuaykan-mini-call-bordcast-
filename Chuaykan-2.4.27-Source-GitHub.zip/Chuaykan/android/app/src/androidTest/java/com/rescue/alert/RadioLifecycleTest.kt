package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.data.AmRadioPlayer
import com.rescue.alert.data.AmRadioRepository
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import com.rescue.alert.model.AmStation
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(AndroidJUnit4::class)
class RadioLifecycleTest {
    private val instrument = InstrumentationRegistry.getInstrumentation()
    private lateinit var wav: File
    private val station = AmStation("test", "Silent local test", "0", streamUrl = null)
    private fun main(block: () -> Unit) = instrument.runOnMainSync(block)
    @Before fun setup() {
        wav = File(instrument.targetContext.cacheDir, "radio-regression.wav")
        val size = 160000
        val b = ByteBuffer.allocate(44 + size).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt(36 + size).put("WAVEfmt ".toByteArray())
        b.putInt(16).putShort(1.toShort()).putShort(1.toShort()).putInt(8000)
        b.putInt(16000).putShort(2.toShort()).putShort(16.toShort())
        b.put("data".toByteArray()).putInt(size)
        wav.writeBytes(b.array())
        main { AmRadioPlayer.stop() }
    }
    @After fun cleanup() { main { AmRadioPlayer.stop() }; wav.delete() }
    private fun awaitPlaying() {
        val end = System.currentTimeMillis() + 5000
        while (System.currentTimeMillis() < end) {
            var playing = false
            main { playing = AmRadioPlayer.isPlaying() }
            if (playing) return
            Thread.sleep(50)
        }
        main { assertEquals(AmRadioPlayer.State.PLAYING, AmRadioPlayer.state) }
    }
    @Test fun stopDuringPrepareDoesNotRestart() {
        main { repeat(20) { AmRadioPlayer.play(station, wav.absolutePath); AmRadioPlayer.stop() } }
        Thread.sleep(500)
        main { assertEquals(AmRadioPlayer.State.IDLE, AmRadioPlayer.state) }
    }
    @Test fun pauseDuringPrepareCanResumeResolvedUrl() {
        main { AmRadioPlayer.play(station, wav.absolutePath); AmRadioPlayer.pause() }
        Thread.sleep(300)
        main { assertEquals(AmRadioPlayer.State.PAUSED, AmRadioPlayer.state); AmRadioPlayer.resume() }
        awaitPlaying()
    }
    @Test fun rapidSwitchKeepsLatestStation() {
        main {
            repeat(10) { AmRadioPlayer.play(station.copy(id = "old-$it"), wav.absolutePath) }
            AmRadioPlayer.play(station.copy(id = "latest"), wav.absolutePath)
        }
        awaitPlaying()
        main { assertEquals("latest", AmRadioPlayer.currentStation?.id) }
    }
    @Test fun errorCanBeStoppedAndReplaced() {
        main {
            AmRadioPlayer.play(station, File(wav.parentFile, "missing.wav").absolutePath)
            assertEquals(AmRadioPlayer.State.ERROR, AmRadioPlayer.state)
            AmRadioPlayer.stop()
            assertEquals(AmRadioPlayer.State.IDLE, AmRadioPlayer.state)
            AmRadioPlayer.play(station, wav.absolutePath)
        }
        awaitPlaying()
    }
    @Test fun officialLiveRadioActuallyAdvancesPlayback() {
        val directoryReady = CountDownLatch(1)
        var liveStation: AmStation? = null
        AmRadioRepository.getStations { stations ->
            liveStation = stations.firstOrNull { it.frequency == "819" && it.modulation == "AM" }
            directoryReady.countDown()
        }
        assertTrue("Directory callback timed out", directoryReady.await(30, TimeUnit.SECONDS))
        val selected = requireNotNull(liveStation)
        val urlReady = CountDownLatch(1)
        var stream: String? = null
        AmRadioRepository.fetchStreamUrl(selected) { stream = it; urlReady.countDown() }
        assertTrue(urlReady.await(20, TimeUnit.SECONDS))
        assertTrue("No live station URL", stream?.startsWith("https://") == true)
        main { AmRadioPlayer.play(selected, requireNotNull(stream)) }
        val deadline = System.currentTimeMillis() + 30000
        var position = 0
        while (System.currentTimeMillis() < deadline && position < 2000) {
            main {
                if (AmRadioPlayer.isPlaying()) {
                    val field = AmRadioPlayer::class.java.getDeclaredField("mediaPlayer")
                    field.isAccessible = true
                    position = (field.get(AmRadioPlayer) as android.media.MediaPlayer).currentPosition
                }
            }
            Thread.sleep(200)
        }
        main { assertEquals(AmRadioPlayer.State.PLAYING, AmRadioPlayer.state) }
        assertTrue("Real HLS decoder did not advance: $position", position >= 2000)
    }

}
