package com.rescue.alert.data

import android.text.Html
import android.util.Xml
import com.rescue.alert.model.DisasterNewsItem
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Public TMD CAP RSS; item publication dates, not the channel's generated time. */
internal object TmdNewsFeed {
    const val URL = "https://www5.tmd.go.th/api/xml/CAP"
    private var etag: String? = null
    private var hasSnapshot = false

    fun fetch(): List<DisasterNewsItem>? {
        val connection = (com.rescue.alert.network.PublicDataGateway.open(URL(URL)) as HttpURLConnection).apply {
            connectTimeout = 7000; readTimeout = 10000
            setRequestProperty("Accept", "application/rss+xml, application/xml")
            setRequestProperty("Cache-Control", "no-cache")
            if (etag != null) setRequestProperty("If-None-Match", etag)
        }
        try {
            if (connection.responseCode == 304 && hasSnapshot) return null
            require(connection.responseCode == 200) { "TMD HTTP ${connection.responseCode}" }
            val parsed = parse(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            etag = connection.getHeaderField("ETag")
            hasSnapshot = true
            return parsed
        } finally { connection.disconnect() }
    }

    fun parse(xml: String): List<DisasterNewsItem> {
        require(!xml.contains("<!DOCTYPE", true) && !xml.contains("<!ENTITY", true))
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xml))
        val result = mutableListOf<DisasterNewsItem>()
        var fields: MutableMap<String, String>? = null
        var rss = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG) {
                if (parser.name == "rss") rss = true
                if (parser.name == "item") fields = mutableMapOf()
                else if (fields != null && parser.name in setOf("title", "link", "description", "guid", "pubDate")) {
                    val key = parser.name
                    fields[key] = parser.nextText().trim()
                }
            } else if (parser.eventType == XmlPullParser.END_TAG && parser.name == "item") {
                fields?.let { item(it)?.let(result::add) }
                fields = null
            }
            parser.next()
        }
        require(rss) { "Not TMD RSS" }
        return result.distinctBy { it.id }.sortedByDescending { it.dateStr }
    }

    private fun item(fields: Map<String, String>): DisasterNewsItem? {
        val title = fields["title"].orEmpty()
        val id = fields["guid"].orEmpty()
        val rawDate = fields["pubDate"].orEmpty()
        val original = runCatching { URI(fields["link"].orEmpty()) }.getOrNull() ?: return null
        if (title.isBlank() || id.isBlank() || rawDate.isBlank() || original.scheme != "https" || original.userInfo != null) return null
        if (original.host !in setOf("www.tmd.go.th", "www5.tmd.go.th")) return null
        // Official www5 serves the same CAP path/identifier with a complete TLS chain.
        val url = URI("https", null, "www5.tmd.go.th", -1, original.path, original.query, original.fragment).toASCIIString()
        val published = runCatching {
            SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).apply { isLenient = false }.parse(rawDate)
        }.getOrNull() ?: return null
        val date = SimpleDateFormat("yyyyMMdd HH:mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Asia/Bangkok")
        }.format(published)
        @Suppress("DEPRECATION")
        val body = Html.fromHtml(fields["description"].orEmpty()).toString().trim()
        return DisasterNewsItem("TMD_$id", "กรมอุตุนิยมวิทยา", "TMD", title, date,
            "ประกาศเตือนภัยกรมอุตุฯ", body.take(240), body, url, isLive = false)
    }
}
