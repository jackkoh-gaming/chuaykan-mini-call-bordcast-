"""Private TLS identity and locally shared pairing credential for the EOC gateway."""
import hashlib
import json
import os
import re
import secrets
import ssl
import subprocess
from pathlib import Path
from src.core.config import PROJECT_ROOT, USER_DATA_ROOT


class GatewaySecurity:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory else USER_DATA_ROOT / '.secrets/gateway-network'
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.directory, 0o700)
        self.key = self.directory / 'tls-key.pem'
        self.cert = self.directory / 'tls-cert.pem'
        self.token_file = self.directory / 'access-token'
        if self.key.exists() != self.cert.exists():
            raise RuntimeError('TLS identity incomplete; refusing insecure fallback')
        if not self.key.exists():
            previous = os.umask(0o077)
            try:
                import sys
                if sys.platform == "win32":
                    from src.platforms.windows_tls import create_identity
                    create_identity(self.key, self.cert)
                else:
                    subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
                        '-keyout', str(self.key), '-out', str(self.cert), '-days', '365',
                        '-subj', '/CN=RescueAlert EOC', '-addext',
                        'subjectAltName=DNS:eoc.rescue.local,IP:127.0.0.1'],
                        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
            finally:
                os.umask(previous)
        if not self.token_file.exists():
            fd = os.open(self.token_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as output:
                output.write(secrets.token_urlsafe(32))
        for path in (self.key, self.cert, self.token_file):
            os.chmod(path, 0o600)
        self.officer_token = (self.directory / "officer-token").read_text().strip() if (self.directory / "officer-token").exists() else ""
        cloud_config = self.directory / "cloud.json"
        self.public_url = json.loads(cloud_config.read_text()).get("url") if cloud_config.exists() else None
        self.token = self.token_file.read_text().strip()
        if not re.fullmatch(r'[A-Za-z0-9_-]{43,128}', self.token):
            raise RuntimeError('Invalid gateway credential; refusing insecure fallback')
        der = ssl.PEM_cert_to_DER_cert(self.cert.read_text())
        self.fingerprint = hashlib.sha256(der).hexdigest()
        self.context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.context.minimum_version = ssl.TLSVersion.TLSv1_2
        self.context.load_cert_chain(self.cert, self.key)

    def pairing(self, host, port):
        return {'url': self.public_url or f'https://{host}:{port}', 'certificate_sha256': self.fingerprint,
                'access_key': self.token}

    def show_pairing(self, parent, host, port):
        from PySide6.QtCore import Qt
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        dialog = QDialog(parent)
        dialog.setWindowTitle('เกตเวย์สาธารณะ Oracle')
        dialog.resize(530, 200)
        layout = QVBoxLayout(dialog)
        label = QLabel('มือถือเชื่อมต่อและลงทะเบียนกับเกตเวย์โดยอัตโนมัติ')
        label.setWordWrap(True)
        layout.addWidget(label)
        endpoint = QLabel(self.public_url or 'ยังไม่ได้เชื่อมต่อเกตเวย์สาธารณะ')
        endpoint.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(endpoint)
        close = QPushButton('ปิด')
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.exec()
