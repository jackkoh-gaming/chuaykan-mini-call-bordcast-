package com.rescue.alert.model

/**
 * Data model representing a disaster news bulletin from DDPM (ปภ.) or TMD (กรมอุตุนิยมวิทยา).
 * Includes title, source, daily timestamp, full description, and official web link.
 */
data class DisasterNewsItem(
    val id: String,
    val source: String,
    val sourceCode: String,      // "DDPM" or "TMD"
    val title: String,
    val dateStr: String,
    val category: String,
    val summary: String,
    val details: String,
    val webUrl: String,
    val severity: String = "WARNING",
    val isLive: Boolean = false
)
