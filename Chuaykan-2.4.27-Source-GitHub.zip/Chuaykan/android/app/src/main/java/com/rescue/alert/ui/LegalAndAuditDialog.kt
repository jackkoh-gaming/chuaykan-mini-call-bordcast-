package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.security.AuditDocumentExporter

/**
 * LegalAndAuditDialog:
 * Displays:
 * 1. ข้อตกลงในการใช้งาน (Terms of Service)
 * 2. ข้อตกลงข้อมูลส่วนบุคคล (PDPA Compliance & Privacy Policy)
 * 3. ข้อมูลที่ตรวจสอบได้ (Verifiable Official Sources & ECDSA Verification)
 */
object LegalAndAuditDialog {

    fun show(context: Context, initialTab: Int = 0) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_legal_audit, null)
        dialog.setContentView(dialogView)
        dialog.setCanceledOnTouchOutside(false)

        val btnTabTerms = dialogView.findViewById<Button>(R.id.btnTabTerms)
        val btnTabPrivacy = dialogView.findViewById<Button>(R.id.btnTabPrivacy)
        val btnTabAudit = dialogView.findViewById<Button>(R.id.btnTabAudit)

        val layoutTerms = dialogView.findViewById<LinearLayout>(R.id.layoutTermsContent)
        val layoutPrivacy = dialogView.findViewById<LinearLayout>(R.id.layoutPrivacyContent)
        val layoutAudit = dialogView.findViewById<LinearLayout>(R.id.layoutAuditContent)

        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseLegal)

        fun switchTab(tabIndex: Int) {
            when (tabIndex) {
                0 -> {
                    layoutTerms.visibility = View.VISIBLE
                    layoutPrivacy.visibility = View.GONE
                    layoutAudit.visibility = View.GONE

                    btnTabTerms.setBackgroundResource(R.drawable.bg_legal_tab_active)
                    btnTabTerms.setTextColor(Color.WHITE)

                    btnTabPrivacy.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabPrivacy.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))

                    btnTabAudit.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabAudit.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                }
                1 -> {
                    layoutTerms.visibility = View.GONE
                    layoutPrivacy.visibility = View.VISIBLE
                    layoutAudit.visibility = View.GONE

                    btnTabTerms.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabTerms.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))

                    btnTabPrivacy.setBackgroundResource(R.drawable.bg_legal_tab_active)
                    btnTabPrivacy.setTextColor(Color.WHITE)

                    btnTabAudit.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabAudit.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                }
                2 -> {
                    layoutTerms.visibility = View.GONE
                    layoutPrivacy.visibility = View.GONE
                    layoutAudit.visibility = View.VISIBLE

                    btnTabTerms.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabTerms.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))

                    btnTabPrivacy.setBackgroundResource(R.drawable.bg_legal_tab_inactive)
                    btnTabPrivacy.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))

                    btnTabAudit.setBackgroundResource(R.drawable.bg_legal_tab_active)
                    btnTabAudit.setTextColor(Color.WHITE)
                }
            }
        }

        btnTabTerms.setOnClickListener { switchTab(0) }
        btnTabPrivacy.setOnClickListener { switchTab(1) }
        btnTabAudit.setOnClickListener { switchTab(2) }

        switchTab(initialTab)

        val btnDownloadAuditDoc = dialogView.findViewById<Button>(R.id.btnDownloadAuditDoc)
        val btnExportPoliceLog = dialogView.findViewById<Button>(R.id.btnExportPoliceLog)

        btnDownloadAuditDoc?.setOnClickListener {
            AuditDocumentExporter.exportGovernmentAuditDoc(context)
        }

        btnExportPoliceLog?.setOnClickListener {
            AuditDocumentExporter.exportPoliceAuditLog(context)
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
        val metrics = context.resources.displayMetrics
        dialog.window?.setLayout(
            (metrics.widthPixels * 0.94).toInt(),
            (metrics.heightPixels * 0.88).toInt()
        )
    }
}
