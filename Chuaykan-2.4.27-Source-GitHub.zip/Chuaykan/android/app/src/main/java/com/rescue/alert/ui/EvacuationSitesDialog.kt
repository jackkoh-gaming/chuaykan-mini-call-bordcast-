package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.data.EvacuationSiteRepository
import com.rescue.alert.model.EvacuationSite

object EvacuationSitesDialog {

    fun show(
        context: Context,
        userLat: Double,
        userLng: Double,
        onFocusLocation: (Double, Double) -> Unit
    ) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_evacuation_sites, null)
        dialog.setContentView(dialogView)

        dialog.window?.let { window ->
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.setDimAmount(0.75f)
        }

        val tvDialogSiteCountBadge = dialogView.findViewById<TextView>(R.id.tvDialogSiteCountBadge)
        val etSearchSites = dialogView.findViewById<EditText>(R.id.etSearchSites)
        val btnTabAll = dialogView.findViewById<Button>(R.id.btnTabAllSites)
        val btnTabShelters = dialogView.findViewById<Button>(R.id.btnTabShelters)
        val btnTabParking = dialogView.findViewById<Button>(R.id.btnTabParking)
        val layoutContainer = dialogView.findViewById<LinearLayout>(R.id.layoutSitesCardsContainer)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseSitesDialog)

        var selectedTab = "ALL" // "ALL", "SHELTER", "PARKING"
        var searchQuery = ""

        val repo = EvacuationSiteRepository.getInstance(context)

        fun updateTabStyles() {
            val activeBg = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_active)
            val inactiveBg = ContextCompat.getDrawable(context, R.drawable.bg_tactical_tab_inactive)
            val white = Color.WHITE
            val slate = ContextCompat.getColor(context, R.color.tactical_text_secondary)

            btnTabAll.background = if (selectedTab == "ALL") activeBg else inactiveBg
            btnTabAll.setTextColor(if (selectedTab == "ALL") white else slate)
            btnTabAll.setTypeface(null, if (selectedTab == "ALL") Typeface.BOLD else Typeface.NORMAL)

            btnTabShelters.background = if (selectedTab == "SHELTER") activeBg else inactiveBg
            btnTabShelters.setTextColor(if (selectedTab == "SHELTER") white else slate)
            btnTabShelters.setTypeface(null, if (selectedTab == "SHELTER") Typeface.BOLD else Typeface.NORMAL)

            btnTabParking.background = if (selectedTab == "PARKING") activeBg else inactiveBg
            btnTabParking.setTextColor(if (selectedTab == "PARKING") white else slate)
            btnTabParking.setTypeface(null, if (selectedTab == "PARKING") Typeface.BOLD else Typeface.NORMAL)
        }

        fun renderCards() {
            layoutContainer.removeAllViews()

            val filterType = if (selectedTab == "ALL") null else selectedTab
            val allSorted = repo.getSitesSortedByDistance(userLat, userLng, filterType)

            val filtered = if (searchQuery.isBlank()) {
                allSorted
            } else {
                val q = searchQuery.lowercase().trim()
                allSorted.filter {
                    it.first.name.lowercase().contains(q) ||
                    it.first.notes.lowercase().contains(q) ||
                    it.first.siteType.lowercase().contains(q)
                }
            }

            tvDialogSiteCountBadge.text = "${filtered.size} แห่ง"

            if (filtered.isEmpty()) {
                val tvEmpty = TextView(context).apply {
                    text = "ยังไม่มีข้อมูลสถานที่ในหมวดนี้จากศูนย์สั่งการ\nตรวจสอบการเชื่อมต่อและที่อยู่ Gateway ในการตั้งค่า"
                    textSize = 14f
                    setTextColor(ContextCompat.getColor(context, R.color.tactical_text_muted))
                    setPadding(16, 32, 16, 32)
                    gravity = android.view.Gravity.CENTER
                }
                layoutContainer.addView(tvEmpty)
                return
            }

            for (pair in filtered) {
                val site = pair.first
                val distKm = pair.second

                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    background = ContextCompat.getDrawable(context, R.drawable.bg_hotlines_card)
                    setPadding(24, 20, 24, 20)
                    val lp = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    lp.setMargins(0, 0, 0, 16)
                    layoutParams = lp
                }

                // Row 1: Badges (Type & Distance)
                val rowHeader = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                }

                val isParking = site.siteType.equals("PARKING", ignoreCase = true)
                val badgeText = if (isParking) "[P] จุดจอดรถปลอดภัย" else if (site.siteType == "RELIEF_CENTER") "[+] ศูนย์ช่วยเหลือ" else "[S] ศูนย์พักพิง/อพยพ"
                val badgeColor = if (isParking) com.rescue.alert.util.ThemePalette.color("#38BDF8") else Color.parseColor("#10B981")
                val badgeBg = if (isParking) R.drawable.bg_chip_am_station_selected else R.drawable.bg_card_safe

                val tvTypeBadge = TextView(context).apply {
                    text = badgeText
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(badgeColor)
                    background = ContextCompat.getDrawable(context, badgeBg)
                    setPadding(14, 4, 14, 4)
                }
                rowHeader.addView(tvTypeBadge)

                val tvDist = TextView(context).apply {
                    text = if (distKm.isFinite()) "ห่าง $distKm กม." else "รอตำแหน่ง GPS"
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#FBBF24"))
                    val params = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        marginStart = 12
                    }
                    layoutParams = params
                }
                rowHeader.addView(tvDist)

                card.addView(rowHeader)

                // Site Name
                val tvName = TextView(context).apply {
                    text = site.name
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(ContextCompat.getColor(context, R.color.tactical_text_primary))
                    setPadding(0, 10, 0, 4)
                }
                card.addView(tvName)

                // Capacity & Contact Info
                val infoText = buildString {
                    if (site.capacity > 0) {
                        append("รองรับได้ ${site.capacity} ${if (isParking) "คัน" else "คน"}")
                    }
                    if (site.contactPhone.isNotBlank()) {
                        if (isNotEmpty()) append(" • ")
                        append("โทร: ${site.contactPhone}")
                    }
                }
                if (infoText.isNotBlank()) {
                    val tvInfo = TextView(context).apply {
                        text = infoText
                        textSize = 12f
                        setTextColor(ContextCompat.getColor(context, R.color.tactical_text_secondary))
                        setPadding(0, 0, 0, 4)
                    }
                    card.addView(tvInfo)
                }

                // Notes
                if (site.notes.isNotBlank()) {
                    val tvNotes = TextView(context).apply {
                        text = site.notes
                        textSize = 12f
                        setTextColor(ContextCompat.getColor(context, R.color.tactical_text_muted))
                        setPadding(0, 2, 0, 10)
                    }
                    card.addView(tvNotes)
                }

                // Action Buttons (View Map, Dial Phone)
                val rowActions = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                }

                val btnFocusMap = Button(context).apply {
                    text = "ดูบนแผนที่"
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    background = ContextCompat.getDrawable(context, R.drawable.bg_button_primary)
                    setPadding(18, 6, 18, 6)
                    val p = LinearLayout.LayoutParams(0, 80, 1f).apply {
                        marginEnd = 10
                    }
                    layoutParams = p
                    setOnClickListener {
                        onFocusLocation(site.latitude, site.longitude)
                        dialog.dismiss()
                    }
                }
                rowActions.addView(btnFocusMap)

                if (site.contactPhone.isNotBlank()) {
                    val btnCall = Button(context).apply {
                        text = "โทรฉุกเฉิน"
                        textSize = 12f
                        setTextColor(Color.WHITE)
                        background = ContextCompat.getDrawable(context, R.drawable.bg_tactical_btn_call)
                        setPadding(18, 6, 18, 6)
                        val p = LinearLayout.LayoutParams(0, 80, 1f)
                        layoutParams = p
                        setOnClickListener {
                            try {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${site.contactPhone.replace("-", "").trim()}")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "ไม่สามารถเปิดแป้นโทรศัพท์ได้", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    rowActions.addView(btnCall)
                }

                card.addView(rowActions)
                layoutContainer.addView(card)
            }
        }

        btnTabAll.setOnClickListener {
            selectedTab = "ALL"
            updateTabStyles()
            renderCards()
        }
        btnTabShelters.setOnClickListener {
            selectedTab = "SHELTER"
            updateTabStyles()
            renderCards()
        }
        btnTabParking.setOnClickListener {
            selectedTab = "PARKING"
            updateTabStyles()
            renderCards()
        }

        etSearchSites.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString() ?: ""
                renderCards()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        updateTabStyles()
        renderCards()
        val listener: (List<EvacuationSite>) -> Unit = { renderCards() }
        repo.addListener(listener)
        dialog.setOnDismissListener { repo.removeListener(listener) }
        dialog.show()
        repo.syncFromGatewayAsync()
    }
}
