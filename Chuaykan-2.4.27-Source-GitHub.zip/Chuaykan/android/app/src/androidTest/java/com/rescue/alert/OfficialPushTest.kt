package com.rescue.alert

import android.content.Context
import android.content.ContextWrapper
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.google.firebase.messaging.RemoteMessage
import com.rescue.alert.model.DisasterStateManager
import com.rescue.alert.receiver.AlertPushReceiver
import com.rescue.alert.source.OfficialCellBroadcastSync
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Test-only push hints/probes; never insert announcements or sound an alarm. */
@RunWith(AndroidJUnit4::class)
class OfficialPushTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private fun data(type: String = "official_feed_changed") = mapOf(
        "type" to type, "protocol" to "1", "revision" to "a".repeat(64),
        "sent_at" to System.currentTimeMillis().toString()
    )

    private fun receive(data: Map<String, String>) {
        val receiver = AlertPushReceiver()
        ContextWrapper::class.java.getDeclaredMethod("attachBaseContext", Context::class.java).apply {
            isAccessible = true
        }.invoke(receiver, context)
        receiver.onMessageReceived(RemoteMessage.Builder("test-only-sender").setData(data).build())
    }

    @Test fun validHintAndProbeAreAccepted() {
        assertTrue(OfficialCellBroadcastSync.isValidPush(data()))
        assertTrue(OfficialCellBroadcastSync.isValidPush(data("official_push_probe")))
    }

    @Test fun unknownProtocolTypeOrInvalidRevisionIsRejected() {
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() + ("protocol" to "2")))
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() + ("type" to "untrusted")))
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() + ("revision" to "invalid")))
    }

    @Test fun expiredFutureOrMissingTimestampIsRejected() {
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() - "sent_at"))
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() + ("sent_at" to (System.currentTimeMillis() - 301_000).toString())))
        assertFalse(OfficialCellBroadcastSync.isValidPush(data() + ("sent_at" to (System.currentTimeMillis() + 61_000).toString())))
    }

    @Test fun probeRecordsReceiptWithoutCreatingAnIncident() {
        val incident = DisasterStateManager.getAlertId(context)
        val before = System.currentTimeMillis()
        receive(data("official_push_probe"))
        val prefs = context.getSharedPreferences("official_push_status", Context.MODE_PRIVATE)
        assertEquals("official_push_probe", prefs.getString("received_type", ""))
        assertTrue(prefs.getLong("received_at", 0) >= before)
        assertEquals(incident, DisasterStateManager.getAlertId(context))
    }

    @Test fun invalidHintDoesNotRecordReceiptOrCreateAnIncident() {
        val prefs = context.getSharedPreferences("official_push_status", Context.MODE_PRIVATE)
        val before = prefs.getLong("received_at", 0)
        val incident = DisasterStateManager.getAlertId(context)
        receive(data() + ("revision" to "invalid"))
        assertEquals(before, prefs.getLong("received_at", 0))
        assertEquals(incident, DisasterStateManager.getAlertId(context))
    }

    @Test fun validHintRefreshesTheRealSourceThroughTheGpsRepository() {
        val before = System.currentTimeMillis()
        receive(data()) // Test-only wake-up hint; source records are never replaced.
        val manager = WorkManager.getInstance(context)
        val deadline = before + 60_000
        var succeeded = false
        while (System.currentTimeMillis() < deadline) {
            val works = manager.getWorkInfosForUniqueWork("official_cell_broadcast_push").get()
            val prefs = context.getSharedPreferences("official_push_status", Context.MODE_PRIVATE)
            succeeded = works.lastOrNull()?.state == WorkInfo.State.SUCCEEDED && prefs.getLong("evaluated_at", 0) >= before
            if (succeeded) break
            Thread.sleep(250)
        }
        assertTrue("Official source refresh did not complete through GPS policy", succeeded)
    }
}
