#!/usr/bin/env bash
set -euo pipefail

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"

APP_ID="thai-disaster-monitor"
APP_NAME="Chuaykan (Mini Call Broadcast)"
APP_NAME_TH="ช่วยกัน (มินิ คอลบอร์ดเคส)"
ICON_SOURCE="$DIR/assets/icons/disaster_icon.png"
ICON_TARGET="$HOME/.local/share/icons/hicolor/512x512/apps/${APP_ID}.png"
LAUNCHER_TARGET="$HOME/.local/share/applications/${APP_ID}.desktop"
DESKTOP_TARGET="$HOME/Desktop/${APP_ID}.desktop"

install_desktop_integration() {
    # User-local installation: opening EOC never requires sudo. Re-running this
    # script refreshes the icon and launcher after assets are changed.
    if [[ ! -f "$ICON_SOURCE" ]]; then
        echo "Warning: EOC icon not found: $ICON_SOURCE" >&2
        return 0
    fi

    install -Dm644 "$ICON_SOURCE" "$ICON_TARGET"
    mkdir -p "$(dirname "$LAUNCHER_TARGET")"
    cat > "$LAUNCHER_TARGET" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=$APP_NAME
Name[th]=$APP_NAME_TH
GenericName=Disaster Early Warning System
GenericName[th]=ระบบเตือนภัยพิบัติล่วงหน้า
Comment=Real-time Thailand disaster command center
Comment[th]=ศูนย์สั่งการภัยพิบัติและกู้ภัยฉุกเฉินแบบเรียลไทม์
Exec=$DIR/run.sh
Path=$DIR
Icon=$APP_ID
Terminal=false
StartupNotify=true
Categories=Utility;
Keywords=disaster;weather;earthquake;flood;thai;eoc;
EOF

    # Keep a clickable Desktop icon when the desktop folder exists. A failure
    # here must never prevent the EOC application itself from starting.
    if [[ -d "$HOME/Desktop" ]]; then
        install -m755 "$LAUNCHER_TARGET" "$DESKTOP_TARGET" || true
        command -v gio >/dev/null 2>&1 &&             gio set "$DESKTOP_TARGET" metadata::trusted true >/dev/null 2>&1 || true
    fi

    command -v update-desktop-database >/dev/null 2>&1 &&         update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
}

install_desktop_integration

if [[ "${1:-}" == "--install-desktop-integration" ]]; then
    exit 0
fi

export QTWEBENGINE_CHROMIUM_FLAGS="--no-sandbox --disable-dev-shm-usage"
export QTWEBENGINE_DISABLE_SANDBOX=1

echo "=================================================================="
echo "LAUNCHING THAILAND DISASTER EOC COMMAND CENTER"
echo "=================================================================="
exec python3 main.py "$@"
