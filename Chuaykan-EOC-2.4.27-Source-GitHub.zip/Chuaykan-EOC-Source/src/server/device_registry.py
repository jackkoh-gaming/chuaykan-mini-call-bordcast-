"""Server-issued device credentials; registration retries require a private installation proof."""
from contextlib import closing
import hashlib
import hmac
import re
import sqlite3
import threading
import time

class DeviceRegistry:
    def __init__(self, path, secret):
        self.path = str(path)
        self.secret = secret.encode()
        self.lock = threading.Lock()
        self.rates = {}
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS gateway_devices (client_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, proof_hash TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL)")
            db.execute("CREATE UNIQUE INDEX IF NOT EXISTS gateway_devices_node ON gateway_devices(device_id)")

    def register(self, payload, address):
        client = str(payload.get('client_id', ''))
        device = str(payload.get('device_id', ''))
        proof = str(payload.get('proof', ''))
        if not re.fullmatch(r'[a-zA-Z0-9_-]{16,64}', client) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,128}', device) or not re.fullmatch(r'[a-zA-Z0-9_-]{43,128}', proof):
            raise ValueError('Invalid registration')
        token = hmac.new(self.secret, (client + ':' + proof).encode(), hashlib.sha256).hexdigest()
        proof_hash = hashlib.sha256(proof.encode()).hexdigest()
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with self.lock, closing(sqlite3.connect(self.path, timeout=10)) as db, db:
            row = db.execute('SELECT device_id, proof_hash FROM gateway_devices WHERE client_id=?', (client,)).fetchone()
            if row:
                if row[0] != device or not hmac.compare_digest(row[1], proof_hash):
                    raise PermissionError('Registration belongs to another installation')
            else:
                if db.execute("SELECT 1 FROM gateway_devices WHERE device_id=?", (device,)).fetchone():
                    raise PermissionError("Device belongs to another installation")
                now = time.monotonic()
                self.rates = {k:v for k,v in self.rates.items() if now-v[0] < 60}
                since, count = self.rates.get(address, (now, 0))
                if count >= 20 or len(self.rates) >= 4096:
                    raise PermissionError('Registration rate exceeded')
                self.rates[address] = (since, count+1)
                db.execute('INSERT INTO gateway_devices VALUES (?,?,?,?)', (client, device, proof_hash, token_hash))
        return {'status': 'REGISTERED', 'access_token': token}

    def authenticate(self, token):
        if not re.fullmatch(r'[0-9a-f]{64}', token):
            return None
        with closing(sqlite3.connect(self.path, timeout=10)) as db, db:
            row = db.execute('SELECT device_id FROM gateway_devices WHERE token_hash=?', (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
        return row[0] if row else None
