package com.rescue.alert.bluetooth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.rescue.alert.R
import com.rescue.alert.ui.MainActivity

/**
 * Foreground service to maintain continuous Bluetooth Mesh operations (F-07).
 * Prevents Android OS from throttling or killing BLE scanning, advertising,
 * and RFCOMM servers when the app is backgrounded or screen is locked.
 * Automatically releases all mesh resources when the service is stopped (F-08).
 *
 * การตรวจประกาศ ปภ. ใช้ WorkManager periodic (ทุก 15 นาที) ที่ตั้งไว้ใน
 * OfficialCellBroadcastSync.schedule() — ไม่ต้อง poll ซ้ำใน service นี้
 */
class MeshForegroundService : Service() {

    companion object {
        private const val TAG = "MeshForegroundService"
        private const val NOTIFICATION_ID = 20261
        private const val CHANNEL_ID = "rescue_alert_mesh_service_channel"
        private const val EXTRA_ENABLE_MICROPHONE = "enable_microphone"

        private fun canConnect(context: Context): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        fun startService(context: Context) {
            if (!canConnect(context)) return
            val intent = Intent(context, MeshForegroundService::class.java).apply {
                // Calls from a visible activity may enable microphone access for later calls.
                putExtra(EXTRA_ENABLE_MICROPHONE, context is android.app.Activity &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start MeshForegroundService: ${e.message}", e)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, MeshForegroundService::class.java)
            try {
                context.stopService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stop MeshForegroundService: ${e.message}", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!canConnect(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                    intent?.getBooleanExtra(EXTRA_ENABLE_MICROPHONE, false) == true &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                try {
                    startForeground(NOTIFICATION_ID, buildNotification(), type)
                } catch (e: SecurityException) {
                    // A sticky background restart cannot acquire while-in-use microphone permission.
                    startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
                }
            } else {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        } catch (e: Exception) {
            Log.w(TAG, "Unable to start mesh foreground service", e)
            stopSelf()
            return START_NOT_STICKY
        }
        // ดึงประกาศ ปภ. ครั้งเดียวตอนเริ่ม service — หลังจากนั้น WorkManager จัดการ periodic sync ทุก 15 นาที
        try {
            com.rescue.alert.source.OfficialCellBroadcastSync.refreshNow(applicationContext)
        } catch (e: Exception) {
            Log.w(TAG, "Initial official feed sync failed: ${e.message}")
        }
        try {
            val meshManager = BluetoothMeshManager.getInstance(applicationContext)
            meshManager.ensureServersStarted()
            meshManager.startBleMeshAdvertising()
            meshManager.startBleMeshScan()
        } catch (e: Exception) {
            Log.e(TAG, "Error in onStartCommand: ${e.message}", e)
        }
        try {
            com.rescue.alert.network.InternetAnnouncementClient.start(applicationContext)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting InternetAnnouncementClient: ${e.message}", e)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "MeshForegroundService destroying - releasing mesh resources (F-08)")
        try {
            com.rescue.alert.network.InternetAnnouncementClient.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping InternetAnnouncementClient in onDestroy: ${e.message}", e)
        }
        try {
            BluetoothMeshManager.getInstance(applicationContext).release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing BluetoothMeshManager in onDestroy: ${e.message}", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "ระบบบลูทูธเมชกู้ภัย (Mesh Foreground Service)"
            val descriptionText = "เชื่อมต่อเครือข่ายบลูทูธกู้ภัยฉุกเฉินแบบไร้เน็ตในพื้นที่"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("${getString(com.rescue.alert.R.string.app_title)} • เมชบลูทูธสแตนด์บาย")
            .setContentText("เมชบลูทูธพร้อม • แจ้งเตือนเมื่อ ปภ. ประกาศเตือนภัยในพื้นที่ GPS ของคุณ")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(false)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()
    }
}
