package com.rescue.alert.util

import android.app.Application
import android.app.UiModeManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate

class RescueAlertApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        com.rescue.alert.network.PublicDataGateway.initialize(this)
        ThemePalette.apply(this)
    }
}

object ThemePalette {
    @Volatile private var light = true
    private fun prefs(context: Context) =
        (if (Build.VERSION.SDK_INT >= 24) context.createDeviceProtectedStorageContext() else context)
            .getSharedPreferences("appearance", Context.MODE_PRIVATE)

    fun isLight(context: Context): Boolean = prefs(context).getBoolean("light", true)
    fun setLight(context: Context, enabled: Boolean) {
        check(prefs(context).edit().putBoolean("light", enabled).commit())
        apply(context)
    }
    fun apply(context: Context) {
        light = isLight(context)
        val mode = if (light) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        AppCompatDelegate.setDefaultNightMode(mode)
        if (Build.VERSION.SDK_INT >= 31)
            context.getSystemService(UiModeManager::class.java)?.setApplicationNightMode(
                if (light) UiModeManager.MODE_NIGHT_NO else UiModeManager.MODE_NIGHT_YES)
    }
    fun color(value: String): Int = Color.parseColor(if (light) day[value.uppercase()] ?: value else value)
    private val day = mapOf(
        "#10B981" to "#047857",
        "#059669" to "#047857",
        "#F59E0B" to "#854D0E",
        "#EF4444" to "#B91C1C",
        "#0B0F19" to "#F1F5F9",
        "#0B1120" to "#F1F5F9",
        "#090E17" to "#F1F5F9",
        "#090D16" to "#F1F5F9",
        "#0A0F1D" to "#F1F5F9",
        "#0A0F1E" to "#F1F5F9",
        "#0F172A" to "#FFFFFF",
        "#131D31" to "#FFFFFF",
        "#111827" to "#FFFFFF",
        "#0F1828" to "#FFFFFF",
        "#121D30" to "#FFFFFF",
        "#1A263E" to "#E8EEF6",
        "#17233B" to "#E8EEF6",
        "#1A2844" to "#E8EEF6",
        "#1E293B" to "#E8EEF6",
        "#18243C" to "#E8EEF6",
        "#1E2B40" to "#E8EEF6",
        "#1E2B45" to "#E8EEF6",
        "#0F213A" to "#E8EEF6",
        "#203152" to "#E8EEF6",
        "#202F4D" to "#E8EEF6",
        "#24344D" to "#B6C5D8",
        "#253554" to "#B6C5D8",
        "#334155" to "#B6C5D8",
        "#33476E" to "#B6C5D8",
        "#2A3C60" to "#B6C5D8",
        "#2B3E64" to "#B6C5D8",
        "#1E293F" to "#B6C5D8",
        "#F8FAFC" to "#172033",
        "#F1F5F9" to "#172033",
        "#E2E8F0" to "#172033",
        "#CBD5E1" to "#475569",
        "#94A3B8" to "#475569",
        "#64748B" to "#52627A",
        "#38BDF8" to "#0369A1",
        "#00F2FE" to "#0369A1",
        "#60A5FA" to "#0369A1",
        "#BAE6FD" to "#0369A1",
        "#7DD3FC" to "#0369A1",
        "#FDE68A" to "#854D0E",
        "#FBBF24" to "#854D0E",
        "#FFD54F" to "#854D0E",
        "#FCA5A5" to "#B91C1C",
        "#F87171" to "#B91C1C",
        "#FF617B" to "#B91C1C",
        "#A7F3D0" to "#047857",
        "#6EE7B7" to "#047857",
        "#34D399" to "#047857",
        "#69F0AE" to "#047857",
        "#1F1116" to "#FFF1F2",
        "#09231B" to "#ECFDF5"
    )
}
