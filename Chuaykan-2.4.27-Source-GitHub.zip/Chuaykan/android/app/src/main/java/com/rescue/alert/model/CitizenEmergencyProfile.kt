package com.rescue.alert.model

import android.content.Context

/**
 * Data model for citizen emergency information.
 * Persists basic non-sensitive fields to SharedPreferences to survive process death (Doc 1 Item 3),
 * ensuring life-saving profile data is not lost when backgrounded.
 */
object CitizenEmergencyProfile {
    private const val PREFS_NAME = "citizen_emergency_profile"

    var name: String = ""
    var fullName: String = ""
        get() = name
        set(value) {
            field = value
            name = value
        }
    var phone: String = ""
    var memberCount: Int = 1
    var isBedridden: Boolean = false
    var isElderly: Boolean = false
    var isInfant: Boolean = false
    var urgentNeeds: String = ""
    var isSavedInRam: Boolean = false
    var lastLatitude: Double? = null
    var lastLongitude: Double? = null

    fun load(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            name = prefs.getString("name", "") ?: ""
            phone = prefs.getString("phone", "") ?: ""
            memberCount = prefs.getInt("member_count", 1)
            isBedridden = prefs.getBoolean("is_bedridden", false)
            isElderly = prefs.getBoolean("is_elderly", false)
            isInfant = prefs.getBoolean("is_infant", false)
            urgentNeeds = prefs.getString("urgent_needs", "") ?: ""
            isSavedInRam = name.isNotBlank() || phone.isNotBlank()
        } catch (e: Exception) {}
    }

    fun persist(context: Context) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putString("name", name)
                .putString("phone", phone)
                .putInt("member_count", memberCount)
                .putBoolean("is_bedridden", isBedridden)
                .putBoolean("is_elderly", isElderly)
                .putBoolean("is_infant", isInfant)
                .putString("urgent_needs", urgentNeeds)
                .apply()
        } catch (e: Exception) {}
    }

    fun clear(context: Context? = null) {
        name = ""
        phone = ""
        memberCount = 1
        isBedridden = false
        isElderly = false
        isInfant = false
        urgentNeeds = ""
        isSavedInRam = false
        lastLatitude = null
        lastLongitude = null
        if (context != null) {
            try {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
            } catch (e: Exception) {}
        }
    }
}
