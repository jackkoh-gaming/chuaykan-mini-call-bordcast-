plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.rescue.alert"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rescue.alert"
        minSdk = 21
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        targetSdk = 34
        buildConfigField("String", "GATEWAY_URL", "\"${providers.gradleProperty("gatewayUrl").getOrElse("")}\"")
        buildConfigField("String", "GATEWAY_CERT_SHA256", "\"${providers.gradleProperty("gatewayCertSha256").getOrElse("")}\"")
        versionCode = 36
        versionName = "2.4.28"
    }

    signingConfigs {
        create("release") {
            val keystoreFile = file(System.getenv("RELEASE_KEYSTORE_PATH") ?: "release.keystore")
            if (keystoreFile.exists() && System.getenv("RELEASE_STORE_PASSWORD") != null) {
                storeFile = keystoreFile
                storePassword = System.getenv("RELEASE_STORE_PASSWORD")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS") ?: "rescue_release"
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD") ?: System.getenv("RELEASE_STORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isDebuggable = false
            signingConfig = if (System.getenv("RELEASE_STORE_PASSWORD") != null) {
                signingConfigs.getByName("release")
            } else {
                null // Release must never silently use the debug signing key.
            }
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
