import sys, socket
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.platforms.windows_bluetooth import WindowsSocket
from winrt.runtime import init_apartment, uninit_apartment, ApartmentType
init_apartment(ApartmentType.MULTI_THREADED)
uninit_apartment()
a,b=socket.socketpair()
wrapped=WindowsSocket(a.detach())
try:
    wrapped.settimeout(0.2)
    try:
        wrapped.recv(16)
        raise AssertionError("Timeout required")
    except socket.timeout:
        pass
    b.sendall(b"actual-frame")
    assert wrapped.recv(6)==b"actual"
    assert wrapped.recv(16)==b"-frame"
    wrapped.sendall(b"return-frame")
    assert b.recv(32)==b"return-frame"
finally:
    wrapped.close(); wrapped.close(); b.close()
print("PASS: Windows native socket sends, receives, times out, closes; COM initialization valid. Bluetooth radio not tested.")
