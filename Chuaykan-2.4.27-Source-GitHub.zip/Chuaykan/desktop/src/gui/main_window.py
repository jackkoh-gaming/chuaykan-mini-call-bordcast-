#!/usr/bin/env python3
"""
MainWindow: Central EOC Command Center Dashboard
Panoramic Geospatial Theater (Left) + Tabbed Cyber-Tactical Command Deck (Right).
Integrates:
1. Live SOS Dispatch Queue & Severity Tracking
2. Interactive Leaflet Map with 360° Radar Sweep
3. Disaster Zone Epicenter & Radius Controller
4. Real-Time Bluetooth Mesh Gateway & Device Discovery (Off-Grid Off-Cellular)
5. Embedded HTTP Gateway Server for Mobile App Sync
"""
from __future__ import annotations
import os
import subprocess
import threading
import time
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Set

from PySide6.QtCore import Qt, QTimer, Signal, Slot, QSize
from PySide6.QtGui import QIcon, QFont
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QSplitter, QMessageBox, QStatusBar,
    QTabWidget, QDoubleSpinBox, QComboBox, QApplication
)

from src.core.config import (
    ICONS_DIR, DEFAULT_SERVER_PORT, COLOR_FLOOD_CYAN,
    COLOR_EMERGENCY_RED, COLOR_SIGNAL_GREEN, COLOR_ALERT_AMBER
)
from src.core.database import Database
from src.core.models import SosCase, DisasterZone
from src.server.dispatch_server import DispatchServer
from src.server.zone_cloud_dispatcher import ZoneCloudDispatcher, OfficialCellBroadcastFeed
from src.gui.official_feed_panel import OfficialFeedPanel
from src.gui.map_widget import MapWidget
from src.gui.zone_control_panel import ZoneControlPanel
from src.gui.dispatch_panel import DispatchPanel
from src.gui.mesh_panel import BluetoothMeshPanel
from src.gui.incoming_call_dialog import IncomingCallDialog
from src.gui.styles import TACTICAL_QSS
from src.gui.transparency_dialog import TransparencyDialog
from src.mesh.bluetooth_mesh_service import BluetoothMeshService, BluetoothMeshNode
from src.mesh.call_audio import CallAudioPlayer


class MainWindow(QMainWindow):
    """
    Ultra-Modern C4I Operations Center GUI with Bluetooth Mesh & HTTP Gateway.
    """
    # Custom Qt signals for thread-safe UI updates from server & bluetooth callbacks
    sig_new_sos = Signal(object)
    sig_sos_updated = Signal(str, str)
    sig_case_finished = Signal(str, str, str, bool, str)
    sig_zone_broadcasted = Signal(object)
    sig_online_zone_dispatch = Signal(object)
    sig_official_feed_loaded = Signal(object)

    sig_mesh_node = Signal(object)
    sig_mesh_packet = Signal(dict)
    sig_mesh_status = Signal(str)
    sig_pairing_request = Signal(object)

    sig_internet_call_incoming = Signal(str, str, str)
    sig_internet_call_answered = Signal(str, str)
    sig_internet_call_ended = Signal()
    sig_internet_call_outgoing = Signal(str, str)

    def __init__(self, port: int = DEFAULT_SERVER_PORT, db: Optional[Database] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ช่วยกัน (มินิ คอลบอร์ดเคส) | Chuaykan (Mini Call Broadcast)")
        self.resize(1560, 940)
        self.setMinimumSize(1100, 700)
        disclosure_menu = self.menuBar().addMenu("ข้อมูลและข้อตกลง")
        disclosure_menu.addAction("เกตเวย์สาธารณะ Oracle",
            lambda: self.server.security.show_pairing(self, self.server.get_local_ip(), self.server.port))
        disclosure_menu.addAction("ข้อตกลง / ข้อมูลส่วนบุคคล / ดาวน์โหลดเอกสาร",
                                  lambda: TransparencyDialog(self).exec())

        # Set Window Icon
        icon_path = ICONS_DIR / "shield_alert.svg"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

        # 1. Initialize Clean Database (Zero Mock Cases)
        self.db = db if db is not None else Database()
        for case in self.db.get_all_sos_cases():
            if case.status == "RESCUED_SAFE":
                self.db.request_completion(case.case_id)
        self.db.cleanup_orphan_sos_cache()

        # 2. Initialize Embedded HTTP Gateway Server
        self.server = DispatchServer(
            db=self.db,
            port=port,
            on_new_sos=lambda case: self.sig_new_sos.emit(case),
            on_sos_updated=lambda cid, st: self.sig_sos_updated.emit(cid, st),
            on_zone_broadcast=lambda zone: self.sig_zone_broadcasted.emit(zone)
        )

        self.server.on_cloud_status = lambda message: self.sig_mesh_status.emit(message)

        # 3. Initialize Bluetooth Mesh Gateway Service with throttled UI emissions
        self._last_mesh_emit_times: Dict[str, float] = {}
        self._known_mesh_devices: set[str] = set()
        self._recent_sos_packet_ids: list[str] = []
        self._last_kpi_mesh_count: int = -1
        self._incoming_call_dialog: Optional[IncomingCallDialog] = None
        self._announcement_process: Optional[subprocess.Popen] = None
        self._announcement_stop = threading.Event()

        def _throttled_mesh_node_callback(node: BluetoothMeshNode):
            now = time.time()
            nkey = getattr(node, "node_id", None) or node.address
            last_t = self._last_mesh_emit_times.get(nkey, 0.0)
            if now - last_t >= 0.5:
                self._last_mesh_emit_times[nkey] = now
                self.sig_mesh_node.emit(node)

        self.mesh_service = BluetoothMeshService(
            on_node_detected=_throttled_mesh_node_callback,
            on_mesh_packet=lambda pkt: self.sig_mesh_packet.emit(pkt),
            on_status_change=lambda msg: self.sig_mesh_status.emit(msg),
            on_pairing_request=lambda request: self.sig_pairing_request.emit(request)
        )

        # Connect internal Qt signals
        self.sig_new_sos.connect(self._on_server_new_sos)
        self.sig_sos_updated.connect(self._on_server_sos_updated)
        self.sig_case_finished.connect(self._on_case_finished)
        self.sig_zone_broadcasted.connect(self._on_server_zone_broadcasted)
        self.sig_online_zone_dispatch.connect(self._on_online_zone_dispatch_finished)
        self.sig_official_feed_loaded.connect(self._on_official_feed_loaded)

        self.sig_mesh_node.connect(self._on_mesh_node_detected)
        self.sig_mesh_packet.connect(self._on_mesh_packet_received)
        self.sig_mesh_status.connect(self._on_mesh_status_updated)
        self.sig_pairing_request.connect(self._on_pairing_request)

        # Internet Call Management
        self.internet_call_audio = CallAudioPlayer()
        self._internet_call_mic_proc: Optional[subprocess.Popen] = None
        self._internet_call_mic_stop: Optional[threading.Event] = None
        self._internet_call_mic_thread: Optional[threading.Thread] = None
        self._is_in_internet_call: bool = False
        self._is_internet_call_incoming: bool = False
        self._internet_call_target: str = ""
        self._incoming_internet_caller: str = ""

        self.server.on_call_incoming = lambda name, phone, cid: self.sig_internet_call_incoming.emit(name, phone, cid)
        self.server.on_call_answered = lambda name, cid: self.sig_internet_call_answered.emit(name, cid)
        self.server.on_call_ended = lambda: self.sig_internet_call_ended.emit()
        self.server.on_call_outgoing = lambda phone, name: self.sig_internet_call_outgoing.emit(phone, name)
        self.server.on_citizen_voice = lambda pcm: self.internet_call_audio.feed("CITIZEN", pcm)

        self.sig_internet_call_incoming.connect(self._on_incoming_internet_call)
        self.sig_internet_call_answered.connect(self._on_internet_call_answered)
        self.sig_internet_call_ended.connect(self._on_internet_call_ended)
        self.sig_internet_call_outgoing.connect(self._on_internet_call_outgoing)

        # Start Embedded Dispatch Server
        try:
            self.server.start()
        except Exception as e:
            print(f"[ERROR] Could not start dispatch server: {e}")

        # Start Bluetooth Mesh Gateway
        try:
            self.mesh_service.start()
        except Exception as e:
            print(f"[ERROR] Could not start bluetooth mesh service: {e}")

        # Build UI
        self._init_ui()

        # Set gateway IP in Bluetooth Mesh Panel
        local_ip = DispatchServer.get_local_ip()
        if hasattr(self, "mesh_panel"):
            self.mesh_panel.set_gateway_ip(local_ip, self.server.port, self.server.security.public_url)

        # Initialize active disaster zone (Doc 2 C-09: Do not auto-activate preset if no active zone in DB)
        self.current_zones = self.db.get_active_zones()
        self.current_zone = self.current_zones[0] if self.current_zones else None
        self.map_widget.set_disaster_zones(self.current_zones)
        self.zone_panel.set_active_zones([z for z in self.current_zones if z.zone_id != "MIC_ZONE_01"])

        # Periodic refresh timer (every 3 seconds)
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.reload_data_from_db)
        self.refresh_timer.start(3000)

        # Live Digital Clock Timer (1 second)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._update_clock)
        self.clock_timer.start(1000)
        self._update_clock()

        # Load the current persisted operational state.
        self.reload_data_from_db()
        self._refresh_official_feed()

        # Real-time background sync for official NDWC feed (polls every 3 minutes)
        self.official_feed_timer = QTimer(self)
        self.official_feed_timer.timeout.connect(self._refresh_official_feed)
        self.official_feed_timer.start(180000)

    def _init_ui(self):
        self.setStyleSheet(TACTICAL_QSS)

        central_widget = QWidget(self)
        central_widget.setObjectName("centralWidget")
        self.setCentralWidget(central_widget)
        root_layout = QVBoxLayout(central_widget)
        root_layout.setContentsMargins(10, 10, 10, 10)
        root_layout.setSpacing(8)

        # =========================================================
        # 1. TOP MISSION CONTROL HUD
        # =========================================================
        top_header = QFrame()
        top_header.setObjectName("elevatedCard")
        header_layout = QVBoxLayout(top_header)
        header_layout.setContentsMargins(10, 6, 10, 6)
        header_layout.setSpacing(6)
        th_layout = QHBoxLayout()
        header_layout.addLayout(th_layout)
        status_layout = QHBoxLayout()
        status_layout.setSpacing(6)
        header_layout.addLayout(status_layout)
        th_layout.setContentsMargins(10, 5, 10, 5)
        th_layout.setSpacing(8)

        # 1.1 Brand & System ID
        brand_row = QHBoxLayout()
        brand_row.setSpacing(8)
        lbl_logo = QLabel()
        logo_path = ICONS_DIR / "shield_alert.svg"
        if logo_path.exists():
            QApplication.instance().theme_manager.set_icon(lbl_logo, logo_path, 24)
        brand_row.addWidget(lbl_logo)

        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        lbl_brand = QLabel("ช่วยกัน (มินิ คอลบอร์ดเคส)")
        lbl_brand.setObjectName("headerTitle")
        lbl_brand.setStyleSheet("font-size: 13.5px; font-weight: 800; color: #FFFFFF;")
        title_box.addWidget(lbl_brand)
        lbl_brand_en = QLabel("Chuaykan (Mini Call Broadcast)")
        lbl_brand_en.setStyleSheet("font-size: 12px; font-weight: 600; color: #38BDF8;")
        title_box.addWidget(lbl_brand_en)

        local_ip = DispatchServer.get_local_ip()
        lbl_sub = QLabel(f"ระบบติดตามพิกัดมือถือ • เกตเวย์พอร์ต {self.server.port} [IP: {local_ip}]")
        lbl_sub.setObjectName("subText")
        title_box.addWidget(lbl_sub)
        brand_row.addLayout(title_box)
        th_layout.addLayout(brand_row)

        th_layout.addStretch()

        self.theme_choice = QComboBox()
        self.theme_choice.setObjectName("themeChoice")
        self.theme_choice.addItems(["โหมดมืด", "โหมดสว่าง"])
        manager = QApplication.instance().theme_manager
        self.theme_choice.setCurrentIndex(1 if manager.light else 0)
        self.theme_choice.currentIndexChanged.connect(lambda index: manager.set_light(index == 1))
        th_layout.addWidget(self.theme_choice)

        # 1.2 DEFCON Threat Condition Badge
        self.lbl_defcon = QLabel("DEFCON 4: สภาวะปกติ เฝ้าระวัง")
        self.lbl_defcon.setStyleSheet(
            "background: rgba(2, 132, 199, 0.2); color: #38BDF8; "
            "border: 1px solid #0284C7; border-radius: 6px; "
            "padding: 5px 12px; font-weight: 800; font-size: 11.5px; letter-spacing: 0.5px;"
        )
        status_layout.addWidget(self.lbl_defcon)

        # 1.3 Live Thailand Clock (UTC+7)
        clock_card = QFrame()
        clock_card.setObjectName("kpiCard")
        cc_layout = QVBoxLayout(clock_card)
        cc_layout.setContentsMargins(8, 3, 8, 3)
        cc_layout.setSpacing(0)
        cc_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.lbl_clock_time = QLabel("--:--:-- น.")
        self.lbl_clock_time.setObjectName("telemetryClock")
        self.lbl_clock_time.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cc_layout.addWidget(self.lbl_clock_time)

        self.lbl_clock_date = QLabel("UTC+7 • วันที่")
        self.lbl_clock_date.setObjectName("subText")
        self.lbl_clock_date.setStyleSheet("font-size: 10px; color: #64748B;")
        self.lbl_clock_date.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cc_layout.addWidget(self.lbl_clock_date)
        th_layout.addWidget(clock_card)

        # 1.4 Glowing KPI Monolith Cards
        # KPI 1: In Flood Zone
        kpi_zone = QFrame()
        kpi_zone.setObjectName("kpiCardRed")
        kz_layout = QHBoxLayout(kpi_zone)
        kz_layout.setContentsMargins(8, 4, 10, 4)
        kz_layout.setSpacing(6)
        ico_z = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_z, ICONS_DIR / "hazard_triangle.svg", 18)
        kz_layout.addWidget(ico_z)
        self.lbl_metric_in_zone = QLabel("ในเขตน้ำท่วม: 0")
        self.lbl_metric_in_zone.setStyleSheet("font-weight: 800; font-size: 12px; color: #FCA5A5;")
        kz_layout.addWidget(self.lbl_metric_in_zone)
        status_layout.addWidget(kpi_zone, 1)

        # KPI 2: Bedridden Patients
        kpi_bed = QFrame()
        kpi_bed.setObjectName("kpiCardRed")
        kb_layout = QHBoxLayout(kpi_bed)
        kb_layout.setContentsMargins(8, 4, 10, 4)
        kb_layout.setSpacing(6)
        ico_b = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_b, ICONS_DIR / "bedridden.svg", 18)
        kb_layout.addWidget(ico_b)
        self.lbl_metric_bedridden = QLabel("ติดเตียง: 0")
        self.lbl_metric_bedridden.setStyleSheet("font-weight: 800; font-size: 12px; color: #FCA5A5;")
        kb_layout.addWidget(self.lbl_metric_bedridden)
        status_layout.addWidget(kpi_bed, 1)

        # KPI 3: Rescue Dispatched
        kpi_disp = QFrame()
        kpi_disp.setObjectName("kpiCardAmber")
        kd_layout = QHBoxLayout(kpi_disp)
        kd_layout.setContentsMargins(8, 4, 10, 4)
        kd_layout.setSpacing(6)
        ico_d = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_d, ICONS_DIR / "ambulance.svg", 18)
        kd_layout.addWidget(ico_d)
        self.lbl_metric_dispatched = QLabel("ส่งทีมแล้ว: 0")
        self.lbl_metric_dispatched.setStyleSheet("font-weight: 800; font-size: 12px; color: #FDE68A;")
        kd_layout.addWidget(self.lbl_metric_dispatched)
        status_layout.addWidget(kpi_disp, 1)

        # KPI 4: Rescued Safe
        kpi_safe = QFrame()
        kpi_safe.setObjectName("kpiCardGreen")
        ks_layout = QHBoxLayout(kpi_safe)
        ks_layout.setContentsMargins(8, 4, 10, 4)
        ks_layout.setSpacing(6)
        ico_s = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_s, ICONS_DIR / "check_circle.svg", 18)
        ks_layout.addWidget(ico_s)
        self.lbl_metric_safe = QLabel("ปลอดภัย: 0")
        self.lbl_metric_safe.setStyleSheet("font-weight: 800; font-size: 12px; color: #6EE7B7;")
        ks_layout.addWidget(self.lbl_metric_safe)
        status_layout.addWidget(kpi_safe, 1)

        # KPI 5: Bluetooth Mesh Nodes Active
        kpi_mesh = QFrame()
        kpi_mesh.setObjectName("kpiCardCyan")
        km_layout = QHBoxLayout(kpi_mesh)
        km_layout.setContentsMargins(8, 4, 10, 4)
        km_layout.setSpacing(6)
        ico_mesh = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_mesh, ICONS_DIR / "bluetooth.svg", 18)
        km_layout.addWidget(ico_mesh)
        self.lbl_metric_mesh = QLabel("บลูทูธ (แอป): 0 เครื่อง")
        self.lbl_metric_mesh.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 11.5px;")
        km_layout.addWidget(self.lbl_metric_mesh)
        status_layout.addWidget(kpi_mesh, 1)

        # KPI 6: Server Gateway Status
        kpi_srv = QFrame()
        kpi_srv.setObjectName("kpiCardCyan")
        ksrv_layout = QHBoxLayout(kpi_srv)
        ksrv_layout.setContentsMargins(8, 4, 10, 4)
        ksrv_layout.setSpacing(6)
        ico_srv = QLabel()
        QApplication.instance().theme_manager.set_icon(ico_srv, ICONS_DIR / "server_online.svg", 18)
        ksrv_layout.addWidget(ico_srv)
        lbl_srv = QLabel(f"ONLINE (:{self.server.port})")
        lbl_srv.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 11.5px;")
        ksrv_layout.addWidget(lbl_srv)
        status_layout.addWidget(kpi_srv, 1)

        root_layout.addWidget(top_header)

        # =========================================================
        # 1.5 GLOBAL INCOMING CALL / INTERCOM ALERT BANNER
        # Prominently displays incoming calls from connected mobile devices
        # with direct Answer and Hang Up buttons accessible from ANY tab.
        # =========================================================
        self.call_alert_banner = QFrame()
        self.call_alert_banner.setObjectName("callAlertBanner")
        self.call_alert_banner.setStyleSheet("""
            QFrame#callAlertBanner {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1E3A8A, stop:0.5 #0F766E, stop:1 #065F46);
                border: 2px solid #38BDF8;
                border-radius: 8px;
                padding: 6px 14px;
            }
        """)
        cab_layout = QHBoxLayout(self.call_alert_banner)
        cab_layout.setContentsMargins(10, 6, 10, 6)
        cab_layout.setSpacing(12)

        ico_call = QLabel()
        ico_cpath = ICONS_DIR / "bluetooth.svg"
        if ico_cpath.exists():
            QApplication.instance().theme_manager.set_icon(ico_call, ico_cpath, 20)
        cab_layout.addWidget(ico_call)

        self.lbl_global_call_title = QLabel("มีสายเรียกเข้าจากโทรศัพท์...")
        self.lbl_global_call_title.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 800;")
        cab_layout.addWidget(self.lbl_global_call_title, 1)

        self.btn_global_answer = QPushButton("รับสาย (Answer Call)")
        self.btn_global_answer.setFixedHeight(30)
        self.btn_global_answer.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_global_answer.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                border: 1.5px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 12px;
                border-radius: 6px;
                padding: 4px 16px;
            }
            QPushButton:hover {
                background-color: #10B981;
                border-color: #A7F3D0;
            }
        """)
        self.btn_global_answer.clicked.connect(self._on_global_answer_clicked)
        cab_layout.addWidget(self.btn_global_answer)

        self.btn_global_hangup = QPushButton("วางสาย (Hang Up)")
        self.btn_global_hangup.setFixedHeight(30)
        self.btn_global_hangup.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_global_hangup.setStyleSheet("""
            QPushButton {
                background-color: #DC2626;
                border: 1.5px solid #F87171;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 12px;
                border-radius: 6px;
                padding: 4px 14px;
            }
            QPushButton:hover {
                background-color: #B91C1C;
                border-color: #FECACA;
            }
        """)
        self.btn_global_hangup.clicked.connect(self._on_global_hangup_clicked)
        cab_layout.addWidget(self.btn_global_hangup)

        self.call_alert_banner.setVisible(False)
        root_layout.addWidget(self.call_alert_banner)

        # =========================================================
        # 2. CENTRAL THEATER BODY (68% Map / 32% Tabbed Console)
        # =========================================================
        main_splitter = QSplitter(Qt.Orientation.Horizontal)

        # 2.1 Left: Panoramic Tactical Map Viewport
        map_container = QFrame()
        map_container.setObjectName("panelCard")
        map_layout = QVBoxLayout(map_container)
        map_layout.setContentsMargins(0, 0, 0, 0)
        map_layout.setSpacing(0)

        self.map_widget = MapWidget()
        self.map_widget.call_citizen_requested.connect(self._start_internet_call_from_map)
        self.map_widget.adopt_official_area_requested.connect(self._on_adopt_official_area)
        map_layout.addWidget(self.map_widget)
        main_splitter.addWidget(map_container)

        # 2.2 Right: Tabbed Integrated Command Deck
        self.tab_console = QTabWidget()
        self.tab_console.setDocumentMode(True)

        # Tab 1: Live SOS Dispatch Queue
        self.dispatch_panel = DispatchPanel()
        self.dispatch_panel.case_focused.connect(self.map_widget.focus_case)
        self.dispatch_panel.status_change_requested.connect(self._update_case_status)
        self.dispatch_panel.call_requested.connect(self._start_internet_call)
        tab_ico_dispatch = QIcon(str(ICONS_DIR / "shield_alert.svg"))
        self.tab_console.addTab(self.dispatch_panel, tab_ico_dispatch, "คิวแจ้งเหตุ (SOS)")

        # Tab 2: Disaster Zone & Evacuation Sites Controller
        self.zone_panel = ZoneControlPanel(db=self.db)
        self.zone_panel.zone_broadcast_requested.connect(self._on_zone_broadcast_from_ui)
        self.zone_panel.zone_removal_requested.connect(self._on_zone_removal_from_ui)
        self.zone_panel.evacuation_sites_updated.connect(self._on_evacuation_sites_updated)
        tab_ico_zone = QIcon(str(ICONS_DIR / "hazard_triangle.svg"))
        self.tab_console.addTab(self.zone_panel, tab_ico_zone, "ควบคุมพื้นที่ (ZONE)")

        # Tab 3: Officer microphone announcement & Geofenced area control
        self.announcement_panel = QWidget()
        announce_layout = QVBoxLayout(self.announcement_panel)
        announce_layout.setContentsMargins(10, 10, 10, 10)
        announce_layout.setSpacing(8)

        announce_title = QLabel("ไมค์ประกาศเจ้าหน้าที่")
        announce_title.setObjectName("headerTitle")
        announce_layout.addWidget(announce_title)

        announce_help = QLabel(
            "ระบบประกาศผ่านไมค์ทางอินเทอร์เน็ตตามพื้นที่ปักหมุด (ไม่ใช้บลูทูธ) • "
            "มือถือจะแจ้งเตือนเมื่อเปิดไมค์ประกาศเท่านั้น"
        )
        announce_help.setObjectName("subText")
        announce_help.setWordWrap(True)
        announce_layout.addWidget(announce_help)

        # Card: กำหนดระยะขอบเขตพื้นที่ประกาศ
        mic_card = QFrame()
        mic_card.setObjectName("panelCard")
        mc_layout = QVBoxLayout(mic_card)
        mc_layout.setContentsMargins(10, 8, 10, 8)
        mc_layout.setSpacing(6)

        lbl_zone_header = QLabel("กำหนดระยะขอบเขตพื้นที่ประกาศ (คลิกบนแผนที่ได้)")
        lbl_zone_header.setStyleSheet("color: #38BDF8; font-weight: bold; font-size: 11.5px;")
        mc_layout.addWidget(lbl_zone_header)

        coords_row = QHBoxLayout()
        lat_col = QVBoxLayout()
        lat_col.addWidget(QLabel("ละติจูด (Lat):"))
        self.spin_mic_lat = QDoubleSpinBox()
        self.spin_mic_lat.setRange(-90.0, 90.0)
        self.spin_mic_lat.setDecimals(5)
        self.spin_mic_lat.setSingleStep(0.0001)
        lat_col.addWidget(self.spin_mic_lat)
        coords_row.addLayout(lat_col)

        lng_col = QVBoxLayout()
        lng_col.addWidget(QLabel("ลองจิจูด (Lng):"))
        self.spin_mic_lng = QDoubleSpinBox()
        self.spin_mic_lng.setRange(-180.0, 180.0)
        self.spin_mic_lng.setDecimals(5)
        self.spin_mic_lng.setSingleStep(0.0001)
        lng_col.addWidget(self.spin_mic_lng)
        coords_row.addLayout(lng_col)
        mc_layout.addLayout(coords_row)

        radius_row = QHBoxLayout()
        radius_row.addWidget(QLabel("ระยะขอบเขต/รัศมี (กม.):"))
        self.spin_mic_radius = QDoubleSpinBox()
        self.spin_mic_radius.setRange(0.1, 100.0)
        self.spin_mic_radius.setValue(3.0)
        self.spin_mic_radius.setDecimals(1)
        self.spin_mic_radius.setSingleStep(0.5)
        self.spin_mic_radius.setStyleSheet(f"color: {COLOR_FLOOD_CYAN}; font-weight: bold;")
        radius_row.addWidget(self.spin_mic_radius)
        mc_layout.addLayout(radius_row)

        # ย้ายปุ่มปักหมุดไมค์ประกาศมาไว้ที่แท็บนี้
        self.btn_pin_mic_area = QPushButton("ปักหมุดไมค์ประกาศ (ไม่แจ้งเตือน • คุมพื้นที่เน็ต)")
        ico_mic = ICONS_DIR / "speaker.svg"
        if ico_mic.exists():
            QApplication.instance().theme_manager.set_icon(self.btn_pin_mic_area, ico_mic, 18)
            self.btn_pin_mic_area.setIconSize(QSize(18, 18))
        self.btn_pin_mic_area.setFixedHeight(38)
        self.btn_pin_mic_area.setStyleSheet(
            "background-color: #0284C7; color: white; font-weight: bold; border-radius: 6px;"
        )
        self.btn_pin_mic_area.clicked.connect(self._save_mic_zone_from_panel)
        mc_layout.addWidget(self.btn_pin_mic_area)

        self.btn_clear_mic_area = QPushButton("ล้างจุดปักหมุดไมค์")
        self.btn_clear_mic_area.setFixedHeight(28)
        self.btn_clear_mic_area.clicked.connect(self._clear_mic_zone_from_panel)
        mc_layout.addWidget(self.btn_clear_mic_area)

        self.lbl_mic_area_info = QLabel("ยังไม่ได้กำหนดพื้นที่คุมไมค์ประกาศ")
        self.lbl_mic_area_info.setObjectName("subText")
        self.lbl_mic_area_info.setWordWrap(True)
        mc_layout.addWidget(self.lbl_mic_area_info)

        announce_layout.addWidget(mic_card)

        self.lbl_announcement_status = QLabel("ไมค์พร้อมใช้งาน • ยังไม่ได้เริ่มประกาศ")
        self.lbl_announcement_status.setWordWrap(True)
        announce_layout.addWidget(self.lbl_announcement_status)

        self.btn_announcement_start = QPushButton("เริ่มประกาศผ่านไมค์ (อินเทอร์เน็ตคุมพื้นที่)")
        self.btn_announcement_start.setObjectName("btnEmergency")
        self.btn_announcement_start.setFixedHeight(42)
        self.btn_announcement_start.clicked.connect(self._start_officer_announcement)
        announce_layout.addWidget(self.btn_announcement_start)

        self.btn_announcement_stop = QPushButton("หยุดประกาศ")
        self.btn_announcement_stop.setFixedHeight(36)
        self.btn_announcement_stop.setEnabled(False)
        self.btn_announcement_stop.clicked.connect(self._stop_officer_announcement)
        announce_layout.addWidget(self.btn_announcement_stop)
        announce_layout.addStretch()

        tab_ico_announce = QIcon(str(ICONS_DIR / "speaker.svg"))
        self.tab_console.addTab(self.announcement_panel, tab_ico_announce, "ไมค์ประกาศ")

        # Tab 4: Bluetooth Mesh Network Operations
        self.mesh_panel = BluetoothMeshPanel(mesh_service=self.mesh_service)
        self.mesh_panel.scan_requested.connect(self._trigger_mesh_scan)
        self.mesh_panel.call_incoming.connect(self._on_call_incoming)
        self.mesh_panel.call_answered.connect(self._on_call_answered)
        self.mesh_panel.call_ended.connect(self._on_call_ended)
        tab_ico_mesh = QIcon(str(ICONS_DIR / "bluetooth.svg"))
        self.tab_console.addTab(self.mesh_panel, tab_ico_mesh, "บลูทูธแมช (MESH)")

        # EOC is a read-only operational view. Phones fetch the official feed directly.
        self.official_feed_panel = OfficialFeedPanel()
        self.official_feed_panel.refresh_requested.connect(self._refresh_official_feed)
        self.tab_console.addTab(self.official_feed_panel, QIcon(str(ICONS_DIR / "shield_alert.svg")), "ประกาศทางการ")

        # A map click creates only a visible draft point in the selected slot.
        # It becomes a risk area only after the operator presses Save.
        self.map_widget.map_clicked.connect(self._on_map_risk_point_selected)
        self.map_widget.dispatch_requested.connect(lambda cid: self._update_case_status(cid, "DISPATCHED"))
        self.map_widget.mark_safe_requested.connect(lambda cid: self._update_case_status(cid, "RESCUED_SAFE"))

        main_splitter.addWidget(self.tab_console)

        # Set Splitter Ratios (Left: 66%, Right: 34%)
        main_splitter.setStretchFactor(0, 66)
        main_splitter.setStretchFactor(1, 34)
        main_splitter.setSizes([990, 570])
        root_layout.addWidget(main_splitter, 1)

        # =========================================================
        # 3. BOTTOM OPERATIONS & REAL BLUETOOTH MESH BAR
        # =========================================================
        op_bar = QFrame()
        op_bar.setObjectName("panelCard")
        ob_layout = QHBoxLayout(op_bar)
        ob_layout.setContentsMargins(12, 6, 12, 6)
        ob_layout.setSpacing(10)

        # Bluetooth Mesh Trigger
        btn_bt_scan = QPushButton("สแกนบลูทูธแมช")
        ico_bt = ICONS_DIR / "bluetooth.svg"
        if ico_bt.exists():
            QApplication.instance().theme_manager.set_icon(btn_bt_scan, ico_bt, 18)
            btn_bt_scan.setIconSize(QSize(18, 18))
        btn_bt_scan.clicked.connect(self._trigger_mesh_scan)
        ob_layout.addWidget(btn_bt_scan)

        # Button: Refresh
        btn_refresh = QPushButton("รีเฟรช")
        ico_ref = ICONS_DIR / "refresh.svg"
        if ico_ref.exists():
            QApplication.instance().theme_manager.set_icon(btn_refresh, ico_ref, 18)
            btn_refresh.setIconSize(QSize(18, 18))
        btn_refresh.clicked.connect(self.reload_data_from_db)
        ob_layout.addWidget(btn_refresh)

        btn_clear_total = QPushButton("ล้างแคชยอดช่วยเหลือ")
        btn_clear_total.clicked.connect(self._clear_rescued_total)
        ob_layout.addWidget(btn_clear_total)

        # Button: Clear All Cases
        btn_clear = QPushButton("ล้างเคส")
        ico_clr = ICONS_DIR / "trash.svg"
        if ico_clr.exists():
            QApplication.instance().theme_manager.set_icon(btn_clear, ico_clr, 18)
            btn_clear.setIconSize(QSize(18, 18))
        btn_clear.clicked.connect(self._clear_all_cases)
        ob_layout.addWidget(btn_clear)

        # Phone Direct Connection Helper Info
        phone_info = QLabel("ที่อยู่เชื่อมต่อมือถือ (RescueAlert): " + (self.server.security.public_url or f"https://{local_ip}:{self.server.port}"))
        phone_info.setStyleSheet("color: #F59E0B; font-weight: bold; font-size: 11.5px; padding-left: 6px;")
        ob_layout.addWidget(phone_info)

        ob_layout.addStretch()

        # Telemetry Stream Beacon & Log Feed
        telemetry_box = QHBoxLayout()
        telemetry_box.setSpacing(8)

        beacon_dot = QLabel()
        b_path = ICONS_DIR / "bluetooth.svg"
        if b_path.exists():
            QApplication.instance().theme_manager.set_icon(beacon_dot, b_path, 14)
        telemetry_box.addWidget(beacon_dot)

        self.lbl_status_ticker = QLabel("บลูทูธแมชออนไลน์ • พร้อมรับสัญญาณฉุกเฉินจากโทรศัพท์มือถือ")
        self.lbl_status_ticker.setObjectName("subText")
        self.lbl_status_ticker.setStyleSheet("color: #00F2FE; font-family: monospace, 'Sarabun'; font-size: 11px;")
        telemetry_box.addWidget(self.lbl_status_ticker)
        ob_layout.addLayout(telemetry_box)

        root_layout.addWidget(op_bar)

    def _update_clock(self):
        """Tick live clock in Thai C2 operations format."""
        today = OfficialCellBroadcastFeed.current_day()
        previous_day = getattr(self, "_official_feed_day", None)
        if previous_day != today:
            self._official_feed_day = today
            self.official_feed_panel.set_alerts([])
            self.map_widget.set_official_alerts([])
            if previous_day is not None:
                self._refresh_official_feed()
        now = datetime.now()
        time_str = now.strftime("%H:%M:%S")
        date_str = now.strftime("%d/%m/%Y")
        if hasattr(self, "lbl_clock_time"):
            self.lbl_clock_time.setText(f"{time_str} น.")
        if hasattr(self, "lbl_clock_date"):
            self.lbl_clock_date.setText(f"UTC+7 • {date_str}")

    # -----------------------------------------------------------
    # BLUETOOTH MESH SLOTS
    # -----------------------------------------------------------
    @Slot(object)
    def _on_mesh_node_detected(self, node: BluetoothMeshNode):
        """Called when a nearby Bluetooth device or RescueAlert node is detected."""
        if hasattr(self, "mesh_panel"):
            self.mesh_panel.update_node(node)

        # Update KPI node count only when count actually changes
        active_count = len(self.mesh_service.get_active_nodes())
        if active_count != self._last_kpi_mesh_count:
            self._last_kpi_mesh_count = active_count
            if hasattr(self, "lbl_metric_mesh"):
                self.lbl_metric_mesh.setText(f"บลูทูธ (แอป): {active_count} เครื่อง")

        # Discrete logging: ONLY log & update ticker when a NEW device appears
        node_key = getattr(node, "node_id", None) or node.address
        if node.is_app_node and node_key not in self._known_mesh_devices:
            self._known_mesh_devices.add(node_key)
            ts = datetime.now().strftime("%H:%M:%S")
            self.lbl_status_ticker.setText(
                f"[{ts}] ตรวจพบโทรศัพท์ RescueAlert เครื่องใหม่: {node.name} (~{node.distance_meters} ม.)"
            )
            if hasattr(self, "mesh_panel"):
                self.mesh_panel.append_log(
                    f"ตรวจพบโทรศัพท์มือถือ RescueAlert เครื่องใหม่: {node.name} (MAC: {node.address})"
                )

    @Slot(object)
    def _on_pairing_request(self, request):
        if request.get("auto_paired"):
            self.mesh_panel.append_log("จับคู่แอป RescueAlert อัตโนมัติแล้ว: " + request["auto_paired"])
            return
        previous = getattr(self, "_pairing_dialog", None)
        if previous:
            previous.close()
            self._pairing_dialog = None
        if request.get("cancel"):
            return
        code = request.get("passkey")
        text = f"จับคู่ Bluetooth กับ {request['label']} เพื่อเปิดช่องสื่อสาร RescueAlert?"
        if code is not None:
            text += f"\n\nตรวจสอบว่ารหัสบนมือถือเหมือนกัน: {code:06d}"
        dialog = QMessageBox(QMessageBox.Icon.Question, "จับคู่ Bluetooth RescueAlert", text,
                             QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, self)
        dialog.setDefaultButton(QMessageBox.StandardButton.No)
        self._pairing_dialog = dialog
        def answered(result):
            request["complete"](result == int(QMessageBox.StandardButton.Yes))
            if getattr(self, "_pairing_dialog", None) is dialog:
                self._pairing_dialog = None
            dialog.deleteLater()
        dialog.finished.connect(answered)
        dialog.open()

    @Slot(dict)
    def _on_mesh_packet_received(self, pkt: dict):
        """Called when emergency SOS data or voice packet arrives via Bluetooth Mesh."""
        pkt_id = pkt.get("packet_id")
        # Multi-hop flood deduplication: Ignore duplicate echoes within sliding cache
        if pkt_id and pkt_id in self._recent_sos_packet_ids:
            return
        if pkt_id:
            self._recent_sos_packet_ids.append(pkt_id)
            if len(self._recent_sos_packet_ids) > 100:
                self._recent_sos_packet_ids.pop(0)

        ts = datetime.now().strftime("%H:%M:%S")
        is_sos = pkt.get("is_sos", False)
        citizen_name = pkt.get("citizen_name", "ผู้ประสบภัย (บลูทูธแมช)")
        remote_addr = pkt.get("remote_addr", "BT_UNKNOWN")
        caller_node_id = pkt.get("source_id") or f"DEV_{remote_addr.replace(':', '')[-6:]}"
        audio_file = pkt.get("audio_filename")
        hop_count = pkt.get("hop_count", 1)

        if pkt.get("status_query"):
            case = self.db.get_sos_case(pkt["status_query"].get("case_id", ""))
            if case and case.case_type == "GENERAL" and case.device_id == caller_node_id:
                self.mesh_service.send_sos_status(caller_node_id, case.case_id, case.status)
            return

        # Check for Call Signaling actions (Request / Answer / Decline / Hangup)
        call_action = None if is_sos else pkt.get("call_action")

        # NEW: Handle incoming call REQUEST from citizen phone to EOC desktop
        if call_action == "request":
            if hasattr(self, "mesh_panel"):
                status = self.mesh_panel.show_incoming_call(citizen_name, caller_node_id, audio_file)
                self.lbl_status_ticker.setText(f"[{ts}] {citizen_name} — {status}")
            return

        if call_action == "answer":
            if hasattr(self, "mesh_panel"):
                # BUG-05 FIX: Validate caller matches active call before accepting
                if not self.mesh_panel.active_caller_id or caller_node_id != self.mesh_panel.active_caller_id:
                    self.mesh_panel.append_log(f"ปฏิเสธสัญญาณ answer จากโหนดที่ไม่ตรงกับสายปัจจุบัน: {caller_node_id}")
                    return
                self.mesh_panel.append_log(f"{citizen_name} ({caller_node_id}) ตอบรับสายแล้ว - เริ่มการสนทนา")
                self.mesh_panel._answer_banner_call(remote_answer=True)
            self.lbl_status_ticker.setText(f"[{ts}] {citizen_name} ตอบรับสายสนทนาแล้ว")
            return
        elif call_action in ("decline", "hangup"):
            if hasattr(self, "mesh_panel"):
                if self.mesh_panel.cancel_queued_call(caller_node_id):
                    return
                # BUG-05 FIX: Validate caller matches active call before accepting
                if self.mesh_panel.active_caller_id and caller_node_id != self.mesh_panel.active_caller_id:
                    self.mesh_panel.append_log(f"ปฏิเสธสัญญาณ {call_action} จากโหนดที่ไม่ตรงกับสายปัจจุบัน: {caller_node_id}")
                    return
                self.mesh_panel.append_log(f"{citizen_name} ({caller_node_id}) วางสาย/ปฏิเสธสายแล้ว")
                self.mesh_panel._decline_banner_call(from_remote=True)
            self.lbl_status_ticker.setText(f"[{ts}] {citizen_name} วางสายแล้ว")
            return

        if is_sos:
            report = pkt.get("sos_payload") or {
                "case_id": "MESH_" + str(pkt_id or caller_node_id),
                "contact_name": citizen_name,
                "lat": pkt.get("latitude"), "lng": pkt.get("longitude"),
                "urgent_note": "รับคำขอรอช่วยเหลือผ่านบลูทูธ (โปรไฟล์จากแอปรุ่นเก่าไม่ครบ)",
            }
            report = dict(report, device_id=caller_node_id, case_type="GENERAL")
            class MeshReceipt:
                def _send_json(receipt, result, status_code):
                    if status_code == 200 and result.get("status") == "SUCCESS":
                        self.mesh_service.send_sos_receipt(caller_node_id, result["case_id"], result.get("case_status", "PENDING"))
                    else:
                        self.lbl_status_ticker.setText("รับ SOS บลูทูธไม่สำเร็จ: " + result.get("message", "ข้อผิดพลาด"))
            self.server._handle_sos_report(report, MeshReceipt())
            return
        self.lbl_status_ticker.setText(f"[{ts}] ข้อความเสียง/สายเรียกเข้าบลูทูธจาก {citizen_name}")

        # Show voice notification or play audio on mesh panel for voice messages
        if hasattr(self, "mesh_panel"):
            action_desc = "แพ็กเก็ตฉุกเฉิน SOS" if is_sos else "ข้อความเสียง"
            self.mesh_panel.append_log(f"รับ{action_desc}สำเร็จจาก {citizen_name} ({remote_addr})")
            if is_sos:
                self.mesh_panel.show_incoming_call(citizen_name, caller_node_id, audio_file)
            elif audio_file:
                card = self.mesh_panel.node_cards.get(caller_node_id)
                if card:
                    card.latest_audio_file = audio_file
                self.mesh_panel._play_audio_file(audio_file)

    @Slot(str, str, object)
    def _on_call_incoming(self, caller_name: str, node_id: str, audio_file):
        """Called when any mobile device initiates an incoming call / voice message."""
        # Don't pop up dialog if already in active call with this node
        if hasattr(self, "mesh_panel") and self.mesh_panel.active_caller_id == node_id:
            card = self.mesh_panel.node_cards.get(node_id)
            if card and card.is_in_call:
                return

        if hasattr(self, "call_alert_banner"):
            self.lbl_global_call_title.setText(f"มีสายเรียกเข้าจากโทรศัพท์: {caller_name} (โหนด: {node_id}) • กำลังส่งเสียงเรียกเข้า...")
            self.btn_global_answer.setText("รับสาย (Answer Call)")
            self.btn_global_answer.setEnabled(True)
            self.call_alert_banner.setVisible(True)

        # Show prominent floating alert dialog with ringtone before answering
        if self._incoming_call_dialog:
            try:
                self._incoming_call_dialog.close()
            except Exception:
                pass
            self._incoming_call_dialog = None

        self._incoming_call_dialog = IncomingCallDialog(caller_name, node_id, audio_file, parent=self)
        self._incoming_call_dialog.call_answered.connect(lambda name, nid: self._on_global_answer_clicked())
        self._incoming_call_dialog.call_declined.connect(lambda name, nid: self._on_global_hangup_clicked())
        self._incoming_call_dialog.show()

    @Slot(str, str)
    def _on_call_answered(self, caller_name: str, node_id: str):
        """Called when call is answered either from HUD banner, Mesh Panel, or Alert Dialog."""
        if self._incoming_call_dialog:
            try:
                self._incoming_call_dialog._stop_ringtone()
                self._incoming_call_dialog.close()
            except Exception:
                pass
            self._incoming_call_dialog = None

        if hasattr(self, "call_alert_banner"):
            self.lbl_global_call_title.setText(f"กำลังสนทนาสายสดกับ: {caller_name} ({node_id}) • ไมค์เจ้าหน้าที่เปิดอยู่")
            self.btn_global_answer.setText("กำลังสนทนาสด")
            self.btn_global_answer.setEnabled(False)
            self.call_alert_banner.setVisible(True)

    @Slot()
    def _on_call_ended(self):
        """Called when call is hung up or terminated."""
        if self._incoming_call_dialog:
            try:
                self._incoming_call_dialog._stop_ringtone()
                self._incoming_call_dialog.close()
            except Exception:
                pass
            self._incoming_call_dialog = None

        if hasattr(self, "call_alert_banner"):
            self.call_alert_banner.setVisible(False)
            self.btn_global_answer.setText("รับสาย (Answer Call)")
            self.btn_global_answer.setEnabled(True)

    def _on_global_answer_clicked(self):
        """Operator clicks Answer button on the global desktop HUD banner."""
        if getattr(self, "_is_internet_call_incoming", False):
            def answer_call():
                try:
                    self.server.answer_internet_call()
                    self.sig_internet_call_answered.emit("ผู้ประสบภัย", "MOBILE")
                except Exception:
                    self.sig_mesh_status.emit("รับสายไม่สำเร็จ: ตรวจการเชื่อมต่อ Oracle")
            threading.Thread(target=answer_call, daemon=True).start()
            return
        if hasattr(self, "mesh_panel"):
            self.mesh_panel._answer_banner_call()

    def _on_global_hangup_clicked(self):
        """Operator clicks Hang Up button on the global desktop HUD banner."""
        if getattr(self, "_is_in_internet_call", False) or getattr(self, "_is_internet_call_incoming", False):
            def end_call():
                try:
                    self.server.hangup_internet_call()
                except Exception:
                    self.sig_mesh_status.emit("วางสายไม่สำเร็จ: ตรวจการเชื่อมต่อ Oracle")
            threading.Thread(target=end_call, daemon=True).start()
            return
        if hasattr(self, "mesh_panel"):
            self.mesh_panel._decline_banner_call()

    def _start_internet_call_from_map(self, case_id: str, phone: str):
        c = self.db.get_sos_case(case_id) if case_id else None
        name = c.citizen_name if c else "ผู้ประสบภัย"
        self._start_internet_call(case_id=case_id, phone=phone, name=name)

    def _start_internet_call(self, case_id: str = "", phone: str = "", name: str = ""):
        if not phone and case_id:
            c = self.db.get_sos_case(case_id)
            if c:
                phone = c.phone_number or ""
                name = c.citizen_name or ""
        def start_call():
            try:
                self.server.start_internet_call(target_phone=phone, citizen_name=name, case_id=case_id)
                self.sig_internet_call_outgoing.emit(phone, name)
            except Exception:
                self.sig_mesh_status.emit("โทรกลับไม่สำเร็จ: ตรวจการเชื่อมต่อ Oracle และเคสปลายทาง")
        threading.Thread(target=start_call, daemon=True, name="CaseCallback").start()

    @Slot(str, str)
    def _on_internet_call_outgoing(self, phone: str, name: str):
        self._internet_call_target = f"{name} ({phone})"
        self._is_in_internet_call = True
        if hasattr(self, "call_alert_banner"):
            self.lbl_global_call_title.setText(f"กำลังโทรหาประชาชน (อินเทอร์เน็ต): {name} ({phone}) • กำลังรอรับสาย...")
            self.btn_global_answer.setText("กำลังโทรออก...")
            self.btn_global_answer.setEnabled(False)
            self.btn_global_hangup.setText("ยกเลิก / วางสาย")
            self.call_alert_banner.setVisible(True)
        ts = datetime.now().strftime("%H:%M:%S")
        self.lbl_status_ticker.setText(f"[{ts}] โทรกลับหาผู้ป่วย {name} ({phone}) ผ่านอินเทอร์เน็ต...")

    @Slot(str, str, str)
    def _on_incoming_internet_call(self, caller_name: str, phone: str, caller_id: str):
        self._is_internet_call_incoming = True
        self._incoming_internet_caller = f"{caller_name} ({phone})"
        if hasattr(self, "call_alert_banner"):
            self.lbl_global_call_title.setText(f"มีสายเรียกเข้าจากโทรศัพท์ (อินเทอร์เน็ต): {caller_name} ({phone}) • กำลังส่งเสียงเรียกเข้า...")
            self.btn_global_answer.setText("รับสาย (Answer Call)")
            self.btn_global_answer.setEnabled(True)
            self.btn_global_hangup.setText("ตัดสาย / ปฏิเสธ")
            self.call_alert_banner.setVisible(True)

    @Slot(str, str)
    def _on_internet_call_answered(self, client_name: str, client_id: str):
        self._is_internet_call_incoming = False
        self._is_in_internet_call = True
        display_name = self._internet_call_target or self._incoming_internet_caller or client_name
        if hasattr(self, "call_alert_banner"):
            self.lbl_global_call_title.setText(f"กำลังสนทนาสายสด (อินเทอร์เน็ต) กับ: {display_name} • ไมค์เจ้าหน้าที่เปิดอยู่")
            self.btn_global_answer.setText("กำลังสนทนาสด")
            self.btn_global_answer.setEnabled(False)
            self.btn_global_hangup.setText("วางสาย (Hang Up)")
            self.call_alert_banner.setVisible(True)
        self.internet_call_audio.start("CITIZEN")
        self._start_internet_call_mic()

    @Slot()
    def _on_internet_call_ended(self):
        self._is_internet_call_incoming = False
        self._is_in_internet_call = False
        self._stop_internet_call_mic()
        self.internet_call_audio.stop()
        if hasattr(self, "call_alert_banner"):
            self.call_alert_banner.setVisible(False)
            self.btn_global_answer.setText("รับสาย (Answer Call)")
            self.btn_global_answer.setEnabled(True)

    def _start_internet_call_mic(self):
        self._stop_internet_call_mic()
        if not shutil.which("arecord"):
            return
        self._internet_call_mic_stop = threading.Event()
        stop_event = self._internet_call_mic_stop

        def _worker():
            try:
                proc = subprocess.Popen(
                    ["arecord", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
                    stdout=subprocess.PIPE
                )
                self._internet_call_mic_proc = proc
                chunk_size = 1600
                while not stop_event.is_set():
                    data = proc.stdout.read(chunk_size)
                    if not data:
                        break
                    self.server.feed_officer_call_voice(data)
                proc.terminate()
                try:
                    proc.wait(timeout=0.5)
                except Exception:
                    proc.kill()
            except Exception as e:
                print(f"[InternetCall] Mic worker error: {e}")

        self._internet_call_mic_thread = threading.Thread(target=_worker, daemon=True, name="InternetCallMic")
        self._internet_call_mic_thread.start()

    def _stop_internet_call_mic(self):
        if hasattr(self, "_internet_call_mic_stop") and self._internet_call_mic_stop:
            self._internet_call_mic_stop.set()
        if hasattr(self, "_internet_call_mic_proc") and self._internet_call_mic_proc:
            try:
                self._internet_call_mic_proc.terminate()
                self._internet_call_mic_proc.wait(timeout=0.3)
            except Exception:
                try:
                    self._internet_call_mic_proc.kill()
                except Exception:
                    pass
            self._internet_call_mic_proc = None

    @Slot(str)
    def _on_mesh_status_updated(self, msg: str):
        if hasattr(self, "mesh_panel"):
            self.mesh_panel.append_log(msg)


    @Slot(float, float)
    def _on_map_risk_point_selected(self, lat: float, lng: float):
        if hasattr(self, "tab_console") and hasattr(self, "announcement_panel") and self.tab_console.currentWidget() == self.announcement_panel:
            self.spin_mic_lat.setValue(lat)
            self.spin_mic_lng.setValue(lng)
            self.map_widget.set_pending_risk_point(lat, lng, 1)
            self.lbl_status_ticker.setText(
                f"เลือกพิกัดไมค์ประกาศแล้ว: {lat:.5f}, {lng:.5f} (รัศมี {self.spin_mic_radius.value():.1f} กม.) • กด “ปักหมุดไมค์ประกาศ” เพื่อคุมพื้นที่"
            )
            return

        mode = self.zone_panel.current_mode()
        self.zone_panel.set_coordinates_from_map(lat, lng)
        if mode == "SITE":
            slot = self.zone_panel.selected_site_slot_number()
            site_type = self.zone_panel.selected_site_type()
            self.map_widget.set_pending_site_point(lat, lng, slot, site_type)
            label = "ศูนย์อพยพ" if site_type == "SHELTER" else ("ที่จอดรถ" if site_type == "PARKING" else "ศูนย์ช่วยเหลือ")
            self.lbl_status_ticker.setText(
                f"เลือกพิกัดจุดร่าง{label} จุดที่ {slot} แล้ว: {lat:.5f}, {lng:.5f} • กด “บันทึกจุดนี้” เพื่อส่งข้อมูลสู่ประชาชน"
            )
        else:
            self.map_widget.set_pending_risk_point(
                lat, lng, self.zone_panel.selected_slot_number()
            )
            self.lbl_status_ticker.setText(
                f"เลือกพิกัดจุดที่ {self.zone_panel.selected_slot_number()} แล้ว • "
                "กดบันทึกจุดนี้เพื่อเปิดพื้นที่เสี่ยง"
            )

    @Slot(object)
    def _on_evacuation_sites_updated(self, sites: list):
        """Called when operator saves/updates evacuation shelter or parking sites."""
        self.map_widget.clear_pending_site_point()
        self.map_widget.set_evacuation_sites(sites)
        if hasattr(self, "mesh_service") and self.mesh_service:
            for s in sites:
                try:
                    self.mesh_service.broadcast_evacuation_site(s.to_dict())
                except Exception as e:
                    print(f"[MainWindow] Mesh broadcast evacuation site error: {e}")
        ts = datetime.now().strftime("%H:%M:%S")
        self.lbl_status_ticker.setText(
            f"[{ts}] อัพเดตศูนย์อพยพ/ที่จอดรถ {len(sites)} จุด • กระจายข้อมูลสู่มือถือประชาชนแล้ว"
        )

    def _start_officer_announcement(self):
        """Capture real microphone PCM and distribute it to both Bluetooth mesh and Internet risk zones."""
        if self._announcement_process is not None and self._announcement_process.poll() is None:
            return

        peer_count = self.mesh_service.get_relay_peer_count() if hasattr(self, "mesh_service") and self.mesh_service else 0

        try:
            self._announcement_stop.clear()
            self._announcement_process = subprocess.Popen(
                ["arecord", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=0,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            self.lbl_announcement_status.setText(f"เปิดไมโครโฟนไม่สำเร็จ: {exc}")
            return

        # Prepare active pinned disaster zones for internet geo-fenced streaming
        active_zones = [z.to_dict() for z in self.db.get_active_zones() if z.is_active]
        announcement_id = f"ANNOUNCE_{int(time.time() * 1000)}"
        if self.server:
            self.server.start_announcement(announcement_id, active_zones)

        self.btn_announcement_start.setEnabled(False)
        self.btn_announcement_stop.setEnabled(True)
        net_status = f"อินเทอร์เน็ต: {len(active_zones)} จุดคุมพื้นที่ (ไม่ใช้บลูทูธ)"
        self.lbl_announcement_status.setText(
            f"กำลังประกาศสด ({net_status}) • กดหยุดเมื่อจบข้อความ"
        )

        def pump_audio():
            sequence = 0
            process = self._announcement_process
            try:
                while (not self._announcement_stop.is_set() and process and
                       process.poll() is None and process.stdout):
                    chunk = process.stdout.read(4000)  # 0.25 s of 8 kHz mono PCM
                    if not chunk:
                        break
                    sequence += 1
                    # Broadcast strictly over Internet to active pinned risk zones (no Bluetooth)
                    if self.server:
                        try:
                            self.server.feed_announcement_chunk(chunk)
                        except Exception:
                            pass
            finally:
                self._announcement_stop.set()
                if process and process.poll() is None:
                    try:
                        process.terminate()
                    except OSError:
                        pass
                self._announcement_process = None
                if self.server:
                    try:
                        self.server.stop_announcement()
                    except Exception:
                        pass
                self.sig_mesh_status.emit("สิ้นสุดการประกาศจากไมโครโฟนเจ้าหน้าที่ (อินเทอร์เน็ตคุมพื้นที่)")

        threading.Thread(target=pump_audio, daemon=True, name="Officer-Announcement-Mic").start()

    def _stop_officer_announcement(self):
        self._announcement_stop.set()
        process = self._announcement_process
        if process and process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass
        self._announcement_process = None
        if self.server:
            try:
                self.server.stop_announcement()
            except Exception:
                pass
        self.btn_announcement_start.setEnabled(True)
        self.btn_announcement_stop.setEnabled(False)
        self.lbl_announcement_status.setText("หยุดประกาศแล้ว (ปิดไมค์)")

    def _trigger_mesh_scan(self):
        """Triggers fresh Bluetooth Mesh scan."""
        if hasattr(self, "mesh_service") and self.mesh_service:
            self.lbl_status_ticker.setText("กำลังสแกนค้นหาอุปกรณ์บลูทูธแมชในรัศมี...")
            # If scanner loop is running, it continuously bursts scans

    # -----------------------------------------------------------
    # SLOTS & EVENT HANDLERS
    # -----------------------------------------------------------
    def _refresh_official_feed(self):
        if not hasattr(self, "official_feed_panel"):
            return
        self.official_feed_panel.set_loading()

        def worker():
            try:
                self.sig_official_feed_loaded.emit({"alerts": OfficialCellBroadcastFeed.fetch_recent(max_age_days=2)})
            except Exception as exc:
                self.sig_official_feed_loaded.emit({"error": str(exc)})

        threading.Thread(target=worker, daemon=True, name="Official-Cell-Broadcast-Feed").start()

    @Slot(object)
    def _on_official_feed_loaded(self, result):
        if not hasattr(self, "official_feed_panel"):
            return
        if result.get("error"):
            self.official_feed_panel.set_error("ไม่สามารถเชื่อมแหล่งข้อมูล ปภ.: " + result["error"])
            return
        today = OfficialCellBroadcastFeed.current_day()
        first_day = (today - timedelta(days=2)).isoformat()
        alerts = [a for a in result.get("alerts", []) if first_day <= a.issued_at[:10] <= today.isoformat()]
        self.official_feed_panel.set_alerts(alerts)
        if hasattr(self, "map_widget"):
            self.map_widget.set_official_alerts(alerts)

    @Slot(float, float, float, str, str)
    def _on_adopt_official_area(self, lat: float, lng: float, radius: float, prov_title: str, alert_title: str):
        """Adopt official NDWC alert area into Mic announcement and Zone dispatch controls."""
        # 1. Update Mic Announcement inputs
        if hasattr(self, "spin_mic_lat"):
            self.spin_mic_lat.setValue(lat)
        if hasattr(self, "spin_mic_lng"):
            self.spin_mic_lng.setValue(lng)
        if hasattr(self, "spin_mic_radius"):
            self.spin_mic_radius.setValue(radius)
        if hasattr(self, "lbl_mic_area_info"):
            self.lbl_mic_area_info.setText(
                f"นำเข้าพื้นที่ ปภ. [{prov_title}]: {lat:.4f}, {lng:.4f} (รัศมี {radius:.1f} กม.) • กด “ปักหมุดไมค์ประกาศ” เพื่อคุมพื้นที่"
            )

        # 2. Update Zone Control draft inputs for mobile phone push alert
        if hasattr(self, "zone_panel"):
            if hasattr(self.zone_panel, "spin_lat"):
                self.zone_panel.spin_lat.setValue(lat)
            if hasattr(self.zone_panel, "spin_lng"):
                self.zone_panel.spin_lng.setValue(lng)
            if hasattr(self.zone_panel, "spin_radius"):
                self.zone_panel.spin_radius.setValue(radius)
            if hasattr(self.zone_panel, "txt_title"):
                self.zone_panel.txt_title.setText(f"พื้นที่เตือนภัย ปภ. ({prov_title})")
            if hasattr(self.zone_panel, "txt_instruction"):
                clean_title = alert_title or f"ประกาศเตือนภัยทางการในพื้นที่จังหวัด{prov_title}"
                self.zone_panel.txt_instruction.setText(clean_title)
            if hasattr(self.zone_panel, "chk_risk"):
                self.zone_panel.chk_risk.setChecked(True)

        # 3. Smooth fly to location on Leaflet map
        if hasattr(self, "map_widget"):
            self.map_widget.pan_to(lat, lng, zoom=10)

        # 4. Status ticker notification
        if hasattr(self, "lbl_status_ticker"):
            self.lbl_status_ticker.setText(
                f"นำเข้าพื้นที่ตามประกาศ ปภ. [{prov_title}] แล้ว (รัศมี {radius:.1f} กม.) • พร้อมเปิดไมค์ประกาศหรือกดส่งแจ้งเตือน Cloud เข้ามือถือได้ทันที"
            )

    def _on_zone_removal_from_ui(self, zones: list[DisasterZone]):
        self._on_zone_broadcast_from_ui(zones, notify=False)

    def _on_zone_broadcast_from_ui(self, zones: list[DisasterZone], *, notify: bool = True):
        active = [zone for zone in zones if zone.is_active and zone.zone_id != "MIC_ZONE_01"][:10]
        self.db.replace_active_zones(active, microphone=False)
        self.current_zones = self.db.get_active_zones()
        self.current_zone = self.current_zones[0] if self.current_zones else None
        self.map_widget.clear_pending_risk_point()
        self.map_widget.set_disaster_zones(self.current_zones)
        self.zone_panel.set_active_zones(active)
        if not notify:
            self.lbl_status_ticker.setText("ลบหมุดพื้นที่เสี่ยงของจุดที่เลือกแล้ว • ไม่ส่งแจ้งเตือน")
        elif active:
            self.map_widget.pan_to(active[-1].center_lat, active[-1].center_lng, zoom=12)
            self.lbl_status_ticker.setText(
                f"กำลังส่งคำเตือนออนไลน์สำหรับพื้นที่เสี่ยง {len(active)} จุด"
            )
            threading.Thread(
                target=self._dispatch_active_zones_online, args=(active,),
                daemon=True, name="EOC-Online-Zone-Dispatch"
            ).start()
        else:
            self.lbl_status_ticker.setText("ไม่มีพื้นที่เสี่ยง: ไม่แสดงจุดและไม่ส่งคำเตือนออนไลน์")
        self.reload_data_from_db()

    def _save_mic_zone_from_panel(self):
        lat = self.spin_mic_lat.value()
        lng = self.spin_mic_lng.value()
        radius = self.spin_mic_radius.value()
        if abs(lat) < 0.00001 and abs(lng) < 0.00001:
            self.lbl_mic_area_info.setText("กรุณากำหนดพิกัด Lat/Lng หรือคลิกเลือกบนแผนที่ก่อน")
            return
        zone = DisasterZone(
            zone_id="MIC_ZONE_01",
            title="พื้นที่ควบคุมไมค์ประกาศ (อินเทอร์เน็ต)",
            hazard_type="ANNOUNCEMENT",
            severity="WARNING",
            center_lat=lat,
            center_lng=lng,
            radius_km=radius,
            instruction="พื้นที่ควบคุมการถ่ายทอดเสียงไมค์ประกาศเจ้าหน้าที่ (ผ่านอินเทอร์เน็ต)",
            agency="ศูนย์ปฏิบัติการสถานการณ์ภัยพิบัติ (EOC)",
            created_at=time.time(),
            is_active=True,
        )
        self.db.replace_active_zones([zone], microphone=True)
        self.current_zones = self.db.get_active_zones()
        self.current_zone = zone
        self.map_widget.clear_pending_risk_point()
        self.map_widget.set_disaster_zones(self.current_zones)
        self.map_widget.pan_to(lat, lng, zoom=12)
        self.lbl_mic_area_info.setText(
            f"ปักหมุดคุมพื้นที่แล้ว: {lat:.4f}, {lng:.4f} (รัศมี {radius:.1f} กม.) • ไม่ส่งแจ้งเตือน"
        )
        self.lbl_status_ticker.setText(
            f"ปักหมุดคุมพื้นที่ไมค์ประกาศแล้ว (รัศมี {radius:.1f} กม. ไม่แจ้งเตือน) • จะแจ้งเตือนเมื่อเปิดไมค์ประกาศเท่านั้น"
        )
        self.reload_data_from_db()

    def _clear_mic_zone_from_panel(self):
        self.db.replace_active_zones([], microphone=True)
        self.current_zones = self.db.get_active_zones()
        self.current_zone = self.current_zones[0] if self.current_zones else None
        self.map_widget.clear_pending_risk_point()
        self.map_widget.set_disaster_zones(self.current_zones)
        self.lbl_mic_area_info.setText("ล้างเฉพาะหมุดไมค์แล้ว • ยังไม่ได้กำหนดพื้นที่ไมค์")
        self.lbl_status_ticker.setText("ล้างพื้นที่คุมไมค์ประกาศแล้ว")
        self.reload_data_from_db()

    def _dispatch_active_zones_online(self, zones: list[DisasterZone]):
        self.sig_online_zone_dispatch.emit(ZoneCloudDispatcher.dispatch_active_zones(zones))

    @Slot(object)
    def _on_online_zone_dispatch_finished(self, results):
        successful = sum(1 for result in results if result.get("status") == "success")
        failed = [result.get("error", "ส่งไม่สำเร็จ") for result in results if result.get("status") != "success"]
        if successful:
            self.lbl_status_ticker.setText(f"ส่ง FCM ไปยังแอป RescueAlert สำเร็จ {successful} พื้นที่")
            self.db.log_event("INFO", "ONLINE_ZONE_DISPATCH", f"ส่ง FCM สำเร็จ {successful} พื้นที่")
        elif failed:
            self.lbl_status_ticker.setText(f"ส่ง FCM ไม่สำเร็จ: {failed[0]}")
            self.db.log_event("ERROR", "ONLINE_ZONE_DISPATCH", "ส่ง FCM ไม่สำเร็จ", failed[0])

    @Slot(object)
    def _on_server_new_sos(self, case: SosCase):
        if self.db.get_sos_case(case.case_id) is None:
            return
        ts = datetime.now().strftime("%H:%M:%S")
        self.lbl_status_ticker.setText(f"[{ts}] ได้รับสัญญาณ SOS จาก {case.citizen_name} ({case.device_id})")
        self.map_widget.add_or_update_sos(case)
        self.reload_data_from_db()
        # Switch tab to SOS Queue to highlight new distress signal
        if hasattr(self, "tab_console"):
            self.tab_console.setCurrentIndex(0)

    @Slot(str, str)
    def _on_server_sos_updated(self, case_id: str, new_status: str):
        case = self.db.get_sos_case(case_id)
        if case and case.case_type == "GENERAL":
            self.mesh_service.send_sos_status(case.device_id, case_id, new_status)
        if new_status in ("RESCUED_SAFE", "REMOVED"):
            self.map_widget.clear_markers()
        self.reload_data_from_db()

    @Slot(object)
    def _on_server_zone_broadcasted(self, zone: DisasterZone):
        self.current_zones = [zone]
        self.current_zone = zone
        self.map_widget.set_disaster_zones(self.current_zones)
        self.zone_panel.set_active_zones([z for z in self.current_zones if z.zone_id != "MIC_ZONE_01"])
        self.reload_data_from_db()

    def _update_case_status(self, case_id: str, new_status: str):
        if new_status == "RESCUED_SAFE":
            case = self.db.get_sos_case(case_id)
            if case is None:
                return
            self.lbl_status_ticker.setText("กำลังปิดเคสและลบข้อมูลจาก Oracle")
            def complete():
                try:
                    if self.server.cloud_bridge:
                        self.server.cloud_bridge.complete_case(case_id)
                    else:
                        self.server.complete_case(case_id, count=True)
                    self.sig_case_finished.emit(case_id, case.device_id, case.case_type, True, "")
                except Exception as exc:
                    self.sig_case_finished.emit(case_id, case.device_id, case.case_type, False, type(exc).__name__)
            threading.Thread(target=complete, daemon=True, name="EOC-Complete-Case").start()
            return
        team = "ทีมกู้ภัยเคลื่อนที่เร็ว 01" if new_status == "DISPATCHED" else ""
        self.db.update_case_status(case_id, new_status, team)
        ts = datetime.now().strftime("%H:%M:%S")
        self.lbl_status_ticker.setText(f"[{ts}] ปรับปรุงสถานะเคส {case_id} -> {new_status}")
        self._on_server_sos_updated(case_id, new_status)

    @Slot(str, str, str, bool, str)
    def _on_case_finished(self, case_id, device_id, case_type, success, error):
        if success:
            if case_type == "GENERAL":
                self.mesh_service.send_sos_status(device_id, case_id, "RESCUED_SAFE")
            self.map_widget.clear_markers()
            self.lbl_status_ticker.setText("ช่วยเหลือแล้ว • ลบข้อมูลเคสและไฟล์แนบ เหลือเฉพาะยอดช่วยเหลือ")
        else:
            self.lbl_status_ticker.setText("รอปิดเคสกับ Oracle • จะลองใหม่ ข้อมูลและยอดยังไม่เปลี่ยน: " + error)
        self.reload_data_from_db()

    def _clear_rescued_total(self):
        self.db.clear_rescued_total()
        self.reload_data_from_db()
        self.lbl_status_ticker.setText("ล้างแคชยอดช่วยเหลือแล้ว • ไม่ลบเคสที่รอช่วยเหลือ")

    def reload_data_from_db(self):
        zones = self.db.get_active_zones()
        self.current_zones = zones
        all_cases = self.db.get_all_sos_cases()
        # ช่วงเริ่มเกิดเหตุ ใช้ออนไลน์กับข้อมูลผู้ป่วยก่อน ไม่รวม BT-MESH
        cases = all_cases

        # Update distance & in-zone flag for all cases
        in_zone_count = 0
        bedridden_count = 0
        dispatched_count = 0
        safe_count = self.db.rescued_total()

        for c in cases:
            c.update_zone_status(zones)
            if c.is_in_danger_zone:
                in_zone_count += 1
            if c.is_bedridden:
                bedridden_count += 1
            if c.status == "DISPATCHED":
                dispatched_count += 1

            # Push pin to map
            self.map_widget.add_or_update_sos(c)

        # Update active evacuation and safe parking sites on map
        active_sites = self.db.get_active_evacuation_sites()
        self.map_widget.set_evacuation_sites(active_sites)

        # Update Dispatch Queue Panel
        self.dispatch_panel.update_cases(cases)

        # Update Top Header Metrics
        self.lbl_metric_in_zone.setText(f"ในเขตน้ำท่วม: {in_zone_count}")
        self.lbl_metric_bedridden.setText(f"ติดเตียง: {bedridden_count}")
        self.lbl_metric_dispatched.setText(f"ส่งทีมแล้ว: {dispatched_count}")
        self.lbl_metric_safe.setText(f"ช่วยเหลือแล้ว: {safe_count}")

        # Update Bluetooth Mesh KPI (App Only)
        if hasattr(self, "mesh_service") and self.mesh_service:
            active_nodes = self.mesh_service.get_active_nodes(max_age_seconds=20.0)
            active_keys = {getattr(n, "node_id", None) or n.address for n in active_nodes}
            if hasattr(self, "_known_mesh_devices"):
                self._known_mesh_devices = self._known_mesh_devices.intersection(active_keys)
            active_count = len(active_keys)
            if active_count != getattr(self, "_last_kpi_mesh_count", -1):
                self._last_kpi_mesh_count = active_count
                if hasattr(self, "lbl_metric_mesh"):
                    self.lbl_metric_mesh.setText(f"บลูทูธ (แอป): {active_count} เครื่อง")

        # Update DEFCON Threat Badge
        if hasattr(self, "lbl_defcon"):
            if in_zone_count > 0:
                self.lbl_defcon.setText("DEFCON 1: สภาวะวิกฤตภัยพิบัติ")
                self.lbl_defcon.setStyleSheet(
                    "background: rgba(239, 68, 68, 0.2); color: #FCA5A5; "
                    "border: 1px solid #EF4444; border-radius: 6px; "
                    "padding: 5px 12px; font-weight: 800; font-size: 11.5px; letter-spacing: 0.5px;"
                )
            else:
                self.lbl_defcon.setText("DEFCON 4: สภาวะปกติ เฝ้าระวัง")
                self.lbl_defcon.setStyleSheet(
                    "background: rgba(2, 132, 199, 0.2); color: #38BDF8; "
                    "border: 1px solid #0284C7; border-radius: 6px; "
                    "padding: 5px 12px; font-weight: 800; font-size: 11.5px; letter-spacing: 0.5px;"
                )

    def _clear_all_cases(self):
        self.db.clear_all()
        self.map_widget.clear_markers()
        self.dispatch_panel.update_cases([])
        self.reload_data_from_db()
        ts = datetime.now().strftime("%H:%M:%S")
        self.lbl_status_ticker.setText(f"[{ts}] ล้างข้อมูลเคสทั้งหมดเรียบร้อย")

    def closeEvent(self, event):
        self._stop_internet_call_mic()
        if hasattr(self, "internet_call_audio") and self.internet_call_audio:
            self.internet_call_audio.stop()
        if self._incoming_call_dialog:
            try:
                self._incoming_call_dialog._stop_ringtone()
                self._incoming_call_dialog.close()
            except Exception:
                pass
            self._incoming_call_dialog = None
        if hasattr(self, "mesh_service") and self.mesh_service:
            self.mesh_service.stop()
        if self.server:
            self.server.stop()
        super().closeEvent(event)
