# Chuaykan 2.4.28 — แก้ข้อมูลสายด่วน

- ถอด 055-403-195, 055-411-061 และ 056-221-199 จากรายการฉุกเฉิน รวม 4 รายการ ไม่เดาเบอร์ทดแทน
- สายด่วนกลาง 1669/1784 ยังอยู่ทุกจังหวัด; 1669 ไม่แสดงเป็นเบอร์ตรงมูลนิธิ
- แก้ชื่อบริการ 1460, 1418, 1163 และชื่อเบอร์กลางโรงพยาบาล
- 199 ระบุขอบเขตที่ยืนยันได้คือ กทม.; ยังไม่รับรองทุกพื้นที่
- ไม่อ้างตรวจรับรองเบอร์ท้องถิ่นครบหรือโทรฟรี/รับสาย 24 ชั่วโมงแบบเหมารวม
- คืนไฟล์ Android data ที่ขาดใน ZIP เดิม; ซอร์สยังใช้ค่าตัวอย่างเพื่อตั้งเซิร์ฟเวอร์เอง
- APK ใช้คีย์เผยแพร่เดียวกับ 2.4.27 ติดตั้งทับ 2.4.27 ได้โดยไม่สั่งล้างข้อมูล แต่รุ่น debug key เดิมติดตั้งทับไม่ได้
- งานนี้แก้ข้อมูลสายด่วนเท่านั้น ไม่เปลี่ยน Oracle, SOS, โทรกลับ หรือระบบประกาศ
- ยังไม่ทดสอบโทรจริง ไม่ได้รับรองเบอร์ท้องถิ่นที่ไม่มีหลักฐาน

หลักฐานเบอร์ผิด:
- https://www.opsmoac.go.th/uttaradit-contact
- https://www2.uttaradit.go.th/travel_top/detail/2/data.html
- https://www.yamaha-motor.co.th/dealer-services/dealer/4747-yamaha-riders-club-nakhon-sawan

หลักฐานชื่อบริการ:
- https://udh.moph.go.th/udh/profile/
- https://rid7.rid.go.th/th/news/101329
- https://pohtecktung.org/index.php?Itemid=112&catid=63&id=5038%3A2026-09-29-04-39-09&option=com_content&view=article
- https://www.prd.go.th/th/content/category/detail/id/33/iid/447299
- https://webportal.bangkok.go.th/healthcenter29/page/main/5540/-/0/info/536469
