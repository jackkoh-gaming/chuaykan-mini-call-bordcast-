#!/usr/bin/env python3
"""
DispatchPanel: Live queue of citizen mobile SOS reports.
Provides filtering, audio playback, status updates, and map focus.
"""
from __future__ import annotations
import subprocess
import time
from typing import List, Optional, Dict

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QButtonGroup, QRadioButton, QTabBar
)

from src.core.config import (
    COLOR_BORDER, COLOR_FLOOD_BLUE, COLOR_FLOOD_CYAN,
    COLOR_EMERGENCY_RED, COLOR_ALERT_AMBER, COLOR_SIGNAL_GREEN,
    RECORDINGS_DIR, ICONS_DIR
)
from src.core.models import SosCase


class SosCard(QFrame):
    """Card widget representing a single citizen SOS case."""
    clicked = Signal(str)
    dispatch_clicked = Signal(str)
    safe_clicked = Signal(str)
    call_clicked = Signal(str, str, str)

    def __init__(self, case: SosCase, parent=None):
        super().__init__(parent)
        self.case = case
        self._init_ui()

    def _init_ui(self):
        self.setObjectName("panelCard")
        # Unified Midnight Navy Slate background with severity left rail indicator
        if self.case.status == "RESCUED_SAFE":
            rail_color = "#10B981"
        elif self.case.is_bedridden:
            rail_color = "#EF4444"
        elif self.case.is_in_danger_zone:
            rail_color = "#EF4444"
        elif self.case.is_elderly:
            rail_color = "#F59E0B"
        else:
            rail_color = "#00F2FE"

        self.setStyleSheet(f"""
            QFrame#panelCard {{
                background-color: #131D31;
                border-left: 4px solid {rail_color};
                border-top: 1px solid #253554;
                border-right: 1px solid #253554;
                border-bottom: 1px solid #253554;
                border-radius: 8px;
            }}
            QPushButton#btnPrimary {{
                background-color: #0284C7;
                border: 1px solid #38BDF8;
                color: #FFFFFF;
                font-weight: bold;
                border-radius: 6px;
                padding: 4px 10px;
            }}
            QPushButton#btnPrimary:hover {{
                background-color: #0369A1;
                border-color: #7DD3FC;
            }}
            QPushButton#btnSuccess {{
                background-color: #059669;
                border: 1px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                border-radius: 6px;
                padding: 4px 10px;
            }}
            QPushButton#btnSuccess:hover {{
                background-color: #047857;
                border-color: #6EE7B7;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        # Header Row: Badges
        badge_row = QHBoxLayout()
        badge_row.setSpacing(4)

        if self.case.is_in_danger_zone:
            lbl_zone = QLabel(f"ในเขตน้ำท่วม ({self.case.distance_to_epicenter_km or 0:.1f} กม.)")
            lbl_zone.setObjectName("badgeCritical")
            badge_row.addWidget(lbl_zone)
        else:
            dist_str = f"{self.case.distance_to_epicenter_km:.1f} กม." if self.case.distance_to_epicenter_km else "นอกเขต"
            lbl_zone = QLabel(f"นอกเขต ({dist_str})")
            lbl_zone.setStyleSheet("background: #1A2844; color: #94A3B8; border: 1px solid #2A3C60; border-radius: 4px; padding: 2px 6px; font-size: 11px;")
            badge_row.addWidget(lbl_zone)

        if self.case.is_bedridden:
            bed_box = QHBoxLayout()
            bed_box.setSpacing(4)
            b_ico = QLabel()
            b_path = ICONS_DIR / "bedridden.svg"
            if b_path.exists():
                b_ico.setPixmap(QIcon(str(b_path)).pixmap(12, 12))
            bed_box.addWidget(b_ico)
            lbl_bed = QLabel("ผู้ป่วยติดเตียง")
            lbl_bed.setObjectName("badgeCritical")
            bed_box.addWidget(lbl_bed)
            badge_row.addLayout(bed_box)

        if self.case.status == "PENDING":
            lbl_status = QLabel("รอดำเนินการ")
            lbl_status.setObjectName("badgeCritical")
        elif self.case.status == "DISPATCHED":
            lbl_status = QLabel("ส่งทีมช่วยแล้ว")
            lbl_status.setObjectName("badgeWarning")
        else:
            lbl_status = QLabel("ช่วยเหลือแล้ว")
            lbl_status.setObjectName("badgeSafe")
        badge_row.addWidget(lbl_status)
        badge_row.addStretch()
        layout.addLayout(badge_row)

        # Citizen Info Row
        name_row = QHBoxLayout()
        name_row.setSpacing(6)
        u_ico = QLabel()
        u_path = ICONS_DIR / "user.svg"
        if u_path.exists():
            u_ico.setPixmap(QIcon(str(u_path)).pixmap(14, 14))
        name_row.addWidget(u_ico)
        lbl_name = QLabel(self.case.citizen_name)
        lbl_name.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFFFFF;")
        name_row.addWidget(lbl_name)
        name_row.addStretch()
        layout.addLayout(name_row)

        phone_row = QHBoxLayout()
        phone_row.setSpacing(6)
        p_ico = QLabel()
        p_path = ICONS_DIR / "phone.svg"
        if p_path.exists():
            p_ico.setPixmap(QIcon(str(p_path)).pixmap(12, 12))
        phone_row.addWidget(p_ico)
        lbl_phone = QLabel(f"เบอร์โทร: {self.case.phone_number}  |  สมาชิก: {self.case.member_count} คน")
        lbl_phone.setStyleSheet("color: #38BDF8; font-size: 12px;")
        phone_row.addWidget(lbl_phone)
        phone_row.addStretch()
        layout.addLayout(phone_row)

        # Coordinates info
        if self.case.latitude is not None and self.case.longitude is not None:
            coord_row = QHBoxLayout()
            coord_row.setSpacing(6)
            c_ico = QLabel()
            c_path = ICONS_DIR / "location_pin.svg"
            if c_path.exists():
                c_ico.setPixmap(QIcon(str(c_path)).pixmap(12, 12))
            coord_row.addWidget(c_ico)
            lbl_coords = QLabel(f"พิกัด GPS: {self.case.latitude:.5f}, {self.case.longitude:.5f} (ความแม่นยำ {self.case.accuracy_meters:.0f} ม.)")
            lbl_coords.setObjectName("subText")
            coord_row.addWidget(lbl_coords)
            coord_row.addStretch()
            layout.addLayout(coord_row)

        # Urgent note
        if self.case.urgent_note:
            note_row = QHBoxLayout()
            note_row.setSpacing(6)
            n_ico = QLabel()
            n_path = ICONS_DIR / "chat.svg"
            if n_path.exists():
                n_ico.setPixmap(QIcon(str(n_path)).pixmap(12, 12))
            note_row.addWidget(n_ico, alignment=Qt.AlignmentFlag.AlignTop)
            lbl_note = QLabel(f"\"{self.case.urgent_note}\"")
            lbl_note.setWordWrap(True)
            lbl_note.setStyleSheet("background: #17233B; border: 1px solid #253554; color: #E2E8F0; padding: 5px 8px; border-radius: 4px; font-size: 11.5px;")
            note_row.addWidget(lbl_note, 1)
            layout.addLayout(note_row)

        # Audio Playback Button (if audio file exists)
        if self.case.audio_file:
            audio_box = QHBoxLayout()
            audio_box.setSpacing(6)
            btn_audio = QPushButton("ฟังคลิปเสียงบันทึกเหตุ (Distress Audio)")
            spk_path = ICONS_DIR / "speaker.svg"
            if spk_path.exists():
                btn_audio.setIcon(QIcon(str(spk_path)))
                btn_audio.setIconSize(QSize(15, 15))
            btn_audio.setStyleSheet("background-color: #202F4D; border: 1px solid #0284C7; color: #38BDF8; font-size: 11px; padding: 5px 8px; border-radius: 5px;")
            btn_audio.clicked.connect(self._play_audio)
            audio_box.addWidget(btn_audio, 1)

            lbl_wave = QLabel("||ı|||ı|ı|||")
            lbl_wave.setStyleSheet("color: #00F2FE; font-weight: bold; font-family: monospace; font-size: 12px; letter-spacing: 1.5px;")
            audio_box.addWidget(lbl_wave)
            layout.addLayout(audio_box)

        # Action Buttons Row
        action_row = QHBoxLayout()
        action_row.setSpacing(6)

        btn_dispatch = QPushButton("โทรกลับ หรือติดต่อกลับ")
        btn_dispatch.setObjectName("btnPrimary")
        btn_dispatch.setFixedHeight(28)
        phone_ico = ICONS_DIR / "phone.svg"
        if phone_ico.exists():
            btn_dispatch.setIcon(QIcon(str(phone_ico)))
            btn_dispatch.setIconSize(QSize(13, 13))

        def _handle_call_back():
            phone = getattr(self.case, 'phone_number', '') or ''
            name = getattr(self.case, 'citizen_name', '') or ''
            self.call_clicked.emit(self.case.case_id, str(phone), str(name))
            self.dispatch_clicked.emit(self.case.case_id)

        btn_dispatch.clicked.connect(_handle_call_back)
        action_row.addWidget(btn_dispatch)

        btn_safe = QPushButton("สำเร็จ (ปลอดภัย)")
        btn_safe.setObjectName("btnSuccess")
        btn_safe.setFixedHeight(28)
        btn_safe.clicked.connect(lambda: self.safe_clicked.emit(self.case.case_id))
        action_row.addWidget(btn_safe)

        layout.addLayout(action_row)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        self.clicked.emit(self.case.case_id)

    def _play_audio(self):
        if not self.case.audio_file:
            return
        audio_path = RECORDINGS_DIR / self.case.audio_file
        if audio_path.exists():
            try:
                # Run lightweight background audio playback via ffplay or aplay
                subprocess.Popen(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(audio_path)])
            except Exception:
                pass


class DispatchPanel(QWidget):
    """
    Live Queue Panel for citizen SOS requests.
    """
    case_focused = Signal(str)
    status_change_requested = Signal(str, str) # case_id, new_status
    call_requested = Signal(str, str, str) # case_id, phone, name

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(320)
        self.all_cases: List[SosCase] = []
        self.current_filter = "ALL"
        self.current_case_type = "CRITICAL"
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Header
        header_frame = QFrame()
        header_frame.setObjectName("elevatedCard")
        h_layout = QVBoxLayout(header_frame)
        h_layout.setContentsMargins(10, 8, 10, 8)
        h_layout.setSpacing(4)

        header_title_row = QHBoxLayout()
        header_title_row.setSpacing(6)
        lbl_q_icon = QLabel()
        q_icon_path = ICONS_DIR / "shield_alert.svg"
        if q_icon_path.exists():
            lbl_q_icon.setPixmap(QIcon(str(q_icon_path)).pixmap(18, 18))
        header_title_row.addWidget(lbl_q_icon)

        lbl_title = QLabel("รับแจ้งเหตุ SOS สด (DISPATCH QUEUE)")
        lbl_title.setObjectName("headerTitle")
        header_title_row.addWidget(lbl_title)
        header_title_row.addStretch()
        h_layout.addLayout(header_title_row)

        self.lbl_stats = QLabel("ทั้งหมด 0 เคส • ในเขตน้ำท่วม 0 • ติดเตียง 0")
        self.lbl_stats.setObjectName("subText")
        h_layout.addWidget(self.lbl_stats)
        layout.addWidget(header_frame)

        self.queue_tabs = QTabBar()
        self.queue_tabs.addTab("ผู้ป่วยวิกฤต (0)")
        self.queue_tabs.addTab("รอช่วยเหลือทั่วไป (0)")
        self.queue_tabs.currentChanged.connect(self._change_queue)
        layout.addWidget(self.queue_tabs)

        # Filter Tabs Row
        filter_bar = QHBoxLayout()
        filter_bar.setSpacing(4)

        self.btn_f_all = QPushButton("ทั้งหมด")
        self.btn_f_in_zone = QPushButton("ในเขตน้ำท่วม")
        self.btn_f_bedridden = QPushButton("ติดเตียง")
        bed_path = ICONS_DIR / "bedridden.svg"
        if bed_path.exists():
            self.btn_f_bedridden.setIcon(QIcon(str(bed_path)))
            self.btn_f_bedridden.setIconSize(QSize(13, 13))
        self.btn_f_pending = QPushButton("รอช่วย")

        self.filter_buttons = [self.btn_f_all, self.btn_f_in_zone, self.btn_f_bedridden, self.btn_f_pending]
        for btn in self.filter_buttons:
            btn.setFixedHeight(26)
            btn.setStyleSheet("padding: 2px 6px; font-size: 11px;")
            filter_bar.addWidget(btn)

        self.btn_f_all.clicked.connect(lambda: self._set_filter("ALL"))
        self.btn_f_in_zone.clicked.connect(lambda: self._set_filter("IN_ZONE"))
        self.btn_f_bedridden.clicked.connect(lambda: self._set_filter("BEDRIDDEN"))
        self.btn_f_pending.clicked.connect(lambda: self._set_filter("PENDING"))

        layout.addLayout(filter_bar)
        self._highlight_active_filter_btn()

        # Scrollable Case List
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("background: transparent; border: none;")

        self.container = QWidget()
        self.case_list_layout = QVBoxLayout(self.container)
        self.case_list_layout.setContentsMargins(0, 0, 0, 0)
        self.case_list_layout.setSpacing(8)
        self.case_list_layout.addStretch()

        self.scroll.setWidget(self.container)
        layout.addWidget(self.scroll)

    def _set_filter(self, f: str):
        self.current_filter = f
        self._highlight_active_filter_btn()
        self.render_cases()

    def _highlight_active_filter_btn(self):
        for btn, name in zip(self.filter_buttons, ["ALL", "IN_ZONE", "BEDRIDDEN", "PENDING"]):
            if name == self.current_filter:
                btn.setStyleSheet(f"background-color: {COLOR_FLOOD_BLUE}; color: #FFFFFF; border: 1px solid #38BDF8; font-weight: bold; font-size: 11.5px; border-radius: 5px;")
            else:
                btn.setStyleSheet("background-color: #202F4D; color: #94A3B8; border: 1px solid #33476E; font-size: 11.5px; border-radius: 5px;")

    def update_cases(self, cases: List[SosCase]):
        self.all_cases = list(cases)
        critical = sum(c.case_type == "CRITICAL" for c in cases)
        general = sum(c.case_type == "GENERAL" and c.status != "RESCUED_SAFE" for c in cases)
        self.queue_tabs.setTabText(0, f"ผู้ป่วยวิกฤต ({critical})")
        self.queue_tabs.setTabText(1, f"รอช่วยเหลือทั่วไป ({general})")
        self.lbl_stats.setText(f"ผู้ป่วยวิกฤต {critical} เคส • รอช่วยเหลือทั่วไป {general} เคส")
        self.render_cases()

    def _change_queue(self, index: int):
        self.current_case_type = "CRITICAL" if index == 0 else "GENERAL"
        self.render_cases()

    def render_cases(self):
        # Clear existing card widgets
        while self.case_list_layout.count() > 1:
            item = self.case_list_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        # Apply current filter
        filtered = [c for c in self.all_cases if c.case_type == self.current_case_type and
                    (c.case_type != "GENERAL" or c.status != "RESCUED_SAFE")]
        if self.current_filter == "IN_ZONE":
            filtered = [c for c in filtered if c.is_in_danger_zone]
        elif self.current_filter == "BEDRIDDEN":
            filtered = [c for c in filtered if c.is_bedridden]
        elif self.current_filter == "PENDING":
            filtered = [c for c in filtered if c.status == "PENDING"]

        for case in filtered:
            card = SosCard(case)
            card.clicked.connect(self.case_focused)
            card.call_clicked.connect(self.call_requested)
            card.dispatch_clicked.connect(lambda cid: self.status_change_requested.emit(cid, "DISPATCHED"))
            card.safe_clicked.connect(lambda cid: self.status_change_requested.emit(cid, "RESCUED_SAFE"))
            self.case_list_layout.insertWidget(self.case_list_layout.count() - 1, card)
