"""8 kHz mono signed PCM adapters for real Windows input/output devices."""
import io
import subprocess
import sys
import threading


class WindowsPcmProcess:
    def __init__(self, capture):
        import sounddevice as sd
        self._lock = threading.Lock()
        self._closed = False
        self.stderr = io.BytesIO()
        self.stdin = None if capture else self
        self.stdout = self if capture else None
        stream_type = sd.RawInputStream if capture else sd.RawOutputStream
        try:
            self.stream = stream_type(samplerate=8000, channels=1, dtype="int16", blocksize=800)
            self.stream.start()
        except Exception as exc:
            raise OSError("เปิดอุปกรณ์เสียง Windows ไม่สำเร็จ: " + str(exc)) from exc

    def read(self, size):
        if self._closed:
            return b""
        try:
            data, _ = self.stream.read(size // 2)
            return bytes(data)
        except Exception as exc:
            if self._closed:
                return b""
            raise OSError("อ่านไมโครโฟนไม่สำเร็จ: " + str(exc)) from exc

    def write(self, data):
        if self._closed:
            raise OSError("ปิดช่องเสียงแล้ว")
        try:
            self.stream.write(data)
        except Exception as exc:
            raise OSError("เล่นเสียงไม่สำเร็จ: " + str(exc)) from exc
        return len(data)

    def poll(self):
        return 0 if self._closed else None

    def terminate(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
            try:
                self.stream.abort()
            finally:
                self.stream.close()

    kill = terminate
    close = terminate

    def wait(self, timeout=None):
        self.terminate()
        return 0


def capture_available():
    if sys.platform == "win32":
        try:
            import sounddevice as sd
            return sd.query_devices(kind="input")["max_input_channels"] > 0
        except Exception:
            return False
    import shutil
    return bool(shutil.which("arecord"))


def open_capture():
    if sys.platform == "win32":
        return WindowsPcmProcess(True)
    return subprocess.Popen(["arecord", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)


def open_playback():
    if sys.platform == "win32":
        return WindowsPcmProcess(False)
    return subprocess.Popen(["aplay", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
                            stdin=subprocess.PIPE, bufsize=0)
