package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.rescue.alert.data.*
import com.rescue.alert.model.*
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.util.Log

/** Explicit live checks: upstream outage must fail instead of substituting fixtures. */
@RunWith(AndroidJUnit4::class)
class LiveApiTest {
    private fun <T> awaitResult(start: (((List<T>) -> Unit)) -> Unit): List<T> {
        val latch = CountDownLatch(1)
        var result = emptyList<T>()
        start { result = it; latch.countDown() }
        assertTrue("API callback timed out", latch.await(90, TimeUnit.SECONDS))
        return result
    }
    @Test fun nbtcReadsBeyondFirstPage() {
        val rows = awaitResult<AmStation> { AmRadioRepository.fetchNbtcStations(300, it) }
        Log.i("LiveApiTest", "NBTC stations=${rows.size}")
        assertTrue("Expected more than the first 300 records", rows.size > 300)
    }
    @Test fun prdLiveStationWith690PrefixResolvesStream() {
        val rows = awaitResult<AmStation> { AmRadioRepository.getStations(it) }
        val station = rows.firstOrNull { it.id.startsWith("690") && it.isLive }
        assertNotNull("Live 690 station missing from real PRD response", station)
        assertTrue(station!!.supportsStreamLookup)
        val latch = CountDownLatch(1)
        var url: String? = null
        AmRadioRepository.fetchStreamUrl(station) { url = it; latch.countDown() }
        assertTrue(latch.await(25, TimeUnit.SECONDS))
        assertTrue("PRD detail returned no HTTPS stream", url?.startsWith("https://") == true)
        Log.i("LiveApiTest", "PRD station=${station.id} stream resolved")
    }
    @Test fun officialNewsParsedOnPhone() {
        val rows = awaitResult<DisasterNewsItem> { DisasterNewsRepository.getNews(true, it) }
        Log.i("LiveApiTest", "Official news=${rows.size}")
        assertTrue(rows.isNotEmpty())
    }
    @Test fun ridDamsParsedOnPhone() {
        val rows = awaitResult<DamItem> { DamMonitorRepository.getDams(true, it) }
        Log.i("LiveApiTest", "RID dams=${rows.size}")
        assertTrue(rows.size >= 35)
    }
    @Test fun thaiwaterParsedOnPhone() {
        val rows = awaitResult<BridgeItem> { BridgeMonitorRepository.getBridges(true, it) }
        Log.i("LiveApiTest", "ThaiWater displayed stations=${rows.size}")
        assertTrue(rows.isNotEmpty())
    }
}
