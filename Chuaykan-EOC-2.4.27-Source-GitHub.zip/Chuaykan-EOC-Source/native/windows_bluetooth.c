#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <ws2bth.h>
#include <bluetoothapis.h>
#include <stdio.h>
#include <stdint.h>
#define API __declspec(dllexport)
static GUID service_uuid = {0x16690002,0xfa01,0x2026,{0x8a,0x8c,0x2c,0x50,0xf1,0x58,0x7b,0xfc}};
static SOCKADDR_BTH endpoint;
static int register_service(WSAESETSERVICEOP operation) {
    CSADDR_INFO address = {0};
    WSAQUERYSETW query = {0};
    address.LocalAddr.lpSockaddr = (SOCKADDR *)&endpoint;
    address.LocalAddr.iSockaddrLength = sizeof(endpoint);
    address.iSocketType = SOCK_STREAM;
    address.iProtocol = BTHPROTO_RFCOMM;
    query.dwSize = sizeof(query);
    query.lpszServiceInstanceName = L"RescueAlertVoiceMesh";
    query.lpServiceClassId = &service_uuid;
    query.dwNameSpace = NS_BTH;
    query.dwNumberOfCsAddrs = 1;
    query.lpcsaBuffer = &address;
    return WSASetServiceW(&query, operation, 0);
}
API int ck_error(void) { return WSAGetLastError(); }
API uintptr_t ck_listen(void) {
    WSADATA data;
    if (WSAStartup(MAKEWORD(2,2), &data)) return (uintptr_t)INVALID_SOCKET;
    SOCKET fd = socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
    if (fd == INVALID_SOCKET) return (uintptr_t)fd;
    memset(&endpoint, 0, sizeof(endpoint));
    endpoint.addressFamily = AF_BTH;
    endpoint.port = 4; /* Android's existing direct-channel fallback uses channel 4. */
    if (bind(fd, (SOCKADDR *)&endpoint, sizeof(endpoint)) == SOCKET_ERROR) goto fail;
    int size = sizeof(endpoint);
    if (getsockname(fd, (SOCKADDR *)&endpoint, &size) == SOCKET_ERROR) goto fail;
    if (listen(fd, 16) == SOCKET_ERROR) goto fail;
    if (register_service(RNRSERVICE_REGISTER) == SOCKET_ERROR) goto fail;
    return (uintptr_t)fd;
fail: {
    int error = WSAGetLastError();
    closesocket(fd);
    WSASetLastError(error);
    return (uintptr_t)INVALID_SOCKET;
}}
API int ck_discoverable(int enabled) {
    BLUETOOTH_FIND_RADIO_PARAMS params = {sizeof(params)};
    HANDLE radio = NULL;
    HBLUETOOTH_RADIO_FIND finder = BluetoothFindFirstRadio(&params, &radio);
    if (!finder) return (int)GetLastError();
    BOOL ok = BluetoothEnableIncomingConnections(radio, enabled);
    if (ok) ok = BluetoothEnableDiscovery(radio, enabled);
    int error = ok ? 0 : (int)GetLastError();
    CloseHandle(radio);
    BluetoothFindRadioClose(finder);
    return error;
}
API uintptr_t ck_accept(uintptr_t fd, char *address, int capacity) {
    SOCKADDR_BTH peer = {0};
    int size = sizeof(peer);
    SOCKET client = accept((SOCKET)fd, (SOCKADDR *)&peer, &size);
    if (client == INVALID_SOCKET) return (uintptr_t)client;
    unsigned long long a = peer.btAddr;
    snprintf(address, capacity, "%02X:%02X:%02X:%02X:%02X:%02X", (unsigned)((a>>40)&255),
      (unsigned)((a>>32)&255), (unsigned)((a>>24)&255), (unsigned)((a>>16)&255),
      (unsigned)((a>>8)&255), (unsigned)(a&255));
    return (uintptr_t)client;
}
API int ck_recv(uintptr_t fd, char *buffer, int size) { return recv((SOCKET)fd, buffer, size, 0); }
API int ck_send(uintptr_t fd, const char *buffer, int size) { return send((SOCKET)fd, buffer, size, 0); }
API int ck_timeout(uintptr_t fd, int ms) {
    DWORD timeout = (DWORD)ms;
    if (setsockopt((SOCKET)fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout))) return -1;
    return setsockopt((SOCKET)fd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout));
}
API void ck_shutdown(uintptr_t fd, int how) { shutdown((SOCKET)fd, how); }
API void ck_close(uintptr_t fd) { closesocket((SOCKET)fd); }
API void ck_unregister(void) { register_service(RNRSERVICE_DELETE); }
