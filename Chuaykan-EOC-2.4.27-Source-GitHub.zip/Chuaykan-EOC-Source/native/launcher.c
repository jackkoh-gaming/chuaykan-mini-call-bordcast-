#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <wchar.h>
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR tail, int show) {
    (void)instance; (void)previous; (void)tail; (void)show;
    wchar_t base[32768], python[32768], command[32768];
    DWORD count = GetModuleFileNameW(NULL, base, 32768);
    if (count == 0 || count >= 32000) return 1;
    wchar_t *slash = wcsrchr(base, L'\\');
    if (!slash) return 1;
    *slash = 0;
    if (swprintf(python, 32768, L"%ls\\runtime\\pythonw.exe", base) < 0) return 1;
    if (swprintf(command, 32768, L"\"%ls\" -I \"%ls\\app\\windows_entry.py\"", python, base) < 0) return 1;
    if (GetFileAttributesW(python) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL, L"Extract the entire Chuaykan ZIP first. Keep runtime and app beside Chuaykan.exe.", L"Chuaykan", MB_OK|MB_ICONERROR);
        return 1;
    }
    STARTUPINFOW start = {0}; start.cb = sizeof(start);
    PROCESS_INFORMATION process = {0};
    if (!CreateProcessW(python, command, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, base, &start, &process)) {
        MessageBoxW(NULL, L"Cannot start the bundled Windows runtime. Extract all files and try again.", L"Chuaykan", MB_OK|MB_ICONERROR);
        return 1;
    }
    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD code = 1;
    GetExitCodeProcess(process.hProcess, &code);
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
    if (code) MessageBoxW(NULL, L"Chuaykan could not start or stopped with an error. See %LOCALAPPDATA%\\Chuaykan\\logs\\startup.log.", L"Chuaykan", MB_OK|MB_ICONERROR);
    return (int)code;
}
