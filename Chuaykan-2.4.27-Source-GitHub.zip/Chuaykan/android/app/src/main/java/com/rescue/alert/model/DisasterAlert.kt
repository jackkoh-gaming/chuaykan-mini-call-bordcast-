package com.rescue.alert.model

/**
 * CAP-compatible disaster alert data model.
 * Supports both Circle (center + radius) and Polygon area definitions.
 */
data class Point(val lat: Double, val lng: Double)

data class DisasterAlert(
    val alertId: String,
    val title: String,
    val instruction: String,
    val severity: String,         // "CRITICAL" or "WARNING"
    val centerLat: Double?,
    val centerLng: Double?,
    val radiusKm: Double?,
    val polygon: List<Point>?,
    val sentTimestamp: Long,
    val expiresAt: Long,
    val signature: String
)
