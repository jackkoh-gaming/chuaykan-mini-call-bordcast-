#!/usr/bin/env python3
"""
MeshPanel: Bluetooth Mesh Network Operations & Device Discovery Panel
Displays real-time off-grid Bluetooth Mesh nodes, nearby phones, signal RSSI,
and hardware gateway status.
Smooth 1 Hz reconciliation loop with in-place widget updates (Zero-Thrash).
"""
from __future__ import annotations
import time
from collections import OrderedDict
import subprocess
import shutil
import threading
from typing import List, Dict, Optional

from PySide6.QtCore import Qt, Signal, Slot, QSize, QTimer, QSettings
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QScrollArea, QTextEdit, QGridLayout, QListWidget, QListWidgetItem, QLayout
)

from src.core.config import (
    ICONS_DIR, RECORDINGS_DIR, RINGTONE_PATH, COLOR_FLOOD_CYAN, COLOR_FLOOD_BLUE,
    COLOR_SIGNAL_GREEN, COLOR_EMERGENCY_RED, COLOR_TEXT_SECONDARY
)
from src.mesh.bluetooth_mesh_service import (
    BluetoothMeshNode, BluetoothMeshService, RESCUE_MESH_SERVICE_UUID,
    APP_HANDSHAKE_BEACON
)


class MeshNodeCard(QFrame):
    """
    Card representing a single discovered Bluetooth Mesh device.
    Supports in-place telemetry updates without widget destruction.
    Includes direct Call / Answer button for voice communication.
    """
    call_requested = Signal(object, bool)  # node, is_in_call

    def __init__(self, node: BluetoothMeshNode, parent=None):
        super().__init__(parent)
        self.node = node
        self.is_in_call = False
        self.has_incoming_call = False
        self.latest_audio_file: Optional[str] = None
        self._init_ui()

    def _init_ui(self):
        self.setObjectName("panelCard")
        rail_color = COLOR_FLOOD_CYAN if getattr(self.node, "is_app_node", True) else "#475569"
        self.setStyleSheet(f"""
            QFrame#panelCard {{
                background-color: #131D31;
                border-left: 4px solid {rail_color};
                border-top: 1px solid #253554;
                border-right: 1px solid #253554;
                border-bottom: 1px solid #253554;
                border-radius: 6px;
                padding: 6px;
            }}
            QLabel {{ background: transparent; }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        # Row 1: Icon, Friendly Name, and Status Badge
        r1 = QHBoxLayout()
        r1.setSpacing(6)

        self.lbl_ico = QLabel()
        ico_name = "bluetooth.svg" if getattr(self.node, "is_app_node", True) else "mobile.svg"
        ico_path = ICONS_DIR / ico_name
        if ico_path.exists():
            self.lbl_ico.setPixmap(QIcon(str(ico_path)).pixmap(14, 14))
        r1.addWidget(self.lbl_ico)

        self.lbl_name = QLabel(self.node.name)
        self.lbl_name.setWordWrap(True)
        self.lbl_name.setStyleSheet("font-size: 13px; font-weight: bold; color: #FFFFFF;")
        r1.addWidget(self.lbl_name, 1)

        r1.addStretch()

        self.lbl_badge = QLabel()
        self._update_badge_style()
        r1.addWidget(self.lbl_badge)
        layout.addLayout(r1)

        # Row 2: Physical MAC / Canonical ID, Distance, and RSSI
        r2 = QHBoxLayout()
        r2.setSpacing(8)

        self.lbl_mac = QLabel()
        self._update_mac_label()
        self.lbl_mac.setStyleSheet("font-family: monospace; font-size: 11px; color: #94A3B8;")
        r2.addWidget(self.lbl_mac)

        r2.addStretch()

        self.lbl_dist = QLabel()
        self._update_dist_label()
        self.lbl_dist.setStyleSheet("font-size: 11px; color: #38BDF8; font-weight: bold;")
        r2.addWidget(self.lbl_dist)
        layout.addLayout(r2)

        # Row 3: Call & Voice Intercom Action Controls
        r3 = QHBoxLayout()
        r3.setSpacing(6)

        self.btn_call = QPushButton("รับสาย / สนทนาสายตรง")
        self.btn_call.setFixedHeight(28)
        self.btn_call.setCursor(Qt.CursorShape.PointingHandCursor)
        self._apply_idle_btn_style()
        self.btn_call.clicked.connect(self._toggle_call)
        r3.addWidget(self.btn_call, 1)

        self.lbl_call_status = QLabel("สแตนด์บาย")
        self.lbl_call_status.setStyleSheet("color: #94A3B8; font-size: 10.5px;")
        r3.addWidget(self.lbl_call_status)
        layout.addLayout(r3)

    def _apply_idle_btn_style(self):
        self.btn_call.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                border: 1px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11px;
                border-radius: 5px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: #10B981;
                border-color: #6EE7B7;
            }
        """)

    def _apply_active_btn_style(self):
        self.btn_call.setStyleSheet("""
            QPushButton {
                background-color: #DC2626;
                border: 1px solid #F87171;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11px;
                border-radius: 5px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: #B91C1C;
                border-color: #FCA5A5;
            }
        """)

    def _apply_incoming_btn_style(self):
        self.btn_call.setStyleSheet("""
            QPushButton {
                background-color: #D97706;
                border: 1px solid #FBBF24;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11px;
                border-radius: 5px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: #F59E0B;
                border-color: #FDE68A;
            }
        """)

    def set_incoming_call(self, has_incoming: bool, audio_file: Optional[str] = None):
        """Sets incoming call visual state on this node card."""
        self.has_incoming_call = has_incoming
        if audio_file:
            self.latest_audio_file = audio_file
        if has_incoming and not self.is_in_call:
            self.btn_call.setText("มีสายเรียกเข้า! [กดรับสาย]")
            self._apply_incoming_btn_style()
            self.lbl_call_status.setText("มีสายเข้า")
            self.lbl_call_status.setStyleSheet("color: #FBBF24; font-weight: bold; font-size: 10.5px;")

    def set_in_call(self, in_call: bool):
        """Sets active call state on this node card."""
        self.is_in_call = in_call
        self.has_incoming_call = False
        if in_call:
            self.btn_call.setText("วางสาย")
            self._apply_active_btn_style()
            self.lbl_call_status.setText("กำลังสนทนา")
            self.lbl_call_status.setStyleSheet("color: #34D399; font-weight: bold; font-size: 10.5px;")
        else:
            self.btn_call.setText("โทรผ่าน Bluetooth")
            self._apply_idle_btn_style()
            self.lbl_call_status.setText("สแตนด์บาย")
            self.lbl_call_status.setStyleSheet("color: #94A3B8; font-size: 10.5px;")

    def _toggle_call(self):
        new_state = not self.is_in_call
        self.call_requested.emit(self.node, new_state)

    def _update_badge_style(self):
        if getattr(self.node, "is_app_node", True):
            self.lbl_badge.setText("RESCUE ALERT APP")
            self.lbl_badge.setStyleSheet(
                "background: rgba(0, 242, 254, 0.2); color: #00F2FE; "
                "border: 1px solid #00F2FE; border-radius: 4px; padding: 2px 6px; font-size: 10px; font-weight: bold;"
            )
        else:
            self.lbl_badge.setText("BLE MESH")
            self.lbl_badge.setStyleSheet(
                "background: #1E293B; color: #94A3B8; "
                "border: 1px solid #334155; border-radius: 4px; padding: 2px 6px; font-size: 10px;"
            )

    def _update_mac_label(self):
        node_id = getattr(self.node, "node_id", "")
        addr = getattr(self.node, "address", "")
        if node_id and node_id != addr and not node_id.startswith("NODE_" + addr.replace(":", "")[-6:]):
            self.lbl_mac.setText(f"MAC: {addr} • ID: {node_id}")
        else:
            self.lbl_mac.setText(f"MAC: {addr}")

    def _update_dist_label(self):
        dist = getattr(self.node, "distance_meters", 1)
        rssi = getattr(self.node, "rssi", 0)
        last_seen = getattr(self.node, "last_seen", time.time())
        sec_ago = max(0, int(time.time() - last_seen))
        time_tag = "สด" if sec_ago <= 2 else f"{sec_ago}วิ"
        self.lbl_dist.setText(f"~{dist} ม. (RSSI: {rssi} dBm) • {time_tag}")

    def update_telemetry(self, node: BluetoothMeshNode):
        """
        In-place updates to labels without deleting or re-creating widgets.
        Guarantees zero flicker, zero Qt event overhead, and stable layouts.
        """
        self.node = node

        # Update name if changed
        if self.lbl_name.text() != node.name:
            self.lbl_name.setText(node.name)

        # Update MAC & ID in-place
        self._update_mac_label()

        # Update Distance, RSSI & Timestamp in-place
        self._update_dist_label()


class BluetoothMeshPanel(QWidget):
    """
    Dedicated EOC Tab for managing Bluetooth Mesh P2P connections.
    Uses a 1 Hz reconciliation timer to smoothly display active nodes
    without widget recreation or UI jitter.
    """
    scan_requested = Signal()
    call_incoming = Signal(str, str, object)  # caller_name, node_id, audio_file
    call_answered = Signal(str, str)          # caller_name, node_id
    call_ended = Signal()

    def __init__(self, mesh_service: Optional[BluetoothMeshService] = None, parent=None):
        super().__init__(parent)
        self.mesh_service = mesh_service
        self.nodes_dict: Dict[str, BluetoothMeshNode] = {}
        self.node_cards: Dict[str, MeshNodeCard] = {}
        self.empty_card: Optional[QFrame] = None
        self._active_audio_proc: Optional[subprocess.Popen] = None
        self._ringtone_proc: Optional[subprocess.Popen] = None
        self._call_state = "idle"
        self._call_timer = QTimer(self)
        self._call_timer.setSingleShot(True)
        self._call_timer.timeout.connect(self._on_call_timeout)
        self._last_hangup_time: Dict[str, float] = {}
        self._waiting_calls = OrderedDict()
        self._call_settings = QSettings("Chuaykan", "BluetoothCalls")
        self._suspended_callers = dict(self._call_settings.value("suspended", {}) or {})
        self._decline_reply_times = {}
        self._init_ui()
        self._refresh_call_queue()

        # 1 Hz UI Reconciliation Loop
        self.reconcile_timer = QTimer(self)
        self.reconcile_timer.setInterval(1000)  # 1000 ms = 1 Hz
        self.reconcile_timer.timeout.connect(self.reconcile_nodes)
        self.reconcile_timer.start()

    def set_mesh_service(self, mesh_service: BluetoothMeshService):
        """Attaches BluetoothMeshService to query active canonical nodes."""
        self.mesh_service = mesh_service

    def _init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.panel_scroll = QScrollArea()
        self.panel_scroll.setWidgetResizable(True)
        self.panel_scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.panel_scroll.setWidget(body)
        outer.addWidget(self.panel_scroll)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # 1. Header Frame
        hdr = QFrame()
        hdr.setObjectName("elevatedCard")
        h_layout = QVBoxLayout(hdr)
        h_layout.setContentsMargins(12, 8, 12, 8)
        h_layout.setSpacing(4)

        t_row = QHBoxLayout()
        t_row.setSpacing(8)
        b_ico = QLabel()
        b_path = ICONS_DIR / "bluetooth.svg"
        if b_path.exists():
            b_ico.setPixmap(QIcon(str(b_path)).pixmap(18, 18))
        t_row.addWidget(b_ico)

        lbl_title = QLabel("เครือข่ายบลูทูธแมช (BLUETOOTH MESH)")
        lbl_title.setWordWrap(True)
        lbl_title.setObjectName("headerTitle")
        t_row.addWidget(lbl_title)
        t_row.addStretch()
        h_layout.addLayout(t_row)

        lbl_sub = QLabel("สื่อสารฉุกเฉินไร้เสาสัญญาณ • ตรวจจับเฉพาะโทรศัพท์ที่เปิดแอป RescueAlert")
        lbl_sub.setWordWrap(True)
        lbl_sub.setObjectName("subText")
        h_layout.addWidget(lbl_sub)
        layout.addWidget(hdr)

        # 2. Hardware Status Box
        status_box = QFrame()
        status_box.setObjectName("panelCard")
        s_layout = QVBoxLayout(status_box)
        s_layout.setContentsMargins(10, 8, 10, 8)
        s_layout.setSpacing(6)

        row_hw = QHBoxLayout()
        row_hw.addWidget(QLabel("สถานะฮาร์ดแวร์:"))
        lbl_hw_val = QLabel("hci0 (Intel Corp.) • สแตนด์บายรับสัญญาณสด")
        lbl_hw_val.setStyleSheet("color: #10B981; font-weight: bold;")
        row_hw.addWidget(lbl_hw_val)
        row_hw.addStretch()
        s_layout.addLayout(row_hw)

        row_uuid = QHBoxLayout()
        row_uuid.addWidget(QLabel("รหัสช่องสัญญาณแอป (UUID):"))
        lbl_uuid_val = QLabel(f"{RESCUE_MESH_SERVICE_UUID[:18]}...")
        lbl_uuid_val.setStyleSheet("font-family: monospace; color: #00F2FE; font-size: 11px;")
        row_uuid.addWidget(lbl_uuid_val)
        row_uuid.addStretch()
        s_layout.addLayout(row_uuid)

        row_gw = QHBoxLayout()
        row_gw.addWidget(QLabel("เกตเวย์รับส่งข้อมูล:"))
        self.lbl_gw_ip = QLabel("กำลังเริ่มเกตเวย์")
        self.lbl_gw_ip.setStyleSheet("font-family: monospace; color: #F59E0B; font-weight: bold; font-size: 11.5px;")
        row_gw.addWidget(self.lbl_gw_ip)
        row_gw.addStretch()
        s_layout.addLayout(row_gw)

        row_handshake = QHBoxLayout()
        row_handshake.addWidget(QLabel("โหมดตรวจจับ:"))
        lbl_handshake_val = QLabel("เฉพาะอุปกรณ์ที่โหลดแอป RescueAlert (App Handshake + UUID Verification)")
        lbl_handshake_val.setStyleSheet("color: #10B981; font-weight: bold; font-size: 11px;")
        row_handshake.addWidget(lbl_handshake_val)
        row_handshake.addStretch()
        s_layout.addLayout(row_handshake)

        row_relay = QHBoxLayout()
        row_relay.addWidget(QLabel("โหนดรีเลย์ที่ยืนยันแล้ว (Relay Peers):"))
        self.lbl_relay_count = QLabel("0 เครื่อง")
        self.lbl_relay_count.setStyleSheet("color: #00F2FE; font-weight: bold; font-size: 11.5px;")
        row_relay.addWidget(self.lbl_relay_count)
        row_relay.addStretch()
        s_layout.addLayout(row_relay)

        for row in (row_hw, row_uuid, row_gw, row_handshake, row_relay):
            row.itemAt(0).widget().setFixedWidth(165)
            row.itemAt(0).widget().setWordWrap(True)
            row.itemAt(1).widget().setWordWrap(True)
            row.setStretch(1, 1)
        layout.addWidget(status_box)

        # 2.5 Persistent Incoming Call Banner
        self.active_caller_name: Optional[str] = None
        self.active_caller_id: Optional[str] = None
        self.active_call_audio: Optional[str] = None

        self.call_banner = QFrame()
        self.call_banner.setObjectName("callBanner")
        self.call_banner.setStyleSheet("""
            QFrame#callBanner {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1E3A8A, stop:1 #065F46);
                border: 2px solid #38BDF8;
                border-radius: 8px;
                padding: 6px 10px;
            }
        """)
        cb_layout = QGridLayout(self.call_banner)
        cb_layout.setContentsMargins(6, 4, 6, 4)
        cb_layout.setSpacing(8)

        self.lbl_banner_title = QLabel("มีสายเรียกเข้าจากโทรศัพท์...")
        self.lbl_banner_title.setStyleSheet("color: rgb(255,255,255); font-size: 12.5px; font-weight: bold;")
        self.lbl_banner_title.setWordWrap(True)
        cb_layout.addWidget(self.lbl_banner_title, 0, 0, 1, 2)

        self.btn_banner_answer = QPushButton("รับสาย (Answer)")
        self.btn_banner_answer.setFixedHeight(34)
        self.btn_banner_answer.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_banner_answer.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                border: 1px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11.5px;
                border-radius: 5px;
                padding: 3px 12px;
            }
            QPushButton:hover {
                background-color: #10B981;
            }
        """)
        self.btn_banner_answer.clicked.connect(self._answer_banner_call)
        cb_layout.addWidget(self.btn_banner_answer, 1, 0)

        self.btn_banner_decline = QPushButton("วางสาย")
        self.btn_banner_decline.setFixedHeight(34)
        self.btn_banner_decline.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_banner_decline.setStyleSheet("""
            QPushButton {
                background-color: #DC2626;
                border: 1px solid #F87171;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11.5px;
                border-radius: 5px;
                padding: 3px 10px;
            }
            QPushButton:hover {
                background-color: #B91C1C;
            }
        """)
        self.btn_banner_decline.clicked.connect(self._decline_banner_call)
        cb_layout.addWidget(self.btn_banner_decline, 1, 1)
        cb_layout.setColumnStretch(0, 1)
        cb_layout.setColumnStretch(1, 1)

        self.call_banner.setVisible(False)
        layout.addWidget(self.call_banner)
        queue_box = QFrame()
        queue_box.setObjectName("panelCard")
        queue_layout = QVBoxLayout(queue_box)
        self.lbl_queue_count = QLabel()
        queue_layout.addWidget(self.lbl_queue_count)
        self.call_queue_list = QListWidget()
        self.call_queue_list.setStyleSheet("QListWidget {background: #131D31; color: #FFFFFF; border: 1px solid #253554; border-radius: 6px;} QListWidget::item {padding: 6px;} QListWidget::item:selected {background: #0369A1; color: rgb(255,255,255);}")
        self.call_queue_list.setMinimumHeight(88)
        self.call_queue_list.setMaximumHeight(150)
        self.call_queue_list.currentItemChanged.connect(self._update_suspend_buttons)
        queue_layout.addWidget(self.call_queue_list)
        buttons = QHBoxLayout()
        self.btn_suspend_call = QPushButton("ระงับการโทร")
        self.btn_resume_call = QPushButton("เปิดรับสายอีกครั้ง")
        self.btn_suspend_call.setStyleSheet("QPushButton {background: #B91C1C; color: rgb(255,255,255); border-radius: 5px;} QPushButton:disabled {background: #334155; color: #94A3B8;}")
        self.btn_resume_call.setStyleSheet("QPushButton {background: #047857; color: rgb(255,255,255); border-radius: 5px;} QPushButton:disabled {background: #334155; color: #94A3B8;}")
        for button in (self.btn_suspend_call, self.btn_resume_call):
            button.setFixedHeight(34)
            buttons.addWidget(button, 1)
        self.btn_suspend_call.clicked.connect(lambda: self._set_selected_suspended(True))
        self.btn_resume_call.clicked.connect(lambda: self._set_selected_suspended(False))
        queue_layout.addLayout(buttons)
        layout.addWidget(queue_box)

        # 3. Discovered Nodes Header
        nodes_header_row = QHBoxLayout()
        lbl_sec = QLabel("โทรศัพท์ที่เปิดแอป RescueAlert:")
        lbl_sec.setObjectName("sectionTitle")
        nodes_header_row.addWidget(lbl_sec)

        self.lbl_node_count = QLabel("0 เครื่อง")
        self.lbl_node_count.setStyleSheet("color: #00F2FE; font-weight: bold;")
        nodes_header_row.addWidget(self.lbl_node_count)
        nodes_header_row.addStretch()

        btn_rescan = QPushButton("สแกนค้นหา")
        btn_rescan.setFixedHeight(24)
        btn_rescan.clicked.connect(self._on_scan_clicked)
        nodes_header_row.addWidget(btn_rescan)
        layout.addLayout(nodes_header_row)

        # 4. Scrollable Nodes List
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("background: transparent; border: none;")

        self.container = QWidget()
        self.nodes_layout = QVBoxLayout(self.container)
        self.nodes_layout.setContentsMargins(0, 0, 0, 0)
        self.nodes_layout.setSpacing(6)

        # Create persistent empty state card (Zero instantiation thrash)
        self._build_empty_placeholder()

        self.nodes_layout.addStretch()
        self.scroll.setWidget(self.container)
        layout.addWidget(self.scroll, 1)

        # 5. Live Mesh Telemetry Console
        layout.addWidget(QLabel("บันทึกสัญญาณบลูทูธแมช (TELEMETRY LOG):"))
        self.txt_log = QTextEdit()
        self.txt_log.document().setMaximumBlockCount(200)
        self.txt_log.setFixedHeight(90)
        self.txt_log.setReadOnly(True)
        self.txt_log.setStyleSheet(
            "background-color: #17233B; border: 1px solid #253554; "
            "color: #38BDF8; font-family: monospace; font-size: 10.5px; border-radius: 6px;"
        )
        self.append_log("เริ่มต้นระบบบลูทูธแมช • พร้อมรับการเชื่อมต่อจากแอป RescueAlert")
        layout.addWidget(self.txt_log)

    def _build_empty_placeholder(self):
        """Creates permanent empty state frame, shown/hidden without destruction."""
        self.empty_card = QFrame()
        self.empty_card.setObjectName("panelCard")
        self.empty_card.setStyleSheet("""
            QFrame#panelCard {
                background-color: #131D31;
                border: 1px dashed #253554;
                border-radius: 6px;
                padding: 12px;
            }
            QLabel { background: transparent; }
        """)
        ec_layout = QVBoxLayout(self.empty_card)
        ec_layout.setContentsMargins(8, 8, 8, 8)
        ec_layout.setSpacing(4)
        lbl_e1 = QLabel("ยังไม่พบโทรศัพท์ที่โหลดแอป RescueAlert ในระยะสัญญาณ")
        lbl_e1.setStyleSheet("color: #94A3B8; font-size: 12px; font-weight: bold;")
        lbl_e2 = QLabel("ตรวจจับเฉพาะอุปกรณ์ที่โหลดแอปแล้ว (App Handshake + UUID Verification) • ละเว้นอุปกรณ์บลูทูธทั่วไป 100%")
        lbl_e1.setWordWrap(True)
        lbl_e2.setWordWrap(True)
        lbl_e2.setStyleSheet("color: #64748B; font-size: 11px;")
        ec_layout.addWidget(lbl_e1)
        ec_layout.addWidget(lbl_e2)
        self.nodes_layout.insertWidget(0, self.empty_card)
        self.empty_card.setVisible(True)

    def append_log(self, text: str):
        """Appends timestamped entry to the telemetry log and auto-scrolls."""
        ts = time.strftime("%H:%M:%S")
        self.txt_log.append(f"[{ts}] {text}")
        sb = self.txt_log.verticalScrollBar()
        if sb:
            sb.setValue(sb.maximum())

    def update_node(self, node: BluetoothMeshNode):
        """
        Fast in-memory cache update called on packet arrival.
        DOES NOT touch layouts or delete widgets.
        """
        if getattr(node, "is_app_node", True):
            node_key = getattr(node, "node_id", None) or node.address
            self.nodes_dict[node_key] = node

    def set_gateway_ip(self, ip: str, port: int, public_url=None):
        self.lbl_gw_ip.setText(public_url or f"https://{ip}:{port}")

    def reconcile_nodes(self):
        expired = [node_id for node_id, entry in self._waiting_calls.items() if time.monotonic() - entry[2] > 35]
        for node_id in expired:
            self.cancel_queued_call(node_id)
        """
        1 Hz reconciliation loop:
        - Reconciles active canonical nodes from BluetoothMeshService (or internal cache).
        - In-place telemetry update on existing MeshNodeCard widgets.
        - Adds new cards when new canonical nodes appear.
        - Removes only cards that have truly timed out.
        """
        now = time.time()
        # 1. Fetch active nodes from service or fallback cache
        if self.mesh_service:
            active_nodes = self.mesh_service.get_active_nodes(max_age_seconds=12.0)
            # Update relay peer count display
            relay_count = self.mesh_service.get_relay_peer_count()
            if hasattr(self, "lbl_relay_count"):
                self.lbl_relay_count.setText(f"{relay_count} เครื่อง")
        else:
            active_nodes = [
                n for n in self.nodes_dict.values()
                if (now - getattr(n, "last_seen", 0)) <= 12.0 and getattr(n, "is_app_node", True)
            ]

        # Filter and sort
        app_nodes = [n for n in active_nodes if getattr(n, "is_app_node", True)]
        app_nodes.sort(key=lambda n: getattr(n, "rssi", -100), reverse=True)

        self.lbl_node_count.setText(f"{len(app_nodes)} เครื่อง")

        if not app_nodes:
            # Show empty state
            if self.empty_card:
                self.empty_card.setVisible(True)
            # Remove any lingering cards
            for key, card in list(self.node_cards.items()):
                self.nodes_layout.removeWidget(card)
                card.deleteLater()
                del self.node_cards[key]
            return

        # Hide empty state
        if self.empty_card:
            self.empty_card.setVisible(False)

        active_keys = set()

        # 2. In-place update or instantiate new cards
        for node in app_nodes:
            node_key = getattr(node, "node_id", None) or node.address
            active_keys.add(node_key)

            if node_key in self.node_cards:
                # IN-PLACE TELEMETRY UPDATE: Zero destruction
                self.node_cards[node_key].update_telemetry(node)
            else:
                # NEW CANONICAL NODE: Instantiate exactly once
                card = MeshNodeCard(node)
                card.call_requested.connect(self._on_card_call_toggled)
                self.node_cards[node_key] = card
                insert_idx = max(0, self.nodes_layout.count() - 1)
                self.nodes_layout.insertWidget(insert_idx, card)
                self.append_log(f"เชื่อมต่อโหนดใหม่: {node.name} (ID: {node_key})")

        # 3. Clean up expired cards
        expired_keys = [k for k in list(self.node_cards.keys()) if k not in active_keys]
        for key in expired_keys:
            card = self.node_cards.pop(key)
            self.nodes_layout.removeWidget(card)
            card.deleteLater()
            name = getattr(card.node, "name", key)
            self.append_log(f"โหนดหมดอายุการเชื่อมต่อ: {name} ({key})")

    def _update_suspend_buttons(self, *args):
        item = self.call_queue_list.currentItem()
        node_id = item.data(Qt.ItemDataRole.UserRole) if item else None
        self.btn_suspend_call.setEnabled(bool(node_id) and node_id not in self._suspended_callers)
        self.btn_resume_call.setEnabled(node_id in self._suspended_callers)

    def _refresh_call_queue(self):
        selected = self.call_queue_list.currentItem()
        selected_id = selected.data(Qt.ItemDataRole.UserRole) if selected else None
        self.call_queue_list.clear()
        rows = []
        if self.active_caller_id:
            rows.append((self.active_caller_id, f"สายปัจจุบัน • {self.active_caller_name}"))
        rows.extend((node_id, f"คิว {i} • {entry[0]}") for i, (node_id, entry) in enumerate(self._waiting_calls.items(), 1))
        rows.extend((node_id, f"ระงับ • {name}") for node_id, name in self._suspended_callers.items())
        seen = set()
        for node_id, text in rows:
            if node_id in seen:
                continue
            seen.add(node_id)
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, node_id)
            item.setToolTip(node_id)
            self.call_queue_list.addItem(item)
            if node_id == selected_id:
                self.call_queue_list.setCurrentItem(item)
        self.lbl_queue_count.setText(f"คิวรอสาย: {len(self._waiting_calls)} • ระงับ: {len(self._suspended_callers)}")
        self._update_suspend_buttons()

    def _set_selected_suspended(self, suspended):
        item = self.call_queue_list.currentItem()
        if not item:
            return
        node_id = item.data(Qt.ItemDataRole.UserRole)
        if suspended:
            name = self._waiting_calls.get(node_id, (self.active_caller_name or node_id,))[0]
            self._suspended_callers[node_id] = name
            self._waiting_calls.pop(node_id, None)
            if node_id == self.active_caller_id:
                self._decline_banner_call()
            elif self.mesh_service:
                self.mesh_service.broadcast_officer_call_decline(node_id)
        else:
            self._suspended_callers.pop(node_id, None)
        self._call_settings.setValue("suspended", self._suspended_callers)
        self._call_settings.sync()
        self._refresh_call_queue()

    def cancel_queued_call(self, node_id):
        if node_id not in self._waiting_calls:
            return False
        del self._waiting_calls[node_id]
        self._refresh_call_queue()
        return True

    def _advance_call_queue(self):
        if self._call_state != "idle":
            return
        while self._waiting_calls:
            node_id, (name, audio, last_seen) = self._waiting_calls.popitem(last=False)
            if time.monotonic() - last_seen <= 35 and node_id not in self._suspended_callers:
                self.show_incoming_call(name, node_id, audio, _from_queue=True)
                break
        self._refresh_call_queue()

    def _send_queue_position(self, node_id, position):
        if self.mesh_service:
            self.mesh_service.send_call_queue(node_id, position)

    def show_incoming_call(self, caller_name: str, node_id: str, audio_filename: Optional[str] = None, *, _from_queue=False):
        """
        Activates incoming call alert banner and highlights the corresponding node card.
        """
        if node_id in self._suspended_callers or (time.time() - self._last_hangup_time.get(node_id, 0)) < 4:
            now = time.monotonic()
            if self.mesh_service and now - self._decline_reply_times.get(node_id, 0) >= 4:
                self.mesh_service.broadcast_officer_call_decline(node_id)
                self._decline_reply_times[node_id] = now
            return "ระงับ/เพิ่งวางสาย"
        if self.active_caller_id == node_id:
            if self._call_state == "incoming":
                self._send_queue_position(node_id, 0)
            return "สายปัจจุบัน"
        if self._call_state != "idle" or (self._waiting_calls and not _from_queue):
            if node_id not in self._waiting_calls and len(self._waiting_calls) >= 50:
                if self.mesh_service:
                    self.mesh_service.broadcast_officer_call_decline(node_id)
                return "คิวเต็ม"
            self._waiting_calls[node_id] = (caller_name, audio_filename, time.monotonic())
            self._send_queue_position(node_id, list(self._waiting_calls).index(node_id) + 1)
            self._refresh_call_queue()
            if self._call_state == "idle":
                QTimer.singleShot(0, self._advance_call_queue)
            return "เข้าคิวรอสาย"
        self._call_state = "incoming"
        self._call_timer.start(30_000)
        self._send_queue_position(node_id, 0)
        self.active_caller_name = caller_name
        self.active_caller_id = node_id
        self.active_call_audio = audio_filename

        self._start_ringtone()
        self.lbl_banner_title.setText(f"มีสายเรียกเข้าจากโทรศัพท์: {caller_name} ({node_id}) • กำลังส่งเสียงเรียกเข้า...")
        self.btn_banner_answer.setEnabled(True)
        self.btn_banner_answer.setText("รับสาย (Answer)")
        self.btn_banner_answer.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                border: 1px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11.5px;
                border-radius: 5px;
                padding: 3px 12px;
            }
            QPushButton:hover {
                background-color: #10B981;
            }
        """)
        self.call_banner.setVisible(True)

        # Highlight card if already discovered
        for card_key, card in self.node_cards.items():
            if card_key == node_id or (getattr(card.node, "address", "") == node_id):
                card.set_incoming_call(True, audio_filename)

        self.append_log(f"มีสายเรียกเข้าจาก: {caller_name} (โหนด {node_id}) - กรุณากดปุ่มรับสาย")
        self._refresh_call_queue()
        self.call_incoming.emit(caller_name, node_id, audio_filename)
        return "รอเจ้าหน้าที่รับสาย"

    def _answer_banner_call(self, remote_answer: bool = False):
        """Operator clicks Answer button on the incoming call banner.
        Sends EOC_CALL_ANSWER back to citizen and activates mic for two-way voice."""
        self._stop_ringtone()
        if not self.active_caller_name and not self.active_caller_id:
            return

        # If already in an active call, clicking this button toggles mic mute/unmute
        card = self.node_cards.get(self.active_caller_id)
        if self._call_state == "active" and self.active_caller_id:
            if remote_answer:
                return
            self._toggle_officer_call_mic_mute()
            return
        if remote_answer and self._call_state != "dialing":
            return
        if not remote_answer and self._call_state != "incoming":
            return

        caller_name = self.active_caller_name or "โทรศัพท์ที่เชื่อมต่อ"
        caller_id = self.active_caller_id or "UNKNOWN"
        if not self.mesh_service or not self.mesh_service.get_relay_peer_count():
            self.append_log("รับสายไม่ได้: ช่อง Bluetooth ถูกตัดการเชื่อมต่อ")
            self._decline_banner_call(from_remote=True)
            return
        try:
            self.mesh_service.call_audio.start(caller_id)
        except OSError as exc:
            self.append_log(f"เปิดลำโพงไม่ได้: {exc}")
            self._decline_banner_call()
            return
        if not remote_answer and not self.mesh_service.broadcast_officer_call_answer(caller_id):
            self.append_log("ส่งสัญญาณรับสายไม่ได้")
            self._decline_banner_call(from_remote=True)
            return
        self._call_state = "active"
        self._call_timer.stop()

        self.lbl_banner_title.setText(f"กำลังสนทนาสดกับ: {caller_name} ({caller_id}) • ไมค์เปิดอยู่")
        self.btn_banner_answer.setText("ไมค์เปิด (กดเพื่อปิดไมค์)")
        self.btn_banner_answer.setEnabled(True)
        self.btn_banner_answer.setStyleSheet("""
            QPushButton {
                background-color: #0D9488;
                border: 1.5px solid #2DD4BF;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11px;
                border-radius: 5px;
                padding: 3px 10px;
            }
            QPushButton:hover {
                background-color: #14B8A6;
            }
        """)

        # Set corresponding card to in-call
        for card_key, card in self.node_cards.items():
            if card_key == caller_id or (getattr(card.node, "address", "") == caller_id):
                card.set_in_call(True)

        # Send EOC_CALL_ANSWER back to citizen phone so they know call was accepted
        # Start officer microphone for two-way voice communication
        if self.mesh_service:
            try:
                self._start_officer_call_mic(caller_id)
            except Exception as e:
                self.append_log(f"ไม่สามารถเปิดไมค์ได้: {e}")

        # Play incoming voice message if available
        if self.active_call_audio:
            self._play_audio_file(self.active_call_audio)

        self.append_log(f"เจ้าหน้าที่รับสายจาก {caller_name} ({caller_id}) สำเร็จ — ไมค์เปิดแล้ว พร้อมสนทนา 2 ทาง")
        self.call_answered.emit(caller_name, caller_id)

    def _toggle_officer_call_mic_mute(self):
        """Toggles officer's microphone between muted and unmuted during an active call."""
        if hasattr(self, "_call_mic_proc") and self._call_mic_proc:
            self._stop_officer_call_mic()
            self.btn_banner_answer.setText("ไมค์ปิดอยู่ (กดเพื่อเปิดไมค์)")
            self.btn_banner_answer.setStyleSheet("""
                QPushButton {
                    background-color: #475569;
                    border: 1.5px solid #94A3B8;
                    color: #FFFFFF;
                    font-weight: bold;
                    font-size: 11px;
                    border-radius: 5px;
                    padding: 3px 10px;
                }
                QPushButton:hover {
                    background-color: #64748B;
                }
            """)
            self.append_log("ปิดไมค์เจ้าหน้าที่ชั่วคราว (Mute)")
        else:
            if self.active_caller_id:
                self._start_officer_call_mic(self.active_caller_id)
                self.btn_banner_answer.setText("ไมค์เปิด (กดเพื่อปิดไมค์)")
                self.btn_banner_answer.setStyleSheet("""
                    QPushButton {
                        background-color: #0D9488;
                        border: 1.5px solid #2DD4BF;
                        color: #FFFFFF;
                        font-weight: bold;
                        font-size: 11px;
                        border-radius: 5px;
                        padding: 3px 10px;
                    }
                    QPushButton:hover {
                        background-color: #14B8A6;
                    }
                """)
                self.append_log("เปิดไมค์เจ้าหน้าที่แล้ว (Unmute)")

    def _decline_banner_call(self, from_remote: bool = False):
        """Operator clicks Hang Up / End Call button, or remote party ended the call."""
        caller_name = self.active_caller_name or "โทรศัพท์"
        caller_id = self.active_caller_id
        previous_state = self._call_state
        self._call_state = "idle"
        self._call_timer.stop()
        if self.mesh_service:
            self.mesh_service.call_audio.stop()

        self._stop_ringtone()
        self._stop_audio_playback()
        self._stop_officer_call_mic()  # Stop officer mic when call ends
        self.call_banner.setVisible(False)

        # Reset answer button style
        self.btn_banner_answer.setText("รับสาย (Answer)")
        self.btn_banner_answer.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                border: 1px solid #34D399;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11.5px;
                border-radius: 5px;
                padding: 3px 12px;
            }
            QPushButton:hover {
                background-color: #10B981;
            }
        """)

        # If call was not answered yet (still incoming), send decline; otherwise hangup
        if not from_remote and self.mesh_service and caller_id:
            try:
                was_in_call = previous_state in ("active", "dialing")
                if was_in_call:
                    self.mesh_service.hangup_officer_call(target_node_id=caller_id)
                else:
                    self.mesh_service.broadcast_officer_call_decline(target_node_id=caller_id)
            except Exception:
                pass

        if caller_id:
            self._last_hangup_time[caller_id] = time.time()
            for card_key, card in self.node_cards.items():
                if card_key == caller_id or (getattr(card.node, "address", "") == caller_id):
                    card.set_in_call(False)
                    card.set_incoming_call(False)

        self.append_log(f"ศูนย์ EOC สิ้นสุดการสนทนา/วางสายกับ: {caller_name}")
        self.active_caller_name = None
        self.active_caller_id = None
        self.active_call_audio = None
        self.call_ended.emit()
        self._refresh_call_queue()
        QTimer.singleShot(0, self._advance_call_queue)

    def _on_card_call_toggled(self, node: BluetoothMeshNode, is_in_call: bool):
        """Triggered directly by clicking Call / Hang Up on an individual node card."""
        node_key = getattr(node, "node_id", None) or node.address
        if node_key in self._waiting_calls:
            self.append_log("ผู้ติดต่อกำลังรอในคิว • กรุณารับสายตามลำดับคิว")
            return
        if self.active_caller_id == node_key:
            if self._call_state == "incoming":
                self._answer_banner_call()
            else:
                self._decline_banner_call()
            return
        if not self.mesh_service or not self.mesh_service.get_relay_peer_count():
            self.append_log("ยังไม่มีช่องเสียง Bluetooth เชื่อมต่อสำเร็จ โทรออกไม่ได้")
            return
        if self._call_state != "idle":
            self._decline_banner_call()
        self._stop_ringtone()
        if is_in_call:
            # BUG-08 FIX: Terminate existing active call before starting new one
            if self.active_caller_id and self.active_caller_id != node_key:
                prev_id = self.active_caller_id
                self.append_log(f"ตัดสายเดิมกับ {self.active_caller_name} ({prev_id}) เพื่อโทรหา {node.name}")
                # Hangup previous call
                if self.mesh_service:
                    try:
                        self.mesh_service.hangup_officer_call(target_node_id=prev_id)
                    except Exception:
                        pass
                # Reset previous card UI
                prev_card = self.node_cards.get(prev_id)
                if prev_card:
                    prev_card.set_in_call(False)
                    prev_card.set_incoming_call(False)

            self.active_caller_name = node.name
            self.active_caller_id = node_key
            self._call_state = "dialing"
            self.lbl_banner_title.setText(f"กำลังรอ {node.name} รับสาย")
            self.btn_banner_answer.setText("รอรับสาย")
            self.btn_banner_answer.setEnabled(False)
            self.call_banner.setVisible(True)

            if self.mesh_service:
                try:
                    if not self.mesh_service.broadcast_officer_call_request(target_node_id=node_key):
                        self.append_log("ส่งสัญญาณโทรออกไม่ได้: ไม่มีช่องเชื่อมต่อ")
                        self._decline_banner_call(from_remote=True)
                        return
                except Exception as exc:
                    self.append_log(f"โทรออกไม่ได้: {exc}")
                    self._decline_banner_call(from_remote=True)
                    return
            self._call_timer.start(30_000)

            card = self.node_cards.get(node_key)
            if card and card.latest_audio_file:
                self._play_audio_file(card.latest_audio_file)

            self.append_log(f"ส่งสัญญาณโทรเข้าเครื่องประชาชน: {node.name} (ID: {node_key})")
            if card:
                card.btn_call.setText("ยกเลิกการโทร")
                card.lbl_call_status.setText("รอปลายทางรับสาย")
        else:
            self._stop_audio_playback()
            if self.mesh_service:
                try:
                    self.mesh_service.hangup_officer_call(target_node_id=node_key)
                except Exception:
                    pass

            if self.active_caller_id == node_key:
                self.call_banner.setVisible(False)
                self.active_caller_name = None
                self.active_caller_id = None
                self.active_call_audio = None
            self.append_log(f"วางสายสนทนากับโหนด: {node.name}")
            self.call_ended.emit()
        self._refresh_call_queue()
        QTimer.singleShot(0, self._advance_call_queue)

    def _on_call_timeout(self):
        self.append_log("ไม่มีการรับสายภายใน 30 วินาที")
        self._decline_banner_call()

    def _start_ringtone(self):
        """Starts looping ringtone sound to alert operator of incoming call."""
        if not RINGTONE_PATH.exists():
            return
        self._stop_ringtone()
        try:
            if shutil.which("ffplay"):
                self._ringtone_proc = subprocess.Popen(
                    ["ffplay", "-nodisp", "-loop", "0", "-loglevel", "quiet", str(RINGTONE_PATH)]
                )
            elif shutil.which("aplay"):
                self._ringtone_proc = subprocess.Popen(
                    ["aplay", "-q", str(RINGTONE_PATH)]
                )
        except Exception as e:
            self.append_log(f"ไม่สามารถเริ่มเสียงแจ้งเตือนสายเข้าได้: {e}")

    def _stop_ringtone(self):
        """Stops active ringtone sound immediately."""
        if hasattr(self, "_ringtone_proc") and self._ringtone_proc:
            try:
                self._ringtone_proc.terminate()
                self._ringtone_proc.wait(timeout=0.2)
            except Exception:
                try:
                    self._ringtone_proc.kill()
                except Exception:
                    pass
            self._ringtone_proc = None

    def _play_audio_file(self, filename: str):
        """Plays voice audio clip via ffplay or aplay without blocking GUI."""
        if not filename:
            return
        audio_path = RECORDINGS_DIR / filename
        if not audio_path.exists():
            return

        self._stop_audio_playback()
        try:
            if shutil.which("ffplay"):
                self._active_audio_proc = subprocess.Popen(
                    ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(audio_path)]
                )
            elif shutil.which("aplay"):
                self._active_audio_proc = subprocess.Popen(
                    ["aplay", "-q", str(audio_path)]
                )
        except Exception as e:
            self.append_log(f"ไม่สามารถเล่นเสียงได้: {e}")

    def _stop_audio_playback(self):
        """Stops active voice playback if playing."""
        if hasattr(self, "_active_audio_proc") and self._active_audio_proc:
            try:
                self._active_audio_proc.terminate()
                self._active_audio_proc.wait(timeout=0.2)
            except Exception:
                try:
                    self._active_audio_proc.kill()
                except Exception:
                    pass
            self._active_audio_proc = None

    def _start_officer_call_mic(self, target_node_id: str):
        """Start recording officer's microphone and stream PCM to citizen via Bluetooth Mesh.
        Uses arecord to capture 8000 Hz mono 16-bit PCM, same format as announcement mic."""
        self._stop_officer_call_mic()
        if not shutil.which("arecord"):
            self.append_log("ไม่พบ arecord — ไม่สามารถเปิดไมค์สนทนาได้")
            return

        self._call_mic_target = target_node_id
        self._call_mic_stop = threading.Event()
        stop_event = self._call_mic_stop
        session_id = time.time_ns()

        def _mic_stream_worker():
            try:
                proc = subprocess.Popen(
                    ["arecord", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
                    stdout=subprocess.PIPE,
                )
                self._call_mic_proc = proc
                chunk_size = 1600  # 100ms of 8000Hz 16-bit mono = 1600 bytes
                call_seq = 0
                while not stop_event.is_set():
                    data = proc.stdout.read(chunk_size)
                    if not data:
                        break
                    if self.mesh_service:
                        call_seq += 1
                        call_id = f"EOC_CALL_VOICE_{session_id}_{call_seq}"
                        sent = self.mesh_service.broadcast_officer_audio(
                            audio_pcm=data,
                            announcement_id=call_id,
                            target_node_id=target_node_id
                        )
                        if call_seq == 1:
                            print(f"[CallAudio] Microphone PCM sent peer={target_node_id} channels={sent}", flush=True)
                        if not sent:
                            break
                proc.terminate()
                try:
                    proc.wait(timeout=0.5)
                except Exception:
                    proc.kill()
            except Exception as e:
                print(f"[MeshPanel] Officer call mic error: {e}")

        self._call_mic_thread = threading.Thread(
            target=_mic_stream_worker, daemon=True, name="OfficerCallMic"
        )
        self._call_mic_thread.start()
        self.append_log(f"เปิดไมค์เจ้าหน้าที่สำหรับสนทนากับ {target_node_id}")

    def _stop_officer_call_mic(self):
        """Stop officer's microphone streaming."""
        if hasattr(self, "_call_mic_stop") and self._call_mic_stop:
            self._call_mic_stop.set()
        if hasattr(self, "_call_mic_proc") and self._call_mic_proc:
            try:
                self._call_mic_proc.terminate()
                self._call_mic_proc.wait(timeout=0.3)
            except Exception:
                try:
                    self._call_mic_proc.kill()
                except Exception:
                    pass
            self._call_mic_proc = None
        self._call_mic_stop = None
        self._call_mic_thread = None

    def render_nodes(self):
        """Backwards compatibility alias for reconcile_nodes."""
        self.reconcile_nodes()

    def _on_scan_clicked(self):
        self.append_log("สั่งการสแกนค้นหาอุปกรณ์บลูทูธใหม่อีกครั้ง...")
        self.scan_requested.emit()

    def clear_all_nodes(self):
        """Immediately removes all node cards and shows empty state when Bluetooth is stopped/disabled."""
        if self._call_state != "idle":
            self._decline_banner_call()
        self._stop_officer_call_mic()
        self._stop_ringtone()
        self._stop_audio_playback()
        self.call_banner.setVisible(False)
        self.active_caller_name = None
        self.active_caller_id = None
        self.active_call_audio = None
        self.nodes_dict.clear()
        for key, card in list(self.node_cards.items()):
            self.nodes_layout.removeWidget(card)
            card.deleteLater()
        self.node_cards.clear()
        if self.empty_card:
            self.empty_card.setVisible(True)
        self.lbl_node_count.setText("0 เครื่อง")
        if hasattr(self, "lbl_relay_count"):
            self.lbl_relay_count.setText("0 เครื่อง")

    def closeEvent(self, event):
        self._stop_ringtone()
        self._stop_audio_playback()
        if hasattr(self, "reconcile_timer") and self.reconcile_timer.isActive():
            self.reconcile_timer.stop()
        self.clear_all_nodes()
        super().closeEvent(event)
