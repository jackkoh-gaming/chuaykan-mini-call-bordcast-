package com.rescue.alert.model

/**
 * Represents the confidence level of the device's current location.
 * Used to determine the appropriate alert level (Critical vs Warning).
 */
enum class LocationConfidence {
    /** Fresh location available (< 30 minutes old) */
    FRESH,
    /** Location exists but is stale (> 2 hours old) */
    STALE,
    /** No location data available */
    UNAVAILABLE
}

data class LocationState(
    val latitude: Double?,
    val longitude: Double?,
    val confidence: LocationConfidence,
    val ageMillis: Long?
)
