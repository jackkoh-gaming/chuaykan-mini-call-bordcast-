package com.rescue.alert

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.Button
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.bluetooth.BluetoothMeshManager
import com.rescue.alert.model.DisasterStateManager
import com.rescue.alert.model.MeshVoicePacket
import com.rescue.alert.ui.MainActivity
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Incoming frames are local fixtures with TTL=1: no relay, SOS or outgoing call. */
@RunWith(AndroidJUnit4::class)
class AnnouncementSeparationTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext

    @Test fun microphoneCoverageNeverBecomesEmergencyRiskArea() {
        for (zone in listOf(
            org.json.JSONObject().put("zone_id", "MIC_ZONE_01"),
            org.json.JSONObject().put("zone_id", "mic_zone_02"),
            org.json.JSONObject().put("zone_id", "CUSTOM").put("hazard_type", "ANNOUNCEMENT"),
            org.json.JSONObject().put("hazard_type", "announcement"))) {
            assertFalse(MainActivity.isEmergencyRiskZone(zone))
        }
        assertTrue(MainActivity.isEmergencyRiskZone(org.json.JSONObject().put("zone_id", "FLOOD_01").put("hazard_type", "FLOOD")))
    }

    @Test fun microphoneShowsOnlyItsBannerAndNotification() {
        val activity = instrumentation.startActivitySync(Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        instrumentation.runOnMainSync {
            activity.javaClass.getDeclaredMethod("stopPeriodicRiskZoneSync").apply {
                isAccessible = true }.invoke(activity)
        }
        Thread.sleep(3500)
        var originalAreaVisibility = View.GONE
        instrumentation.runOnMainSync {
            activity.javaClass.getDeclaredMethod("updateDisasterStateUI").apply {
                isAccessible = true }.invoke(activity)
            originalAreaVisibility = activity.findViewById<View>(R.id.layoutActiveDisaster).visibility
        }
        val originalAlertId = DisasterStateManager.getAlertId(context)
        val mesh = BluetoothMeshManager.getInstance(context)
        val receive = mesh.javaClass.getDeclaredMethod("processIncomingPacketBytes",
            ByteArray::class.java, String::class.java).apply { isAccessible = true }
        fun frame(id: String, body: ByteArray) {
            val packet = MeshVoicePacket(id + System.nanoTime(), sourceNodeId = "EOC_GATEWAY_HQ",
                sourceHouseName = "EOC เจ้าหน้าที่", targetNodeId = mesh.myNodeId,
                hopCount = 0, ttl = 1, audioData = body)
            instrumentation.runOnMainSync { receive.invoke(mesh, BluetoothMeshManager.serializePacket(packet), null) }
            instrumentation.waitForIdleSync()
        }
        fun assertVisibility(microphone: Int) {
            instrumentation.runOnMainSync {
                assertEquals(microphone, activity.findViewById<View>(R.id.layoutOfficerLiveMicBanner).visibility)
                assertEquals(originalAreaVisibility, activity.findViewById<View>(R.id.layoutActiveDisaster).visibility)
                assertEquals(originalAreaVisibility == View.VISIBLE, activity.findViewById<View>(R.id.btnGeneralSos).isShown)
            }
            assertEquals(originalAlertId, DisasterStateManager.getAlertId(context))
            if (Build.VERSION.SDK_INT >= 23) {
                val notifications = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                assertEquals(microphone == View.VISIBLE, notifications.activeNotifications.any {
                    it.id == BluetoothMeshManager.NOTIF_ID_OFFICER_ANNOUNCEMENT })
            }
        }
        try {
            instrumentation.runOnMainSync { mesh.handleOfficerAnnouncementEnded() }
            instrumentation.waitForIdleSync()
            frame("EOC_CONTROL_", "{}".toByteArray())
            frame("EOC_CALL_VOICE_", ByteArray(512))
            frame("EOC_ANNOUNCE_", byteArrayOf())
            assertVisibility(View.GONE)
            frame("EOC_ANNOUNCE_", ByteArray(512))
            assertVisibility(View.VISIBLE)
            // Recompute risk UI while mic is visible: it must still not create area SOS.
            instrumentation.runOnMainSync {
                activity.javaClass.getDeclaredMethod("updateDisasterStateUI").apply {
                    isAccessible = true }.invoke(activity)
            }
            assertVisibility(View.VISIBLE)
            frame("EOC_ANNOUNCE_END_", byteArrayOf())
            assertVisibility(View.GONE)
            instrumentation.runOnMainSync {
                val button = activity.findViewById<Button>(R.id.btnPulsingSos)
                assertEquals("SOS\nผู้ป่วยฉุกเฉิน", button.text.toString())
                assertEquals("ต้องการช่วยเหลือ", activity.findViewById<Button>(R.id.btnGeneralSos).text.toString())
            }
        } finally {
            instrumentation.runOnMainSync { mesh.handleOfficerAnnouncementEnded(); activity.finish() }
        }
    }

    @Test fun dispatchPresenceCannotBypassRiskArea() {
        val activity = instrumentation.startActivitySync(Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        try {
            var wasShown = false
            instrumentation.runOnMainSync { wasShown = activity.findViewById<View>(R.id.btnGeneralSos).isShown }
            context.sendBroadcast(Intent("com.rescue.alert.ACTION_OFFICER_APPROACHING").setPackage(context.packageName))
            instrumentation.waitForIdleSync()
            instrumentation.runOnMainSync {
                assertEquals(wasShown, activity.findViewById<View>(R.id.btnGeneralSos).isShown)
            }
        } finally { instrumentation.runOnMainSync { activity.finish() } }
    }

    @Test fun officerRiskZoneStillRequiresMatchingCoordinates() {
        // Isolated preferences; never overwrite the user's real incident or pending requests.
        val isolated = object : ContextWrapper(context) {
            override fun getSharedPreferences(name: String, mode: Int) =
                super.getSharedPreferences("announcement_test_$name", mode)
        }
        try {
            DisasterStateManager.setDisasterActive(isolated, "TEST_ZONE", "Test", "Test",
                centerLat = 13.75, centerLng = 100.50, radiusKm = 1.0)
            assertTrue(DisasterStateManager.isDeviceInRiskArea(isolated, 13.75, 100.50))
            assertFalse(DisasterStateManager.isDeviceInRiskArea(isolated, 14.0, 101.0))
            DisasterStateManager.setDisasterResolved(isolated)
            assertFalse(DisasterStateManager.isDeviceInRiskArea(isolated, 13.75, 100.50))
        } finally { isolated.getSharedPreferences("disaster_state_prefs", Context.MODE_PRIVATE).edit().clear().commit() }
    }

    @Test fun generalRequestWaitsForMatchingEocReceiptAndDoesNotDuplicate() {
        val prefix = "local_general_test_${System.nanoTime()}_"
        val folder = java.io.File(context.cacheDir, prefix).apply { mkdirs() }
        val isolated = object : ContextWrapper(context) {
            override fun getFilesDir() = folder
            override fun getSharedPreferences(name: String, mode: Int) = super.getSharedPreferences(prefix + name, mode)
        }
        val outbox = com.rescue.alert.data.GeneralSosOutbox
        try {
            val id = outbox.queue(isolated, org.json.JSONObject().put("contact_name", "LOCAL TEST")
                .put("lat", 13.75).put("lng", 100.50))
            assertTrue(outbox.hasPending(isolated))
            assertTrue(outbox.status(isolated).contains("รอศูนย์ EOC ตอบรับ"))
            assertEquals(id, outbox.queue(isolated, org.json.JSONObject().put("contact_name", "LOCAL TEST")))
            outbox.acknowledge(isolated, "DIFFERENT_CASE")
            assertTrue(outbox.status(isolated).contains("รอศูนย์ EOC ตอบรับ"))
            outbox.acknowledge(isolated, id)
            assertTrue(outbox.status(isolated).contains("ศูนย์ EOC ตอบรับข้อมูลแล้ว"))
            outbox.applyStatus(isolated, id, "RESCUED_SAFE")
            assertTrue(outbox.isCompleted(isolated))
            assertFalse(outbox.hasPending(isolated))
        } finally {
            isolated.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE).edit().clear().commit()
            folder.deleteRecursively() // Own temporary test data only; never invoke retry/send.
        }
    }

    @Test fun matchingAreaShowsBothActionsTogetherWithoutAnExtraScreen() {
        // UI fixture is restricted to our emulator; never inject an incident on a user's phone.
        org.junit.Assume.assumeTrue(Build.FINGERPRINT.startsWith("generic"))
        org.junit.Assume.assumeFalse(DisasterStateManager.isDisasterActive(context))
        val locationObject = com.rescue.alert.source.area.AreaLocation
        val latest = locationObject.javaClass.getDeclaredField("latest").apply { isAccessible = true }
        val resolved = locationObject.javaClass.getDeclaredField("resolved").apply { isAccessible = true }
        val originalLatest = latest.get(locationObject)
        val originalResolved = resolved.get(locationObject)
        val activity = instrumentation.startActivitySync(Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        try {
            instrumentation.runOnMainSync {
                activity.javaClass.getDeclaredMethod("stopPeriodicRiskZoneSync").apply {
                    isAccessible = true }.invoke(activity)
            }
            Thread.sleep(3500) // Drain a pre-existing zone request before installing the isolated UI fixture.
            val fix = android.location.Location("gps").apply {
                latitude = 19.91; longitude = 99.84; accuracy = 10f
                time = System.currentTimeMillis()
                elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos()
            }
            locationObject.accept(fix)
            resolved.set(locationObject, fix to com.rescue.alert.source.area.DeviceArea("57", "5701", "570102", "Test"))
            DisasterStateManager.setDisasterActive(context, "DPM_TEST_UI", "TEST", "พื้นที่ทดสอบ UI เท่านั้น",
                targetAreas = listOf(com.rescue.alert.source.area.AlertArea("tambon", "57", "5701", "570102")))
            instrumentation.runOnMainSync {
                activity.javaClass.getDeclaredMethod("updateDisasterStateUI").apply {
                    isAccessible = true }.invoke(activity)
                assertTrue(activity.findViewById<View>(R.id.btnPulsingSos).isShown)
                assertTrue(activity.findViewById<View>(R.id.btnGeneralSos).isShown)
            }
            instrumentation.waitForIdleSync()
            Thread.sleep(300) // Wait for the newly visible frame to be measured/drawn.
            instrumentation.runOnMainSync {
                val frame = activity.findViewById<View>(R.id.layoutActiveDisaster)
                assertTrue(frame.width > 0 && frame.height > 0)
                val bitmap = android.graphics.Bitmap.createBitmap(frame.width, frame.height, android.graphics.Bitmap.Config.ARGB_8888)
                frame.draw(android.graphics.Canvas(bitmap))
                java.io.File(context.cacheDir, "shared-area-ui-test.png").outputStream().use {
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
                }
                bitmap.recycle()
            }
            instrumentation.waitForIdleSync()
            // Mic start/end must leave an already matching area and its two actions intact.
            val mesh = BluetoothMeshManager.getInstance(context)
            instrumentation.runOnMainSync { mesh.handleOfficerAnnouncementChunk("LOCAL TEST", ByteArray(512)) }
            instrumentation.waitForIdleSync()
            instrumentation.runOnMainSync {
                assertTrue(activity.findViewById<View>(R.id.btnGeneralSos).isShown)
                mesh.handleOfficerAnnouncementEnded()
            }
        } finally {
            DisasterStateManager.setDisasterResolved(context)
            latest.set(locationObject, originalLatest)
            resolved.set(locationObject, originalResolved)
            instrumentation.runOnMainSync { activity.finish() }
        }
    }
}
