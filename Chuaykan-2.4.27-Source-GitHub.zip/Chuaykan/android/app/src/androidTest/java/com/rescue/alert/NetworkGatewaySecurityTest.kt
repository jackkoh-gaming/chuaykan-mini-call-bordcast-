package com.rescue.alert

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.network.SecureGateway
import com.rescue.alert.util.AppSettings
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.net.URL

/** Only a real health GET and rejected URLs; no incident or call is generated. */
@RunWith(AndroidJUnit4::class)
class NetworkGatewaySecurityTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private fun rejected(block: () -> Unit) {
        try { block(); fail("Unsafe connection accepted") } catch (_: IllegalArgumentException) {
        } catch (_: IllegalStateException) { }
    }

    @Test fun oracleTlsHealthWorksWithoutManualPairing() {
        val connection = SecureGateway.open(context, URL("${AppSettings.DEFAULT_GATEWAY_URL}/api/health"))
        connection.connectTimeout = 5000; connection.readTimeout = 5000
        try {
            assertEquals(200, connection.responseCode)
            val reply = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            assertEquals("ONLINE", reply.getString("status"))
            assertTrue(context.getSharedPreferences("secure_gateway_pairing", Context.MODE_PRIVATE).all.isEmpty())
        } finally { connection.disconnect() }
    }

    @Test fun unencryptedOrUnapprovedOriginsAreRejectedBeforeRegistration() {
        for (address in listOf("http://gateway.example.org/api/health", "https://unapproved.invalid/api/health",
            "https://other@gateway.example.org/api/health", "https://gateway.example.org/api/health#redirect")) {
            rejected { SecureGateway.open(context, URL(address)) }
        }
        rejected { SecureGateway.open(null, URL("${AppSettings.DEFAULT_GATEWAY_URL}/api/health")) }
    }

    @Test fun gatewayNetworkingCannotBlockTheMainThread() {
        instrumentation.runOnMainSync {
            rejected { SecureGateway.open(context, URL("${AppSettings.DEFAULT_GATEWAY_URL}/api/health")) }
        }
    }
}
