# Oracle official Push sender

This deployment runs the existing NDWC monitor on an Ubuntu VM. Android 2.4.7
already subscribes to `official_feed_changes_v1`; no APK change is required.
The phone still fetches the official source and applies its GPS notification policy.

Copy only the four Python modules listed in `install.sh` and these deployment
files. Transfer the Firebase credential separately over SSH, never in a code archive.
Run `sudo bash gateway/deploy/oracle/install.sh /path/to/credential.json` from
the transferred directory. The installer deliberately leaves the service stopped.

Before cutover, check the official source and validate Firebase credentials.
Stop the old sender, copy its final state to
`/var/lib/rescuealert-push/official-push.json`, owned by `rescuealert`, mode 0600.
Then run `sudo systemctl enable --now rescuealert-official-push.service`.
Confirm phone receipt of an `official_push_probe` before disabling the old sender.
If cutover fails, stop the new sender and restore the old sender; run only one monitor.

Useful commands on the VM:

```sh
systemctl status rescuealert-official-push.service
sudo journalctl -u rescuealert-official-push.service -n 30 --no-pager
```

The service uses `/opt/rescuealert-push/venv`, polls every second, preserves state
across reboots and backs off on errors. It needs outbound HTTPS, not a public web port.
The credential is stored under `/etc/rescuealert/`, readable by the service group.
Source polling cannot make upstream publishers release announcements earlier.
FCM acceptance alone is not proof of phone receipt or a GPS-matching emergency alarm.
