"""Publish the RFCOMM service through BlueZ SDP and receive its real duplex sockets."""
import socket
import dbus
import dbus.service
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib

PROFILE = "org.bluez.Profile1"


class MeshProfile(dbus.service.Object):
    PATH = "/com/rescuealert/eoc/rfcomm"

    def __init__(self, bus, on_connection, on_release):
        super().__init__(bus, self.PATH)
        self.on_connection = on_connection
        self.on_release = on_release
        self.sockets = {}

    @dbus.service.method(PROFILE, in_signature="oha{sv}", out_signature="")
    def NewConnection(self, device, fd, properties):
        connection = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_STREAM,
                                   socket.BTPROTO_RFCOMM, fileno=fd.take())
        address = connection.getpeername()[0]
        self.sockets[str(device)] = connection
        self.on_connection(connection, address)

    @dbus.service.method(PROFILE, in_signature="o", out_signature="")
    def RequestDisconnection(self, device):
        connection = self.sockets.pop(str(device), None)
        if connection:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()

    @dbus.service.method(PROFILE, in_signature="", out_signature="")
    def Release(self):
        self.on_release()


def serve_profile(service_uuid, on_connection, is_running, report):
    DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus(private=True)
    loop = GLib.MainLoop()
    profile = MeshProfile(bus, on_connection, loop.quit)
    manager = dbus.Interface(bus.get_object("org.bluez", "/org/bluez"), "org.bluez.ProfileManager1")
    registered = False

    def accepted():
        nonlocal registered
        registered = True
        report("ช่องเสียง Bluetooth พร้อมรับการเชื่อมต่อผ่าน UUID มาตรฐาน")
        print("[RFCOMM] BlueZ profile registered with SDP channel=4", flush=True)

    def rejected(error):
        report(f"เปิดช่องเสียง Bluetooth ไม่สำเร็จ: {error}")
        print(f"[RFCOMM] Profile registration failed: {error}", flush=True)
        loop.quit()

    def check_running():
        if not is_running():
            loop.quit()
        return True

    timer = GLib.timeout_add(500, check_running)
    try:
        options = dbus.Dictionary({
            "Name": dbus.String("RescueAlertVoiceMesh"), "Role": dbus.String("server"),
            "Channel": dbus.UInt16(4), "RequireAuthentication": dbus.Boolean(False),
            "RequireAuthorization": dbus.Boolean(False),
        }, signature="sv")
        manager.RegisterProfile(profile.PATH, service_uuid, options,
                                reply_handler=accepted, error_handler=rejected)
        loop.run()
    finally:
        GLib.source_remove(timer)
        if registered:
            try:
                manager.UnregisterProfile(profile.PATH, timeout=2)
            except dbus.DBusException:
                pass
        for device in list(profile.sockets):
            profile.RequestDisconnection(device)
        profile.remove_from_connection()
        bus.close()
