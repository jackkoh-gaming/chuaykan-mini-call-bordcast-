package com.rescue.alert

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.content.Intent
import android.content.ContextWrapper
import android.app.NotificationManager
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.speech.tts.TextToSpeech
import android.widget.TextView
import android.widget.Button
import android.view.View
import androidx.core.graphics.ColorUtils
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.ui.EmergencyActivity
import com.rescue.alert.util.ThemePalette
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class EmergencyPopupTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext

    private fun openPopup(): EmergencyActivity = instrumentation.startActivitySync(
        Intent(context, EmergencyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("ALERT_ID", "LOCAL_POPUP_TEST")
            .putExtra("TITLE", "ทดสอบหน้าต่างแจ้งเตือนในเครื่องเท่านั้น")
            .putExtra("INSTRUCTION", "ข้อความประกาศยาวสำหรับตรวจการเลื่อนอ่านและปุ่มตกลง ".repeat(60))
            .putExtra("SENDER", "การทดสอบในเครื่อง")
            .putExtra("AREA_DESC", "ไม่มีเหตุภัยจริง")
            .putExtra("MUTE_SOUND", true)) as EmergencyActivity

    @Test fun verifiedNotificationPathOpensPopupWithoutNotificationTapWhenAppVisible() {
        val originalAlert = com.rescue.alert.model.DisasterStateManager.getAlertId(context)
        val activity = openPopup()
        val isolated = object : ContextWrapper(context) {
            override fun getSharedPreferences(name: String, mode: Int) =
                super.getSharedPreferences("auto_popup_test_$name", mode)
            override fun sendBroadcast(intent: Intent) { /* No real incident state broadcast. */ }
        }
        val monitor = instrumentation.addMonitor(EmergencyActivity::class.java.name, null, false)
        var opened: EmergencyActivity? = null
        val id = "LOCAL_AUTO_POPUP_TEST"
        try {
            instrumentation.waitForIdleSync()
            val trigger = com.rescue.alert.engine.AlertProcessingEngine.javaClass.declaredMethods.single {
                it.name == "triggerCriticalNotification"
            }.apply { isAccessible = true }
            trigger.invoke(com.rescue.alert.engine.AlertProcessingEngine, isolated, id,
                "ทดสอบเปิดอัตโนมัติในเครื่อง", "ไม่มีเหตุภัยจริง", true,
                System.currentTimeMillis() + 60_000L, null, null, null,
                "การทดสอบในเครื่อง", "TEST", "ไม่มีเหตุภัยจริง", null, null, null)
            opened = monitor.waitForActivityWithTimeout(3000) as? EmergencyActivity
            assertNotNull("Alert should open without a notification tap", opened)
            assertEquals(id, opened!!.intent.getStringExtra("ALERT_ID"))
            assertEquals(originalAlert, com.rescue.alert.model.DisasterStateManager.getAlertId(context))
        } finally {
            instrumentation.removeMonitor(monitor)
            instrumentation.runOnMainSync {
                opened?.finish()
                if (!activity.isFinishing) activity.finish()
            }
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id.hashCode())
            isolated.getSharedPreferences("disaster_state_prefs", Context.MODE_PRIVATE).edit().clear().commit()
        }
    }

    @Test fun longPopupHasReadableColoursAndVisibleCloseButtonInBothModes() {
        val original = ThemePalette.isLight(context)
        try {
            for (light in listOf(true, false)) {
                instrumentation.runOnMainSync { ThemePalette.setLight(context, light) }
                val activity = openPopup()
                try {
                    instrumentation.waitForIdleSync()
                    instrumentation.runOnMainSync {
                        for (id in listOf(R.id.tvAlertHeaderBadge, R.id.tvAlertTitle,
                            R.id.tvAlertInstruction, R.id.tvAlertArea)) {
                            val text = activity.findViewById<TextView>(id)
                            assertTrue("Text contrast too low: $id", ColorUtils.calculateContrast(
                                text.currentTextColor, Color.WHITE) >= 4.5)
                        }
                        val button = activity.findViewById<Button>(R.id.btnAcknowledgeEmergency)
                        val visible = Rect()
                        assertTrue(button.getGlobalVisibleRect(visible))
                        assertEquals("Close button clipped by long bulletin", button.height, visible.height())
                        assertTrue(ColorUtils.calculateContrast(button.currentTextColor,
                            button.backgroundTintList!!.defaultColor) >= 4.5)
                    }
                    val image = instrumentation.uiAutomation.takeScreenshot()
                    File(context.filesDir, "popup-${if (light) "light" else "dark"}.png").outputStream().use {
                        image.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
                    }
                } finally { instrumentation.runOnMainSync { activity.finish() } }
            }
        } finally { instrumentation.runOnMainSync { ThemePalette.setLight(context, original) } }
    }

    @Test fun blockedSpeechStopCannotFreezeCloseOrUiThread() {
        val activity = openPopup()
        val release = CountDownLatch(1)
        val entered = CountDownLatch(1)
        // Test-only stalled engine reproduces the stop call in the historical ANR.
        val speech = object : TextToSpeech(context, null) {
            override fun stop(): Int {
                entered.countDown()
                release.await(5, TimeUnit.SECONDS)
                return TextToSpeech.SUCCESS
            }
        }
        try {
            activity.javaClass.getDeclaredField("tts").apply { isAccessible = true }.set(activity, speech)
            val closed = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post {
                activity.findViewById<Button>(R.id.btnAcknowledgeEmergency).performClick()
                closed.countDown()
            }
            assertTrue("Close button blocked UI", closed.await(500, TimeUnit.MILLISECONDS))
            assertTrue("Speech cleanup did not start", entered.await(2, TimeUnit.SECONDS))
            val heartbeat = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post { heartbeat.countDown() }
            assertTrue("UI waits for blocked TTS engine", heartbeat.await(500, TimeUnit.MILLISECONDS))
        } finally {
            release.countDown()
            instrumentation.runOnMainSync { if (!activity.isFinishing) activity.finish() }
        }
    }

    @Test fun captureHistoricalAnrMainThread() {
        if (Build.VERSION.SDK_INT < 30) return
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val exit = manager.getHistoricalProcessExitReasons(context.packageName, 0, 32)
            .firstOrNull { it.reason == ApplicationExitInfo.REASON_ANR } ?: return
        val trace = exit.traceInputStream?.bufferedReader()?.use { it.readText() } ?: return
        val main = Regex("(?m)^\"main\"[\\s\\S]*?(?=\\n\\n)").find(trace)?.value ?: "main stack unavailable"
        File(context.filesDir, "popup-anr-main.txt").writeText("${exit.description}\n$main")
    }
}
