package com.rescue.alert.model

enum class DamStatus(val label: String, val code: String) {
    CRITICAL_HIGH("วิกฤตน้ำหลาก", "CRITICAL_HIGH"),  // > 85%
    WARNING_HIGH("เฝ้าระวังสูง", "WARNING_HIGH"),      // 70% - 85%
    NORMAL("เกณฑ์ปกติ", "NORMAL"),                     // 30% - 70%
    CRITICAL_LOW("วิกฤตน้ำน้อย", "CRITICAL_LOW")       // < 30%
}

data class DamItem(
    val id: String,
    val name: String,
    val province: String,
    val region: String,
    val agency: String,
    val storageMcm: Double,
    val capacityMcm: Double,
    val percent: Double,
    val inflowMcm: Double,
    val releasedMcm: Double,
    val dateStr: String,
    val isLiveTelemetry: Boolean = false
) {
    val status: DamStatus
        get() = when {
            percent >= 85.0 -> DamStatus.CRITICAL_HIGH
            percent >= 70.0 -> DamStatus.WARNING_HIGH
            percent >= 30.0 -> DamStatus.NORMAL
            else -> DamStatus.CRITICAL_LOW
        }
}
