package com.rescue.alert.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.rescue.alert.model.DisasterNewsItem
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Live, read-only public bulletins and early warning feeds from:
 * 1. National Disaster Warning Center / DDPM (ปภ. 1784)
 * 2. Thai Meteorological Department (กรมอุตุนิยมวิทยา TMD)
 */
object DisasterNewsRepository {
    const val SOURCE_PAGE = "https://academicndwc.github.io/CBS-DashBoard/"
    private const val SNAPSHOT_URL = SOURCE_PAGE + "data/data.json"
    const val REFRESH_INTERVAL_MS = 10_000L
    private const val FEED_URL =
        "https://script.google.com/macros/s/AKfycbypPalKcGpXQXvrGqo3-NFTRfGdhShklY_vrGMwLRsAvQugFaV6-gApi6M-S6MBI5hE6Q/exec?type=data"
    private const val CACHE_TTL_MS = REFRESH_INTERVAL_MS
    private val cachedNews = mutableListOf<DisasterNewsItem>()
    @Volatile var lastFetchTime = 0L
        private set
    @Volatile var lastError: String? = null
        private set
    private var snapshotETag: String? = null
    private var officialNews = emptyList<DisasterNewsItem>()
    private var tmdNews = emptyList<DisasterNewsItem>()
    private var fetching = false
    private val waiting = mutableListOf<(List<DisasterNewsItem>) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    internal fun currentDayKey(at: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Asia/Bangkok")
        }.format(Date(at))

    internal fun recentOnly(items: List<DisasterNewsItem>, at: Long = System.currentTimeMillis()): List<DisasterNewsItem> {
        val today = currentDayKey(at)
        val start = Calendar.getInstance(TimeZone.getTimeZone("Asia/Bangkok"), Locale.US).apply {
            timeInMillis = at
            add(Calendar.DAY_OF_MONTH, -2)
        }
        val firstDay = currentDayKey(start.timeInMillis)
        val format = SimpleDateFormat("yyyyMMdd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Asia/Bangkok")
            isLenient = false
        }
        return items.filter {
            val day = it.dateStr.substringBefore(' ')
            day.matches(Regex("[0-9]{8}")) && day >= firstDay && day <= today &&
                runCatching { format.parse(day) }.getOrNull() != null
        }
    }

    fun getNews(context: Context? = null, forceRefresh: Boolean = false, callback: (List<DisasterNewsItem>) -> Unit) {
        val now = System.currentTimeMillis()
        synchronized(cachedNews) {
            val daily = recentOnly(cachedNews, now)
            cachedNews.clear(); cachedNews.addAll(daily)
            if (!forceRefresh && lastFetchTime > 0 && now - lastFetchTime < CACHE_TTL_MS) {
                val copy = cachedNews.toList()
                mainHandler.post { callback(recentOnly(copy)) }
                return
            }
            waiting.add(callback)
            if (fetching) return
            fetching = true
        }
        Thread {
            val errors = mutableListOf<String>()
            var succeeded = false
            try {
                fetchOfficialBulletins()?.let { officialNews = it }
                succeeded = true
            } catch (_: Exception) { errors.add("ปภ.: ติดต่อแหล่งข่าวไม่ได้ • แสดงข้อมูลเดิม") }
            try {
                TmdNewsFeed.fetch()?.let { tmdNews = it }
                succeeded = true
            } catch (_: Exception) { errors.add("กรมอุตุฯ: ติดต่อแหล่งข่าวไม่ได้ • แสดงข้อมูลเดิม") }
            lastError = errors.takeIf { it.isNotEmpty() }?.joinToString("\n")
            val callbacks: List<(List<DisasterNewsItem>) -> Unit>
            val result: List<DisasterNewsItem>
            synchronized(cachedNews) {
                cachedNews.clear()
                cachedNews.addAll(recentOnly(officialNews + tmdNews).distinctBy { it.id }.sortedByDescending { it.dateStr })
                if (succeeded) lastFetchTime = System.currentTimeMillis()
                result = cachedNews.toList()
                callbacks = waiting.toList()
                waiting.clear()
                fetching = false
            }
            mainHandler.post { callbacks.forEach { it(recentOnly(result)) } }
        }.start()
    }

    fun getNews(forceRefresh: Boolean = false, callback: (List<DisasterNewsItem>) -> Unit) =
        getNews(null, forceRefresh, callback)

    private fun fetchOfficialBulletins(): List<DisasterNewsItem>? =
        fetchJson()?.let { parseBulletins(it) }

    internal fun parseBulletins(root: JSONObject): List<DisasterNewsItem> {
        val items = ArrayList<DisasterNewsItem>()
        require(root.optJSONArray("fact_cb") != null) { "Missing official records" }
            val messages = indexBy(root.optJSONArray("dim_message"), "message_id")
            val senders = indexBy(root.optJSONArray("dim_sender"), "sender_id")
            val events = indexBy(root.optJSONArray("dim_event"), "event_id")
            val disasters = indexBy(root.optJSONArray("dim_disaster"), "disaster_id")
            val facts = root.optJSONArray("fact_cb") ?: JSONArray()
            for (i in 0 until facts.length()) {
                val fact = facts.optJSONObject(i) ?: continue
                val id = fact.optString("alert_id")
                if (id.isBlank()) continue
                val message = messages[fact.optString("message_id")]
                val sender = senders[fact.optString("sender_id")]
                val event = events[fact.optString("event_id")]
                val disaster = disasters[fact.optString("disaster_id")]
                val title = fact.optString("title", "ประกาศเตือนภัย")
                val details = message?.optString("message_th").orEmpty().ifBlank { title }
                val source = sender?.optString("sender_name").orEmpty()
                    .ifBlank { "กรมป้องกันและบรรเทาสาธารณภัย" }
                val category = event?.optString("event_th").orEmpty().ifBlank {
                    disaster?.optString("disaster_name").orEmpty().ifBlank { "การแจ้งเตือนภัย" }
                }
                val issued = fact.optString("date_id").removePrefix("D-") + " " + fact.optString("time")
                val sCode = if (source.contains("อุตุนิยมวิทยา") || source.contains("TMD")) "TMD" else "DDPM"
                
                // This feed has no per-article URL: link to the actual source dashboard.
                val officialWebUrl = SOURCE_PAGE

                items.add(
                    DisasterNewsItem(
                        id = "OFFICIAL_" + id,
                        source = source,
                        sourceCode = sCode,
                        title = title,
                        dateStr = issued.trim(),
                        category = category,
                        summary = details.take(240),
                        details = details,
                        webUrl = officialWebUrl,
                        severity = severityFor(title, category),
                        isLive = false
                    )
                )
            }
        // Display only records returned by the official source.

        return items.sortedByDescending { it.dateStr }
    }




    private fun fetchJson(): JSONObject? {
        var lastFailure: Exception? = null
        for (endpoint in listOf(SNAPSHOT_URL, FEED_URL)) {
            try {
                var current = URL(endpoint)
                repeat(6) {
                    require(current.protocol == "https") { "HTTPS required" }
                    val connection = (com.rescue.alert.network.PublicDataGateway.open(current) as HttpURLConnection).apply {
                        instanceFollowRedirects = false
                        connectTimeout = 7000
                        readTimeout = 10000
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("Cache-Control", "no-cache")
                        setRequestProperty("User-Agent", "RescueAlert/2.4")
                        if (endpoint == SNAPSHOT_URL && snapshotETag != null)
                            setRequestProperty("If-None-Match", snapshotETag)
                    }
                    try {
                        val code = connection.responseCode
                        if (code == 304 && lastFetchTime > 0) return null
                        if (code in 300..399) {
                            current = URL(current, requireNotNull(connection.getHeaderField("Location")))
                        } else {
                            require(code == 200) { "HTTP $code" }
                            val root = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                            require(root.optJSONArray("fact_cb") != null) { "Missing official records" }
                            if (endpoint == SNAPSHOT_URL) snapshotETag = connection.getHeaderField("ETag")
                            return root
                        }
                    } finally { connection.disconnect() }
                }
                error("Too many redirects")
            } catch (e: Exception) { lastFailure = e }
        }
        throw lastFailure ?: IllegalStateException("No official feed")
    }

    private fun indexBy(rows: JSONArray?, key: String): Map<String, JSONObject> {
        val result = HashMap<String, JSONObject>()
        if (rows == null) return result
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            row.optString(key).takeIf { it.isNotBlank() }?.let { result[it] = row }
        }
        return result
    }

    private fun severityFor(title: String, category: String): String {
        val text = (title + " " + category).lowercase()
        return when {
            text.contains("ชาติ") || text.contains("ฉุกเฉิน") || text.contains("วิกฤต") -> "CRITICAL"
            text.contains("ล่วงหน้า") || text.contains("early") || text.contains("พยากรณ์") -> "EARLY_WARNING"
            else -> "WARNING"
        }
    }
}
