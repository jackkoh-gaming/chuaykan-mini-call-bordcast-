package com.rescue.alert.source

import android.content.Context
import androidx.work.*
import com.rescue.alert.data.EvacuationSiteRepository
import java.util.concurrent.TimeUnit

object EvacuationSiteSync {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<EvacuationSiteWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "evacuation_site_sync", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}

class EvacuationSiteWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result =
        if (EvacuationSiteRepository.getInstance(applicationContext).syncFromGateway()) Result.success() else Result.failure()
}
