package com.rescue.alert.source.area

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.rescue.alert.R
import com.rescue.alert.ui.MainActivity
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Location monitoring is independent of microphone/Bluetooth permissions and call state. */
class AreaAlertService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var started = false
    private var lastEvaluation = 0L
    private val locationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { AreaLocation.accept(it) }
            if (System.currentTimeMillis() - lastEvaluation > 30_000) refresh(false)
        }
    }
    private val poll = object : Runnable {
        override fun run() { refresh(true); handler.postDelayed(this, 15 * 60_000L) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!hasPermission(this)) { stopSelf(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(
                CHANNEL, "ติดตามประกาศตาม GPS", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                })
            val open = Intent(this, MainActivity::class.java).putExtra("OPEN_AREA_ALERTS", true)
            val notification = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("${getString(com.rescue.alert.R.string.app_title)} • ติดตามประกาศตาม GPS")
                .setContentText("รอ push ประกาศ ปภ. ตาม GPS • ตรวจสำรองประมาณทุก 15 นาที")
                .setOngoing(false).setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW).setShowWhen(false)
                .setContentIntent(PendingIntent.getActivity(this, 24050, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(24050, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            else startForeground(24050, notification)
            isRunning = true
            if (!started) {
                started = true
                val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 60_000)
                    .setMinUpdateIntervalMillis(30_000).setMaxUpdateDelayMillis(60_000).build()
                locationClient.requestLocationUpdates(request, callback, Looper.getMainLooper())
                    .addOnFailureListener { Log.w("AreaAlerts", "Location updates unavailable", it) }
                locationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener {
                    if (it != null) { AreaLocation.accept(it); refresh(false) }
                }
                handler.post(poll)
            }
        } catch (e: SecurityException) {
            Log.w("AreaAlerts", "Location permission was revoked", e)
            stopSelf(); return START_NOT_STICKY
        } catch (e: Exception) {
            Log.w("AreaAlerts", "Location monitor cannot start: ${e.message}")
            stopSelf(); return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun refresh(force: Boolean) {
        if (!started || io.isShutdown) return
        if (!busy.compareAndSet(false, true)) return
        lastEvaluation = System.currentTimeMillis()
        io.execute { try { AreaAlertRepository.refresh(applicationContext, force) } catch (_: Exception) { } finally { busy.set(false) } }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        isRunning = false
        started = false
        handler.removeCallbacksAndMessages(null)
        locationClient.removeLocationUpdates(callback)
        io.shutdownNow(); super.onDestroy()
    }
    companion object {
        @Volatile var isRunning = false
            private set
        private const val CHANNEL = "area_alert_monitor_v1"
        fun hasPermission(context: Context) = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        fun start(context: Context) {
            if (!hasPermission(context)) return
            try { ContextCompat.startForegroundService(context, Intent(context, AreaAlertService::class.java)) }
            catch (e: Exception) { Log.w("AreaAlerts", "Open app to start location monitor: ${e.message}") }
        }
    }
}
