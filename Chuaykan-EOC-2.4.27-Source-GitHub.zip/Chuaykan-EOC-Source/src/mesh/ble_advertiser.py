"""Register EOC BLE presence and report acceptance from BlueZ."""
import dbus
import dbus.service
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib
from src.mesh.rfcomm_profile import MeshProfile
from src.mesh.pairing_agent import PairingAgent

ADVERTISEMENT = "org.bluez.LEAdvertisement1"
PROPERTIES = "org.freedesktop.DBus.Properties"
MANAGER = "org.bluez.LEAdvertisingManager1"


class EocAdvertisement(dbus.service.Object):
    PATH = "/com/rescuealert/eoc/advertisement"

    def __init__(self, bus, service_uuid, released):
        super().__init__(bus, self.PATH)
        self.released = released
        self.properties = {
            "Type": dbus.String("peripheral"),
            "ServiceUUIDs": dbus.Array([service_uuid], signature="s"),
            "LocalName": dbus.String("RescueAlert-EOC-Gateway"),
            "Discoverable": dbus.Boolean(True),
        }

    @dbus.service.method(PROPERTIES, in_signature="s", out_signature="a{sv}")
    def GetAll(self, interface):
        if interface != ADVERTISEMENT:
            raise dbus.exceptions.DBusException("Unknown interface", name="org.bluez.Error.InvalidArguments")
        return self.properties

    @dbus.service.method(ADVERTISEMENT, in_signature="", out_signature="")
    def Release(self):
        self.released()


def advertise(service_uuid, rfcomm_uuid, on_connection, on_pairing_request, is_running, report, is_app_peer=None):
    DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus(private=True)
    loop = GLib.MainLoop()
    registered = False
    manager = None
    advertisement = None
    profile = MeshProfile(bus, on_connection, loop.quit)
    profile_manager = dbus.Interface(bus.get_object("org.bluez", "/org/bluez"), "org.bluez.ProfileManager1")
    profile_registered = False
    agent = PairingAgent(bus, on_pairing_request, rfcomm_uuid, is_app_peer)
    agent_manager = dbus.Interface(bus.get_object("org.bluez", "/org/bluez"), "org.bluez.AgentManager1")
    agent_registered = False

    def accepted():
        nonlocal registered
        registered = True
        report("EOC BLE ลงทะเบียนสำเร็จ • มือถือค้นพบศูนย์สั่งการได้")
        print("[BLE] EOC advertisement registered", flush=True)

    def rejected(error):
        report(f"EOC BLE ลงทะเบียนไม่สำเร็จ: {error}")
        print(f"[BLE] Registration failed: {error}", flush=True)
        loop.quit()

    def profile_accepted():
        nonlocal profile_registered
        profile_registered = True
        report("ช่องเสียง Bluetooth พร้อมรับการเชื่อมต่อผ่าน UUID มาตรฐาน")
        print("[RFCOMM] BlueZ profile registered with SDP channel=4", flush=True)
        manager.RegisterAdvertisement(advertisement.PATH, dbus.Dictionary({}, signature="sv"),
                                      reply_handler=accepted, error_handler=rejected)

    def check_running():
        if not is_running():
            loop.quit()
        return True

    timer = None
    try:
        agent_manager.RegisterAgent(agent.PATH, "NoInputNoOutput")
        agent_registered = True
        agent_manager.RequestDefaultAgent(agent.PATH)
        objects = dbus.Interface(bus.get_object("org.bluez", "/"),
                                 "org.freedesktop.DBus.ObjectManager").GetManagedObjects()
        adapter_path = next(path for path, interfaces in objects.items() if MANAGER in interfaces)
        manager = dbus.Interface(bus.get_object("org.bluez", adapter_path), MANAGER)
        advertisement = EocAdvertisement(bus, service_uuid, loop.quit)
        timer = GLib.timeout_add(500, check_running)
        options = dbus.Dictionary({
            "Name": dbus.String("RescueAlertVoiceMesh"), "Role": dbus.String("server"),
            "Channel": dbus.UInt16(4), "RequireAuthentication": dbus.Boolean(False),
            "RequireAuthorization": dbus.Boolean(False),
        }, signature="sv")
        profile_manager.RegisterProfile(profile.PATH, rfcomm_uuid, options,
                                        reply_handler=profile_accepted, error_handler=rejected)
        loop.run()
    finally:
        if timer is not None:
            GLib.source_remove(timer)
        if registered and manager and advertisement:
            try:
                manager.UnregisterAdvertisement(advertisement.PATH, timeout=2)
            except dbus.DBusException:
                pass
        if advertisement:
            advertisement.remove_from_connection()
        if profile_registered:
            try:
                profile_manager.UnregisterProfile(profile.PATH, timeout=2)
            except dbus.DBusException:
                pass
        for device in list(profile.sockets):
            profile.RequestDisconnection(device)
        profile.remove_from_connection()
        if agent_registered:
            try:
                agent_manager.UnregisterAgent(agent.PATH, timeout=2)
            except dbus.DBusException:
                pass
        agent.remove_from_connection()
        bus.close()
