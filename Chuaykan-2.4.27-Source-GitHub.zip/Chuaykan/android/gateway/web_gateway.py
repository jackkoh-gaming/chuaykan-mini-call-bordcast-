#!/usr/bin/env python3
"""
RescueAlert Disaster Gateway - Web Management Dashboard
Features:
- Live Officer Voice & Text Dispatch
- 2-Way SOS Location Sharing (Off-Grid Blackout Resilient)
- Interactive Leaflet Map with Real-time SOS Markers & Rescue Status Tracking
- One-Click 'Mark Rescued' Sync with Citizen Mobile Devices
- SQLite WAL Persistent Outbox & Dispatch History
- Threaded High-Performance Server
"""
import http.server
import socketserver
import json
import os
import sys
import time
import subprocess
import re
import sqlite3
import secrets
import math
import uuid
import hmac
import base64
from typing import Any, Optional, Dict, List
from urllib.parse import urlparse, parse_qs

# Ensure parent directory is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gateway.crypto import sign_alert
from gateway.models import DisasterAlert, Point
from gateway.dispatcher import FCMDispatcher
from gateway.feed_ingester import fetch_recent_earthquakes, fetch_tmd_live_disaster

HOST = os.environ.get("GATEWAY_HOST", "127.0.0.1")
# C-10: Default to 8095 to prevent port collision with Desktop DispatchServer on 8090
PORT = int(os.environ.get("GATEWAY_PORT", 8095))
ADMIN_API_KEY = os.environ.get("RESCUE_ADMIN_API_KEY")
if not ADMIN_API_KEY:
    ADMIN_API_KEY = secrets.token_hex(16)

MAX_REQUEST_BODY = 12 * 1024 * 1024  # 12 MB max payload size
SOS_RATE_LIMIT = {}  # ip -> list of timestamps
SOS_CASES = {}
DISPATCH_HISTORY = []

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sos_cases.db")


def _parse_bool(val: Any, default: bool = False) -> bool:
    """Strict boolean parser preventing 'false' string from being truthy (Doc 2 H-11)."""
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return bool(val)
    if isinstance(val, str):
        val_clean = val.strip().lower()
        if val_clean in ("true", "1", "yes", "y"):
            return True
        if val_clean in ("false", "0", "no", "n", ""):
            return False
    return default


def _validate_float(val: Any, min_val: float = -float('inf'), max_val: float = float('inf')) -> Optional[float]:
    """Strict float validator rejecting NaN, Inf and out-of-bounds numbers (Doc 2 H-12)."""
    if val is None:
        return None
    try:
        f = float(val)
        if math.isnan(f) or math.isinf(f):
            return None
        if not (min_val <= f <= max_val):
            return None
        return f
    except (ValueError, TypeError):
        return None



def init_db():
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sos_cases (
                case_id TEXT PRIMARY KEY,
                device_id TEXT,
                alert_id TEXT,
                lat REAL,
                lng REAL,
                accuracy REAL,
                location_status TEXT,
                battery INTEGER,
                timestamp INTEGER,
                status TEXT,
                time_str TEXT,
                contact_name TEXT,
                contact_phone TEXT,
                member_count INTEGER,
                is_bedridden INTEGER,
                is_elderly INTEGER,
                is_infant INTEGER,
                urgent_needs TEXT,
                urgent_note TEXT,
                has_audio INTEGER,
                audio_url TEXT
            );
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS dispatch_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_id TEXT,
                title TEXT,
                signature TEXT,
                sent_time INTEGER,
                channel TEXT,
                dispatch_result TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        conn.commit()
    finally:
        conn.close()


def db_save_sos_case(case_data: dict):
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("""
            INSERT OR REPLACE INTO sos_cases (
                case_id, device_id, alert_id, lat, lng, accuracy, location_status,
                battery, timestamp, status, time_str, contact_name, contact_phone,
                member_count, is_bedridden, is_elderly, is_infant, urgent_needs,
                urgent_note, has_audio, audio_url
            ) VALUES (
                :case_id, :device_id, :alert_id, :lat, :lng, :accuracy, :location_status,
                :battery, :timestamp, :status, :time_str, :contact_name, :contact_phone,
                :member_count, :is_bedridden, :is_elderly, :is_infant, :urgent_needs,
                :urgent_note, :has_audio, :audio_url
            )
        """, {
            **case_data,
            "is_bedridden": 1 if case_data.get("is_bedridden") else 0,
            "is_elderly": 1 if case_data.get("is_elderly") else 0,
            "is_infant": 1 if case_data.get("is_infant") else 0,
            "has_audio": 1 if case_data.get("has_audio") else 0
        })
        conn.commit()
    finally:
        conn.close()


def db_update_case_status(case_id: str, new_status: str):
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("UPDATE sos_cases SET status = ? WHERE case_id = ?", (new_status, case_id))
        conn.commit()
    finally:
        conn.close()


def db_get_all_sos_cases() -> dict:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.execute("SELECT * FROM sos_cases ORDER BY timestamp ASC")
        rows = cur.fetchall()
        result = {}
        for r in rows:
            d = dict(r)
            d["is_bedridden"] = bool(d["is_bedridden"])
            d["is_elderly"] = bool(d["is_elderly"])
            d["is_infant"] = bool(d["is_infant"])
            d["has_audio"] = bool(d["has_audio"])
            result[d["case_id"]] = d
        return result
    finally:
        conn.close()


def db_save_dispatch(alert_id: str, title: str, signature: str, sent_time: int, channel: str, dispatch_result: dict):
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("""
            INSERT INTO dispatch_history (alert_id, title, signature, sent_time, channel, dispatch_result)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (alert_id, title, signature, sent_time, channel, json.dumps(dispatch_result, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()


def db_clear_sos_cases():
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("DELETE FROM sos_cases")
        conn.commit()
    finally:
        conn.close()


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[COMMAND] ศูนย์ประสานงานกู้ภัยฉุกเฉิน (RescueAlert 2-Way Lifeline)</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: #0f172a; color: #f8fafc; min-height: 100vh; line-height: 1.5; }
        header { background: #1e293b; border-bottom: 1px solid #334155; position: sticky; top: 0; z-index: 50; padding: 12px 20px; }
        .header-content { max-width: 1280px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; }
        .logo-box { display: flex; align-items: center; gap: 12px; }
        .logo-icon { font-size: 28px; }
        .logo-title { font-size: 18px; font-weight: 700; color: #ef4444; }
        .logo-sub { font-size: 11px; color: #94a3b8; }
        .badge-group { display: flex; align-items: center; gap: 10px; }
        .badge-sos { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px; border-radius: 9999px; font-size: 12px; font-weight: 600; background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .badge-net { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px; border-radius: 9999px; font-size: 12px; font-weight: 500; background: rgba(16, 185, 129, 0.1); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.2); }
        .dot-pulse { width: 8px; height: 8px; border-radius: 50%; background: #ef4444; display: inline-block; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.4; transform: scale(1.3); } }

        main { max-width: 1280px; margin: 0 auto; padding: 20px; display: grid; grid-template-columns: 1fr; gap: 24px; }
        @media (min-width: 1024px) { main { grid-template-columns: 7fr 5fr; } }

        .card { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); margin-bottom: 24px; }
        .card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
        .card-title { font-size: 16px; font-weight: 600; color: #ffffff; display: flex; align-items: center; gap: 8px; }
        .card-sub { font-size: 11px; color: #94a3b8; }

        /* Map area */
        #mapContainer { width: 100%; height: 380px; background: #0b1329; border: 1px solid #334155; border-radius: 10px; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; }
        #leafletMap { width: 100%; height: 100%; position: absolute; top: 0; left: 0; z-index: 1; }
        .map-legend { margin-top: 10px; display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; }

        /* Forms & Inputs */
        label { display: block; font-size: 12px; font-weight: 500; color: #cbd5e1; margin-bottom: 5px; }
        textarea, input, select { width: 100%; background: #0f172a; border: 1px solid #475569; border-radius: 8px; padding: 8px 12px; font-size: 13px; color: #f8fafc; outline: none; font-family: inherit; }
        textarea:focus, input:focus, select:focus { border-color: #ef4444; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }
        .form-group { margin-bottom: 12px; }

        .preset-btn { width: 100%; text-align: left; padding: 9px 12px; background: rgba(15, 23, 42, 0.8); border: 1px solid #334155; border-radius: 8px; font-size: 11px; color: #cbd5e1; cursor: pointer; margin-bottom: 6px; transition: background 0.15s; }
        .preset-btn:hover { background: #334155; color: #ffffff; }

        .toggle-box { padding: 10px 14px; background: rgba(15, 23, 42, 0.6); border: 1px solid #334155; border-radius: 8px; display: flex; align-items: center; justify-content: space-between; font-size: 12px; margin-bottom: 12px; }
        .toggle-box input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; accent-color: #10b981; }

        .btn-dispatch { width: 100%; padding: 14px; background: #dc2626; color: #ffffff; font-weight: 700; font-size: 14px; border: none; border-radius: 8px; cursor: pointer; transition: background 0.2s, transform 0.1s; box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4); display: flex; align-items: center; justify-content: center; gap: 8px; }
        .btn-dispatch:hover { background: #b91c1c; }
        .btn-dispatch:active { transform: scale(0.99); }
        .btn-dispatch:disabled { background: #64748b; cursor: not-allowed; box-shadow: none; }

        /* Status Console */
        #dispatchStatusConsole { margin-top: 14px; padding: 12px 14px; border-radius: 8px; font-size: 12px; line-height: 1.6; background: rgba(15, 23, 42, 0.8); border: 1px solid #334155; }
        .status-idle { color: #94a3b8; }
        .status-loading { color: #38bdf8; font-weight: 600; }
        .status-success { color: #34d399; font-weight: 600; }
        .status-error { color: #f87171; font-weight: 600; }

        /* SOS Queue */
        .sos-queue-box { max-height: 280px; overflow-y: auto; padding-right: 4px; display: flex; flex-direction: column; gap: 10px; }
        .sos-empty { text-align: center; color: #64748b; padding: 24px; font-size: 13px; }
        .sos-item { padding: 14px; border-radius: 10px; border: 1px solid; display: flex; flex-direction: column; gap: 8px; }
        .sos-item-waiting { background: rgba(69, 10, 10, 0.5); border-color: rgba(185, 28, 28, 0.6); }
        .sos-item-rescued { background: rgba(6, 78, 59, 0.4); border-color: rgba(4, 120, 87, 0.6); }
        .btn-rescue { width: 100%; padding: 8px 12px; background: #059669; color: #ffffff; font-weight: 700; border: none; border-radius: 6px; cursor: pointer; font-size: 12px; transition: background 0.15s; }
        .btn-rescue:hover { background: #047857; }

        /* Earthquakes */
        .eq-item { padding: 8px 10px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(51, 65, 85, 0.6); border-radius: 6px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 11px; }
        .btn-refresh { font-size: 11px; background: #334155; color: #cbd5e1; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer; }
        .btn-refresh:hover { background: #475569; }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-content">
            <div class="logo-box">
                <span class="logo-icon" style="font-size: 16px; font-weight: bold; color: #ef4444;">[RESCUE]</span>
                <div>
                    <h1 class="logo-title">RescueAlert ศูนย์บัญชาการกู้ภัยฉุกเฉิน</h1>
                    <p class="logo-sub">ระบบสั่งการสดและรับพิกัดขอความช่วยเหลือ 2-Way Off-Grid & Cloud</p>
                </div>
            </div>
            <div class="badge-group">
                <span id="sosBadge" class="badge-sos">
                    <span class="dot-pulse"></span>
                    รอความช่วยเหลือ: <span id="sosCount">0</span> ราย
                </span>
                <span class="badge-net">
                    [LINK] Cloud & Tactical Linked
                </span>
            </div>
        </div>
    </header>

    <main>
        <!-- Left Column: Map & Active SOS Pins -->
        <div>
            <!-- Map Card -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        [MAP] แผนที่พิกัดผู้ประสบภัย & ขอบเขตอันตราย
                    </h2>
                    <span class="card-sub">หมุดแดง [SOS] = รอการช่วยเหลือ | หมุดเขียว [SAFE] = สำเร็จแล้ว</span>
                </div>
                <div id="mapContainer">
                    <div id="leafletMap"></div>
                </div>
                <div class="map-legend">
                    <span id="coordInfo">ยังไม่ได้กำหนดพื้นที่ประกาศ</span>
                    <span id="sosMapStatus" style="color: #34d399; font-weight: 500;">[ONLINE] ระบบออนไลน์ พร้อมรับ-ส่งสัญญาณ</span>
                </div>
            </div>

            <!-- Active SOS Queue -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title" style="color: #f87171;">
                        [QUEUE] คิวผู้ประสบภัยที่กดขอความช่วยเหลือ (Live SOS Queue)
                    </h2>
                    <button type="button" onclick="fetchSosList()" class="btn-refresh">
                        [REFRESH] รีเฟรช
                    </button>
                </div>
                <div id="sosList" class="sos-queue-box">
                    <div class="sos-empty">ยังไม่มีสัญญาณขอความช่วยเหลือเข้ามาในขณะนี้</div>
                </div>
            </div>
        </div>

        <!-- Right Column: Officer Dispatch & Voice Console -->
        <div>
            <!-- Officer Live Voice/Message Dispatch Card -->
            <div class="card" style="border-left: 4px solid #ef4444;">
                <div class="card-header">
                    <h2 class="card-title">
                        [DISPATCH] คำสั่งเสียงสดจากเจ้าหน้าที่กู้ภัย (Live Dispatch)
                    </h2>
                    <span style="font-size: 11px; background: #450a0a; color: #fca5a5; padding: 2px 8px; border-radius: 4px; border: 1px solid #991b1b;">
                        OFFICER LIVE
                    </span>
                </div>
                <p style="font-size: 12px; color: #cbd5e1; margin-bottom: 12px;">
                    ส่งสัญญาณแจ้งประชาชนในพื้นที่: เมื่อเจ้าหน้าที่ไปถึงจะแสดงปุ่มให้ประชาชนกดแชร์พิกัดกลับมายังศูนย์
                </p>

                <!-- Preset Quick Buttons -->
                <div style="margin-bottom: 14px;">
                    <button type="button" onclick="setVoiceText('[OFFICER] เจ้าหน้าที่กู้ภัยกำลังจะไปจุดนี้ (ซอย 2) เมื่อไปถึงจะแสดงปุ่มที่หน้าจอ ให้ประชาชนรบกวนช่วยกดเพื่อแชร์ตำแหน่งให้ทราบ')"
                        class="preset-btn">
                        • "เจ้าหน้าที่กำลังจะไปจุดนี้... ช่วยกดปุ่มแชร์ตำแหน่งให้ทราบ"
                    </button>
                    <button type="button" onclick="setVoiceText('[OFFICER] ขณะนี้เรือกู้ภัยและทหารเข้าพื้นที่แล้ว ใครที่ติดอยู่บนหลังคาหรือชั้น 2 ขอให้กดปุ่มแชร์ตำแหน่งทันทีเพื่อส่งเรือเข้ารับ')"
                        class="preset-btn">
                        • "เรือกู้ภัยเข้าพื้นที่แล้ว ขอให้กดปุ่มแชร์ตำแหน่งทันที"
                    </button>
                </div>

                <div class="form-group">
                    <label>ข้อความเสียงที่เจ้าหน้าที่ต้องการประกาศ</label>
                    <textarea id="officerMessage" rows="3" required placeholder="ระบุประกาศและคำแนะนำจากเจ้าหน้าที่"></textarea>
                </div>

                <div class="grid-2">
                    <div>
                        <label>จุดศูนย์กลาง (Lat, Lng)</label>
                        <input id="officerLat" type="text" placeholder="ระบุละติจูด, ลองจิจูดของพื้นที่จริง">
                    </div>
                    <div>
                        <label>รัศมีปฏิบัติการ (กม.)</label>
                        <input id="officerRadius" type="number" step="0.5" value="15.0">
                    </div>
                </div>

                <button type="button" id="btnDispatchOfficer" onclick="handleVoiceDispatch()" class="btn-dispatch">
                    <span>[DISPATCH] ยิงสัญญาณคำสั่งเจ้าหน้าที่ -> แสดงปุ่ม SOS บนมือถือชาวบ้าน</span>
                </button>

                <!-- Live Status Feedback Console -->
                <div id="dispatchStatusConsole">
                    <div class="status-idle">
                        [ONLINE] <b>สถานะระบบ:</b> พร้อมส่งสัญญาณเตือนภัยฉุกเฉิน
                    </div>
                </div>
            </div>

            <!-- Live USGS Earthquake Monitor -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        [USGS] แผ่นดินไหว Real-time (USGS Feed)
                    </h2>
                    <button type="button" onclick="loadEarthquakes()" class="btn-refresh">
                        [REFRESH]
                    </button>
                </div>
                <div id="earthquakeList" style="font-size: 11px; max-height: 160px; overflow-y: auto; padding-right: 4px;">
                    <div style="color: #94a3b8; text-align: center; padding: 8px;">กำลังดึงข้อมูล...</div>
                </div>
            </div>
        </div>
    </main>

    <!-- Async Leaflet loading (non-blocking fallback) -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" defer></script>

    <script>
        let ADMIN_KEY = "";
        function getAdminKey() {
            if (!ADMIN_KEY) {
                ADMIN_KEY = sessionStorage.getItem("rescue_admin_key") || "";
            }
            if (!ADMIN_KEY) {
                ADMIN_KEY = prompt("กรุณาระบุ RescueAlert Admin API Key เพื่อยืนยันสิทธิ์:") || "";
                if (ADMIN_KEY) {
                    sessionStorage.setItem("rescue_admin_key", ADMIN_KEY);
                }
            }
            return ADMIN_KEY;
        }

        function escapeHtml(str) {
            if (str == null) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        let mapInstance = null;
        let mapCircle = null;
        let sosMarkers = {};

        function initMapSafe() {
            const el = document.getElementById('leafletMap');
            if (typeof L !== 'undefined' && el && !mapInstance) {
                try {
                    mapInstance = L.map('leafletMap').setView([13.75, 100.5], 6);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '© OpenStreetMap contributors'
                    }).addTo(mapInstance);

                } catch (e) {
                    console.warn("Leaflet map init error:", e);
                }
            } else if (!mapInstance) {
                el.innerHTML = `
                    <div style="width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #64748b; font-size: 13px; text-align: center; padding: 20px;">
                        <div style="width: 80px; height: 80px; border-radius: 50%; border: 2px dashed #ef4444; display: flex; align-items: center; justify-content: center; margin-bottom: 12px; background: rgba(239, 68, 68, 0.1);">
                            <span style="font-size: 14px; font-weight: bold; color: #ef4444;">[RADAR]</span>
                        </div>
                        <div style="font-weight: 600; color: #cbd5e1; margin-bottom: 4px;">เรดาร์ควบคุมพื้นที่ฉุกเฉิน (Tactical Radar)</div>
                        <div>โหลดแผนที่ไม่ได้ กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ต</div>
                    </div>
                `;
            }
        }

        setTimeout(initMapSafe, 1000);
        setTimeout(initMapSafe, 3000);

        function setVoiceText(txt) {
            document.getElementById('officerMessage').value = txt;
        }

        async function handleVoiceDispatch() {
            const btn = document.getElementById('btnDispatchOfficer');
            const consoleBox = document.getElementById('dispatchStatusConsole');
            const originalHtml = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '<span>[PENDING] กำลังยิงสัญญาณเตือนภัย...</span>';
            consoleBox.innerHTML = '<div class="status-loading">[CONNECTING] กำลังเชื่อมต่อและส่งสัญญาณผ่านดาวเทียม/คลาวด์ Google Firebase...</div>';

            try {
                const latEl = document.getElementById('officerLat');
                const coords = (latEl ? latEl.value : '').split(',');
                if (coords.length !== 2 || coords.some(c => !c.trim())) throw new Error('กรุณาระบุพิกัดพื้นที่จริง');
                const lat = Number(coords[0].trim());
                const lng = Number(coords[1].trim());
                if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) throw new Error('พิกัดไม่ถูกต้อง');
                const radius = parseFloat(document.getElementById('officerRadius')?.value || '15.0');
                const isMuted = document.getElementById('voiceMute')?.checked ?? true;
                const message = document.getElementById('officerMessage')?.value?.trim();
                if (!message) throw new Error('กรุณาระบุข้อความประกาศจริง');

                const payload = {
                    title: "[OFFICER] ประกาศจากเจ้าหน้าที่กู้ภัย",
                    instruction: message,
                    severity: "CRITICAL",
                    center_lat: lat,
                    center_lng: lng,
                    radius_km: radius,
                    is_muted: isMuted,
                };

                const res = await fetch('/api/dispatch', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-API-Key': getAdminKey()
                    },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                
                const fcmRes = data.dispatch_result?.fcm;
                
                let htmlReport = `<div class="status-success">[SUCCESS] <b>ยิงสัญญาณสำเร็จ!</b> (รหัส: ${escapeHtml(data.alert_id)})<br>`;
                let alertMsg = `[BROADCAST] ยิงสัญญาณเรียบร้อยแล้ว! (รหัส: ${data.alert_id})\n\n`;

                if (fcmRes) {
                    if (fcmRes.status === 'success') {
                        htmlReport += `[FCM] <b>Google Firebase Cloud:</b> ส่งสำเร็จ!<br><span style="font-family: monospace; font-size: 11px; color: #cbd5e1;">Message ID: ${escapeHtml(String(fcmRes.message_id))}</span><br>`;
                        alertMsg += `[SUCCESS] Google Firebase Cloud: สำเร็จ!\n(Message ID: ${fcmRes.message_id})\n\n`;
                    } else {
                        htmlReport += `[ERROR] Google Cloud Error: ${escapeHtml(String(fcmRes.error))}<br>`;
                        alertMsg += `[ERROR] Google Cloud Error: ${fcmRes.error}\n\n`;
                    }
                }
                htmlReport += `[DEVICE] <b>ผลลัพธ์:</b> โทรศัพท์ประชาชนในพื้นที่ได้รับสัญญาณแจ้งเตือนทันที</div>`;
                consoleBox.innerHTML = htmlReport;

                alert(alertMsg);
            } catch (err) {
                consoleBox.innerHTML = `<div class="status-error">[ERROR] เกิดข้อผิดพลาดในการส่ง: ${escapeHtml(String(err))}</div>`;
                alert("เกิดข้อผิดพลาดในการส่ง: " + err);
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
        }


        async function fetchSosList() {
            try {
                const res = await fetch('/api/sos/list', {
                    headers: {
                        'X-API-Key': getAdminKey()
                    }
                });
                if (!res.ok) {
                    console.warn("fetchSosList unauthorized or error:", res.status);
                    return;
                }
                const list = await res.json();
                updateSosUI(list);
            } catch (e) {
                console.warn("fetchSosList error:", e);
            }
        }

        function updateSosUI(data) {
            const cases = (data && data.cases) ? data.cases : (data || []);
            const container = document.getElementById('sosList');
            if (!container) return;
            const keys = Object.keys(cases);
            const waitingCount = keys.filter(k => cases[k].status === 'WAITING_RESCUE').length;
            const badge = document.getElementById('sosCount');
            if (badge) badge.innerText = waitingCount;

            if (keys.length === 0) {
                container.innerHTML = '<div class="sos-empty">ยังไม่มีสัญญาณขอความช่วยเหลือเข้ามาในขณะนี้</div>';
                return;
            }

            container.innerHTML = '';
            keys.reverse().forEach(k => {
                try {
                    const c = cases[k];
                    const isWaiting = c.status === 'WAITING_RESCUE';
                    const hasCoords = c.lat != null && c.lng != null && !isNaN(c.lat) && !isNaN(c.lng);

                    if (hasCoords && mapInstance && typeof L !== 'undefined') {
                        const markerColor = isWaiting ? '#ef4444' : '#10b981';
                        if (!sosMarkers[k]) {
                            const marker = L.circleMarker([c.lat, c.lng], {
                                radius: 10,
                                fillColor: markerColor,
                                color: '#ffffff',
                                weight: 2,
                                opacity: 1,
                                fillOpacity: 0.9
                            }).addTo(mapInstance);
                            marker.bindPopup(`<b>${escapeHtml(c.device_id)}</b><br>สถานะ: ${isWaiting ? '[WAITING] รอความช่วยเหลือ' : '[SAFE] ปลอดภัยแล้ว'}<br>แบต: ${escapeHtml(String(c.battery))}%`);
                            sosMarkers[k] = marker;
                        } else {
                            sosMarkers[k].setLatLng([c.lat, c.lng]);
                            sosMarkers[k].setStyle({ fillColor: markerColor });
                        }
                    }

                    const card = document.createElement('div');
                    card.className = 'sos-item ' + (isWaiting ? 'sos-item-waiting' : 'sos-item-rescued');

                    let actionHtml = '';
                    if (isWaiting) {
                        actionHtml = `
                            <div style="margin-top: 10px; display: flex; gap: 8px;">
                                <button class="btn-mark-rescue" data-case-id="${escapeHtml(c.case_id)}" style="flex: 1; padding: 6px 12px; background: #10b981; color: white; border: none; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer;">
                                    [SAFE] ช่วยเหลือสำเร็จแล้ว
                                </button>
                            </div>
                        `;
                    } else {
                        actionHtml = '<div style="font-size: 11px; color: #34d399; font-weight: 500;">[SAFE] ช่วยเหลือแล้ว / นำส่งศูนย์พักพิงเรียบร้อย</div>';
                    }

                    let profileBadges = '';
                    if (c.is_bedridden) profileBadges += '<span style="background: #ef4444; color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; margin-right: 4px;">ผู้ป่วยติดเตียง</span>';
                    if (c.is_elderly) profileBadges += '<span style="background: #f59e0b; color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; margin-right: 4px;">ผู้สูงอายุ</span>';
                    if (c.is_infant) profileBadges += '<span style="background: #3b82f6; color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; margin-right: 4px;">เด็กทารก</span>';
                    if (profileBadges) profileBadges = `<div style="margin-top: 6px;">${profileBadges}</div>`;

                    let contactHtml = '';
                    if (c.contact_name || c.contact_phone) {
                        contactHtml = `<div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">ผู้ติดต่อ: <b>${escapeHtml(c.contact_name || '-')}</b> (${escapeHtml(c.contact_phone || '-')}) | สมาชิก: ${escapeHtml(String(c.member_count || 1))} คน</div>`;
                    }

                    let urgentHtml = '';
                    const needsText = c.urgent_needs || c.urgent_note;
                    if (needsText) {
                        urgentHtml = '<div style="font-size: 11px; color: #fca5a5; margin-top: 2px;">' +
                            'ความต้องการด่วน: <b>' + escapeHtml(needsText) + '</b></div>';
                    }

                    let audioHtml = '';
                    if (c.has_audio && c.audio_url) {
                        const authedAudioUrl = c.audio_url + '?token=' + encodeURIComponent(getAdminKey());
                        audioHtml = '<div style="margin-top: 8px; background: rgba(15, 23, 42, 0.85); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 8px; padding: 10px 12px;">' +
                            '<div style="font-size: 11px; font-weight: 700; color: #f87171; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">' +
                            '<span>[VOICE]</span> <span>ข้อความเสียงขอความช่วยเหลือจากผู้ประสบภัย:</span>' +
                            '</div>' +
                            '<audio controls src="' + escapeHtml(authedAudioUrl) + '" style="width: 100%; height: 36px;"></audio>' +
                            '</div>';
                    }

                    const coordStr = hasCoords
                        ? `<span style="font-family: monospace; color: #fcd34d;">${Number(c.lat).toFixed(4)}, ${Number(c.lng).toFixed(4)}</span>`
                        : `<span style="color: #f87171; font-weight: 600;">ไม่ระบุ (ไม่พบสัญญาณ GPS / ในอาคาร)</span>`;

                    card.innerHTML = `
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-weight: 700; font-size: 13px; color: #ffffff;">
                                ${isWaiting ? '[SOS]' : '[SAFE]'} ${escapeHtml(c.device_id)}
                            </span>
                            <span style="font-size: 11px; padding: 2px 8px; border-radius: 4px; font-weight: 600; background: ${isWaiting ? '#ef4444' : '#10b981'}; color: #ffffff;">
                                ${isWaiting ? 'รอความช่วยเหลือ (SOS)' : 'ช่วยเหลือสำเร็จแล้ว'}
                            </span>
                        </div>
                        <div style="font-size: 11px; color: #cbd5e1; margin-top: 2px;">
                            พิกัด: ${coordStr} | แบตเตอรี่: ${escapeHtml(String(c.battery))}% | เวลา: ${escapeHtml(c.time_str || '')}
                        </div>
                        ${profileBadges}
                        ${contactHtml}
                        ${urgentHtml}
                        ${audioHtml}
                        ${actionHtml}
                    `;
                    container.appendChild(card);
                } catch (cardErr) {
                    console.error("Error rendering SOS card:", k, cardErr);
                }
            });

            // Bind click handlers cleanly without inline onclick (CRIT-5)
            container.querySelectorAll('.btn-mark-rescue').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const cid = this.getAttribute('data-case-id');
                    if (cid) markRescued(cid);
                });
            });
        }

        async function markRescued(caseId) {
            try {
                const res = await fetch('/api/sos/complete', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-API-Key': getAdminKey()
                    },
                    body: JSON.stringify({ case_id: caseId })
                });
                const data = await res.json();
                fetchSosList();
                alert("[SAFE] บันทึกว่าช่วยเหลือสำเร็จแล้ว! ระบบส่งสัญญาณแจ้งไปยังโทรศัพท์ผู้ประสบภัยว่าปลอดภัยแล้ว");
            } catch (err) {
                alert("เกิดข้อผิดพลาด: " + err);
            }
        }

        async function loadEarthquakes() {
            const container = document.getElementById('earthquakeList');
            container.innerHTML = '<div style="color: #94a3b8; text-align: center; padding: 6px;">กำลังดึงข้อมูล...</div>';
            try {
                const res = await fetch('/api/earthquakes');
                const list = await res.json();
                if (!list || !list.length) {
                    container.innerHTML = '<div style="color: #64748b; text-align: center; padding: 6px;">ไม่มีแผ่นดินไหวขนาด >= 4.0 ใน 24 ชม.</div>';
                    return;
                }
                container.innerHTML = '';
                list.slice(0, 4).forEach(eq => {
                    const row = document.createElement('div');
                    row.className = 'eq-item';
                    row.innerHTML = `
                        <div>
                            <div style="font-weight: 500; color: #e2e8f0;">${escapeHtml(eq.title)}</div>
                            <div style="font-size: 10px; color: #94a3b8;">${Number(eq.center_lat).toFixed(2)}, ${Number(eq.center_lng).toFixed(2)} | รัศมี ${Number(eq.radius_km).toFixed(0)} กม.</div>
                        </div>
                    `;
                    container.appendChild(row);
                });
            } catch (err) {
                container.innerHTML = '<div style="color: #f87171; text-align: center; padding: 6px;">ดึงข้อมูลไม่สำเร็จ</div>';
            }
        }

        // Automatic Start - Zero Delay
        fetchSosList();
        loadEarthquakes();
        setInterval(fetchSosList, 2000);
    </script>
</body>
</html>
"""


class GatewayHandler(http.server.BaseHTTPRequestHandler):

    def is_authenticated(self, allow_query_token: bool = False) -> bool:
        """Verifies API key using timing-safe comparison (Doc 2 C-04, C-05)."""
        auth_header = self.headers.get("Authorization", "").strip()
        if auth_header.startswith("Bearer "):
            token = auth_header[7:].strip()
            if token and hmac.compare_digest(token, ADMIN_API_KEY):
                return True

        api_key = self.headers.get("X-API-Key", "").strip()
        if api_key and hmac.compare_digest(api_key, ADMIN_API_KEY):
            return True

        if allow_query_token:
            qs = parse_qs(urlparse(self.path).query)
            token = qs.get("token", [""])[0].strip()
            if token and hmac.compare_digest(token, ADMIN_API_KEY):
                return True

        # Doc 2 C-05: Strict elimination of query string authentication on administrative endpoints
        return False

    def send_unauthorized(self):
        self.send_response(401)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(b'{"error": "Unauthorized. Requires valid RescueAlert Admin API key."}')

    def is_rate_limited(self, client_ip: str, max_per_min: int = 30) -> bool:
        now = time.time()
        # M-18: Periodic retention cleanup of stale rate limiter entries
        if len(SOS_RATE_LIMIT) > 500:
            stale_keys = [k for k, v in SOS_RATE_LIMIT.items() if not v or (now - v[-1] > 120)]
            for k in stale_keys:
                SOS_RATE_LIMIT.pop(k, None)

        times = [t for t in SOS_RATE_LIMIT.get(client_ip, []) if now - t < 60]
        if len(times) >= max_per_min:
            return True
        times.append(now)
        SOS_RATE_LIMIT[client_ip] = times
        return False

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == "/" or url.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            # CRIT-5: Content-Security-Policy header
            self.send_header("Content-Security-Policy", "default-src 'self' 'unsafe-inline' https://unpkg.com https://*.tile.openstreetmap.org data: blob:;")
            self.end_headers()
            # C-05: Never inject secret key into browser HTML
            rendered_html = HTML_TEMPLATE.replace("__ADMIN_KEY__", "")
            self.wfile.write(rendered_html.encode("utf-8"))

        elif url.path == "/api/sos/list":
            # CRIT-4: Enforce authentication on citizen PII
            if not self.is_authenticated():
                self.send_unauthorized()
                return

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            cases = db_get_all_sos_cases()
            qs = parse_qs(url.query)
            # C-10: Dual-schema compatibility
            if qs.get("format", [""])[0] == "wrapper":
                out = {"count": len(cases), "cases": list(cases.values()), "list": list(cases.values())}
            else:
                out = cases
            self.wfile.write(json.dumps(out, ensure_ascii=False).encode("utf-8"))

        elif url.path == "/api/alerts/live":
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            tmd_alert = fetch_tmd_live_disaster()
            if not tmd_alert:
                self.send_response(503)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(json.dumps({"status": "unavailable", "message": "ไม่มีรายงานภัยพิบัติแบบเรียลไทม์จากแหล่งข้อมูลในขณะนี้"}, ensure_ascii=False).encode("utf-8"))
                return
            source_label = "กรมอุตุนิยมวิทยา (TMD Live Feed)"
            out = {
                "alert_id": tmd_alert.alert_id,
                "title": tmd_alert.title,
                "instruction": tmd_alert.instruction,
                "severity": tmd_alert.severity,
                "center_lat": tmd_alert.center_lat,
                "center_lng": tmd_alert.center_lng,
                "radius_km": tmd_alert.radius_km,
                "source": source_label,
                "timestamp": int(time.time() * 1000)
            }
            self.wfile.write(json.dumps(out, ensure_ascii=False).encode("utf-8"))

        elif url.path == "/api/earthquakes":
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            eqs = fetch_recent_earthquakes(min_magnitude=4.2)
            out = []
            for eq in eqs:
                out.append({
                    "alert_id": eq.alert_id,
                    "title": eq.title,
                    "instruction": eq.instruction,
                    "severity": eq.severity,
                    "center_lat": eq.center_lat,
                    "center_lng": eq.center_lng,
                    "radius_km": eq.radius_km
                })
            self.wfile.write(json.dumps(out, ensure_ascii=False).encode("utf-8"))

        elif url.path == "/api/news":
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps([], ensure_ascii=False).encode("utf-8"))

        elif url.path.startswith("/api/sos/audio/"):
            if not self.is_authenticated(allow_query_token=True):
                self.send_unauthorized()
                return

            filename = os.path.basename(url.path)
            recordings_dir = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "recordings"))
            audio_path = os.path.realpath(os.path.join(recordings_dir, filename))
            if not audio_path.startswith(recordings_dir + os.sep):
                self.send_response(400)
                self.end_headers()
                return

            if os.path.isfile(audio_path):
                self.send_response(200)
                self.send_header("Content-Type", "audio/mp4")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(os.path.getsize(audio_path)))
                self.end_headers()
                with open(audio_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        url = urlparse(self.path)
        content_length = int(self.headers.get("Content-Length", 0))

        if content_length > MAX_REQUEST_BODY:
            self.send_response(413)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"error": "Payload too large. Maximum body size exceeded."}')
            return

        body = self.rfile.read(content_length)

        if url.path == "/api/dispatch":
            if not self.is_authenticated():
                self.send_unauthorized()
                return

            try:
                req = json.loads(body.decode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": f"Invalid JSON format: {str(e)}"}).encode("utf-8"))
                return

            alert_id = f"OFFICER_{int(time.time())}"
            title = str(req.get("title", "[OFFICER] ประกาศจากเจ้าหน้าที่กู้ภัย"))[:128]
            instruction = str(req.get("instruction", "โปรดกดปุ่มแชร์ตำแหน่งบนหน้าจอเพื่อให้เจ้าหน้าที่ทราบพิกัดของคุณ"))[:500]
            severity = str(req.get("severity", "CRITICAL"))[:32]
            is_muted = False

            c_lat = _validate_float(req.get("center_lat"), -90.0, 90.0)
            c_lng = _validate_float(req.get("center_lng"), -180.0, 180.0)
            r_km = _validate_float(req.get("radius_km"), 0.1, 500.0)
            if c_lat is None or c_lng is None or r_km is None or not str(req.get("instruction", "")).strip():
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error":"Valid coordinates, radius and announcement text are required"}')
                return

            alert = DisasterAlert(
                alert_id=alert_id,
                title=title,
                instruction=instruction,
                severity=severity,
                center_lat=c_lat,
                center_lng=c_lng,
                radius_km=r_km,
            )

            channel = "fcm"
            dispatch_results = {}

            # 1. FCM Cloud Dispatch
            if channel in ("fcm", "both"):
                fcm_res = FCMDispatcher.dispatch_topic(
                    alert=alert,
                    topic="emergency_alerts",
                    is_muted=is_muted
                )
                dispatch_results["fcm"] = fcm_res


            record = {
                "alert_id": alert.alert_id,
                "title": alert.title,
                "signature": alert.signature,
                "sent_time": alert.sent_time,
                "channel": channel,
                "dispatch_result": dispatch_results
            }
            if len(DISPATCH_HISTORY) > 200:
                del DISPATCH_HISTORY[:50]
            DISPATCH_HISTORY.append(record)
            db_save_dispatch(alert.alert_id, alert.title, alert.signature, alert.sent_time, channel, dispatch_results)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(record).encode("utf-8"))

        elif url.path == "/api/sos/report":
            client_ip = self.client_address[0]
            if self.is_rate_limited(client_ip):
                self.send_response(429)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error": "Too many requests. Please wait."}')
                return

            try:
                req = json.loads(body.decode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": f"Invalid JSON format: {str(e)}"}).encode("utf-8"))
                return

            # CRIT-4: Sanitize device_id strictly against path traversal
            raw_id = str(req.get("device_id", "phone"))
            sanitized_id = re.sub(r'[^A-Za-z0-9_-]', '', raw_id)[:64]
            device_id = sanitized_id if sanitized_id else "citizen_device"
            # H-13: Collision-resistant case ID
            case_id = f"CASE_{int(time.time() * 1000)}_{uuid.uuid4().hex[:6]}"

            # H-12: Strict coordinate validation
            parsed_lat = _validate_float(req.get("lat"), -90.0, 90.0)
            parsed_lng = _validate_float(req.get("lng"), -180.0, 180.0)

            # M-6: Error handling around int/float conversions
            raw_battery = req.get("battery", 100)
            try:
                parsed_battery = max(0, min(100, int(raw_battery)))
            except (ValueError, TypeError):
                parsed_battery = 100

            parsed_accuracy = _validate_float(req.get("accuracy"), 0.0, 100000.0) or -1.0

            try:
                parsed_members = max(1, min(50, int(req.get("member_count", 1))))
            except (ValueError, TypeError):
                parsed_members = 1

            # H-14: Enforce audio upload limits (<= 7MB base64, <= 5MB decoded)
            voice_audio_base64 = req.get("voice_audio_base64", "")
            has_audio = False
            audio_url = ""
            if voice_audio_base64:
                if len(voice_audio_base64) > 7 * 1024 * 1024:
                    self.send_response(413)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"error": "Voice audio exceeds maximum permitted size (7MB)"}')
                    return
                try:
                    decoded_bytes = base64.b64decode(voice_audio_base64)
                    if len(decoded_bytes) > 5 * 1024 * 1024:
                        self.send_response(413)
                        self.send_header("Content-Type", "application/json")
                        self.end_headers()
                        self.wfile.write(b'{"error": "Voice audio decoded size exceeds 5MB limit"}')
                        return

                    recordings_dir = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "recordings"))
                    os.makedirs(recordings_dir, exist_ok=True)
                    audio_filename = f"sos_{case_id}.m4a"
                    audio_path = os.path.realpath(os.path.join(recordings_dir, audio_filename))
                    if not audio_path.startswith(recordings_dir + os.sep):
                        self.send_response(400)
                        self.send_header("Content-Type", "application/json")
                        self.end_headers()
                        self.wfile.write(b'{"error": "Path traversal attempt detected in audio path"}')
                        return
                    with open(audio_path, "wb") as f:
                        f.write(decoded_bytes)
                    has_audio = True
                    audio_url = f"/api/sos/audio/{audio_filename}"
                    print(f"[VOICE RECORDING SAVED] {audio_filename} ({len(voice_audio_base64)} chars base64)")
                except Exception as ex:
                    print(f"Failed to save voice recording: {ex}")

            # H-11: Strict boolean parsing
            case_data = {
                "case_id": case_id,
                "device_id": device_id,
                "alert_id": str(req.get("alert_id", "-"))[:64],
                "lat": parsed_lat,
                "lng": parsed_lng,
                "accuracy": parsed_accuracy,
                "location_status": str(req.get("location_status", "LOCATION_AVAILABLE" if parsed_lat is not None else "LOCATION_UNAVAILABLE"))[:32],
                "battery": parsed_battery,
                "timestamp": int(req.get("timestamp", int(time.time() * 1000))),
                "status": "WAITING_RESCUE",
                "time_str": time.strftime("%H:%M:%S"),
                "contact_name": str(req.get("contact_name", ""))[:128],
                "contact_phone": str(req.get("contact_phone", ""))[:32],
                "member_count": parsed_members,
                "is_bedridden": _parse_bool(req.get("is_bedridden", False)),
                "is_elderly": _parse_bool(req.get("is_elderly", False)),
                "is_infant": _parse_bool(req.get("is_infant", False)),
                "urgent_needs": str(req.get("urgent_needs", ""))[:500],
                "urgent_note": str(req.get("urgent_note", ""))[:500],
                "has_audio": has_audio,
                "audio_url": audio_url
            }

            # M-18: Bounded retention on in-memory SOS_CASES
            if len(SOS_CASES) > 500:
                oldest_keys = list(SOS_CASES.keys())[:100]
                for k in oldest_keys:
                    SOS_CASES.pop(k, None)
            SOS_CASES[case_id] = case_data
            db_save_sos_case(case_data)

            bedridden_tag = " [ผู้ป่วยติดเตียง!]" if case_data["is_bedridden"] else ""
            voice_tag = " [มีข้อความเสียง]" if has_audio else ""
            loc_tag = f"{parsed_lat}, {parsed_lng}" if parsed_lat is not None else "ไม่ระบุพิกัด (GPS Unavailable)"
            print(f"\n[INCOMING SOS REPORT] จากเครื่อง: {device_id}{bedridden_tag}{voice_tag} | พิกัด: {loc_tag} | แบตเตอรี่: {parsed_battery}%")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "received", "case_id": case_id, "has_audio": has_audio}).encode("utf-8"))

        elif url.path in ("/api/sos/complete", "/api/sos/update_status"):
            if not self.is_authenticated():
                self.send_unauthorized()
                return

            try:
                req = json.loads(body.decode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": f"Invalid JSON format: {str(e)}"}).encode("utf-8"))
                return

            case_id = str(req.get("case_id", ""))
            default_status = "RESCUED_SAFE" if url.path == "/api/sos/complete" else "DISPATCHED"
            new_status = str(req.get("status", default_status))
            if case_id:
                if case_id in SOS_CASES:
                    SOS_CASES[case_id]["status"] = new_status
                db_update_case_status(case_id, new_status)
                print(f"[RESCUE STATUS UPDATED] เคส {case_id} -> {new_status}")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "updated", "case_id": case_id, "new_status": new_status}).encode("utf-8"))

        elif url.path == "/api/sos/reset":
            if not self.is_authenticated():
                self.send_unauthorized()
                return

            SOS_CASES.clear()
            db_clear_sos_cases()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "reset"}).encode("utf-8"))

        elif url.path == "/api/alerts/dispatch_real":
            if not self.is_authenticated():
                self.send_unauthorized()
                return

            tmd_alert = fetch_tmd_live_disaster()
            if not tmd_alert:
                self.send_response(503)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "unavailable",
                    "message": "ไม่มีรายงานภัยพิบัติแบบเรียลไทม์ในขณะนี้ (ยกเลิกการส่งอัตโนมัติเพื่อป้องกันการเตือนภัยเท็จ)"
                }, ensure_ascii=False).encode("utf-8"))
                return
            
            fcm_res = FCMDispatcher.dispatch_topic(alert=tmd_alert, topic="emergency_alerts", is_muted=True)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "dispatched",
                "alert": {
                    "alert_id": tmd_alert.alert_id,
                    "title": tmd_alert.title,
                    "instruction": tmd_alert.instruction,
                    "severity": tmd_alert.severity,
                    "center_lat": tmd_alert.center_lat,
                    "center_lng": tmd_alert.center_lng
                },
                "result": fcm_res
            }).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def run_web_gateway():
    init_db()
    global SOS_CASES
    SOS_CASES = db_get_all_sos_cases()
    server = ThreadedHTTPServer((HOST, PORT), GatewayHandler)
    print(f"[READY] RescueAlert 2-Way Lifeline Gateway running at http://{HOST}:{PORT}")
    print(f"[AUTH] Master API Key configured.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Gateway.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_web_gateway()
