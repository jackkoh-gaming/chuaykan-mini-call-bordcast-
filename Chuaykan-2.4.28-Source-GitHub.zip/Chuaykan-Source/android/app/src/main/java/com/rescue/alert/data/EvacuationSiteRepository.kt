package com.rescue.alert.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.rescue.alert.model.EvacuationSite
import com.rescue.alert.util.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

/** EOC-supplied sites, an offline cache, and full-snapshot HTTP sync. */
class EvacuationSiteRepository private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("evacuation_sites_prefs", Context.MODE_PRIVATE)
    private val sitesMap = mutableMapOf<String, EvacuationSite>()
    private val listeners = CopyOnWriteArraySet<(List<EvacuationSite>) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val syncing = AtomicBoolean(false)
    private var meshRevision = 0L

    init {
        // Load only the cache version populated from EOC responses.
        val saved = prefs.getString(CACHE_KEY, null)
        if (saved != null) {
            try {
                parseSites(JSONArray(saved)).filter { it.isActive }.forEach { sitesMap[it.siteId] = it }
            } catch (e: Exception) {
                Log.w(TAG, "Invalid evacuation cache", e)
            }
        }
    }

    fun addListener(listener: (List<EvacuationSite>) -> Unit) { listeners.add(listener) }
    fun removeListener(listener: (List<EvacuationSite>) -> Unit) { listeners.remove(listener) }

    private fun notifyListeners() {
        mainHandler.post {
            val snapshot = getAllActiveSites()
            listeners.forEach { it(snapshot) }
        }
    }

    private fun persistSitesLocked() {
        val arr = JSONArray()
        sitesMap.values.forEach { arr.put(it.toJsonObject()) }
        prefs.edit().putString(CACHE_KEY, arr.toString()).remove("saved_sites_json").apply()
    }

    fun getAllActiveSites(): List<EvacuationSite> = synchronized(sitesMap) {
        sitesMap.values.filter { it.isActive }
    }

    fun upsertSite(site: EvacuationSite) {
        synchronized(sitesMap) {
            meshRevision++
            if (site.isActive) sitesMap[site.siteId] = site else sitesMap.remove(site.siteId)
            persistSitesLocked()
        }
        notifyListeners()
    }

    fun processMeshSiteJson(jsonString: String): Boolean = try {
        upsertSite(EvacuationSite.fromJsonObject(JSONObject(jsonString)))
        true
    } catch (e: Exception) {
        Log.w(TAG, "Invalid mesh evacuation site", e)
        false
    }

    suspend fun syncFromGateway(gatewayUrl: String = AppSettings.getGatewayBaseUrl(context)): Boolean =
        withContext(Dispatchers.IO) { syncSnapshot(gatewayUrl) }

    fun syncFromGatewayAsync(gatewayUrl: String = AppSettings.getGatewayBaseUrl(context)) {
        Thread({ syncSnapshot(gatewayUrl) }, "evacuation-sync").start()
    }

    private fun syncSnapshot(gatewayUrl: String): Boolean {
        if (!syncing.compareAndSet(false, true)) return false
        var connection: HttpURLConnection? = null
        try {
            val revision = synchronized(sitesMap) { meshRevision }
            val configuredGateway = AppSettings.getGatewayBaseUrl(context)
            connection = com.rescue.alert.network.SecureGateway.open(context, URL("${gatewayUrl.trimEnd('/')}/api/evacuation/sites"))
            connection.apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
            }
            check(connection.responseCode == 200) { "HTTP ${connection.responseCode}" }
            val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return applyGatewaySnapshot(JSONObject(response), revision, configuredGateway)
        } catch (e: Exception) {
            Log.d(TAG, "EOC evacuation sync unavailable; retaining cache: ${e.message}")
            return false
        } finally {
            connection?.disconnect()
            syncing.set(false)
        }
    }

    internal fun applyGatewaySnapshot(response: JSONObject, revision: Long, gateway: String): Boolean {
        val incoming = parseSites(response.getJSONArray("sites")).filter { it.isActive }.associateBy { it.siteId }
        synchronized(sitesMap) {
            // A full empty snapshot means deletion; failed/malformed requests never enter here.
            if (revision != meshRevision || gateway != AppSettings.getGatewayBaseUrl(context)) return false
            if (sitesMap == incoming) return true
            sitesMap.clear()
            sitesMap.putAll(incoming)
            persistSitesLocked()
        }
        notifyListeners()
        return true
    }

    private fun parseSites(array: JSONArray): List<EvacuationSite> =
        (0 until array.length()).map { EvacuationSite.fromJsonObject(array.getJSONObject(it)) }

    fun getSitesSortedByDistance(userLat: Double, userLng: Double, filterType: String? = null): List<Pair<EvacuationSite, Double>> {
        val sites = getAllActiveSites().filter {
            filterType == null || filterType == "ALL" || it.siteType == filterType ||
                (filterType == "SHELTER" && it.siteType == "RELIEF_CENTER")
        }
        if (!hasLocation(userLat, userLng)) return sites.sortedBy { it.name }.map { it to Double.NaN }
        return sites.map { it to calculateDistanceKm(userLat, userLng, it.latitude, it.longitude) }.sortedBy { it.second }
    }

    fun getNearestShelter(userLat: Double, userLng: Double): Pair<EvacuationSite, Double>? =
        if (hasLocation(userLat, userLng)) getSitesSortedByDistance(userLat, userLng, "SHELTER").firstOrNull() else null

    fun getNearestParking(userLat: Double, userLng: Double): Pair<EvacuationSite, Double>? =
        if (hasLocation(userLat, userLng)) getSitesSortedByDistance(userLat, userLng, "PARKING").firstOrNull() else null

    companion object {
        private const val TAG = "EvacuationSiteRepo"
        private const val CACHE_KEY = "verified_sites_json_v2"
        @Volatile private var instance: EvacuationSiteRepository? = null

        fun getInstance(context: Context): EvacuationSiteRepository = instance ?: synchronized(this) {
            instance ?: EvacuationSiteRepository(context.applicationContext).also { instance = it }
        }

        fun hasLocation(lat: Double, lng: Double): Boolean =
            lat.isFinite() && lng.isFinite() && lat in -90.0..90.0 && lng in -180.0..180.0 && (lat != 0.0 || lng != 0.0)

        fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = (sin(dLat / 2).pow(2.0) + cos(Math.toRadians(lat1)) *
                cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2.0)).coerceIn(0.0, 1.0)
            return round(6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a)) * 10.0) / 10.0
        }
    }
}
