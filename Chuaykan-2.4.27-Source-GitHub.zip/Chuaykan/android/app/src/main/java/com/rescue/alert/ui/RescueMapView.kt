package com.rescue.alert.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Interactive Google Maps View for RescueAlert.
 * Embeds Google Maps road tile layer (with Thai language street labels) and Leaflet map engine.
 * Displays the user's real GPS coordinates with the iconic Google Maps blue dot,
 * pulse accuracy aura, and approaching rescue lifeline units.
 */
class RescueMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val webView: WebView = WebView(context)
    private var isMapLoaded: Boolean = false
    private var pendingSites: List<com.rescue.alert.model.EvacuationSite> = emptyList()
    private var pendingFocus: Triple<Double, Double, Int>? = null
    private var pendingLat: Double? = null
    private var pendingLng: Double? = null
    private var pendingAccuracy: Float = 25f

    init {
        initWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebView() {
        webView.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun requestDisallowIntercept(disallow: Boolean) {
                Handler(Looper.getMainLooper()).post {
                    parent?.requestDisallowInterceptTouchEvent(disallow)
                }
            }
        }, "AndroidInterface")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "tel") {
                    try {
                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, uri))
                    } catch (_: android.content.ActivityNotFoundException) { }
                    return true
                }
                return uri.scheme != "file"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                isMapLoaded = true
                setEvacuationSites(pendingSites)
                pendingFocus?.let { focusLocation(it.first, it.second, it.third) }
                pendingLat?.let { lat ->
                    pendingLng?.let { lng ->
                        updateMarkerInJs(lat, lng, pendingAccuracy)
                    }
                }
            }
        }

        webView.loadUrl("file:///android_asset/map.html")
        addView(webView)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
        when (ev?.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onInterceptTouchEvent(ev)
    }

    fun setLocationPermissionGranted(
        granted: Boolean,
        lat: Double = Double.NaN,
        lng: Double = Double.NaN,
        accuracy: Float = -1f
    ) {
        if (!granted || !com.rescue.alert.data.EvacuationSiteRepository.hasLocation(lat, lng)) {
            clearUserLocation()
            return
        }
        pendingLat = lat
        pendingLng = lng
        pendingAccuracy = accuracy

        if (isMapLoaded) {
            updateMarkerInJs(lat, lng, accuracy)
        }
    }

    fun clearUserLocation() {
        pendingLat = null
        pendingLng = null
        post {
            webView.evaluateJavascript("clearUserLocation();", null)
        }
    }

    private fun updateMarkerInJs(lat: Double, lng: Double, accuracy: Float) {
        post {
            webView.evaluateJavascript("setUserLocation($lat, $lng, $accuracy);", null)
            setEvacuationSites(pendingSites)
        }
    }

    fun recenter() {
        post {
            webView.evaluateJavascript("recenterUser();", null)
        }
    }

    fun zoomIn() {
        post {
            webView.evaluateJavascript("zoomInMap();", null)
        }
    }

    fun zoomOut() {
        post {
            webView.evaluateJavascript("zoomOutMap();", null)
        }
    }

    fun setDangerZone(lat: Double, lng: Double, radiusKm: Double) {
        post {
            webView.evaluateJavascript("setDangerZone($lat, $lng, ${radiusKm * 1000});", null)
        }
    }

    fun clearDangerZone() {
        post {
            webView.evaluateJavascript("clearDangerZone();", null)
        }
    }

    fun showApproachingOfficer(lat: Double, lng: Double, title: String, distanceMeters: Int) {
        post {
            val safeTitle = org.json.JSONObject.quote(title)
            webView.evaluateJavascript("showApproachingOfficer($lat, $lng, $safeTitle, $distanceMeters);", null)
        }
    }

    fun clearApproachingOfficer() {
        post {
            webView.evaluateJavascript("clearApproachingOfficer();", null)
        }
    }

    fun setEvacuationSites(sites: List<com.rescue.alert.model.EvacuationSite>) {
        pendingSites = sites.toList()
        if (!isMapLoaded) return
        post {
            val jsonArr = org.json.JSONArray()
            sites.forEach { jsonArr.put(it.toJsonObject()) }
            webView.evaluateJavascript("setEvacuationSites($jsonArr);", null)
        }
    }

    fun clearEvacuationSites() {
        setEvacuationSites(emptyList())
    }

    fun focusLocation(lat: Double, lng: Double, zoom: Int = 16) {
        pendingFocus = Triple(lat, lng, zoom)
        if (!isMapLoaded) return
        post {
            webView.evaluateJavascript("map.setView([$lat, $lng], $zoom, { animate: true });", null)
        }
    }

    fun destroy() {
        isMapLoaded = false
        try {
            webView.stopLoading()
            webView.clearHistory()
            removeAllViews()
            webView.destroy()
        } catch (e: Exception) {}
    }
}
