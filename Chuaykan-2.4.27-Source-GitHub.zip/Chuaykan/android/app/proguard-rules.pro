-keep class com.google.firebase.messaging.** { *; }
-keep class com.rescue.alert.model.** { *; }
-keep class com.rescue.alert.engine.** { *; }
-keep class com.rescue.alert.security.** { *; }
-keep class com.rescue.alert.ui.RescueMapView { *; }
-keepclassmembers class **.R$* {
    public static <fields>;
}

-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Standard Android ProGuard rules
-dontwarn android.support.**
-keep class android.support.** { *; }
-keep class androidx.** { *; }
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
