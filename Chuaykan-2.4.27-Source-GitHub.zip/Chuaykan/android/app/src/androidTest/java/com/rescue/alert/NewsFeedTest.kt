package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.data.DisasterNewsRepository as News
import com.rescue.alert.model.DisasterNewsItem
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class NewsFeedTest {
    @Test fun preservesSourceTextAndUsesActualSourcePage() {
        val root = JSONObject("""{"fact_cb":[{"alert_id":"CB-test","date_id":"D-20261001","time":"20:23","title":"ประกาศต้นทาง","message_id":"M1","sender_id":"S1"}],"dim_message":[{"message_id":"M1","message_th":"เนื้อหาจริงจากต้นทาง"}],"dim_sender":[{"sender_id":"S1","sender_name":"กรมอุตุนิยมวิทยา"}]}""")
        val item = News.parseBulletins(root).single()
        assertEquals("ประกาศต้นทาง", item.title)
        assertEquals("เนื้อหาจริงจากต้นทาง", item.details)
        assertEquals("TMD", item.sourceCode)
        assertEquals(News.SOURCE_PAGE, item.webUrl)
        assertFalse("Snapshot records must not claim live push", item.isLive)
    }
    @Test fun successfulEmptyFeedContainsNoInventedNews() {
        assertTrue(News.parseBulletins(JSONObject("{\"fact_cb\":[]}")).isEmpty())
    }
    @Test fun brokenSchemaIsNotSuccessfulEmptyFeed() {
        try { News.parseBulletins(JSONObject("{}")); fail("Missing official records accepted") }
        catch (_: IllegalArgumentException) {}
    }
    @Test fun realPhoneNewsMatchesOfficialRecordAndConcurrentRefresh() {
        val latch = CountDownLatch(2)
        var first = emptyList<DisasterNewsItem>()
        var second = emptyList<DisasterNewsItem>()
        News.getNews(true) { first = it; latch.countDown() }
        News.getNews(true) { second = it; latch.countDown() }
        assertTrue("News callbacks timed out", latch.await(90, TimeUnit.SECONDS))
        assertNull("Real upstream fetch failed", News.lastError)
        assertEquals(first, News.recentOnly(first))
        assertEquals(first, second)
        val raw = URL(News.SOURCE_PAGE + "data/data.json").openConnection().apply {
            connectTimeout = 10000; readTimeout = 15000
        }.getInputStream().bufferedReader().use { JSONObject(it.readText()) }
        val original = News.parseBulletins(raw).associateBy { it.id }
        val officialToday = first.filter { original.containsKey(it.id) }
        for (item in officialToday) {
            assertEquals(original[item.id]?.title, item.title)
            assertEquals(original[item.id]?.details, item.details)
            assertEquals(original[item.id]?.dateStr, item.dateStr)
            assertEquals(News.SOURCE_PAGE, item.webUrl)
        }
        assertEquals(News.recentOnly(original.values.toList()).map { it.id }.toSet(), officialToday.map { it.id }.toSet())
        val page = URL(News.SOURCE_PAGE).openConnection().apply {
            connectTimeout = 10000; readTimeout = 15000
        }.getInputStream().bufferedReader().use { it.readText() }
        assertTrue(page.contains("fact_cb") || page.contains("Cell Broadcast"))
    }
    private fun utc(value: String): Long = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.parse(value)!!.time

    @Test fun threeDaysIncludeBothPreviousDatesAndExcludeOlderFutureOrInvalidDates() {
        val sample = DisasterNewsItem("test", "source", "DDPM", "title", "20261001 12:00", "", "", "", News.SOURCE_PAGE)
        val all = listOf(sample, sample.copy(id="yesterday", dateStr="20260930 23:59"),
            sample.copy(id="first", dateStr="20260929 00:00"), sample.copy(id="old", dateStr="20260928 23:59"),
            sample.copy(id="future", dateStr="20261002 00:00"), sample.copy(id="unknown", dateStr=""),
            sample.copy(id="invalid", dateStr="20260931 12:00"))
        assertEquals(listOf("test", "yesterday", "first"), News.recentOnly(all, utc("2026-10-01 16:59")).map { it.id })
    }
    @Test fun bangkokMidnightRemovesOnlyExpiredDayFromCachedSnapshot() {
        val old = DisasterNewsItem("old", "source", "TMD", "title", "20260929 23:59", "", "", "", News.SOURCE_PAGE)
        val recent = old.copy(id="recent", dateStr="20261001 23:59")
        assertEquals("20261001", News.currentDayKey(utc("2026-10-01 16:59")))
        assertEquals("20261002", News.currentDayKey(utc("2026-10-01 17:00")))
        assertEquals(listOf(old, recent), News.recentOnly(listOf(old, recent), utc("2026-10-01 16:59")))
        assertEquals(listOf(recent), News.recentOnly(listOf(old, recent), utc("2026-10-01 17:00")))
        assertTrue(News.recentOnly(emptyList(), utc("2026-10-01 17:00")).isEmpty())
    }

    @Test fun threeDaysCrossYearBoundaryRegardlessOfDeviceTimezone() {
        val originalZone = java.util.TimeZone.getDefault()
        try {
            java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("America/Los_Angeles"))
            val sample = DisasterNewsItem("today", "source", "DDPM", "title", "20270101 00:00", "", "", "", News.SOURCE_PAGE)
            val all = listOf(sample, sample.copy(id="previous", dateStr="20261231 23:59"),
                sample.copy(id="first", dateStr="20261230 00:00"), sample.copy(id="old", dateStr="20261229 23:59"))
            assertEquals(listOf("today", "previous", "first"), News.recentOnly(all, utc("2026-12-31 17:00")).map { it.id })
        } finally { java.util.TimeZone.setDefault(originalZone) }
    }

}
