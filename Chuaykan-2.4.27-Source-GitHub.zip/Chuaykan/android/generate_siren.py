#!/usr/bin/env python3
"""Generate emergency siren WAV file for RescueAlert app."""
import wave, struct, math, os

SAMPLE_RATE = 22050
DURATION = 3  # seconds
FREQ_LOW = 800
FREQ_HIGH = 1200

output_dir = os.path.join(os.path.dirname(__file__), "app/src/main/res/raw")
os.makedirs(output_dir, exist_ok=True)
output_path = os.path.join(output_dir, "siren_critical.wav")

samples = []
total_samples = SAMPLE_RATE * DURATION
for i in range(total_samples):
    t = i / SAMPLE_RATE
    # Sweep frequency up and down (siren effect)
    sweep = (math.sin(2 * math.pi * t / DURATION * 2) + 1) / 2  # 0 to 1, 2 cycles
    freq = FREQ_LOW + (FREQ_HIGH - FREQ_LOW) * sweep
    sample = math.sin(2 * math.pi * freq * t)
    # Add slight distortion for urgency
    sample = max(-1, min(1, sample * 1.2))
    samples.append(int(sample * 32000))

with wave.open(output_path, 'w') as wav:
    wav.setnchannels(1)
    wav.setsampwidth(2)
    wav.setframerate(SAMPLE_RATE)
    for s in samples:
        wav.writeframes(struct.pack('<h', s))

print(f"Generated siren: {output_path} ({os.path.getsize(output_path)} bytes)")
