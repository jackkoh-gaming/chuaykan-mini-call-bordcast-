#!/usr/bin/env python3
"""
Thailand Disaster Early Warning & Emergency Operations Center (EOC)
Desktop Command Center Application
Root Entrypoint
"""
from __future__ import annotations
import os
import sys
from pathlib import Path

# Chromium & QtWebEngine environment flags
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--no-sandbox --disable-dev-shm-usage")
os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

def main() -> int:
    from src.gui.app import main as gui_main
    return gui_main()

if __name__ == "__main__":
    sys.exit(main())
