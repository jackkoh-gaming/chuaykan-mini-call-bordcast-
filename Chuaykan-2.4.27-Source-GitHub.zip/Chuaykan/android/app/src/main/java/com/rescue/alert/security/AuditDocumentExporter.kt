package com.rescue.alert.security

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.rescue.alert.BuildConfig
import com.rescue.alert.model.CitizenEmergencyProfile
import com.rescue.alert.model.DisasterStateManager
import com.rescue.alert.util.AppSettings
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AuditDocumentExporter:
 * Generates and exports:
 * 1. สรุปข้อมูลทางเทคนิคและความโปร่งใสของระบบ (Self-Generated Technical & Public Transparency Summary)
 * 2. บันทึกข้อมูลการทำงานและความปลอดภัยเชิงเทคนิค (Self-Generated Technical Audit Log, ECDSA P-256 Status, Local Checksum)
 */
object AuditDocumentExporter {

    private fun getTimestampStr(): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun getFormattedDateStr(): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy HH:mm:ss", Locale("th", "TH"))
        return sdf.format(Date())
    }

    fun sha256(text: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(text.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "HASH_ERROR"
        }
    }

    fun termsDisclosure(): String = """
ข้อตกลงการใช้งาน • ฉบับปรับปรุง 2 ตุลาคม 2569

1. แอพสนับสนุนข่าวภัยพิบัติ การแจ้งเหตุ และการประสานช่วยเหลือ ข่าวไม่ได้ยืนยันว่าทีมกู้ภัยรับเคสหรือกำลังเดินทาง สถานะส่งสำเร็จและได้รับการช่วยเหลือขึ้นกับการตอบกลับของระบบเจ้าหน้าที่
2. ข่าว ปภ. และกรมอุตุฯ แสดงไม่เกิน 3 วันปฏิทินตามเวลาไทย (วันนี้และ 2 วันก่อนหน้า) ตรวจข่าวทุก 10 วินาทีเมื่อเปิดหน้าข่าว ความสดขึ้นกับต้นทางและการเชื่อมต่อ ไม่ใช่การเผยแพร่ข่าวใหม่ทุก 10 วินาที
3. วิทยุเป็นเสียงสตรีมจากสถานีที่เลือก ต้องมีอินเทอร์เน็ตและเสียงสื่อของเครื่อง ไม่ใช่เครื่องรับ AM/FM ที่ทำงานได้โดยไม่มีอินเทอร์เน็ต
4. ใช้ SOS เพื่อขอความช่วยเหลือตามจริง ปุ่มขอช่วยเหลือทั่วไปส่งข้อมูลกู้ชีพโดยไม่ต้องถ่ายรูป แยกจากคิวผู้ป่วยวิกฤติ ห้ามแจ้งเหตุเท็จหรือก่อกวน
5. โครงการไม่แสวงหาผลกำไร ไม่มีโฆษณาหรือระบบซื้อบริการในแอพ ค่าอินเทอร์เน็ตและบริการของเครือข่ายเป็นไปตามผู้ให้บริการ
6. ผู้พัฒนาต้นฉบับไม่ได้ตรวจรับรองหรือรับผิดชอบการดัดแปลงและการแจกจ่ายโดยบุคคลอื่นนอกเหนือจากรุ่นที่จัดทำ ข้อความนี้ไม่ตัดสิทธิหรือหน้าที่ที่กฎหมายกำหนด

ผู้พัฒนา ตรวจสอบ และแก้ไข: จิรายุ โคว
เครื่องมือพัฒนา AI Agent: Google Antigravity, Gemini 3.8 Flash, Claude Opus 4.6, OpenAI Codex, GPT 6-Astra, GPT 6.1-Sol (รายชื่อตามข้อมูลที่ผู้พัฒนาระบุ)
    """.trimIndent()

    fun privacyDisclosure(): String = """
ข้อมูลส่วนบุคคลและการใช้งานข้อมูล

กฎหมายที่เกี่ยวข้อง: พ.ร.บ.คุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 (ตรวจตัวบท 2 ตุลาคม 2569)
• มาตรา 22–23: เก็บเท่าที่จำเป็น และแจ้งวัตถุประสงค์ ข้อมูลที่เก็บ ระยะเก็บ ผู้รับข้อมูล ช่องทางติดต่อผู้ควบคุม และสิทธิของเจ้าของข้อมูล
• มาตรา 24(2): ข้อมูลทั่วไปอาจใช้ฐานจำเป็นเพื่อป้องกันหรือระงับอันตรายต่อชีวิต ร่างกาย หรือสุขภาพ
• มาตรา 26: ข้อมูลสุขภาพและความพิการต้องมีความยินยอมโดยชัดแจ้งหรือเข้าเงื่อนไขยกเว้น เช่น มาตรา 26(1) เพื่อป้องกันหรือระงับอันตรายข้างต้นเมื่อเจ้าของข้อมูลไม่สามารถให้ความยินยอมได้ ไม่ใช่ยกเว้นทุกข้อมูลเพียงเพราะเป็นงานกู้ภัย
• มาตรา 30–36: สิทธิขอเข้าถึง โอน คัดค้าน ลบ ระงับใช้ และแก้ไขข้อมูลตามเงื่อนไขของแต่ละมาตรา
• มาตรา 37: ผู้ควบคุมต้องรักษาความมั่นคงปลอดภัยและจัดการลบข้อมูลตามเงื่อนไขกฎหมาย
การอนุญาตสิทธิ์ Android หรือเปิดอ่านเอกสารไม่ใช่ความยินยอม PDPA โดยอัตโนมัติ ผู้ดำเนินงานที่กำหนดวัตถุประสงค์และวิธีใช้ข้อมูลต้องประเมินฐานกฎหมาย ระบุผู้ควบคุม/ช่องทางติดต่อจริงและระยะเก็บให้ผู้ใช้ทราบ เอกสารนี้ยังไม่ได้ระบุรายละเอียดดังกล่าวครบ และไม่ใช่การรับรองว่าระบบปฏิบัติตามกฎหมายครบถ้วน
ตัวบทจากกรมประชาสัมพันธ์: https://law.prd.go.th/th/content/page/index/id/234607

• โปรไฟล์ในเครื่อง: ชื่อ เบอร์ติดต่อ จำนวนสมาชิก ผู้ติดเตียง ผู้สูงอายุ เด็กเล็ก และความต้องการเร่งด่วนหรือข้อมูลสุขภาพที่ผู้ใช้กรอก ใช้เพื่อประสานช่วยเหลือ เก็บในพื้นที่ส่วนตัวของแอพ ไม่ใช่คำรับรองว่าเข้ารหัสทุกไฟล์
• GPS: ใช้ประเมินพื้นที่แจ้งเตือนและพิกัดแจ้งเหตุ เมื่ออนุญาตสิทธิ์ แอพมีบริการติดตามตำแหน่งเพื่อประเมินพื้นที่ภัย ข้อมูลตำแหน่งอาจรวมในแพ็กเก็ตแจ้งเหตุหรือสื่อสารกับทีมกู้ภัย
• Bluetooth: เมื่ออนุญาตสิทธิ์ เครื่องประกาศรหัสโหนดและตรวจหาอุปกรณ์ที่ใช้โปรโตคอลแอพเดียวกัน เชื่อมต่ออัตโนมัติโดยไม่ต้องกดจับคู่ อุปกรณ์แอพใกล้เคียงอาจเป็นผู้รับหรือส่งต่อแพ็กเก็ต ไม่รับรองการเข้ารหัส Bluetooth แบบไม่จับคู่หรือยืนยันตัวบุคคลจาก UUID เพียงอย่างเดียว
• SOS: ส่งโปรไฟล์ที่กรอก พิกัด และข้อมูลแจ้งเหตุไปยังระบบเจ้าหน้าที่ผ่านช่องทางที่เชื่อมต่อ การแจ้งเหตุบางประเภทหรือการสนทนาใช้ไมโครโฟนตามสิทธิ์ที่อนุญาต ปุ่มขอช่วยเหลือทั่วไปไม่ต้องถ่ายรูป
• บริการภายนอก: Firebase Cloud Messaging ใช้รับข้อความแจ้งเตือน Google Play Services ใช้ตำแหน่ง และผู้ให้บริการข่าว แผนที่ วิทยุ รับคำขอเครือข่าย เช่น IP และข้อมูลทางเทคนิคที่จำเป็น ไม่ควรเข้าใจว่าทุกข้อมูลอยู่ในเครื่องเท่านั้น
• การเก็บรักษา: โปรไฟล์อยู่จนผู้ใช้แก้ไขข้อมูลที่บันทึกไว้หรือล้างข้อมูลแอพ คิวแจ้งเหตุอาจเก็บเพื่อส่งใหม่เมื่อเชื่อมต่อสำเร็จ การล้างในมือถือไม่ลบสำเนาที่เจ้าหน้าที่หรือผู้รับได้ไปแล้ว แอพไม่มีนโยบายลบทุกข้อมูลตามจำนวนวันเดียวกัน
• การควบคุม: แก้ไขโปรไฟล์ผ่านหน้าโปรไฟล์ และจัดการสิทธิ์ตำแหน่ง ไมโครโฟน Bluetooth หรือข้อมูลแอพในตั้งค่า Android การปิดสิทธิ์อาจทำให้ฟังก์ชันช่วยเหลือที่เกี่ยวข้องใช้งานไม่ได้
• หากต้องการตรวจ แก้ไข หรือลบข้อมูลที่ส่งถึงหน่วยช่วยเหลือ ให้ติดต่อหน่วยที่รับเคส เอกสารนี้แจ้งพฤติกรรมของแอพ ไม่ใช่ผลรับรองการปฏิบัติตามกฎหมายโดยหน่วยงานภายนอก
• เอกสารตรวจสอบที่ส่งออกไม่ใส่ชื่อ เบอร์โทร ข้อมูลสุขภาพ พิกัดจริง หมายเลขประจำเครื่อง โทเคน หรือรหัสเชื่อมต่อ ผู้ใช้เลือกบันทึกและแชร์เอง
    """.trimIndent()

    fun auditDisclosure(): String = """
ข้อมูลที่ตรวจสอบได้

1. ข่าว ปภ.: https://academicndwc.github.io/CBS-DashBoard/ — ใช้รหัสประกาศและข้อความต้นทาง ลิงก์แดชบอร์ดเป็นหน้ารวม ไม่ใช่ลิงก์เฉพาะข่าวที่ต้นทางไม่ได้ให้
2. ข่าวกรมอุตุฯ: https://www5.tmd.go.th/api/xml/CAP — ใช้วันเผยแพร่และลิงก์เอกสาร CAP ของแต่ละประกาศ
3. วิทยุกรมประชาสัมพันธ์: https://prdee.prd.go.th/radio — รายชื่อสถานีและสตรีมสดขึ้นกับต้นทาง ไม่กำหนดทุกสถานีเป็นความถี่เดียว
4. ไม่มี Google Alert ในหน้าข่าวปัจจุบัน ข้อมูลจากแหล่งอื่นในฟังก์ชันเขื่อน/แผนที่ไม่ใช่ข่าวอัตโนมัติของทุกหน่วยงาน
5. ข้อความ Gateway ที่มีลายมือชื่อใช้ SHA256withECDSA ตามเส้นทางตรวจรับ ข่าวที่อ่านผ่าน HTTPS ไม่ใช่เอกสาร ECDSA ที่รับรองโดยรัฐบาล การมีตัวตรวจลายมือชื่อไม่ได้ยืนยันว่าข้อความหนึ่งผ่านการตรวจแล้ว
6. การเชื่อมต่อระบบเจ้าหน้าที่ผ่าน HTTPS ใช้การตรวจใบรับรองและกุญแจเชื่อมต่อ ไม่ใช่คำรับรองว่าทุกช่องทางสื่อสารไม่มีโอกาสถูกดักจับ
7. เอกสาร TXT เป็นสรุปจากแอพ ไม่ใช่ใบรับรองภาครัฐหรือหลักฐานประวัติเหตุการณ์ทั้งหมด ค่า SHA-256 ช่วยเปรียบเทียบไฟล์ ไม่ได้ป้องกันผู้แก้ไฟล์คำนวณค่าใหม่
8. ไม่แสดงผลสแกนของแอพอื่นหรือไฟล์เครื่องมือผู้พัฒนาที่ไม่อยู่ในแอพ เอกสารนี้ไม่ใช่ผลสแกนไวรัสและไม่รับรองว่าไม่มีไวรัสทุกชนิด ตรวจไฟล์ APK ที่แจกจ่ายด้วยเครื่องมือของผู้ตรวจได้
    """.trimIndent()

    private fun apkSha256(context: Context): String = try {
        val digest = MessageDigest.getInstance("SHA-256")
        File(context.applicationInfo.sourceDir).inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { "ไม่สามารถอ่านไฟล์ APK เพื่อคำนวณ SHA-256 ได้" }

    fun buildGovernmentAuditSpecification(context: Context): String = """
เอกสารข้อตกลง ความเป็นส่วนตัว และความโปร่งใสจากแอพ
ชื่อแอพ: ช่วยกัน (มินิ คอลบอร์ดเคส) / Chuaykan (Mini Call Broadcast)
แพ็กเกจ: ${context.packageName}
เวอร์ชัน: ${BuildConfig.VERSION_NAME} (versionCode: ${BuildConfig.VERSION_CODE})
วันที่สร้างเอกสาร: ${getFormattedDateStr()}
SHA-256 ของ APK หลักที่ติดตั้ง (ไม่รวม split APK): ${apkSha256(context)}

${termsDisclosure()}

${privacyDisclosure()}

${auditDisclosure()}
    """.trimIndent()

    fun buildPoliceAuditLog(context: Context): String {
        val body = """
ภาพรวมสถานะแอพ ณ เวลาส่งออก • ไม่ใช่ประวัติเหตุการณ์หรือเอกสารรับรองตำรวจ
ชื่อแอพ: ช่วยกัน (มินิ คอลบอร์ดเคส) / Chuaykan (Mini Call Broadcast)
แพ็กเกจ: ${context.packageName}
เวอร์ชัน: ${BuildConfig.VERSION_NAME} (versionCode: ${BuildConfig.VERSION_CODE})
วันที่สร้าง: ${getFormattedDateStr()}
โปรไฟล์ในหน่วยความจำแอพ: ${if (CitizenEmergencyProfile.isSavedInRam) "มีข้อมูล" else "ไม่มีข้อมูล"}
สถานะภัยในแอพ: ${if (DisasterStateManager.isDisasterActive(context)) "มีสถานะภัย" else "โหมดปกติ"}
ประหยัดพลังงาน: ${AppSettings.isPowerSavingActive(context)}
SHA-256 ของ APK หลักที่ติดตั้ง: ${apkSha256(context)}
ไม่มีการดึงพิกัดหรือข้อมูลระบุตัวบุคคลเพื่อสร้างเอกสารนี้
ไม่ได้ตรวจข้อความ ECDSA หรือสแกนไวรัส ณ เวลาส่งออก
${auditDisclosure()}
        """.trimIndent()
        return "$body\n\nSHA-256 ของข้อความ UTF-8 ก่อนบรรทัดนี้: ${sha256(body)}"
    }

    private fun isLowRamDevice(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        return am?.isLowRamDevice ?: false
    }

    /**
     * Export the Government Audit Specification:
     * Saves to Downloads folder and opens Share Chooser
     */
    fun exportGovernmentAuditDoc(context: Context): Boolean {
        val fileName = "Chuaykan_MiniCallBroadcast_Terms_Privacy_Transparency.txt"
        val content = buildGovernmentAuditSpecification(context)
        val saved = saveToDownloads(context, fileName, content)
        shareFile(
            context = context,
            fileName = fileName,
            content = content,
            subject = "เอกสารข้อตกลงและความโปร่งใส: ช่วยกัน (มินิ คอลบอร์ดเคส) / Chuaykan (Mini Call Broadcast)"
        )
        if (saved) {
            Toast.makeText(
                context,
                "บันทึกเอกสารลงโฟลเดอร์ Download สำเร็จ:\n$fileName",
                Toast.LENGTH_LONG
            ).show()
        }
        return saved
    }

    /**
     * Export the Police Audit Log:
     * Saves to Downloads folder and opens Share Chooser
     */
    fun exportPoliceAuditLog(context: Context): Boolean {
        val timeTag = getTimestampStr()
        val fileName = "Chuaykan_MiniCallBroadcast_Technical_Status_$timeTag.txt"
        val content = buildPoliceAuditLog(context)
        val saved = saveToDownloads(context, fileName, content)
        shareFile(
            context = context,
            fileName = fileName,
            content = content,
            subject = "ภาพรวมสถานะแอพสำหรับตรวจสอบ: ช่วยกัน (มินิ คอลบอร์ดเคส) / Chuaykan (Mini Call Broadcast)"
        )
        if (saved) {
            Toast.makeText(
                context,
                "บันทึกภาพรวมสถานะแอพสำเร็จ:\n$fileName",
                Toast.LENGTH_LONG
            ).show()
        }
        return saved
    }

    private fun saveToDownloads(context: Context, fileName: String, content: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    val stream = resolver.openOutputStream(uri) ?: throw java.io.IOException("เปิดไฟล์ดาวน์โหลดไม่ได้")
                    stream.use { os ->
                        os.write(content.toByteArray(Charsets.UTF_8))
                    }
                    true
                } else {
                    false
                }
            } else {
                val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: File(context.filesDir, "downloads")
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val destFile = File(downloadsDir, fileName)
                destFile.writeText(content, Charsets.UTF_8)
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun shareFile(context: Context, fileName: String, content: String, subject: String) {
        try {
            val cacheDir = File(context.cacheDir, "exports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val file = File(cacheDir, fileName)
            file.writeText(content, Charsets.UTF_8)

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, "$subject\n\nเอกสารสร้างจากแอพ ไม่ใช่ผลรับรองจากหน่วยงานภายนอก โปรดตรวจขอบเขตและค่า SHA-256 ในไฟล์แนบ")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "ส่งออกหรือส่งต่อเอกสาร")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "เกิดข้อผิดพลาดในการเปิดช่องทางส่งต่อ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
