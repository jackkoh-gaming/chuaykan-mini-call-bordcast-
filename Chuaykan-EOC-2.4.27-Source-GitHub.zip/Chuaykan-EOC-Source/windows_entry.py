"""Windows runtime entrypoint with local diagnostic logs and no bundled user state."""
import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
local = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData/Local"))) / "Chuaykan"
(local / "logs").mkdir(parents=True, exist_ok=True)
os.environ.setdefault("RESCUE_GATEWAY_DIR", str(root / "gateway"))
os.environ.setdefault("RESCUE_ECDSA_KEY_PATH", str(local / ".secrets/ecdsa_p256_private.pem"))
log = (local / "logs/startup.log").open("a", encoding="utf-8", buffering=1)
sys.stdout = log
sys.stderr = log
try:
    import main
    raise SystemExit(main.main())
except Exception:
    import traceback
    traceback.print_exc()
    raise
