package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.security.AuditDocumentExporter as Audit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.security.MessageDigest

@RunWith(AndroidJUnit4::class)
class MobileDisclosureTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun documentMatchesInstalledVersionAndAllThreeUiSections() {
        val report = Audit.buildGovernmentAuditSpecification(context)
        val installed = context.packageManager.getPackageInfo(context.packageName, 0)
        assertTrue(report.contains("เวอร์ชัน: ${installed.versionName} (versionCode: ${installed.versionCode})"))
        assertTrue(report.contains(Audit.termsDisclosure()))
        assertTrue(report.contains(Audit.privacyDisclosure()))
        assertTrue(report.contains(Audit.auditDisclosure()))
        assertTrue(report.contains("จิรายุ โคว"))
        assertFalse(report.contains("SHA256-TDMC-BROADCAST"))
        assertFalse(report.contains("ZERO SPYWARE & MALWARE GUARANTEE"))
    }

    @Test fun statusExportHasNoCoordinatesDeviceIdentityOrUnverifiedCertification() {
        val report = Audit.buildPoliceAuditLog(context)
        assertFalse(report.contains("Build Fingerprint:"))
        assertFalse(report.contains("Device Identity Reference"))
        assertFalse(report.contains("Deployment Geolocation Audit"))
        assertFalse(report.contains("[ACTIVE]"))
        assertFalse(report.contains("HMAC-SHA256"))
        assertTrue(report.contains("ไม่มีการดึงพิกัดหรือข้อมูลระบุตัวบุคคล"))
        val divider = "\n\nSHA-256 ของข้อความ UTF-8 ก่อนบรรทัดนี้: "
        assertEquals(Audit.sha256(report.substringBeforeLast(divider)), report.substringAfterLast(divider))
    }

    @Test fun exportedApkHashMatchesActualInstalledFile() {
        val digest = MessageDigest.getInstance("SHA-256")
        File(context.applicationInfo.sourceDir).inputStream().use { input ->
            val buffer = ByteArray(32768)
            while (true) {
                val size = input.read(buffer)
                if (size < 0) break
                digest.update(buffer, 0, size)
            }
        }
        val expected = digest.digest().joinToString("") { "%02x".format(it) }
        assertTrue(Audit.buildGovernmentAuditSpecification(context).contains(expected))
    }
}
