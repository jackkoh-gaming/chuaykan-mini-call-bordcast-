"""
Disaster Alert Gateway - Dispatcher Module
Dispatches verified alerts through Firebase Cloud Messaging (FCM).
"""
import json
import logging
from typing import Dict, Optional
from .models import DisasterAlert

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("GatewayDispatcher")



class FCMDispatcher:
    """Dispatches high-priority data messages via Firebase Cloud Messaging."""

    _app = None

    @classmethod
    def _get_app(cls, cred_path: Optional[str] = None):
        if cls._app is not None:
            return cls._app

        import os
        import json
        import firebase_admin
        from firebase_admin import credentials

        # 1. Try JSON string from environment variable
        env_json = os.environ.get("FIREBASE_SERVICE_ACCOUNT_KEY", "").strip()
        if env_json.startswith("{") and "PLACEHOLDER" not in env_json:
            try:
                cert_dict = json.loads(env_json)
                cred = credentials.Certificate(cert_dict)
                try:
                    cls._app = firebase_admin.get_app()
                except ValueError:
                    cls._app = firebase_admin.initialize_app(cred)
                return cls._app
            except Exception as e:
                logger.warning(f"Failed to load credentials from FIREBASE_SERVICE_ACCOUNT_KEY env: {e}")

        # 2. Try credentials path from env or argument
        if not cred_path:
            cred_path = os.environ.get("FIREBASE_CREDENTIALS_PATH")
        if not cred_path:
            cred_path = os.path.join(os.path.dirname(__file__), "serviceAccountKey.json")

        if not os.path.exists(cred_path):
            raise FileNotFoundError(f"Firebase credentials not found at: {cred_path}")

        with open(cred_path, "r", encoding="utf-8") as f:
            content = f.read()
            if "PLACEHOLDER" in content:
                raise ValueError("Firebase credentials contain placeholder values. Set FIREBASE_CREDENTIALS_PATH in production.")

        try:
            cls._app = firebase_admin.get_app()
        except ValueError:
            cred = credentials.Certificate(cred_path)
            cls._app = firebase_admin.initialize_app(cred)

        return cls._app

    @classmethod
    def dispatch_topic(
        cls,
        alert: DisasterAlert,
        topic: str = "emergency_alerts",
        is_muted: bool = True,
        cred_path: Optional[str] = None
    ) -> Dict:
        """
        Sends FCM data message payload over Google Firebase servers.
        """
        try:
            import firebase_admin
            from firebase_admin import messaging

            cls._get_app(cred_path)

            data_payload = alert.to_fcm_data()
            data_payload["muteSound"] = "true" if is_muted else "false"

            # Data-only is required: Android lets notification payloads be handled by
            # the system while the app is backgrounded, skipping AlertPushReceiver.
            # High priority data wakes the receiver, which verifies the signature and
            # posts the app's critical full-screen notification.
            message = messaging.Message(
                data=data_payload,
                topic=topic,
                android=messaging.AndroidConfig(
                    priority="high",
                    ttl=3600
                )
            )

            logger.info(f"[FCM] Sending FCM Topic Push: topic='{topic}', alert_id='{alert.alert_id}', muted={is_muted}")
            msg_id = messaging.send(message)
            logger.info(f"[SUCCESS] FCM Message successfully delivered to Google Cloud: {msg_id}")

            return {
                "status": "success",
                "transport": "fcm_topic",
                "topic": topic,
                "message_id": msg_id,
                "alert_id": alert.alert_id
            }
        except Exception as e:
            logger.error(f"[ERROR] Failed to dispatch FCM message: {e}")
            return {
                "status": "error",
                "transport": "fcm_topic",
                "topic": topic,
                "error": str(e)
            }
