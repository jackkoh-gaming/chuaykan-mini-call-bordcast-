package com.rescue.alert.network

import android.content.Context
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** HTTPS only; trust the public Oracle gateway certificate; credentials are issued by the gateway. */
object SecureGateway {
    private const val PREFS = "secure_gateway_pairing"
    @Volatile private var cachedTls: Pair<String, javax.net.ssl.SSLSocketFactory>? = null
    fun fingerprint(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("pin", "").orEmpty()
    fun accessKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("key", "").orEmpty()

    fun save(context: Context, base: String, pin: String, key: String) {
        val origin = URL(base)
        require(origin.protocol == "https" && origin.host.isNotBlank() && origin.userInfo == null &&
            origin.query == null && origin.ref == null && origin.path in listOf("", "/") && origin.port != 0) { "ใช้ที่อยู่ HTTPS ของศูนย์เท่านั้น" }
        val normalizedPin = pin.replace(":", "").trim().lowercase()
        require(normalizedPin.matches(Regex("[0-9a-f]{64}"))) { "SHA-256 ใบรับรองต้องมี 64 ตัวอักษร" }
        require(key.matches(Regex("[A-Za-z0-9_-]{43,128}"))) { "ระบุรหัสจับคู่ที่ได้รับจากเจ้าหน้าที่" }
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("origin", base.trimEnd('/')).putString("pin", normalizedPin).putString("key", key).commit())
    }

    private fun matches(certificate: X509Certificate, pin: String): Boolean {
        certificate.checkValidity()
        val digest = MessageDigest.getInstance("SHA-256").digest(certificate.encoded)
        val expected = ByteArray(32) { pin.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        return MessageDigest.isEqual(digest, expected)
    }

    private fun connect(url: URL, origin: URL, pin: String): HttpsURLConnection {
        check(url.protocol == "https" && url.host.equals(origin.host, true) && url.port == origin.port &&
            url.userInfo == null && url.ref == null) { "ปฏิเสธการเชื่อมต่อที่ไม่ได้เข้ารหัส" }
        val trust = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) { throw java.security.cert.CertificateException("Client trust not supported") }
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                if (chain.isEmpty() || !matches(chain[0], pin)) throw java.security.cert.CertificateException("EOC certificate does not match pairing")
            }
        }
        val factory = synchronized(this) {
            cachedTls?.takeIf { it.first == pin }?.second ?: SSLContext.getInstance("TLS").apply {
                init(null, arrayOf<TrustManager>(trust), SecureRandom())
            }.socketFactory.also { cachedTls = pin to it }
        }
        return (url.openConnection() as HttpsURLConnection).apply {
            sslSocketFactory = factory
            setHostnameVerifier { host, session ->
                host.equals(origin.host, true) && runCatching {
                    matches(session.peerCertificates[0] as X509Certificate, pin)
                }.getOrDefault(false)
            }
            instanceFollowRedirects = false

        }
    }
    @Synchronized
    private fun registeredKey(context: Context, origin: URL, pin: String): String {
        val prefs = context.getSharedPreferences("oracle_gateway_device", Context.MODE_PRIVATE)
        prefs.getString("token", null)?.let { return it }
        val client = prefs.getString("client", null) ?: java.util.UUID.randomUUID().toString().replace("-", "")
        val proof = prefs.getString("proof", null) ?: android.util.Base64.encodeToString(ByteArray(32).also { SecureRandom().nextBytes(it) }, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        check(prefs.edit().putString("client", client).putString("proof", proof).commit())
        val nodePrefs = context.getSharedPreferences("mesh_node_identity_prefs", Context.MODE_PRIVATE)
        val device = nodePrefs.getString("persistent_node_id", null)
            ?: com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(context).myNodeId
        val conn = connect(URL("$origin/api/device/register"), origin, pin)
        try {
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            val body = org.json.JSONObject().put("client_id", client).put("device_id", device).put("proof", proof).toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(body.size)
            conn.outputStream.use { it.write(body) }
            check(conn.responseCode == 200) { "ลงทะเบียนเกตเวย์ไม่สำเร็จ (${conn.responseCode})" }
            val reply = conn.inputStream.bufferedReader().use { it.readText() }
            check(reply.length < 2048)
            val token = org.json.JSONObject(reply).getString("access_token")
            check(token.matches(Regex("[0-9a-f]{64}")))
            check(prefs.edit().putString("token", token).commit())
            // Remove the previous manually entered shared pairing credential after registration succeeds.
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
            return token
        } finally {
            conn.disconnect()
        }
    }

    fun open(context: Context?, url: URL): HttpsURLConnection {
        require(context != null) { "Gateway context required" }
        check(android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) { "Gateway networking requires a background thread" }
        val origin = URL(com.rescue.alert.util.AppSettings.DEFAULT_GATEWAY_URL)
        val pin = com.rescue.alert.util.AppSettings.CLOUD_CERTIFICATE_SHA256
        val connection = connect(url, origin, pin)
        val key = registeredKey(context, origin, pin)
        return connection.apply { setRequestProperty("X-API-Key", key) }
    }

}
