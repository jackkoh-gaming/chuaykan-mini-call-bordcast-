#!/usr/bin/env python3
"""
Application Entrypoint for PySide6 GUI
"""
import os
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QColor, QPalette, QFontDatabase
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox

from src.gui.main_window import MainWindow
from src.gui.transparency_dialog import TransparencyDialog

def main() -> int:
    # High-DPI support
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("Chuaykan (Mini Call Broadcast)")
    app.setOrganizationName("Chuaykan")

    # Use the same Thai font as the prototype on a clean Windows installation.
    from src.core.config import ASSETS_DIR
    QFontDatabase.addApplicationFont(str(ASSETS_DIR / "fonts/Sarabun-Regular.ttf"))

    # Font setup
    font = QFont("Sarabun", 10)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font)

    from src.gui.theme import ThemeManager
    app.theme_manager = ThemeManager(app)

    try:
        terms = TransparencyDialog(require_acceptance=True)
    except (OSError, ValueError) as error:
        QMessageBox.critical(None, "เปิดข้อตกลงไม่ได้",
                             "ยังเข้าใช้งานไม่ได้ กรุณาตรวจไฟล์เอกสาร\n" + str(error))
        return 1
    if terms.exec() != QDialog.DialogCode.Accepted:
        return 0

    window = MainWindow()
    window.show()

    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
