package com.rescue.alert.security

import android.content.Context
import android.util.Base64
import android.util.Log
import java.security.KeyFactory
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Verifies alert authenticity strictly via Asymmetric Public-Key ECDSA (NIST P-256 / SHA256withECDSA)
 * and prevents replay attacks with timestamp-ordered deduplication cache.
 *
 * Client strictly holds ONLY the Public Key. Private signing key resides strictly in the dispatcher.
 * Downgrade attacks (e.g. HMAC or plaintext fallback) are strictly rejected.
 */
object AlertVerifier {
    // Official RescueAlert Public Key (NIST P-256 / secp256r1 X.509 SubjectPublicKeyInfo in Base64)
    private const val EC_PUBLIC_KEY_X509_BASE64 =
        ""

    private const val MAX_ALERT_AGE_MILLIS = 30 * 60 * 1000L // 30 minutes
    private const val TAG = "AlertVerifier"

    @Volatile
    private var cachedPublicKey: PublicKey? = null

    private fun decodeBase64(base64Str: String): ByteArray {
        return Base64.decode(base64Str.trim(), Base64.DEFAULT)
    }

    private fun getPublicKey(): PublicKey? {
        if (cachedPublicKey != null) return cachedPublicKey
        return synchronized(this) {
            if (cachedPublicKey != null) cachedPublicKey
            else {
                try {
                    val keyBytes = decodeBase64(EC_PUBLIC_KEY_X509_BASE64)
                    val keySpec = X509EncodedKeySpec(keyBytes)
                    val keyFactory = KeyFactory.getInstance("EC")
                    val pub = keyFactory.generatePublic(keySpec)
                    cachedPublicKey = pub
                    pub
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to parse embedded EC public key", e)
                    null
                }
            }
        }
    }

    /**
     * Strict signature verification.
     * ZERO BYPASS / ZERO DOWNGRADE ALLOWED:
     * Signatures must strictly start with "SIG_EC:" and mathematically verify with the official NIST P-256 public key.
     */
    fun verifySignature(alertId: String, sentTime: Long, signature: String): Boolean {
        if (signature.isBlank() ||
            signature.equals("BYPASS", ignoreCase = true) ||
            signature.equals("LIVE_SYNC", ignoreCase = true)
        ) {
            Log.w(TAG, "Rejected alert $alertId: Blank or bypass signature")
            return false
        }

        if (!signature.startsWith("SIG_EC:")) {
            Log.w(TAG, "Rejected alert $alertId: Non-ECDSA or legacy signature format rejected for security")
            return false
        }

        return try {
            val message = "$alertId:$sentTime"
            val sigB64 = signature.removePrefix("SIG_EC:").trim()
            verifyAsymmetricSignature(message, sigB64)
        } catch (e: Exception) {
            Log.e(TAG, "Signature verification error for alert $alertId", e)
            false
        }
    }

    /**
     * Performs genuine mathematical cryptographic verification of the ECDSA signature
     * using the official embedded NIST P-256 Public Key and SHA256withECDSA.
     */
    private fun verifyAsymmetricSignature(message: String, signatureBase64: String): Boolean {
        return try {
            val pubKey = getPublicKey() ?: return false
            val sigBytes = decodeBase64(signatureBase64)
            if (sigBytes.isEmpty()) return false

            val verifier = Signature.getInstance("SHA256withECDSA")
            verifier.initVerify(pubKey)
            verifier.update(message.toByteArray(Charsets.UTF_8))
            val verified = verifier.verify(sigBytes)
            if (!verified) {
                Log.w(TAG, "Asymmetric ECDSA signature verification failed mathematically!")
            }
            verified
        } catch (e: Exception) {
            Log.e(TAG, "Error executing asymmetric ECDSA verification", e)
            false
        }
    }

    // Fast thread-safe in-memory cache to prevent TOCTOU race condition across concurrent threads (Doc 2 H-15)
    private val inMemoryAlertIds = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
    private var callCounter = 0

    /**
     * Anti-Replay: Check if this alert has expired or was already processed.
     * Synchronized to prevent TOCTOU race condition across concurrent FCM and mesh receivers (Doc 2 H-15).
     */
    @Synchronized
    fun isAlreadyProcessedOrExpired(
        context: Context, alertId: String, sentTime: Long, expiresAt: Long
    ): Boolean {
        val now = System.currentTimeMillis()
        val effectiveExpires = if (expiresAt > 0L) expiresAt else (now + 2 * 60 * 60 * 1000L)
        val effectiveSent = if (sentTime > 0L) sentTime else now
        if (now > effectiveExpires || (now - effectiveSent) > MAX_ALERT_AGE_MILLIS) {
            return true
        }

        // Fast thread-safe in-memory check to prevent race condition (Doc 2 H-15)
        if (inMemoryAlertIds.contains(alertId)) {
            return true
        }

        val prefs = context.getSharedPreferences("alert_history", Context.MODE_PRIVATE)
        if (prefs.contains(alertId)) {
            inMemoryAlertIds.add(alertId)
            return true
        }

        // Immediately add to atomic in-memory set and commit synchronously to SharedPreferences
        inMemoryAlertIds.add(alertId)
        if (inMemoryAlertIds.size > 200) {
            val it = inMemoryAlertIds.iterator()
            if (it.hasNext()) {
                it.next()
                it.remove()
            }
        }
        prefs.edit().putLong(alertId, now).commit()

        callCounter++
        if (callCounter >= 10) {
            callCounter = 0
            cleanupOldAlerts(context)
        }
        return false
    }

    /**
     * Cleans up expired and oldest alert entries in timestamp order (M-5 fix).
     * Retains at most the 100 most recent alert IDs.
     */
    @Synchronized
    private fun cleanupOldAlerts(context: Context) {
        val prefs = context.getSharedPreferences("alert_history", Context.MODE_PRIVATE)
        val allEntries = prefs.all
        val now = System.currentTimeMillis()

        // 1. Collect entries with their recorded timestamp
        val entryList = mutableListOf<Pair<String, Long>>()
        for ((key, value) in allEntries) {
            val ts = (value as? Long) ?: (value as? Number)?.toLong() ?: 0L
            entryList.add(Pair(key, ts))
        }

        // 2. Identify expired entries or excess beyond 100
        val editor = prefs.edit()
        var modified = false

        // Sort ascending by timestamp (oldest first)
        entryList.sortBy { it.second }

        val toRemove = mutableSetOf<String>()
        // Remove expired entries (> 30 min old)
        for ((key, ts) in entryList) {
            if (ts > 0 && (now - ts) > MAX_ALERT_AGE_MILLIS) {
                toRemove.add(key)
            }
        }

        // If remaining still exceeds 100, remove oldest
        val remaining = entryList.filter { !toRemove.contains(it.first) }
        if (remaining.size > 100) {
            val overflow = remaining.take(remaining.size - 100)
            for (item in overflow) {
                toRemove.add(item.first)
            }
        }

        for (key in toRemove) {
            editor.remove(key)
            inMemoryAlertIds.remove(key)
            modified = true
        }

        if (modified) {
            editor.commit()
        }
    }
}
