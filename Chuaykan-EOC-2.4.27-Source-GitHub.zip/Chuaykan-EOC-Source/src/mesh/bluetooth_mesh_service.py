#!/usr/bin/env python3
"""
Bluetooth Mesh Gateway & Transport Service
Enables the EOC Command Center to detect, connect, and receive distress signals
and audio packets from Android devices running RescueAlert via Bluetooth Mesh & BLE.
Includes production Anti-RPA deduplication engine to ensure 1 physical device = 1 node count.
"""
from __future__ import annotations
import asyncio
import sys
import json
import math
from datetime import datetime, timezone
import os
import re
import shutil
import socket
import struct
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from src.core.config import RECORDINGS_DIR
from src.mesh.call_audio import CallAudioPlayer

# Dedicated RescueAlert Mesh UUIDs matching Android BluetoothMeshManager.kt
RESCUE_MESH_SERVICE_UUID = "16690000-fa01-2026-8a8c-2c50f1587bfc"
RESCUE_MESH_CHAR_UUID = "16690001-fa01-2026-8a8c-2c50f1587bfc"
RESCUE_RFCOMM_UUID = "16690002-fa01-2026-8a8c-2c50f1587bfc"
APP_PROTOCOL_MAGIC = "RESCUE_ALERT_THAI_DISASTER_MESH_v2"
HEADER_MAGIC_INT = 0x54484149  # "THAI" in ASCII

# App-Only Discovery: Handshake beacon prefix embedded in BLE Service Data
# Both mobile (Android/iOS) and desktop (EOC Gateway) MUST advertise this
# in their Service Data payload. Devices without this beacon are ignored.
APP_HANDSHAKE_BEACON = b"RA_APP_v2"

# Multi-hop mesh relay configuration
MESH_RELAY_MAX_HOPS = 5          # Maximum hops a packet can traverse
MESH_RELAY_TTL_DEFAULT = 3       # Default TTL for new packets


@dataclass
class BluetoothMeshNode:
    node_id: str
    name: str
    address: str
    rssi: int
    distance_meters: int
    is_app_node: bool
    last_seen: float
    services: List[str] = field(default_factory=list)
    distance_category: str = "ใกล้"


@dataclass
class RpaMappingEntry:
    canonical_id: str
    last_seen: float
    rssi: int


def _safe_id(s: str) -> str:
    """Sanitize node/source ID to prevent path traversal (F-03)."""
    cleaned = re.sub(r"[^A-Za-z0-9_\-]", "_", s)
    return cleaned[:32] if cleaned else "UNKNOWN"


def calculate_log_distance(rssi: int, tx_power: int = -59, n: float = 2.5) -> Tuple[int, str]:
    """
    Log-distance path loss formula:
    d = 10 ^ ((tx_power - rssi) / (10 * n))
    Returns (distance_meters, distance_category)
    F-09: Replaces over-simplistic linear formulas with standard RF path-loss model
    and bounded qualitative range ('ใกล้' / 'กลาง' / 'ไกล').
    """
    if rssi == 0:
        return 10, "กลาง"
    try:
        ratio = (tx_power - rssi) / (10.0 * n)
        dist = 10.0 ** ratio
        meters = max(1, min(100, int(round(dist))))
    except Exception:
        meters = 10

    if meters <= 4:
        cat = "ใกล้"
    elif meters <= 15:
        cat = "กลาง"
    else:
        cat = "ไกล"
    return meters, cat


def _recv_exact(sock: socket.socket, n: int, allow_idle: bool = False) -> bytes:
    """
    Guarantees reading exactly n bytes from stream socket (F-06, F-13).
    Raises ConnectionError if stream is closed before all bytes are read.
    """
    buf = bytearray()
    while len(buf) < n:
        try:
            chunk = sock.recv(n - len(buf))
        except socket.timeout:
            if allow_idle:
                continue
            raise
        if not chunk:
            raise ConnectionError("Socket closed prematurely while reading expected bytes")
        buf.extend(chunk)
    return bytes(buf)


class BluetoothMeshService:
    """
    Central Bluetooth Mesh Gateway Service running on the EOC Desktop Host.
    Scans for nearby mobile nodes and accepts direct P2P mesh distress transmissions.
    Features an Anti-RPA deduplication engine with active window TTL (15-20s).
    """

    def __init__(
        self,
        on_node_detected: Optional[Callable[[BluetoothMeshNode], None]] = None,
        on_mesh_packet: Optional[Callable[[dict], None]] = None,
        on_status_change: Optional[Callable[[str], None]] = None,
        active_ttl: float = 20.0,
        purge_ttl: float = 60.0,
        on_pairing_request: Optional[Callable[[dict], None]] = None
    ):
        self.on_node_detected = on_node_detected
        self.on_mesh_packet = on_mesh_packet
        self.on_status_change = on_status_change
        self.on_pairing_request = on_pairing_request

        # Anti-RPA Deduplication Storage
        self.active_ttl = active_ttl
        self.purge_ttl = purge_ttl
        self.canonical_nodes: Dict[str, BluetoothMeshNode] = {}
        self.rpa_to_canonical: Dict[str, RpaMappingEntry] = {}
        self._lock = threading.RLock()

        # Backward compatibility reference
        self.nodes: Dict[str, BluetoothMeshNode] = self.canonical_nodes

        self.is_running = False
        self._ble_thread: Optional[threading.Thread] = None
        self._adv_thread: Optional[threading.Thread] = None
        self._rfcomm_thread: Optional[threading.Thread] = None
        self._rfcomm_socket: Optional[socket.socket] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._scanner = None
        self._adv_proc: Optional[subprocess.Popen] = None
        self._adv_lock = threading.Lock()
        self._connections = {}  # Classic address -> (duplex socket, frame write lock)
        self.call_audio = CallAudioPlayer()
        self._last_audio_status = 0.0

        # Multi-hop Mesh Relay State
        self.relay_enabled = True
        self.relay_peers: Dict[str, float] = {}  # addr -> last_seen (verified app peers)
        self._seen_packet_ids: Dict[str, float] = {}  # packet_id -> timestamp (flood dedup)
        self._seen_pkt_lock = threading.Lock()

        # Voice Session Accumulation (F-02)
        self._voice_sessions: Dict[str, dict] = {}
        self._voice_lock = threading.Lock()
        self._flusher_thread: Optional[threading.Thread] = None

    def start(self):
        """Start BLE scanning, continuous BLE advertising, and RFCOMM listening daemon threads."""
        if self.is_running:
            return
        # Initialise libdbus threading before the BlueZ worker creates its connection.
        if sys.platform != "win32":
            from dbus.mainloop.glib import threads_init
            threads_init()
        self.is_running = True
        self._emit_status("เริ่มต้นระบบเครือข่ายบลูทูธแมช (กำลังเปิดแสกนเนอร์และกระจายสัญญาณ)...")

        # Android needs the EOC controller to accept classic Bluetooth pages before
        # it can open the RFCOMM voice and emergency-data channel.
        self._enable_classic_gateway_discovery()

        # 1. Start BLE Scanner Thread
        self._ble_thread = threading.Thread(target=self._run_ble_loop, daemon=True, name="BLE-Mesh-Scanner")
        self._ble_thread.start()

        # 2. Start Resilient BLE Advertising Thread
        self._adv_thread = threading.Thread(target=self._run_ble_advertiser, daemon=True, name="BLE-Mesh-Advertiser")
        self._adv_thread.start()

        # The BlueZ worker owns both advertisement and RFCOMM profile on one D-Bus loop.

        threading.Thread(target=self._run_officer_position, daemon=True, name="EOC-GPS").start()

        # 4. Start Voice Session Flusher Thread (F-02)
        self._flusher_thread = threading.Thread(target=self._run_voice_flusher, daemon=True, name="Mesh-Voice-Flusher")
        self._flusher_thread.start()

    @staticmethod
    def _enable_classic_gateway_discovery():
        """Keep the EOC controller reachable for Android RFCOMM connections."""
        if not shutil.which("bluetoothctl"):
            return
        for command in (
            ["bluetoothctl", "discoverable-timeout", "0"],
            ["bluetoothctl", "pairable", "on"],
            ["bluetoothctl", "discoverable", "on"],
        ):
            try:
                subprocess.run(
                    command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3.0
                )
            except (OSError, subprocess.SubprocessError):
                # A system-managed controller can still expose RFCOMM without bluetoothctl.
                return

    def __del__(self):
        try:
            self.stop()
        except Exception:
            pass

    def _cleanup_adv_proc_locked(self):
        """Reap and clean up the advertising subprocess and its pipes. Caller must hold self._adv_lock."""
        proc = self._adv_proc
        self._adv_proc = None
        if proc is None:
            return

        if proc.stdin:
            try:
                proc.stdin.close()
            except Exception:
                pass

        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=1.0)
            else:
                proc.wait(timeout=0.2)
        except Exception:
            pass

    def _cleanup_adv_proc(self):
        """Thread-safe public cleanup of advertising process."""
        with self._adv_lock:
            self._cleanup_adv_proc_locked()

    def clear_all_nodes(self):
        """Immediately clears all in-memory discovered nodes and RPA mappings."""
        with self._lock:
            self.canonical_nodes.clear()
            self.rpa_to_canonical.clear()
            self.relay_peers.clear()
        with self._voice_lock:
            self._voice_sessions.clear()

    def stop(self):
        """Stop all background Bluetooth services and clear nodes from memory."""
        self.is_running = False
        self.call_audio.stop()
        with self._lock:
            connections = list(self._connections.values())
            self._connections.clear()
        for connection, _ in connections:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()
        self._cleanup_adv_proc()
        try:
            self.flush_voice_sessions(idle=0.0)
        except Exception:
            pass
        self.clear_all_nodes()

        if self._rfcomm_socket:
            try:
                self._rfcomm_socket.close()
            except Exception:
                pass

        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)

        if shutil.which("bluetoothctl"):
            try:
                subprocess.run(
                    ["bluetoothctl", "advertise", "off"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2.0
                )
            except Exception:
                pass

        if shutil.which("btmgmt"):
            try:
                subprocess.run(
                    ["btmgmt", "--index", "0", "rm-adv", "1"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2.0
                )
            except Exception:
                pass

    def _emit_status(self, msg: str):
        if self.on_status_change:
            try:
                self.on_status_change(msg)
            except Exception as e:
                print(f"[BluetoothMeshService] Status callback error: {e}")

    # =========================================================
    # ANTI-RPA DEDUPLICATION ENGINE CORE METHODS
    # =========================================================
    def _extract_id_from_service_data(self, service_data: Dict[str, bytes]) -> Optional[str]:
        """Tier 1: Extract persistent canonical node ID from BLE Service Data payload."""
        if not service_data:
            return None

        target_uuid_short = RESCUE_MESH_SERVICE_UUID.replace("-", "").lower()
        for s_uuid, s_data in service_data.items():
            uuid_str = str(s_uuid).replace("-", "").lower()
            if target_uuid_short in uuid_str or uuid_str in target_uuid_short or len(service_data) == 1:
                raw_bytes = bytes(s_data)
                # Sub-case 1A: Magic 'RA' + 6-byte Node ID
                if len(raw_bytes) >= 8 and raw_bytes[:2] == b"RA":
                    extracted = raw_bytes[2:8].decode("utf-8", errors="ignore").strip()
                    if extracted:
                        return f"NODE_{extracted}"

                # Sub-case 1B: MeshVoicePacket wire format with HEADER_MAGIC_INT ('THAI')
                if len(raw_bytes) >= 17:
                    magic = struct.unpack_from(">I", raw_bytes, 0)[0]
                    if magic == HEADER_MAGIC_INT:
                        pid_len = raw_bytes[7]
                        src_len = raw_bytes[8]
                        idx = 13 + pid_len
                        if len(raw_bytes) >= idx + src_len:
                            src_id = raw_bytes[idx:idx + src_len].decode("utf-8", errors="ignore").strip()
                            if src_id:
                                return src_id

                # Sub-case 1C: Plain ASCII string tag
                try:
                    text = raw_bytes.decode("utf-8", errors="ignore").strip()
                    if text.startswith("NODE_") and len(text) >= 6:
                        return text[:16]
                    if text.startswith("RESCUE_") and len(text) >= 8:
                        return text[:16]
                except Exception:
                    pass

        return None

    def _extract_id_from_name(self, raw_name: str) -> Optional[str]:
        """Tier 2: Extract persistent model identifier from authentic device name."""
        if not raw_name:
            return None

        # Ignore auto-generated transient MAC fallback names
        if "โทรศัพท์" in raw_name or re.search(r"\([0-9a-fA-F:]{4,}\)", raw_name):
            return None

        if "RescueAlert-EOC-Gateway" in raw_name:
            return "NODE_EOC_GATEWAY"

        # Match model patterns like 'RescueAlert (Redmi A2)' or 'Redmi A2'
        m = re.search(r"RescueAlert[\s\-_]*\(?([A-Za-z0-9\s]+)\)?", raw_name, re.IGNORECASE)
        if m:
            clean_model = re.sub(r"[^A-Za-z0-9]", "", m.group(1)).upper()
            if clean_model:
                return f"NODE_{clean_model[:10]}"

        # If raw_name contains recognizable phone model and app is confirmed
        clean = re.sub(r"[^A-Za-z0-9]", "", raw_name).upper()
        if len(clean) >= 4 and not clean.startswith("PHONE"):
            return f"NODE_{clean[:10]}"

        return None

    def _find_temporal_handover(
        self,
        addr: str,
        rssi: int,
        service_uuids: List[str],
        now: float
    ) -> Optional[str]:
        """Tier 4: Match unmapped RPA to an existing active node undergoing MAC rotation."""
        candidates = []
        for cid, node in self.canonical_nodes.items():
            # Node must have been seen recently (within last 6s)
            if (now - node.last_seen) > 6.0:
                continue
            # Address must be different (indicating address changed)
            if node.address == addr:
                continue
            # Old address must have stopped transmitting (at least 1.0s gap)
            old_rpa_entry = self.rpa_to_canonical.get(node.address)
            if old_rpa_entry and (now - old_rpa_entry.last_seen) < 1.0:
                continue
            # RSSI proximity: same RF environment (delta <= 12 dBm)
            if abs(rssi - node.rssi) > 12:
                continue
            # Match only generic/fallback nodes to avoid hijacking verified devices
            if cid.startswith("NODE_") and len(cid) <= 12:
                candidates.append(cid)

        if len(candidates) == 1:
            return candidates[0]
        return None

    def resolve_canonical_node(
        self,
        addr: str,
        raw_name: str,
        display_name: str,
        rssi: int,
        service_uuids: List[str],
        service_data: Dict[str, bytes]
    ) -> BluetoothMeshNode:
        """
        Thread-safe canonical node resolution and in-place updating.
        Guarantees 1 phone = 1 canonical node record.
        """
        now = time.time()
        meters, cat = calculate_log_distance(rssi)

        with self._lock:
            # Tier 1: Service Data Identity (Most accurate - carries authentic node ID)
            cid = self._extract_id_from_service_data(service_data)

            # Tier 2: Existing RPA Mapping Lookup (already resolved for this MAC)
            if not cid and addr in self.rpa_to_canonical:
                cid = self.rpa_to_canonical[addr].canonical_id

            # Tier 3: Model / Device Name
            if not cid:
                cid = self._extract_id_from_name(raw_name)

            # Tier 4: Temporal Signal Handover Heuristic
            if not cid:
                cid = self._find_temporal_handover(addr, rssi, service_uuids, now)

            # Tier 5: New Unique Device Fallback
            if not cid:
                cid = f"NODE_{addr.replace(':', '')[-6:].upper()}"

            # Update RPA Mapping Table
            self.rpa_to_canonical[addr] = RpaMappingEntry(
                canonical_id=cid,
                last_seen=now,
                rssi=rssi
            )

            # Update or Create Canonical Node Record
            if cid in self.canonical_nodes:
                node = self.canonical_nodes[cid]
                # F-09: Exponential moving average filter on RSSI
                if rssi != 0:
                    smoothed_rssi = int(round(0.4 * node.rssi + 0.6 * rssi))
                    meters, cat = calculate_log_distance(smoothed_rssi)
                    node.rssi = smoothed_rssi
                else:
                    node.rssi = rssi
                node.address = addr
                node.distance_meters = meters
                node.distance_category = cat
                node.last_seen = now
                if service_uuids:
                    node.services = service_uuids
                # Only update name if raw_name was provided
                if raw_name:
                    node.name = display_name
            else:
                node = BluetoothMeshNode(
                    node_id=cid,
                    name=display_name,
                    address=addr,
                    rssi=rssi,
                    distance_meters=meters,
                    is_app_node=True,
                    last_seen=now,
                    services=service_uuids,
                    distance_category=cat
                )
                self.canonical_nodes[cid] = node

            return node

    def _prune_stale_records(self, now: float):
        """Prunes expired RPAs and inactive canonical nodes to prevent memory growth."""
        # Prune stale RPA mapping entries (> purge_ttl)
        stale_rpas = [addr for addr, entry in self.rpa_to_canonical.items() if (now - entry.last_seen) > self.purge_ttl]
        for addr in stale_rpas:
            del self.rpa_to_canonical[addr]

        # Prune dead canonical nodes (> purge_ttl)
        stale_nodes = [cid for cid, node in self.canonical_nodes.items()
                       if node.address not in self._connections and (now - node.last_seen) > self.purge_ttl]
        for cid in stale_nodes:
            del self.canonical_nodes[cid]

    def get_active_nodes(self, max_age_seconds: Optional[float] = None) -> List[BluetoothMeshNode]:
        """Returns strictly unique active canonical nodes seen within the active TTL window."""
        if max_age_seconds is None:
            max_age_seconds = self.active_ttl
        now = time.time()
        with self._lock:
            self._prune_stale_records(now)
            active = [
                node for node in self.canonical_nodes.values()
                if (node.address in self._connections or (now - node.last_seen) <= max_age_seconds) and node.is_app_node
            ]
            return sorted(active, key=lambda n: n.rssi, reverse=True)

    def get_node_count(self, max_age_seconds: Optional[float] = None) -> int:
        """Returns strictly the true count of canonical physical devices (1 phone = 1 count)."""
        return len(self.get_active_nodes(max_age_seconds=max_age_seconds))

    # =========================================================
    # CONTINUOUS BIDIRECTIONAL BLE ADVERTISING ON HCI0
    # =========================================================
    def _run_ble_advertiser(self):
        """Recover an actual BlueZ advertisement after adapter/service changes."""
        if sys.platform == "win32":
            from src.platforms.windows_bluetooth import advertise
        else:
            from src.mesh.ble_advertiser import advertise
        def connected(connection, address):
            self._emit_status(f"โทรศัพท์เชื่อมต่อช่องเสียง Bluetooth: {address}")
            threading.Thread(target=self._handle_rfcomm_client,
                             args=(connection, address), daemon=True,
                             name=f"RFCOMM-{address}").start()
        while self.is_running:
            try:
                advertise(RESCUE_MESH_SERVICE_UUID, RESCUE_RFCOMM_UUID, connected,
                          self.on_pairing_request, lambda: self.is_running, self._emit_status,
                          lambda addr: time.time() - self.relay_peers.get(addr, 0) < 60)
            except Exception as exc:
                self._emit_status(f"เปิดสัญญาณ EOC BLE ไม่สำเร็จ: {exc}")
                print(f"[BLE] Advertiser error: {exc}", flush=True)
            for _ in range(6):
                if not self.is_running:
                    return
                time.sleep(0.5)

    # =========================================================
    # BLE SCANNER
    # =========================================================
    def _run_ble_loop(self):
        try:
            from bleak import BleakScanner
        except ImportError:
            self._emit_status("ไม่พบโมดูล bleak ในระบบ - กำลังใช้โหมดพื้นฐาน")
            return

        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        async def scan_worker():
            def detection_callback(device, advertisement_data):
                if not self.is_running:
                    return

                addr = device.address
                raw_name = device.name or advertisement_data.local_name or ""
                display_name = raw_name if raw_name else f"โทรศัพท์ RescueAlert ({addr[-5:]})"
                rssi = advertisement_data.rssi
                service_uuids = [u.lower() for u in (advertisement_data.service_uuids or [])]
                service_data = advertisement_data.service_data or {}

                # ============================================================
                # STRICT APP-ONLY FILTER (App Handshake Verification)
                # Devices MUST satisfy ALL of the following to be detected:
                #   1. Advertise RescueAlert Service UUID, AND
                #   2. Include APP_HANDSHAKE_BEACON in BLE Service Data payload
                # Name-only matching is NOT sufficient — prevents false positives
                # from generic Bluetooth devices with similar names.
                # ============================================================

                # Condition 1: Service UUID must match RescueAlert Mesh UUID
                # (100% rejects generic Bluetooth devices: earphones, cars, TVs, etc.)
                has_rescue_uuid = (
                    RESCUE_MESH_SERVICE_UUID.lower() in service_uuids or
                    any(RESCUE_MESH_SERVICE_UUID.lower() in str(s).lower() for s in service_data.keys())
                )
                if not has_rescue_uuid:
                    return  # No RescueAlert UUID → not our app → ignore

                # Condition 2: If Service Data is present, verify beacon integrity
                if service_data:
                    has_app_beacon = False
                    for s_uuid, s_data in service_data.items():
                        raw_bytes = bytes(s_data)
                        if raw_bytes.startswith(APP_HANDSHAKE_BEACON):
                            has_app_beacon = True
                            break
                        # Accept compact beacon: 'RA' + 6-char node ID
                        if len(raw_bytes) >= 8 and raw_bytes[:2] == b"RA":
                            has_app_beacon = True
                            break
                        if len(raw_bytes) >= 17:
                            try:
                                magic = struct.unpack_from(">I", raw_bytes, 0)[0]
                                if magic == HEADER_MAGIC_INT:
                                    has_app_beacon = True
                                    break
                            except Exception:
                                pass
                        # Accept NODE_ or RESCUE_ text tags
                        try:
                            text = raw_bytes.decode("utf-8", errors="ignore").strip()
                            if text.startswith(("NODE_", "RESCUE_")):
                                has_app_beacon = True
                                break
                        except Exception:
                            pass

                    if not has_app_beacon:
                        return  # Corrupted or unverified service data → ignore

                # === VERIFIED APP NODE ===
                # Register as relay peer for multi-hop forwarding
                with self._lock:
                    self.relay_peers[addr] = time.time()

                # Deduplicate and resolve canonical node
                node = self.resolve_canonical_node(
                    addr=addr,
                    raw_name=raw_name,
                    display_name=display_name,
                    rssi=rssi,
                    service_uuids=service_uuids,
                    service_data=service_data
                )

                # Callback dispatched outside lock to avoid deadlocks
                if self.on_node_detected:
                    try:
                        self.on_node_detected(node)
                    except Exception as ex:
                        print(f"[BluetoothMeshService] on_node_detected error: {ex}")

                # F-03 Security: Do not parse unauthenticated mesh packets from raw BLE advertisement service data.
                # Inbound emergency packets are accepted exclusively over verified channels (RFCOMM with app handshake or verified GATT).

            while self.is_running:
                try:
                    self._scanner = BleakScanner(detection_callback=detection_callback)
                    await self._scanner.start()
                    self._emit_status("บลูทูธแมชสแตนด์บาย • ตรวจจับเฉพาะอุปกรณ์ที่โหลดแอป RescueAlert (App Handshake + UUID)")
                    for _ in range(50):
                        if not self.is_running:
                            break
                        await asyncio.sleep(0.1)
                    await self._scanner.stop()
                    await asyncio.sleep(1.0)
                except Exception as e:
                    self._emit_status(f"BLE Scanner แจ้งเตือน: {e}")
                    await asyncio.sleep(3.0)

        try:
            self._loop.run_until_complete(scan_worker())
        except Exception as e:
            print(f"[BluetoothMeshService] BLE loop terminated: {e}")
        finally:
            self._loop.close()

    # =========================================================
    # RFCOMM DIRECT MESH SOCKET LISTENER
    # =========================================================
    def _run_rfcomm_server(self):
        from src.mesh.rfcomm_profile import serve_profile
        def connected(connection, address):
            self._emit_status(f"โทรศัพท์เชื่อมต่อช่องเสียง Bluetooth: {address}")
            threading.Thread(target=self._handle_rfcomm_client,
                             args=(connection, address), daemon=True,
                             name=f"RFCOMM-{address}").start()
        while self.is_running:
            try:
                serve_profile(RESCUE_RFCOMM_UUID, connected, lambda: self.is_running, self._emit_status)
            except Exception as exc:
                print(f"[RFCOMM] Profile unavailable: {exc}", flush=True)
            for _ in range(6):
                if not self.is_running:
                    return
                time.sleep(0.5)

    def _handle_rfcomm_client(self, client_sock: socket.socket, remote_addr: str):
        dev_display = f"Phone-{remote_addr[-5:]}"
        try:
            client_sock.settimeout(15.0)

            # ============================================================
            # RFCOMM APP HANDSHAKE VERIFICATION (F-06, F-13)
            # Read first 4 bytes to check protocol magic without consuming
            # trailing packet frames into an arbitrary 64-byte buffer.
            # ============================================================
            first_4 = _recv_exact(client_sock, 4)
            is_verified = False
            if first_4 == APP_PROTOCOL_MAGIC[:4].encode("utf-8"):
                # Full handshake string sent by Android: "RESCUE_ALERT_THAI_DISASTER_MESH_v2\x00"
                expected_rest = (APP_PROTOCOL_MAGIC[4:] + "\x00").encode("utf-8")
                is_verified = _recv_exact(client_sock, len(expected_rest)) == expected_rest
            elif first_4 == APP_HANDSHAKE_BEACON[:4]:
                expected_rest = APP_HANDSHAKE_BEACON[4:]
                is_verified = _recv_exact(client_sock, len(expected_rest)) == expected_rest
            else:
                self._emit_status(f"ปฏิเสธการเชื่อมต่อ RFCOMM จาก {remote_addr}: ไม่ใช่แอป RescueAlert")
                return

            if not is_verified:
                self._emit_status(f"ปฏิเสธการเชื่อมต่อ RFCOMM จาก {remote_addr}: ไม่ใช่แอป RescueAlert")
                return

            # Register as verified relay peer
            with self._lock:
                previous = self._connections.get(remote_addr)
                self._connections[remote_addr] = (client_sock, threading.Lock())
                self.relay_peers[remote_addr] = time.time()
            if previous and previous[0] is not client_sock:
                previous[0].close()
            print(f"[RFCOMM] Duplex connection ready address={remote_addr}", flush=True)

            self._emit_status(f"ยืนยันตัวตนแอป RescueAlert สำเร็จ: {remote_addr}")

            # ============================================================
            # CONTINUOUS MULTI-FRAME READ LOOP (F-06)
            # Continues reading subsequent frames until client disconnects or times out.
            # ============================================================
            while self.is_running:
                client_sock.settimeout(5.0)
                try:
                    header_bytes = _recv_exact(client_sock, 8, allow_idle=True)
                except (ConnectionError, socket.timeout, OSError):
                    break

                magic, payload_len = struct.unpack(">II", header_bytes)
                if magic != HEADER_MAGIC_INT or not (0 < payload_len <= 131072):
                    break

                payload = _recv_exact(client_sock, payload_len)
                self._parse_incoming_mesh_bytes(payload, remote_addr, dev_display)

        except Exception as e:
            # Expected on client disconnect or timeout
            pass
        finally:
            with self._lock:
                current = self._connections.get(remote_addr)
                if current and current[0] is client_sock:
                    del self._connections[remote_addr]
            print(f"[RFCOMM] Connection closed address={remote_addr}", flush=True)
            try:
                client_sock.close()
            except Exception:
                pass
            # Flush any remaining voice session from this client
            try:
                self.flush_voice_sessions(idle=0.0)
            except Exception:
                pass

    def _write_voice_wav(self, sid: str, audio_bytes: bytes, timestamp: float) -> Optional[str]:
        try:
            safe_sid = _safe_id(sid)
            filename = f"mesh_{safe_sid}_{int(timestamp * 1000)}.wav"
            target_path = (RECORDINGS_DIR / filename).resolve()
            rec_dir_res = RECORDINGS_DIR.resolve()
            # F-03 Path Traversal Guard
            if rec_dir_res not in target_path.parents and target_path.parent != rec_dir_res:
                print(f"[BluetoothMeshService] Security: rejected audio path traversal {target_path}")
                return None
            RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
            import wave
            with wave.open(str(target_path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(8000)
                wf.writeframes(audio_bytes)
            return filename
        except Exception as e:
            print(f"[BluetoothMeshService] Error writing voice wav: {e}")
            return None

    def _run_voice_flusher(self):
        """Background daemon periodically flushing idle voice sessions (F-02)."""
        while self.is_running:
            try:
                self.flush_voice_sessions(idle=1.5)
            except Exception:
                pass
            time.sleep(0.5)

    def flush_voice_sessions(self, idle: float = 1.5):
        """
        Flush voice sessions that have been idle for >= idle seconds (F-02).
        Merges all received speech chunks into a single .wav file and invokes on_mesh_packet.
        """
        now = time.time()
        to_flush = []
        with self._voice_lock:
            for sid, sess in list(self._voice_sessions.items()):
                if now - sess["last"] >= idle:
                    to_flush.append((sid, sess))
                    del self._voice_sessions[sid]

        for sid, sess in to_flush:
            audio_bytes = bytes(sess["buf"])
            if len(audio_bytes) < 100:
                continue
            audio_filename = self._write_voice_wav(sid, audio_bytes, sess.get("start_time", now))
            if audio_filename and sess.get("latest_packet"):
                pkt = dict(sess["latest_packet"])
                pkt["audio_filename"] = audio_filename
                if self.on_mesh_packet:
                    try:
                        self.on_mesh_packet(pkt)
                    except Exception as ex:
                        print(f"[BluetoothMeshService] on_mesh_packet flush error: {ex}")

    # =========================================================
    # PACKET DECODER
    # =========================================================
    def _parse_incoming_mesh_bytes(self, data: bytes, remote_addr: str, dev_name: str):
        try:
            if len(data) < 13 or struct.unpack_from(">I", data, 0)[0] != HEADER_MAGIC_INT:
                return
            offset = 4

            hop_count = data[offset]
            ttl = data[offset + 1]
            is_sos = (data[offset + 2] == 1)
            pid_len = data[offset + 3]
            src_len = data[offset + 4]
            name_len = data[offset + 5]
            tgt_len = data[offset + 6]
            audio_len = struct.unpack_from(">H", data, offset + 7)[0]
            if ttl == 0 or len(data) != 13 + pid_len + src_len + name_len + tgt_len + audio_len:
                return

            idx = offset + 9
            pid_bytes = data[idx : idx + pid_len]
            idx += pid_len
            src_bytes = data[idx : idx + src_len]
            idx += src_len
            name_bytes = data[idx : idx + name_len]
            idx += name_len
            tgt_bytes = data[idx : idx + tgt_len]
            idx += tgt_len
            audio_bytes = data[idx : idx + audio_len]

            packet_id = pid_bytes.decode("utf-8", errors="ignore") or f"PKT_{int(time.time())}"
            raw_source_id = src_bytes.decode("utf-8", errors="ignore") or f"DEV_{remote_addr.replace(':', '')[-6:]}"
            source_id = _safe_id(raw_source_id)
            house_name = name_bytes.decode("utf-8", errors="ignore") or dev_name
            target_str = tgt_bytes.decode("utf-8", errors="ignore").strip()

            # Parse sender's GPS coordinates if present in target_str (F-05)
            lat: Optional[float] = None
            lng: Optional[float] = None
            if target_str.startswith("GPS:"):
                try:
                    parts = target_str[4:].split(",")
                    lat = float(parts[0])
                    lng = float(parts[1])
                except Exception:
                    pass

            # ============================================================
            # MULTI-HOP FLOOD DEDUPLICATION
            # Prevents the same packet from being processed multiple times
            # when it arrives via different relay paths in the mesh network.
            # ============================================================
            # BUG-01 FIX: Filter out our own EOC packets echoed back by mesh relay
            if source_id == "EOC_GATEWAY_HQ":
                return  # Skip self-echo — we sent this packet, ignore relay-back

            with self._seen_pkt_lock:
                if packet_id in self._seen_packet_ids:
                    return  # Already processed this packet — skip
                self._seen_packet_ids[packet_id] = time.time()
                # Prune old entries (keep last 60 seconds)
                cutoff = time.time() - 60.0
                stale = [k for k, v in self._seen_packet_ids.items() if v < cutoff]
                for k in stale:
                    del self._seen_packet_ids[k]

            # Anti-RPA integration: Lock source_id to remote_addr
            now = time.time()
            with self._lock:
                self.relay_peers[remote_addr] = now
                self.rpa_to_canonical[remote_addr] = RpaMappingEntry(
                    canonical_id=source_id,
                    last_seen=now,
                    rssi=0
                )
                if source_id in self.canonical_nodes:
                    node = self.canonical_nodes[source_id]
                    node.address = remote_addr
                    node.last_seen = now
                    if house_name:
                        node.name = house_name
                else:
                    node = BluetoothMeshNode(source_id, house_name, remote_addr, 0, 0, True, now)
                    self.canonical_nodes[source_id] = node
            if self.on_node_detected:
                self.on_node_detected(node)

            # Forward non-local traffic without ringing or recording it at the EOC.
            if self.relay_enabled and ttl > 1 and hop_count < MESH_RELAY_MAX_HOPS:
                relay_data = self._build_relay_packet(data, offset, hop_count + 1, ttl - 1)
                if relay_data:
                    self._relay_to_peers(relay_data, exclude_addr=remote_addr)
            if target_str not in ("EOC_GATEWAY_HQ", "BROADCAST") and not target_str.startswith("GPS:"):
                return
            if packet_id.startswith("MESH_HELLO"):
                self._relay_to_peers(self._control_packet("MESH_READY", source_id), only_addr=remote_addr)
                return
            if packet_id.startswith("MESH_READY"):
                return
            if packet_id.startswith("SOS_STATUS_QUERY_"):
                try:
                    query = json.loads(audio_bytes.decode("utf-8"))
                    if isinstance(query, dict) and self.on_mesh_packet:
                        self.on_mesh_packet({"packet_id": packet_id, "source_id": source_id, "status_query": query})
                except (ValueError, UnicodeError):
                    pass
                return
            if packet_id.startswith("SOS_PROFILE_"):
                try:
                    report = json.loads(audio_bytes.decode("utf-8"))
                    if not isinstance(report, dict) or report.get("case_type") != "GENERAL":
                        return
                    if self.on_mesh_packet:
                        self.on_mesh_packet({"packet_id": packet_id, "source_id": source_id,
                            "citizen_name": house_name, "is_sos": True, "sos_payload": report})
                except (ValueError, UnicodeError):
                    self._emit_status("แพ็กเก็ตโปรไฟล์ SOS ไม่ถูกต้อง")
                return
            if packet_id.startswith("EOC_CALL_VOICE"):
                # Calls are live and private to the accepted peer, never saved as voice messages.
                self.call_audio.feed(source_id, audio_bytes)
                return
            if packet_id.startswith("EOC_CALL_QUEUE"):
                return  # Targeted queue acknowledgments are control data, never audio.
            if packet_id.startswith("EOC_CALL_"):
                print(f"[Call] RX {packet_id.split('_')[2]} peer={source_id}", flush=True)

            # Save or accumulate received audio (F-02, F-03)
            audio_filename = None
            if audio_bytes and len(audio_bytes) > 0:
                if is_sos:
                    # SOS audio is immediate: write single .wav directly
                    audio_filename = self._write_voice_wav(source_id, audio_bytes, now)
                else:
                    # PTT streaming voice: accumulate chunks into session buffer (F-02)
                    with self._voice_lock:
                        if source_id not in self._voice_sessions:
                            self._voice_sessions[source_id] = {
                                "buf": bytearray(audio_bytes),
                                "start_time": now,
                                "last": now,
                                "latest_packet": None
                            }
                        else:
                            sess = self._voice_sessions[source_id]
                            sess["buf"].extend(audio_bytes)
                            sess["last"] = now

            packet_dict = {
                "packet_id": packet_id,
                "source_id": source_id,
                "citizen_name": house_name,
                "remote_addr": remote_addr,
                "is_sos": is_sos,
                "hop_count": hop_count,
                "audio_filename": audio_filename,
                "latitude": lat,
                "longitude": lng,
                "timestamp": time.time()
            }

            # Detect call signaling actions from citizen phones
            if packet_id.startswith("EOC_CALL_REQUEST") or packet_id.startswith("CALL_REQUEST"):
                packet_dict["call_action"] = "request"
            elif packet_id.startswith("EOC_CALL_ANSWER"):
                packet_dict["call_action"] = "answer"
            elif packet_id.startswith("EOC_CALL_DECLINE"):
                packet_dict["call_action"] = "decline"
            elif packet_id.startswith("EOC_CALL_HANGUP") or packet_id.startswith("EOC_CALL_END"):
                packet_dict["call_action"] = "hangup"
                with self._voice_lock:
                    if source_id in self._voice_sessions:
                        del self._voice_sessions[source_id]

            if audio_bytes and not is_sos:
                with self._voice_lock:
                    if source_id in self._voice_sessions:
                        self._voice_sessions[source_id]["latest_packet"] = packet_dict
                self._emit_status(f"กำลังรับสัญญาณเสียงสดจาก {house_name} ({remote_addr})...")
            else:
                action_name = "สัญญาณฉุกเฉินบลูทูธแมช" if is_sos else "แพ็กเก็ตข้อมูลบลูทูธแมช"
                self._emit_status(f"ได้รับ{action_name}จาก {house_name} ({remote_addr}) [Hop: {hop_count}]")
                if self.on_mesh_packet:
                    try:
                        self.on_mesh_packet(packet_dict)
                    except Exception as ex:
                        print(f"[BluetoothMeshService] on_mesh_packet callback error: {ex}")

            # ============================================================
            # MULTI-HOP RELAY FORWARDING
            # If TTL > 0 and hop_count < MESH_RELAY_MAX_HOPS, relay the
            # packet to other verified app peers (excluding the sender).
            # This enables chain-relay: App A → App B → App C → EOC Desktop
            # ============================================================
        except Exception as e:
            print(f"[BluetoothMeshService] Error decoding mesh packet: {e}")

    def _build_relay_packet(self, original_data: bytes, offset: int,
                            new_hop: int, new_ttl: int) -> Optional[bytes]:
        """
        Rebuild the mesh packet with incremented hop_count and decremented TTL
        for relay forwarding to nearby verified peers.
        """
        try:
            data = bytearray(original_data)
            data[offset] = min(255, new_hop)      # hop_count
            data[offset + 1] = min(255, new_ttl)  # ttl
            return bytes(data)
        except Exception:
            return None

    @staticmethod
    def _control_packet(action: str, target: str) -> bytes:
        fields = [f"{action}_{time.time_ns()}".encode(), b"EOC_GATEWAY_HQ",
                  "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode(), target.encode()]
        return (struct.pack(">IBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0)
                + bytes(map(len, fields)) + struct.pack(">H", 0) + b"".join(fields))

    def _relay_to_peers(self, packet_data: bytes, exclude_addr: str = "", only_addr: str = "") -> int:
        """Write whole frames on established duplex sockets; never guess Android's RFCOMM port."""
        with self._lock:
            connections = [(addr, pair) for addr, pair in self._connections.items()
                           if addr != exclude_addr and (not only_addr or addr == only_addr)]
        frame = struct.pack(">II", HEADER_MAGIC_INT, len(packet_data)) + packet_data
        sent = 0
        for address, (connection, write_lock) in connections:
            try:
                with write_lock:
                    connection.sendall(frame)
                sent += 1
            except OSError as exc:
                print(f"[RFCOMM] Send failed address={address}: {exc}", flush=True)
                with self._lock:
                    current = self._connections.get(address)
                    if current and current[0] is connection:
                        del self._connections[address]
                connection.close()
        return sent


    def broadcast_officer_audio(self, audio_pcm: bytes, announcement_id: Optional[str] = None,
                                target_node_id: str = "BROADCAST") -> int:
        """Send one 16-bit little-endian PCM chunk to verified RescueAlert peers."""
        if not self.is_running or not audio_pcm:
            return 0

        # Android's mesh packet has a 16-bit audio length; keep a safer per-chunk cap.
        safe_audio = bytes(audio_pcm[:24000])
        packet_id = announcement_id or f"EOC_ANNOUNCE_{int(time.time() * 1000)}"
        source_id = b"EOC_GATEWAY_HQ"
        if announcement_id and announcement_id.startswith("EOC_CALL_VOICE"):
            source_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC (สายตรง)".encode("utf-8")
        else:
            source_name = "EOC เจ้าหน้าที่ประกาศ".encode("utf-8")
        target = target_node_id.encode("utf-8")[:64]
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        if not packet_id_bytes:
            return 0

        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            self._emit_status("ไม่มีโทรศัพท์ RescueAlert ที่ยืนยันแล้วในระยะบลูทูธ: ไม่ส่งเสียง")
            return 0

        sent = self._relay_to_peers(payload)
        now = time.monotonic()
        if now - self._last_audio_status >= 1.0:
            self._last_audio_status = now
            self._emit_status(f"ส่งเสียง EOC ผ่านบลูทูธไปยัง {sent} โหนด")
        return sent

    def broadcast_officer_announcement_end(self) -> int:
        """Send announcement end marker to dismiss notification and stop playback on phones."""
        if not self.is_running:
            return 0
        packet_id = f"EOC_ANNOUNCE_END_{int(time.time() * 1000)}"
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "EOC เจ้าหน้าที่ประกาศ".encode("utf-8")
        target = b"BROADCAST"
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        safe_audio = b""
        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            return 0
        sent = self._relay_to_peers(payload)
        self._emit_status("ส่งสัญญาณปิดไมค์ประกาศ EOC ไปยังเครือข่ายบลูทูธแมชแล้ว")
        return sent

    def broadcast_officer_call_request(self, target_node_id: str = "BROADCAST") -> int:
        """Send direct call request packet to a specific RescueAlert phone or broadcast to all."""
        if not self.is_running:
            return 0
        packet_id = f"EOC_CALL_REQUEST_{int(time.time() * 1000)}"
        # BUG-01 FIX: Register in dedup cache to prevent self-echo
        with self._seen_pkt_lock:
            self._seen_packet_ids[packet_id] = time.time()
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode("utf-8")
        target = target_node_id.encode("utf-8")[:64]
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        safe_audio = b""
        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            self._emit_status("ไม่มีโทรศัพท์ RescueAlert ในระยะบลูทูธ: ไม่สามารถโทรออกได้")
            return 0
        sent = self._relay_to_peers(payload)
        self._emit_status(f"ส่งสัญญาณโทรเข้า (Call Request) ไปยัง {target_node_id} ผ่าน {len(before)} โหนดบลูทูธ")
        return sent

    def hangup_officer_call(self, target_node_id: str = "BROADCAST") -> int:
        """Send hangup packet to terminate active call or stop ringing on phones."""
        if not self.is_running:
            return 0
        packet_id = f"EOC_CALL_HANGUP_{int(time.time() * 1000)}"
        # BUG-01 FIX: Register in dedup cache to prevent self-echo
        with self._seen_pkt_lock:
            self._seen_packet_ids[packet_id] = time.time()
        # Purge any queued voice buffer for this node to avoid flushing trailing audio
        with self._voice_lock:
            if target_node_id in self._voice_sessions:
                del self._voice_sessions[target_node_id]
            if target_node_id == "BROADCAST":
                self._voice_sessions.clear()
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode("utf-8")
        target = target_node_id.encode("utf-8")[:64]
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        safe_audio = b""
        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            return 0
        sent = self._relay_to_peers(payload)
        self._emit_status(f"ส่งสัญญาณวางสาย (Hangup) ไปยัง {target_node_id} เรียบร้อยแล้ว")
        return sent

    def broadcast_officer_call_answer(self, target_node_id: str = "BROADCAST") -> int:
        """Send call answer packet to notify citizen that EOC officer accepted the call."""
        if not self.is_running:
            return 0
        packet_id = f"EOC_CALL_ANSWER_{int(time.time() * 1000)}"
        # Register in dedup cache to prevent self-echo
        with self._seen_pkt_lock:
            self._seen_packet_ids[packet_id] = time.time()
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode("utf-8")
        target = target_node_id.encode("utf-8")[:64]
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        safe_audio = b""
        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            return 0
        sent = self._relay_to_peers(payload)
        self._emit_status(f"ส่งสัญญาณรับสาย (Answer) ไปยัง {target_node_id} — เจ้าหน้าที่พร้อมสนทนา")
        return sent

    def broadcast_officer_call_decline(self, target_node_id: str = "BROADCAST") -> int:
        """Send call decline packet to notify citizen that EOC officer declined the call."""
        if not self.is_running:
            return 0
        packet_id = f"EOC_CALL_DECLINE_{int(time.time() * 1000)}"
        with self._seen_pkt_lock:
            self._seen_packet_ids[packet_id] = time.time()
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode("utf-8")
        target = target_node_id.encode("utf-8")[:64]
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        safe_audio = b""
        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            return 0
        sent = self._relay_to_peers(payload)
        self._emit_status(f"ส่งสัญญาณปฏิเสธสาย (Decline) ไปยัง {target_node_id}")
        return sent

    def broadcast_evacuation_site(self, site_dict: dict) -> int:
        """Broadcast an evacuation site or safe parking area over Bluetooth Mesh to citizens."""
        if not self.is_running:
            return 0
        site_id = site_dict.get("site_id", "SITE_01")
        packet_id = f"EOC_SITE_{site_id}_{int(time.time())}"
        with self._seen_pkt_lock:
            self._seen_packet_ids[packet_id] = time.time()
        source_id = b"EOC_GATEWAY_HQ"
        source_name = "ศูนย์สั่งการ EOC (ข้อมูลจุดอพยพ)".encode("utf-8")
        target = b"BROADCAST"
        packet_id_bytes = packet_id.encode("utf-8")[:120]
        # Payload JSON encoded in safe_audio bytes
        payload_json = json.dumps(site_dict, ensure_ascii=False).encode("utf-8")
        safe_audio = bytes(payload_json[:4000])

        payload = (
            struct.pack(">IBBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0, len(packet_id_bytes))
            + bytes([len(source_id), len(source_name), len(target)])
            + struct.pack(">H", len(safe_audio))
            + packet_id_bytes + source_id + source_name + target + safe_audio
        )
        with self._lock:
            before = list(self._connections)
        if not before:
            return 0
        sent = self._relay_to_peers(payload)
        name = site_dict.get("name", site_id)
        self._emit_status(f"ส่งข้อมูลจุดอพยพ/ที่จอดรถ '{name}' ข้ามบลูทูธแมชสำเร็จ")
        return sent

    def send_sos_receipt(self, target: str, case_id: str, case_status: str = "PENDING") -> int:
        return self._relay_to_peers(self._json_packet("EOC_SOS_ACK", {"case_id": case_id, "status": "SUCCESS", "case_status": case_status}, target))

    def send_sos_status(self, target: str, case_id: str, case_status: str) -> int:
        return self._relay_to_peers(self._json_packet("EOC_SOS_STATUS", {
            "case_id": case_id, "status": "SUCCESS", "case_status": case_status}, target))

    def send_call_queue(self, target_node_id: str, position: int) -> int:
        if not target_node_id or target_node_id == "BROADCAST" or not 0 <= position <= 50:
            return 0
        return self._relay_to_peers(self._json_packet("EOC_CALL_QUEUE", {"position": position}, target_node_id))

    @staticmethod
    def _json_packet(kind: str, report: dict, target: str = "BROADCAST") -> bytes:
        fields = [f"{kind}_{time.time_ns()}".encode(), b"EOC_GATEWAY_HQ",
                  "เจ้าหน้าที่ศูนย์สั่งการ EOC".encode(), target.encode()]
        body = json.dumps(report, ensure_ascii=False).encode()
        return (struct.pack(">IBBB", HEADER_MAGIC_INT, 0, MESH_RELAY_MAX_HOPS, 0)
                + bytes(map(len, fields)) + struct.pack(">H", len(body)) + b"".join(fields) + body)

    def _run_officer_position(self):
        # Only GPSD measured TPV fixes are advertised; an unavailable GPS produces no pin.
        while self.is_running:
            try:
                with socket.create_connection(("127.0.0.1", 2947), timeout=2) as gps:
                    gps.settimeout(2)
                    gps.sendall(b'?WATCH={"enable":true,"json":true};\n')
                    reader = gps.makefile("r")
                    for _ in range(8):
                        fix = json.loads(reader.readline())
                        if fix.get("class") != "TPV" or fix.get("mode", 0) < 2:
                            continue
                        stamp = datetime.fromisoformat(fix["time"].replace("Z", "+00:00")).timestamp()
                        lat, lng = float(fix["lat"]), float(fix["lon"])
                        accuracy = max(float(fix.get("epx", math.inf)), float(fix.get("epy", math.inf)))
                        if not (0 <= time.time() - stamp <= 30 and -90 <= lat <= 90 and -180 <= lng <= 180 and 0 <= accuracy <= 250):
                            continue
                        self._relay_to_peers(self._json_packet("EOC_POSITION", {
                            "lat": lat, "lng": lng, "accuracy": accuracy, "timestamp": int(stamp * 1000)}))
                        break
            except (OSError, ValueError, KeyError, TypeError):
                pass
            time.sleep(5)

    def get_relay_peer_count(self) -> int:
        """Count usable channels, not merely BLE advertisements."""
        with self._lock:
            return len(self._connections)

    def is_app_verified_peer(self, addr: str) -> bool:
        """Check if a given Bluetooth address has been verified as a RescueAlert app peer."""
        with self._lock:
            if addr in self.relay_peers:
                return (time.time() - self.relay_peers[addr]) < 30.0
        return False
