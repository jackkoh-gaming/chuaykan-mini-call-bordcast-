"""Headless public gateway. Runs separately from the official-feed Firebase monitor."""
import os
import signal
import threading
from pathlib import Path

os.environ.setdefault('EOC_DATA_DIR', '/var/lib/chuaykan-eoc/data')
os.environ.setdefault('EOC_RECORDINGS_DIR', '/var/lib/chuaykan-eoc/recordings')
from src.core.database import Database
from src.server.dispatch_server import DispatchServer
from src.server.gateway_security import GatewaySecurity

security = GatewaySecurity(Path(os.environ.get('EOC_SECURITY_DIR', '/etc/chuaykan-eoc')))
if not security.officer_token:
    raise RuntimeError('Officer credential required for a public gateway')
server = DispatchServer(Database(), port=int(os.environ.get('EOC_PORT', '443')), security=security)
from src.server.public_data_cache import PublicDataCache
server.public_data = PublicDataCache()
server.public_data.start()
stopped = threading.Event()
for signum in (signal.SIGTERM, signal.SIGINT):
    signal.signal(signum, lambda *args: stopped.set())
def purge_legacy_completed():
    for case in server.db.get_all_sos_cases():
        if case.status == "RESCUED_SAFE":
            server.complete_case(case.case_id)
    server.db.cleanup_orphan_sos_cache()
purge_legacy_completed()
server.start()
print('Chuaykan public HTTPS gateway ready', flush=True)
while not stopped.wait(1):
    if server.announcer.expire_idle():
        server.db.log_event("INFO", "MIC_SOURCE_TIMEOUT", "Microphone source disconnected; stream ended")
server.public_data.stop_event.set()
server.stop()
