Third-party notices

MIT applies only to original Chuaykan code. Dependencies, map tiles, government
news and fonts keep their upstream licenses and attribution.

Windows binaries bundle dynamically linked PySide6/Qt 6.11.2 components, whose
LGPLv3/GPLv3/commercial license terms are not replaced by MIT. This distribution
uses the open-source terms for the included modules. License texts and package
metadata are retained in the distribution. Qt source: https://code.qt.io/
PySide source: https://code.qt.io/pyside/pyside-setup.git/
Licenses: https://doc.qt.io/qtforpython-6/licenses.html
Users may replace these shared libraries and modify the application; this
project imposes no restriction on reverse engineering for debugging such changes.

CPython 3.11: PSF license, https://www.python.org/downloads/source/
Microsoft ICU 72: Unicode/ICU licenses, see licenses/Microsoft-ICU-*.
ICU forwarders call the real ICU library; their sources are native/*.def.
Sarabun: SIL Open Font License, see assets/fonts/OFL.txt.
Leaflet: BSD-2-Clause, see licenses/Leaflet-BSD-2-Clause.txt.
Sounddevice, PortAudio, Bleak, PyWinRT, cryptography, Firebase Admin and their
transitive dependencies retain upstream licenses in package metadata and notices.
Windows adapters do not remove hardware or operating-system requirements.
OpenStreetMap/map tile attribution must remain visible.
Official Thai disaster records retain source terms, not the project's MIT license.
