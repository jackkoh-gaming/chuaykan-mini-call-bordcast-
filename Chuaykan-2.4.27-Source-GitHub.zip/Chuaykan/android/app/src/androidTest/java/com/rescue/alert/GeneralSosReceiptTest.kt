package com.rescue.alert

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.data.GeneralSosOutbox
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

/** Local fixtures use unique files/preferences; no Bluetooth, request or incident is sent. */
@RunWith(AndroidJUnit4::class)
class GeneralSosReceiptTest {
    private fun isolated(action: (Context, File) -> Unit) {
        val app = InstrumentationRegistry.getInstrumentation().targetContext
        val prefix = "receipt_test_${UUID.randomUUID()}_"
        val directory = File(app.cacheDir, prefix).apply { mkdirs() }
        val names = mutableSetOf<String>()
        val context = object : ContextWrapper(app) {
            override fun getFilesDir(): File = directory
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                names.add(prefix + name)
                return app.getSharedPreferences(prefix + name, mode)
            }
        }
        try { action(context, directory) } finally {
            for (name in names) app.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit()
            directory.deleteRecursively()
        }
    }

    @Test fun acceptedRequestRemainsRecoverableUntilRescueCompletes() = isolated { context, directory ->
        val id = GeneralSosOutbox.queue(context, JSONObject().put("device_id", "ISOLATED_TEST_DEVICE"))
        assertNotNull(GeneralSosOutbox.pendingUpload(context))
        GeneralSosOutbox.acknowledge(context, "unrelated_receipt")
        assertTrue(File(directory, "general_sos_pending.json").exists())
        GeneralSosOutbox.acknowledge(context, id)
        assertTrue(GeneralSosOutbox.hasPending(context))
        assertTrue(File(directory, "general_sos_pending.json").exists())
        assertNull(GeneralSosOutbox.pendingUpload(context))
        GeneralSosOutbox.applyStatus(context, id, "RESCUED_SAFE")
        assertTrue(GeneralSosOutbox.isCompleted(context))
        assertFalse(File(directory, "general_sos_pending.json").exists())
    }

    @Test fun explicitNewRequestUsesNewIdentityAfterRemovedReceipt() = isolated { context, directory ->
        val id = GeneralSosOutbox.queue(context, JSONObject().put("device_id", "ISOLATED_TEST_DEVICE"))
        GeneralSosOutbox.acknowledge(context, id)
        // Legacy versions deleted the request after receipt; this state belongs only to this test context.
        File(directory, "general_sos_pending.json").delete()
        context.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE).edit()
            .putBoolean("accepted", false).putBoolean("needs_resend", true).commit()
        assertFalse(GeneralSosOutbox.hasPending(context))
        assertTrue(GeneralSosOutbox.status(context).contains("คำขอเดิมไม่อยู่ในคิว"))
        val resent = GeneralSosOutbox.queue(context, JSONObject().put("device_id", "ISOLATED_TEST_DEVICE").put("urgent_note", "isolated explicit resend"))
        assertNotEquals(id, resent)
        assertTrue(GeneralSosOutbox.hasPending(context))
        assertEquals(resent, JSONObject(File(directory, "general_sos_pending.json").readText()).getString("case_id"))
        assertEquals(resent, GeneralSosOutbox.queue(context, JSONObject()))
    }
    @Test fun removedAcceptedReceiptCannotAutomaticallyReuploadRetainedProfile() = isolated { context, directory ->
        val id = GeneralSosOutbox.queue(context, JSONObject().put("device_id", "ISOLATED_TEST_DEVICE").put("contact_name", "private fixture"))
        GeneralSosOutbox.acknowledge(context, id)
        GeneralSosOutbox.markMissing(context, "unrelated")
        assertTrue(File(directory, "general_sos_pending.json").exists())
        GeneralSosOutbox.markMissing(context, id)
        assertNull(GeneralSosOutbox.pendingUpload(context))
        assertFalse(File(directory, "general_sos_pending.json").exists())
        assertFalse(GeneralSosOutbox.hasPending(context))
        assertFalse(GeneralSosOutbox.isCompleted(context)) // Missing is not a false rescue confirmation.
    }

    @Test fun legacyCriticalRequestUsesRegisteredIdentityAndStableReceipt() {
        val original = JSONObject().put("device_id", "OWN_MODEL").put("case_type", "CRITICAL")
            .put("patient_photo_base64", "isolated_photo_bytes").toString()
        val first = com.rescue.alert.data.EmergencyOutboxManager.prepareSosPayload(original, "OWN_NODE", "OWN_MODEL")
        val second = com.rescue.alert.data.EmergencyOutboxManager.prepareSosPayload(original, "OWN_NODE", "OWN_MODEL")
        assertEquals("OWN_NODE", first.getString("device_id"))
        assertEquals(first.getString("case_id"), second.getString("case_id"))
        assertEquals("isolated_photo_bytes", first.getString("patient_photo_base64"))
        first.put("case_id", "existing_case")
        assertEquals("existing_case", com.rescue.alert.data.EmergencyOutboxManager.prepareSosPayload(first.toString(), "OWN_NODE", "OWN_MODEL").getString("case_id"))
        try {
            com.rescue.alert.data.EmergencyOutboxManager.prepareSosPayload(original, "OTHER_NODE", "OTHER_MODEL")
            fail("Another device must be rejected")
        } catch (_: IllegalArgumentException) { }
    }

    @Test fun completedReceiptKeepsSosHiddenAcrossNewAlertsAndRepeatedStatus() = isolated { context, _ ->
        val id = GeneralSosOutbox.queue(context, JSONObject())
        GeneralSosOutbox.applyStatus(context, "unrelated", "RESCUED_SAFE")
        assertFalse(GeneralSosOutbox.suppressesSos(context))
        GeneralSosOutbox.applyStatus(context, id, "RESCUED_SAFE")
        assertTrue(GeneralSosOutbox.suppressesSos(context))
        context.getSharedPreferences("disaster_state_prefs", Context.MODE_PRIVATE).edit()
            .putString("disaster_alert_id", "NEXT_ALERT").commit()
        GeneralSosOutbox.applyStatus(context, id, "PENDING")
        assertTrue(GeneralSosOutbox.suppressesSos(context))
        assertFalse(GeneralSosOutbox.hasPending(context))
        assertNull(GeneralSosOutbox.pendingUpload(context))
    }

    @Test fun criticalReceiptHidesSosOnlyAfterMatchingCompletion() = isolated { context, _ ->
        GeneralSosOutbox.acknowledgeCritical(context, "CRITICAL_ISOLATED_TEST", "PENDING")
        assertFalse(GeneralSosOutbox.suppressesSos(context))
        GeneralSosOutbox.applyStatus(context, "CRITICAL_OTHER", "RESCUED_SAFE")
        assertFalse(GeneralSosOutbox.suppressesSos(context))
        GeneralSosOutbox.applyStatus(context, "CRITICAL_ISOLATED_TEST", "RESCUED_SAFE")
        assertTrue(GeneralSosOutbox.suppressesSos(context))
        assertTrue(GeneralSosOutbox.consumeSafeScreen(context))
        assertFalse(GeneralSosOutbox.consumeSafeScreen(context))
    }

    @Test fun sosUnlocksAt72HoursWithoutResendingCompletedCase() = isolated { context, _ ->
        val id = GeneralSosOutbox.queue(context, JSONObject())
        GeneralSosOutbox.applyStatus(context, id, "RESCUED_SAFE")
        val state = context.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE)
        val start = state.getLong("completed_at", -1)
        assertTrue(start > 0)
        GeneralSosOutbox.applyStatus(context, id, "RESCUED_SAFE")
        assertEquals(start, state.getLong("completed_at", -1))
        assertTrue(GeneralSosOutbox.isCompleted(context, start + GeneralSosOutbox.RESCUE_COOLDOWN_MS - 1))
        assertFalse(GeneralSosOutbox.isCompleted(context, start + GeneralSosOutbox.RESCUE_COOLDOWN_MS))
        assertFalse(GeneralSosOutbox.hasPending(context))
        assertNull(GeneralSosOutbox.pendingUpload(context))
        GeneralSosOutbox.applyStatus(context, id, "RESCUED_SAFE")
        assertFalse(GeneralSosOutbox.isCompleted(context)) // Late old receipt cannot lock SOS again.
        val newId = GeneralSosOutbox.queue(context, JSONObject())
        assertNotEquals(id, newId)
    }

    @Test fun legacyCompletionStartsOnePersistent72HourWindow() = isolated { context, _ ->
        val state = context.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE)
        state.edit().putBoolean("completed", true).putString("latest", "LEGACY_ISOLATED").commit()
        assertTrue(GeneralSosOutbox.isCompleted(context, 1000))
        assertTrue(GeneralSosOutbox.isCompleted(context, 2000))
        assertEquals(1000, state.getLong("completed_at", -1))
        assertFalse(GeneralSosOutbox.isCompleted(context, 1000 + GeneralSosOutbox.RESCUE_COOLDOWN_MS))
        assertFalse(state.contains("latest"))
    }

    @Test fun criticalCompletionAlsoUnlocksAfter72Hours() = isolated { context, _ ->
        GeneralSosOutbox.acknowledgeCritical(context, "CRITICAL_ISOLATED_COOLDOWN", "PENDING")
        GeneralSosOutbox.applyStatus(context, "CRITICAL_ISOLATED_COOLDOWN", "RESCUED_SAFE")
        val start = context.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE).getLong("completed_at", -1)
        assertTrue(GeneralSosOutbox.isCompleted(context, start + GeneralSosOutbox.RESCUE_COOLDOWN_MS - 1))
        assertFalse(GeneralSosOutbox.isCompleted(context, start + GeneralSosOutbox.RESCUE_COOLDOWN_MS))
        assertFalse(GeneralSosOutbox.suppressesSos(context))
        GeneralSosOutbox.applyStatus(context, "CRITICAL_ISOLATED_COOLDOWN", "RESCUED_SAFE")
        assertFalse(GeneralSosOutbox.isCompleted(context))
    }

}
