package com.rescue.alert.ui

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.*
import androidx.appcompat.widget.SwitchCompat
import com.rescue.alert.R
import com.rescue.alert.util.AppSettings

/**
 * SettingsDialog: Handles Display Scaling configuration (ขนาดดิสเพลย์)
 * and Ultra Power Saving (ประหยัดพลังงานยามไฟดับ).
 */
object SettingsDialog {

    fun show(activity: MainActivity, onSettingsSaved: (displayScaleChanged: Boolean, powerSavingChanged: Boolean) -> Unit) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(activity)
        val dialogView = inflater.inflate(R.layout.dialog_settings, null)
        dialog.setContentView(dialogView)

        dialog.setCanceledOnTouchOutside(false)

        val rgDisplayScale = dialogView.findViewById<RadioGroup>(R.id.rgDisplayScale)
        val rbScale0 = dialogView.findViewById<RadioButton>(R.id.rbScale0)
        val rbScale1 = dialogView.findViewById<RadioButton>(R.id.rbScale1)
        val rbScale2 = dialogView.findViewById<RadioButton>(R.id.rbScale2)
        val rbScale3 = dialogView.findViewById<RadioButton>(R.id.rbScale3)
        val tvPreview = dialogView.findViewById<TextView>(R.id.tvDisplayScalePreview)
        val tvBattery = dialogView.findViewById<TextView>(R.id.tvSettingsBatteryLevel)
        val switchUltra = dialogView.findViewById<SwitchCompat>(R.id.switchUltraPowerSave)
        val switchAuto = dialogView.findViewById<SwitchCompat>(R.id.switchAutoPowerSave)
        val etGatewayUrl = dialogView.findViewById<EditText>(R.id.etGatewayUrl)
        val btnSave = dialogView.findViewById<Button>(R.id.btnSaveSettings)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseSettings)

        val themeGroup = dialogView.findViewById<RadioGroup>(R.id.rgTheme)
        themeGroup.check(if (com.rescue.alert.util.ThemePalette.isLight(activity)) R.id.rbThemeLight else R.id.rbThemeDark)
        themeGroup.setOnCheckedChangeListener { _, checked ->
            val light = checked == R.id.rbThemeLight
            if (light != com.rescue.alert.util.ThemePalette.isLight(activity)) {
                dialog.dismiss()
                com.rescue.alert.util.ThemePalette.setLight(activity, light)
            }
        }

        // 1. Initialize Display Scale
        val currentScaleIndex = AppSettings.getDisplayScaleIndex(activity)
        when (currentScaleIndex) {
            0 -> rbScale0.isChecked = true
            1 -> rbScale1.isChecked = true
            2 -> rbScale2.isChecked = true
            3 -> rbScale3.isChecked = true
        }

        fun updatePreview(index: Int) {
            val previewSizes = listOf(14f, 16.5f, 19f, 21.5f)
            tvPreview.textSize = previewSizes.getOrElse(index) { 14f }
            val labels = listOf("100%", "115%", "130%", "145%")
            tvPreview.text = "ตัวอย่างสเกล ${labels[index]}: แจ้งเตือนภัยฉุกเฉินระดับวิกฤต รับทราบ / ปลอดภัย"
        }
        updatePreview(currentScaleIndex)

        rgDisplayScale.setOnCheckedChangeListener { _, checkedId ->
            val newIndex = when (checkedId) {
                R.id.rbScale1 -> 1
                R.id.rbScale2 -> 2
                R.id.rbScale3 -> 3
                else -> 0
            }
            updatePreview(newIndex)
        }

        // 2. Initialize Ultra Power Saving
        val currentUltra = AppSettings.isUltraPowerSaving(activity)
        val currentAuto = AppSettings.isAutoPowerSaving(activity)
        switchUltra.isChecked = currentUltra
        switchAuto.isChecked = currentAuto

        val rowUltra = dialogView.findViewById<View>(R.id.rowUltraPowerSave)
        val rowAuto = dialogView.findViewById<View>(R.id.rowAutoPowerSave)
        rowUltra?.setOnClickListener {
            switchUltra.isChecked = !switchUltra.isChecked
        }
        rowAuto?.setOnClickListener {
            switchAuto.isChecked = !switchAuto.isChecked
        }

        val batteryLevel = AppSettings.getBatteryPercentage(activity)
        if (batteryLevel >= 0) {
            tvBattery.text = "แบตเตอรี่ $batteryLevel%"
        } else {
            tvBattery.text = "พร้อมประหยัดไฟ"
        }

        // 3. Initialize Gateway Base URL (O-1)
        val currentGatewayUrl = AppSettings.getGatewayBaseUrl(activity)
        etGatewayUrl?.setText(currentGatewayUrl)

        btnSave.setOnClickListener {
            val rawGateway = etGatewayUrl.text.toString().trim()
            val gateway = if (rawGateway.contains("://")) rawGateway else "https://$rawGateway"
            val parsed = runCatching { java.net.URI(gateway) }.getOrNull()
            if (parsed == null || parsed.host.isNullOrBlank() || parsed.scheme != "https" ||
                parsed.rawUserInfo != null || parsed.fragment != null || parsed.query != null ||
                parsed.port !in -1..65535 || parsed.port == 0) {
                etGatewayUrl.error = "ระบุที่อยู่ Gateway ที่ถูกต้อง เช่น https://gateway.example.org"
                return@setOnClickListener
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N &&
                parsed.scheme == "http" && !android.security.NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(parsed.host)) {
                etGatewayUrl.error = "ที่อยู่นี้ต้องใช้ HTTPS ตามการตั้งค่าเครือข่ายของแอป"
                return@setOnClickListener
            }
            val selectedScaleIndex = when (rgDisplayScale.checkedRadioButtonId) {
                R.id.rbScale1 -> 1
                R.id.rbScale2 -> 2
                R.id.rbScale3 -> 3
                else -> 0
            }

            val scaleChanged = selectedScaleIndex != currentScaleIndex
            val newUltra = switchUltra.isChecked
            val newAuto = switchAuto.isChecked
            val powerChanged = (newUltra != currentUltra) || (newAuto != currentAuto)

            AppSettings.setDisplayScaleIndex(activity, selectedScaleIndex)
            AppSettings.setUltraPowerSaving(activity, newUltra)
            AppSettings.setAutoPowerSaving(activity, newAuto)

            AppSettings.setGatewayBaseUrl(activity, gateway)

            dialog.dismiss()
            onSettingsSaved(scaleChanged, powerChanged)
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
        dialog.window?.setLayout(
            (activity.resources.displayMetrics.widthPixels * 0.94).toInt(),
            (activity.resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }
}
