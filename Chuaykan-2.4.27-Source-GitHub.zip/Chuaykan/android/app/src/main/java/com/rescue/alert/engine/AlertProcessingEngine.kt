package com.rescue.alert.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.rescue.alert.R
import com.rescue.alert.source.area.*
import org.json.JSONArray
import com.rescue.alert.model.Point
import com.rescue.alert.security.AlertVerifier
import com.rescue.alert.ui.EmergencyActivity

/**
 * Core disaster alert processing pipeline.
 * Processes verified FCM data messages from AlertPushReceiver only.
 */
object AlertProcessingEngine {

    private const val TAG = "AlertProcessingEngine"
    const val CHANNEL_ID_CRITICAL = "rescue_alert_critical"
    const val CHANNEL_ID_CRITICAL_SILENT = "rescue_alert_critical_silent"
    const val CHANNEL_ID_WARNING = "rescue_alert_warning"
    const val CHANNEL_ID_EARLY_WARNING = "rescue_alert_early_warning"

    enum class ProcessResult {
        TRIGGERED_CRITICAL,
        TRIGGERED_WARNING,
        DROPPED_INVALID_SIGNATURE,
        DROPPED_EXPIRED_OR_REPLAY,
        DROPPED_OUTSIDE_DANGER_ZONE,
        DROPPED_LOCATION_UNAVAILABLE,
        DROPPED_NOT_ACTIONABLE,
        ERROR_MISSING_DATA
    }

    fun processAlert(
        context: Context,
        data: Map<String, String>,
        isMuted: Boolean = true
    ): ProcessResult {
        val alertId = data["alertId"] ?: data["alert_id"] ?: return ProcessResult.ERROR_MISSING_DATA
        val title = data["title"] ?: "แจ้งเตือนภัยฉุกเฉิน"
        val instruction = data["instruction"] ?: "โปรดตรวจสอบความปลอดภัยทันที"
        val sentTime = data["sentTime"]?.toLongOrNull() ?: data["timestamp"]?.toLongOrNull() ?: System.currentTimeMillis()
        val expiresAt = data["expiresAt"]?.toLongOrNull() ?: (System.currentTimeMillis() + 2 * 3600 * 1000L)
        val signature = data["signature"] ?: data["sig"] ?: ""

        Log.i(TAG, "Processing alert: ID=$alertId, Title=$title, Sent=$sentTime")

        // 1. ตรวจสอบความถูกต้อง (Security & Anti-Replay)
        if (!AlertVerifier.verifySignature(alertId, sentTime, signature)) {
            Log.w(TAG, "[SECURITY] Alert signature verification FAILED! Discarding.")
            return ProcessResult.DROPPED_INVALID_SIGNATURE
        }

        // Missing, stale or disabled GPS must remain silent.
        val location = AreaLocation.current(context)
            ?: return ProcessResult.DROPPED_LOCATION_UNAVAILABLE

        val broadcastSender = data["sender"] ?: "Thai Disaster EOC"
        val broadcastEventType = data["eventType"] ?: "GENERAL"
        val broadcastAreaDesc = data["areaDesc"] ?: ""

        val centerLat = data["centerLat"]?.toDoubleOrNull() ?: data["center_lat"]?.toDoubleOrNull()
        val centerLng = data["centerLng"]?.toDoubleOrNull() ?: data["center_lng"]?.toDoubleOrNull()
        val radiusKm = data["radiusKm"]?.toDoubleOrNull() ?: data["radius_km"]?.toDoubleOrNull()
        val polygonStr = data["polygon"]

        var inDangerZone = false

        if (AreaLocation.usable(location)) {
            Log.i(TAG, "Device location: ${location.latitude}, ${location.longitude}")

            if (centerLat != null && centerLng != null && radiusKm != null) {
                inDangerZone = GeoFilterEngine.isInsideCircle(
                    location.latitude, location.longitude,
                    centerLat, centerLng, radiusKm
                )
                Log.i(TAG, "Circle Geofence Check: inZone=$inDangerZone (Radius=${radiusKm}km)")
            } else if (polygonStr != null) {
                val points = polygonStr.split(";").mapNotNull {
                    val parts = it.split(",")
                    if (parts.size == 2) {
                        val lat = parts[0].toDoubleOrNull()
                        val lng = parts[1].toDoubleOrNull()
                        if (lat != null && lng != null) Point(lat, lng) else null
                    } else null
                }
                if (points.isNotEmpty()) {
                    inDangerZone = GeoFilterEngine.isInsidePolygon(
                        location.latitude, location.longitude, points
                    )
                    Log.i(TAG, "Polygon Geofence Check: inZone=$inDangerZone (${points.size} vertices)")
                }
            }

            if (centerLat != null || polygonStr != null) {
                if (!inDangerZone) {
                    Log.i(TAG, "Device is OUTSIDE danger zone. Discarding quietly.")
                    return ProcessResult.DROPPED_OUTSIDE_DANGER_ZONE
                }
            }
        }
        if (!inDangerZone) return ProcessResult.DROPPED_OUTSIDE_DANGER_ZONE
        if (AlertVerifier.isAlreadyProcessedOrExpired(context, alertId, sentTime, expiresAt)) {
            return ProcessResult.DROPPED_EXPIRED_OR_REPLAY
        }
        triggerCriticalNotification(
            context, alertId, title, instruction, isMuted, expiresAt,
            centerLat, centerLng, radiusKm, broadcastSender, broadcastEventType, broadcastAreaDesc,
            polygonStr = polygonStr
        )
        return ProcessResult.TRIGGERED_CRITICAL
    }

    /** Recheck GPS at the notification boundary, including PRA/EXA. */
    fun processOfficialCellBroadcast(context: Context, bulletin: AreaBulletin, provinces: JSONArray): ProcessResult {
        if (bulletin.kind != BulletinKind.WARNING) return ProcessResult.DROPPED_NOT_ACTIONABLE
        if (!AreaAlertPolicy.isCurrent(bulletin.issuedAt, System.currentTimeMillis())) {
            return ProcessResult.DROPPED_EXPIRED_OR_REPLAY
        }
        val device = AreaLocation.resolve(context, provinces)
            ?: return ProcessResult.DROPPED_LOCATION_UNAVAILABLE
        if (!bulletin.isFor(device)) return ProcessResult.DROPPED_OUTSIDE_DANGER_ZONE
        if (AreaLocation.cached(context) != device) return ProcessResult.DROPPED_LOCATION_UNAVAILABLE
        triggerCriticalNotification(
            context, "DPM_${bulletin.id}", bulletin.title, bulletin.message, false,
            bulletin.issuedAt + AreaAlertPolicy.NOTIFICATION_WINDOW_MS,
            sender = bulletin.sender, eventType = bulletin.eventName, areaDesc = device.label,
            targetAreas = bulletin.areas
        )
        return ProcessResult.TRIGGERED_CRITICAL
    }

    private fun triggerCriticalNotification(
        context: Context,
        alertId: String,
        title: String,
        instruction: String,
        isMuted: Boolean,
        expiresAt: Long = 0L,
        centerLat: Double? = null,
        centerLng: Double? = null,
        radiusKm: Double? = null,
        sender: String = "Thai Disaster EOC",
        eventType: String = "GENERAL",
        areaDesc: String = "",
        polygonStr: String? = null,
        targetProvinces: String? = null,
        targetAreas: List<AlertArea>? = null
    ) {
        val strippedTitle = stripEmojis(title)
        val sanitizedTitle = if (strippedTitle.isBlank()) "แจ้งเตือนภัยฉุกเฉิน" else strippedTitle
        val sanitizedInstruction = stripEmojis(instruction)

        // Set active disaster state with strict expiration time and risk area boundaries
        com.rescue.alert.model.DisasterStateManager.setDisasterActive(
            context = context,
            alertId = alertId,
            title = sanitizedTitle,
            instruction = sanitizedInstruction,
            expiresAt = expiresAt,
            centerLat = centerLat,
            centerLng = centerLng,
            radiusKm = radiusKm,
            polygonStr = polygonStr,
            targetProvinces = targetProvinces,
            areaDesc = areaDesc,
            targetAreas = targetAreas
        )
        val stateIntent = Intent("com.rescue.alert.ACTION_DISASTER_STATE_CHANGED").apply {
            putExtra("IS_ACTIVE", true)
            putExtra("INSTRUCTION", sanitizedInstruction)
            putExtra("ALERT_ID", alertId)
            centerLat?.let { putExtra("centerLat", it) }
            centerLng?.let { putExtra("centerLng", it) }
            radiusKm?.let { putExtra("radiusKm", it) }
            polygonStr?.let { putExtra("polygon", it) }
            targetProvinces?.let { putExtra("targetProvinces", it) }
            putExtra("areaDesc", areaDesc)
            setPackage(context.packageName)
        }
        context.sendBroadcast(stateIntent)

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = if (isMuted) CHANNEL_ID_CRITICAL_SILENT else CHANNEL_ID_CRITICAL

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                if (isMuted) "สัญญาณเตือนภัยวิกฤต (โหมดเงียบ)" else "สัญญาณเตือนภัยวิกฤต (Critical)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ใช้สำหรับการเตือนภัยพิบัติระดับร้ายแรงถึงชีวิต"
                if (!isMuted) {
                    val sirenUri = Uri.parse("android.resource://${context.packageName}/${R.raw.siren_critical}")
                    setSound(
                        sirenUri, AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                } else {
                    setSound(null, null)
                }
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                setBypassDnd(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val fullScreenIntent = Intent(context, EmergencyActivity::class.java).apply {
            putExtra("ALERT_ID", alertId)
            putExtra("TITLE", sanitizedTitle)
            putExtra("INSTRUCTION", sanitizedInstruction)
            putExtra("MUTE_SOUND", isMuted)
            putExtra("SENDER", sender)
            putExtra("EVENT_TYPE", eventType)
            putExtra("AREA_DESC", areaDesc)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context, alertId.hashCode(), fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .addExtras(android.os.Bundle().apply {
                if (targetAreas != null) putString("official_alert_id", alertId)
            })
            .setTimeoutAfter((expiresAt - System.currentTimeMillis()).coerceAtLeast(1L))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(sanitizedTitle)
            .setContentText(sanitizedInstruction)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(false)
            .setOngoing(true)
            .build()

        notificationManager.notify(alertId.hashCode(), notification)
        // Full-screen notifications may become heads-up alerts while unlocked.
        // Open immediately when our own UI is visible; background/lockscreen
        // presentation remains under the system's full-screen notification rules.
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        val process = android.app.ActivityManager.RunningAppProcessInfo()
        android.app.ActivityManager.getMyMemoryState(process)
        if (!keyguard.isKeyguardLocked && process.importance == android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
            try { context.startActivity(fullScreenIntent) }
            catch (e: RuntimeException) { Log.w(TAG, "Automatic alert window unavailable; notification retained", e) }
        }
    }

    private fun triggerWarningNotification(context: Context, title: String, body: String) {
        val strippedTitle = stripEmojis(title)
        val sanitizedTitle = if (strippedTitle.isBlank()) "แจ้งเตือนภัยฉุกเฉิน" else strippedTitle
        val sanitizedBody = stripEmojis(body)

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_WARNING,
                "การแจ้งเตือนเฝ้าระวังทั่วไป",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_WARNING)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("เฝ้าระวัง: $sanitizedTitle")
            .setContentText(sanitizedBody)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun triggerEarlyWarningNotification(
        context: Context,
        alertId: String,
        title: String,
        body: String,
        source: String = "Google Alert (Google Crisis Response)",
        targetProvince: String? = null,
        advanceHours: Int? = null,
        webUrl: String? = "https://floodhub.google.com/"
    ) {
        if (!com.rescue.alert.util.AppSettings.isEarlyWarningEnabled(context)) {
            Log.i(TAG, "Early warning notifications disabled by user preference")
            return
        }

        val device = AreaLocation.cached(context) ?: return
        val userProvince = device.label.substringAfterLast(" / ")
        if (targetProvince.isNullOrBlank() || targetProvince.trim() != userProvince) return

        val strippedTitle = stripEmojis(title)
        val sanitizedTitle = if (strippedTitle.isBlank()) "แจ้งเตือนภัยล่วงหน้า" else strippedTitle
        val advanceTag = if (advanceHours != null && advanceHours > 0) " (ล่วงหน้า $advanceHours ชม.)" else ""
        val fullTitle = "เตือนภัยล่วงหน้า: $sanitizedTitle$advanceTag"
        val fullBody = "${stripEmojis(body)}\n[แหล่งอ้างอิง: $source]"

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_EARLY_WARNING,
                "การแจ้งเตือนภัยล่วงหน้า (Google Alert & Early Warnings)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "แจ้งเตือนภัยพิบัติและสภาพอากาศรุนแรงล่วงหน้า เพื่อเตรียมการรับมือ"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(context, com.rescue.alert.ui.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_DISASTER_NEWS", true)
            putExtra("EARLY_WARNING_ALERT_ID", alertId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context, alertId.hashCode(), launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_EARLY_WARNING)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(fullTitle)
            .setContentText(fullBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(fullBody))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify("early_warning".hashCode() + alertId.hashCode(), notification)
    }

    private fun stripEmojis(text: String): String {
        return text.replace(Regex("[\\p{So}\\p{Cn}\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\u2600-\\u26FF\\u2700-\\u27BF\\uFE00-\\uFE0F\\u200D\\u20E3\\u2139]+"), "").trim()
    }
}
