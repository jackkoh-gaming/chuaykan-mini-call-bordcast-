# Chuaykan (Mini Call Broadcast) — EOC 2.4.27 Windows

ช่วยกัน (มินิ คอลบอร์ดเคส) รุ่น Windows x64 จากต้นแบบล่าสุด

## เปิดโปรแกรม

ใช้ Windows 11 x64 ที่ยังได้รับการสนับสนุน หรือ Windows 10 x64 1903 ขึ้นไป
(การรองรับ API ไม่ใช่การยืนยันว่าระบบปฏิบัติการเก่านั้นยังปลอดภัย)
แตก ZIP ทั้งโฟลเดอร์แล้วเปิด Chuaykan.exe ห้ามย้าย EXE ออกจาก _internal
ไม่ต้องลง Python แยก ต้องมี Microsoft Visual C++ Redistributable x64 หากเครื่อง
แจ้งว่า DLL runtime หาย: https://aka.ms/vs/17/release/vc_redist.x64.exe
รุ่นนี้ไม่มี Authenticode certificate; Windows อาจแสดง SmartScreen

ข้อมูลใหม่จะอยู่ที่ %LOCALAPPDATA%\Chuaykan ไม่อยู่ในโฟลเดอร์แจก:
ฐานข้อมูล เคส แคช เสียง log และ credentials เริ่มใหม่ ไม่มีข้อมูลต้นแบบ
ลบโฟลเดอร์ข้อมูลดังกล่าวเมื่อปิดโปรแกรมเพื่อเริ่มใหม่ (ข้อมูลจะสูญหาย)

## Oracle และความเป็นส่วนตัว

ZIP ไม่มี API key, officer token, service account, TLS private key หรือข้อมูลเคส
โปรแกรมไม่เชื่อม Oracle จนกว่าผู้ดูแลจะตั้ง credentials ของตนเอง
หลังเปิดครั้งแรกและปิดโปรแกรม ให้ผู้ดูแลสร้างไฟล์ส่วนตัวใน
%LOCALAPPDATA%\Chuaykan\.secrets\gateway-network:

* cloud.json: {"url":"https://YOUR-GATEWAY.example"}
* officer-token: credential เจ้าหน้าที่ที่ผู้ดูแลเซิร์ฟเวอร์ออกให้
* cloud-ca.pem: ใบรับรองสาธารณะ/CA ที่ใช้ตรวจ TLS ของเกตเวย์จริง

คีย์ TLS ของเครื่องถูกสร้างในเครื่อง ไม่ต้องคัดลอก private key ของ Oracle
ห้ามอัปโหลดโฟลเดอร์ .secrets หรือข้อมูลผู้ใช้งานไป GitHub
Firebase เป็นตัวเลือก ต้องกำหนด credentials ของเซิร์ฟเวอร์เอง ไม่รวมไฟล์ใน ZIP
เมื่อช่วยเหลือเสร็จ ระบบต้นแบบลบรายละเอียดเคสและเก็บจำนวนช่วยแล้วในแคช
ส่วนมือถือส่งข้อมูลส่วนตัวเฉพาะเมื่อผู้ใช้กดขอความช่วยเหลือ

## Bluetooth / ไมค์ / GPS

Windows ใช้ WinRT สำหรับ BLE และ Winsock RFCOMM ช่อง 4/SDP UUID เดิม
ต้องมี adapter/driver ที่รองรับ BLE peripheral/GATT advertising และ RFCOMM
เปิด Bluetooth และอนุญาตการค้นหา/จับคู่ตาม Windows ไม่อนุมัติคู่เอง
หาก adapter ไม่ส่ง service data ให้ตั้งชื่อ Bluetooth/เครื่องที่มือถือเห็นเป็น
EOC-Gateway แล้วทดสอบกับมือถือจริง ไมค์และลำโพงใช้ PortAudio PCM 8 kHz mono
ต้องอนุญาต microphone สำหรับ desktop applications ใน Windows Settings
พิกัดเจ้าหน้าที่ใช้ GPSD ที่ 127.0.0.1:2947 เช่นเดิม ต้องมี GPS/bridge จริง
ไม่มีตำแหน่งจำลอง เมื่อไม่มี GPS จะไม่อ้างพิกัดเจ้าหน้าที่

## นักพัฒนา

โค้ดต้นฉบับโครงการใช้ MIT แก้ไขและเผยแพร่ได้ โดยคงประกาศลิขสิทธิ์
dependency และแผนที่คงใบอนุญาตเดิม ดู THIRD_PARTY_NOTICES.md

บน Windows: Python 3.11 x64 + MinGW-w64 x64 (เช่น MSYS2)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-windows.txt -r requirements-build.txt
$env:CHUAYKAN_MINGW_CC="C:\msys64\mingw64\bin\gcc.exe"
python build_windows.py
```

native/windows_bluetooth.c คือ source DLL พร้อม DLL Windows x64 ที่ตรวจ PE แล้ว
ตั้ง CHUAYKAN_PREBUILT_NATIVE=1 ได้เมื่อเลือกใช้ DLL ที่แนบแทน compile ใหม่
ICU มาจาก Microsoft NuGet และส่งต่อไปยัง API จริง ดู icu-manifest.json
Windows มี ICU ของระบบอยู่แล้ว; native/*.def ใช้สร้าง aliases สำหรับ runtime
ทดสอบ Wine ที่ไม่มี ICU โดยไม่ได้แทน API ด้วยข้อมูลปลอม

```powershell
python tests/test_public_callback.py
python tests/test_windows_socket.py
```

หาก driver กราฟิกมีปัญหา ทดลอง Run-Software-Rendering.cmd ซึ่งปิด GPU
โดยไม่ปิด WebEngine sandbox บน Windows

อ่าน VALIDATION_TH.md ก่อนแจกหรือใช้ปฏิบัติงานจริง
