"""Automatically pair RescueAlert app peers; reject ordinary Bluetooth devices."""
import dbus
import dbus.service
from gi.repository import GLib

AGENT = "org.bluez.Agent1"


class PairingAgent(dbus.service.Object):
    PATH = "/com/rescuealert/eoc/pairing"

    def __init__(self, bus, on_request, service_uuid, is_app_peer=None):
        super().__init__(bus, self.PATH)
        self.bus = bus
        self.on_request = on_request
        self.service_uuid = service_uuid
        self.is_app_peer = is_app_peer
        self.pending = {}

    def _request(self, device, passkey, reply, error):
        properties = dbus.Interface(self.bus.get_object("org.bluez", device),
                                    "org.freedesktop.DBus.Properties").GetAll("org.bluez.Device1")
        label = f"{properties.get('Alias', 'โทรศัพท์')} ({properties.get('Address', device)})"
        app_uuids = {self.service_uuid.lower(), "16690000-fa01-2026-8a8c-2c50f1587bfc"}
        advertised = {str(value).lower() for value in properties.get("UUIDs", [])}
        address = str(properties.get("Address", ""))
        confirmed = bool(app_uuids & advertised)
        if not confirmed and self.is_app_peer:
            confirmed = bool(self.is_app_peer(address))
        if confirmed:
            print("[Pairing] RescueAlert app accepted automatically", flush=True)
            reply()
            if self.on_request:
                self.on_request({"auto_paired": label})
        else:
            print("[Pairing] Rejected device without RescueAlert app identity", flush=True)
            error(dbus.DBusException("Not a verified RescueAlert app peer", name="org.bluez.Error.Rejected"))
        return

    @dbus.service.method(AGENT, in_signature="ou", out_signature="", async_callbacks=("reply", "error"))
    def RequestConfirmation(self, device, passkey, reply, error):
        self._request(device, int(passkey), reply, error)

    @dbus.service.method(AGENT, in_signature="o", out_signature="", async_callbacks=("reply", "error"))
    def RequestAuthorization(self, device, reply, error):
        self._request(device, None, reply, error)

    @dbus.service.method(AGENT, in_signature="os", out_signature="")
    def AuthorizeService(self, device, uuid):
        if str(uuid).lower() != self.service_uuid.lower():
            raise dbus.DBusException("Not a RescueAlert service", name="org.bluez.Error.Rejected")

    @dbus.service.method(AGENT, in_signature="", out_signature="")
    def Cancel(self):
        self.pending.clear()
        if self.on_request:
            self.on_request({"cancel": True})

    @dbus.service.method(AGENT, in_signature="", out_signature="")
    def Release(self):
        self.Cancel()
