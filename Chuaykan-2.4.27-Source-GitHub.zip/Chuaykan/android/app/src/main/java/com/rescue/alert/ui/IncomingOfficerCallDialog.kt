package com.rescue.alert.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.rescue.alert.R
import com.rescue.alert.bluetooth.BluetoothMeshManager

/**
 * Tactical modal dialog presented when a rescue officer or EOC command center
 * initiates an incoming voice call over Bluetooth Mesh.
 * Allows citizen to Answer (รับสาย) or Decline/Hangup (วางสาย).
 */
class IncomingOfficerCallDialog(
    private val context: Context,
    private val callerName: String,
    private val callerNodeId: String,
    private val onCallActionCompleted: ((answered: Boolean) -> Unit)? = null
) {

    private val dialog: Dialog = Dialog(context)
    private var pulseAnimator: ObjectAnimator? = null
    private val meshManager = BluetoothMeshManager.getInstance(context)
    val isShowing: Boolean get() = dialog.isShowing

    fun show() {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.dialog_incoming_officer_call, null)
        dialog.setContentView(view)
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)

        val tvCallerName = view.findViewById<TextView>(R.id.tvIncomingCallerName)
        val tvCallerSub = view.findViewById<TextView>(R.id.tvIncomingCallerSub)
        val ivPhoneIcon = view.findViewById<ImageView>(R.id.ivIncomingCallPhoneIcon)
        val btnAnswer = view.findViewById<Button>(R.id.btnAnswerIncomingCall)
        val btnDecline = view.findViewById<Button>(R.id.btnDeclineIncomingCall)

        tvCallerName.text = callerName.ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
        tvCallerSub.text = "โหนด ID: $callerNodeId • ช่องสัญญาณตรง RFCOMM/GATT"

        // Pulsating phone ring animation
        try {
            pulseAnimator = ObjectAnimator.ofFloat(ivPhoneIcon, "alpha", 1.0f, 0.2f).apply {
                duration = 500
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
            }
            pulseAnimator?.start()
        } catch (e: Exception) {}

        // Answer Call Button
        btnAnswer.setOnClickListener {
            if (context is MainActivity) {
                context.answerOfficerCall()
                if (!meshManager.isInCall()) return@setOnClickListener
            } else {
                meshManager.answerIncomingCall(callerNodeId, callerName)
                if (!meshManager.isInCall()) return@setOnClickListener
            }
            stopPulseAnimation()
            dialog.dismiss()
            onCallActionCompleted?.invoke(true)
        }

        // Decline / Hangup Call Button
        btnDecline.setOnClickListener {
            stopPulseAnimation()
            meshManager.declineIncomingCall(callerNodeId, callerName)
            dialog.dismiss()
            onCallActionCompleted?.invoke(false)
        }

        dialog.setOnDismissListener {
            stopPulseAnimation()
        }

        // BUG-11 FIX: Check Activity lifecycle before showing dialog
        // to prevent BadTokenException when Activity is finishing/destroyed
        val activity = context as? android.app.Activity
        if (activity != null && (activity.isFinishing || activity.isDestroyed)) {
            return
        }

        try {
            dialog.show()
        } catch (e: Exception) {
            // Gracefully handle BadTokenException if Activity was destroyed between check and show
            android.util.Log.w("IncomingOfficerCall", "Failed to show dialog: ${e.message}")
        }
    }

    fun dismiss() {
        try {
            stopPulseAnimation()
            if (dialog.isShowing) {
                dialog.dismiss()
            }
        } catch (e: Exception) {}
    }

    private fun stopPulseAnimation() {
        try {
            pulseAnimator?.cancel()
            pulseAnimator = null
        } catch (e: Exception) {}
    }
}
