package com.rescue.alert.engine

import com.rescue.alert.model.Point
import kotlin.math.*

/**
 * On-device geo-filtering engine.
 * Determines if a device is within a disaster danger zone.
 * Supports both Circle (Haversine) and Polygon (Ray-Casting) geometries.
 */
object GeoFilterEngine {
    private const val EARTH_RADIUS_KM = 6371.0

    /**
     * Haversine formula: checks if device is within a circular danger zone.
     */
    fun isInsideCircle(
        deviceLat: Double, deviceLng: Double,
        centerLat: Double, centerLng: Double,
        radiusKm: Double
    ): Boolean {
        if (!valid(deviceLat, deviceLng) || !valid(centerLat, centerLng) ||
            !radiusKm.isFinite() || radiusKm <= 0) return false
        val dLat = Math.toRadians(centerLat - deviceLat)
        val dLng = Math.toRadians(centerLng - deviceLng)

        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(deviceLat)) * cos(Math.toRadians(centerLat)) *
                sin(dLng / 2).pow(2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (EARTH_RADIUS_KM * c) <= radiusKm
    }

    /**
     * Ray-Casting algorithm: checks if device is within a polygon danger zone.
     * Supports irregular shapes like flood zones or mountain ridges.
     */
    fun isInsidePolygon(
        deviceLat: Double, deviceLng: Double,
        polygon: List<Point>
    ): Boolean {
        if (polygon.size < 3 || !valid(deviceLat, deviceLng) || polygon.any { !valid(it.lat, it.lng) }) return false
        var intersectCount = 0
        val size = polygon.size

        for (i in 0 until size) {
            val j = (i + 1) % size
            val p1 = polygon[i]
            val p2 = polygon[j]

            if (((p1.lat > deviceLat) != (p2.lat > deviceLat)) &&
                (deviceLng < (p2.lng - p1.lng) * (deviceLat - p1.lat) / (p2.lat - p1.lat) + p1.lng)
            ) {
                intersectCount++
            }
        }
        return (intersectCount % 2 != 0)
    }

    private fun valid(lat: Double, lng: Double) = lat.isFinite() && lng.isFinite() &&
        lat in -90.0..90.0 && lng in -180.0..180.0
}
