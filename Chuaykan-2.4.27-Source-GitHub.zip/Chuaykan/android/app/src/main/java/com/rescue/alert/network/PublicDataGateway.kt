package com.rescue.alert.network

import android.content.Context
import com.rescue.alert.util.AppSettings
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Public source requests contain no profile fields or device coordinates. */
object PublicDataGateway {
    @Volatile private var appContext: Context? = null
    fun initialize(context: Context) { appContext = context.applicationContext }

    fun open(upstream: URL): HttpURLConnection {
        require(upstream.protocol == "https" && upstream.userInfo == null && upstream.ref == null && upstream.port in listOf(-1, 443))
        val source = when (upstream.host + upstream.path) {
            "academicndwc.github.io/CBS-DashBoard/data/data.json" -> "official"
            "app.rid.go.th/reservoir/api/dam/public" -> "dam"
            "app.rid.go.th/reservoir/api/reservoir/public" -> "reservoir"
            "app.rid.go.th/reservoir/api/rsvmiddles" -> "middle"
            "api-v3.thaiwater.net/api/v1/thaiwater30/public/waterlevel" -> "water"
            "www5.tmd.go.th/api/xml/CAP" -> "tmd"
            "api-ott.prd.go.th/api/v1/radio/all" -> "radio"
            "api-ott.prd.go.th/api/v1/home/radio/detail" -> "radio_detail"
            "datacatalog.nbtc.go.th/api/3/action/datastore_search" -> "nbtc"
            else -> if (upstream.host == "script.google.com" && upstream.path ==
                "/macros/s/AKfycbypPalKcGpXQXvrGqo3-NFTRfGdhShklY_vrGMwLRsAvQugFaV6-gApi6M-S6MBI5hE6Q/exec" && upstream.query == "type=data") "official"
                else error("Unsupported public source")
        }
        require(source == "nbtc" || upstream.query == null || (source == "official" && upstream.query == "type=data"))
        // NBTC currently refuses Oracle with HTTP 403; preserve its existing public reader.
        // No profile or GPS fields are added to the source request.
        if (source == "nbtc") return upstream.openConnection() as HttpURLConnection
        val context = checkNotNull(appContext) { "Public data client not initialized" }
        val query = if (source == "nbtc") "&query=" + URLEncoder.encode(upstream.query.orEmpty(), "UTF-8") else ""
        return SecureGateway.open(context, URL(AppSettings.DEFAULT_GATEWAY_URL + "/api/public-data?source=" + source + query))
    }
}
