"""
Disaster Alert Gateway - Data Models (CAP-Compatible)
Supports Circle (Center + Radius) and Polygon Geofences.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict
import time
from .crypto import sign_alert, create_signed_timestamps


@dataclass
class Point:
    lat: float
    lng: float

    def to_str(self) -> str:
        return f"{self.lat},{self.lng}"


@dataclass
class DisasterAlert:
    alert_id: str
    title: str
    instruction: str
    severity: str = "CRITICAL"  # "CRITICAL" or "WARNING"
    center_lat: Optional[float] = None
    center_lng: Optional[float] = None
    radius_km: Optional[float] = None
    polygon: Optional[List[Point]] = None
    sent_time: int = 0
    expires_at: int = 0
    signature: str = ""
    is_muted: bool = True
    # RescueAlert Broadcast fields mirror public Cell Broadcast/CAP data.
    sender: str = "Thai Disaster EOC"
    event_type: str = "GENERAL"
    area_desc: str = ""

    def __post_init__(self):
        if not self.sent_time or not self.expires_at:
            self.sent_time, self.expires_at = create_signed_timestamps()
        if not self.signature:
            self.signature = sign_alert(self.alert_id, self.sent_time)

    def to_fcm_data(self) -> Dict[str, str]:
        """
        Converts the alert into a key-value string dictionary.
        Required by FCM Data Payload and Android AlertPushReceiver.
        """
        payload = {
            "alertId": str(self.alert_id),
            "title": str(self.title),
            "instruction": str(self.instruction),
            "severity": str(self.severity),
            "sentTime": str(self.sent_time),
            "expiresAt": str(self.expires_at),
            "signature": str(self.signature),
            "muteSound": "true" if self.is_muted else "false",
            "sender": str(self.sender),
            "eventType": str(self.event_type),
            "areaDesc": str(self.area_desc)
        }
        if self.center_lat is not None and self.center_lng is not None and self.radius_km is not None:
            payload["centerLat"] = str(self.center_lat)
            payload["centerLng"] = str(self.center_lng)
            payload["radiusKm"] = str(self.radius_km)

        if self.polygon:
            payload["polygon"] = ";".join(p.to_str() for p in self.polygon)

        return payload
