#!/usr/bin/env python3
"""
Embedded EOC Dispatch Server
Provides REST endpoints for Android RescueAlert mobile phones,
in-field disaster broadcast, and local audio streaming.
"""
from __future__ import annotations
import base64
import hmac
import hashlib
from collections import OrderedDict
import json
import math
import os
import queue
import re
import socket
import struct
import threading
import time
import urllib.parse
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from src.server.gateway_security import GatewaySecurity
from socketserver import ThreadingMixIn
from typing import Callable, Optional, Dict, Any, List

from src.core.config import RECORDINGS_DIR, DEFAULT_SERVER_PORT
from src.core.database import Database
from src.core.models import SosCase, DisasterZone, EvacuationSite, haversine_km


def _parse_bool(val: Any) -> bool:
    """Strict boolean parser preventing 'false' string from becoming True (Doc 2 H-11)."""
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return val != 0
    if isinstance(val, str):
        return val.strip().lower() in ("true", "1", "yes", "t")
    return False


def _validate_float(val: Any, min_val: float, max_val: float, default: Optional[float] = None) -> Optional[float]:
    """Strict float range validator rejecting NaN and Infinity (Doc 2 H-12)."""
    if val is None:
        return default
    try:
        f = float(val)
        if math.isnan(f) or math.isinf(f):
            return default
        if f < min_val or f > max_val:
            return default
        return f
    except (ValueError, TypeError):
        return default


def _validate_int(val: Any, min_val: int, max_val: int, default: int = 1) -> int:
    """Strict integer validator."""
    if val is None:
        return default
    try:
        i = int(val)
        if i < min_val or i > max_val:
            return default
        return i
    except (ValueError, TypeError):
        return default


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, *args, **kwargs):
        self._slots = threading.BoundedSemaphore(64)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()


class AnnouncementSubscriber:
    """Subscriber for live audio streaming with location coordinates for geo-fencing."""
    def __init__(self, lat: Optional[float], lng: Optional[float]):
        self.lat = lat
        self.lng = lng
        self.queue: queue.Queue = queue.Queue(maxsize=120)
        self.in_risk_zone: bool = False
        self.connected_at: float = time.time()


class AnnouncementBroadcaster:
    """
    Manages live officer mic audio streaming to mobile clients over internet/LAN,
    delivering audio packets exclusively to devices within active pinned risk zones.
    """
    def __init__(self):
        self._subscribers: List[AnnouncementSubscriber] = []
        self._lock = threading.Lock()
        self.is_active = False
        self.announcement_id: Optional[str] = None
        self.active_zones: List[Dict[str, Any]] = []
        self.last_audio_at = 0.0

    def register_subscriber(self, lat: Optional[float], lng: Optional[float], device_id="") -> AnnouncementSubscriber:
        sub = AnnouncementSubscriber(lat, lng)
        sub.device_id = device_id
        with self._lock:
            if self.is_active and self.active_zones and lat is not None and lng is not None:
                sub.in_risk_zone = self._is_in_any_zone(lat, lng, self.active_zones)
            self._subscribers.append(sub)
            # If announcement is already underway, immediately transmit metadata frame
            if self.is_active and self.active_zones:
                meta_frame = self.build_frame(0x01, json.dumps({
                    "type": "META",
                    "announcement_id": self.announcement_id,
                    "zones": self.active_zones
                }, ensure_ascii=False).encode("utf-8"))
                try:
                    sub.queue.put_nowait(meta_frame)
                except queue.Full:
                    pass
        return sub

    def unregister_subscriber(self, sub: AnnouncementSubscriber):
        with self._lock:
            if sub in self._subscribers:
                self._subscribers.remove(sub)

    @staticmethod
    def _is_in_any_zone(lat: float, lng: float, zones: List[Dict[str, Any]]) -> bool:
        for z in zones:
            clat = z.get("center_lat")
            clng = z.get("center_lng")
            r_km = z.get("radius_km", 0.0)
            if clat is not None and clng is not None and r_km > 0:
                dist = haversine_km(clat, clng, lat, lng)
                if dist <= r_km:
                    return True
        return False

    @staticmethod
    def build_frame(frame_type: int, payload: bytes) -> bytes:
        # Binary framing: 1 byte type, 4 bytes big-endian length, payload
        return struct.pack("!BI", frame_type, len(payload)) + payload

    def start_announcement(self, announcement_id: str, zones: List[Dict[str, Any]]):
        with self._lock:
            self.is_active = True
            self.last_audio_at = time.monotonic()
            self.announcement_id = announcement_id
            self.active_zones = zones
            # Re-evaluate all subscribers against pinned risk zones
            for sub in self._subscribers:
                if sub.lat is not None and sub.lng is not None:
                    sub.in_risk_zone = self._is_in_any_zone(sub.lat, sub.lng, zones)
                else:
                    sub.in_risk_zone = False

            meta_data = json.dumps({
                "type": "META",
                "announcement_id": announcement_id,
                "zones": zones
            }, ensure_ascii=False).encode("utf-8")
            frame = self.build_frame(0x01, meta_data)

            for sub in self._subscribers:
                try:
                    sub.queue.put_nowait(frame)
                except queue.Full:
                    pass

    def feed_chunk(self, chunk: bytes):
        if not chunk:
            return
        frame = self.build_frame(0x02, chunk)
        with self._lock:
            if not self.is_active:
                return
            self.last_audio_at = time.monotonic()
            for sub in self._subscribers:
                # Deliver PCM audio only to subscribers inside active pinned risk zones
                if sub.in_risk_zone:
                    try:
                        sub.queue.put_nowait(frame)
                    except queue.Full:
                        # Drop packet when subscriber buffer overflows to maintain real-time low latency
                        pass

    def broadcast_call_frame(self, frame_type: int, payload: bytes, target_device_id=""):
        """Deliver a call only to its authenticated device."""
        frame = self.build_frame(frame_type, payload)
        with self._lock:
            for sub in self._subscribers:
                if target_device_id and getattr(sub, "device_id", "") != target_device_id:
                    continue
                try:
                    sub.queue.put_nowait(frame)
                except queue.Full:
                    pass

    def _stop_locked(self):
        if not self.is_active:
            return
        self.is_active = False
        end_frame = self.build_frame(0x03, b"")
        for sub in self._subscribers:
            try:
                sub.queue.put_nowait(end_frame)
            except queue.Full:
                pass
        self.announcement_id = None
        self.active_zones = []

    def stop_announcement(self):
        with self._lock:
            self._stop_locked()

    def expire_idle(self, timeout=15.0):
        """Oracle owns ending a stream when its microphone source disappears."""
        with self._lock:
            if not self.is_active or time.monotonic() - self.last_audio_at < timeout:
                return False
            self._stop_locked()
            return True


class InternetCallSession:
    def __init__(self):
        self.state = "IDLE"  # IDLE, RINGING, CONNECTED
        self.caller_id = ""
        self.caller_name = ""
        self.target_phone = ""
        self.target_device_id = ""
        self.started_at = 0.0
        self.connected_at = 0.0


class DispatchServer:
    def __init__(self,
                 db: Database,
                 port: int = DEFAULT_SERVER_PORT,
                 on_new_sos: Optional[Callable[[SosCase], None]] = None,
                 on_sos_updated: Optional[Callable[[str, str], None]] = None,
                 on_zone_broadcast: Optional[Callable[[DisasterZone], None]] = None,
                 security: Optional[GatewaySecurity] = None):
        self.db = db
        self.security = security or GatewaySecurity()
        self.port = port
        self.on_new_sos = on_new_sos
        self.on_sos_updated = on_sos_updated
        self.on_zone_broadcast = on_zone_broadcast
        self.announcer = AnnouncementBroadcaster()
        self.call_session = InternetCallSession()
        self.on_call_incoming: Optional[Callable[[str, str, str], None]] = None
        self.on_call_answered: Optional[Callable[[str, str], None]] = None
        self.on_call_ended: Optional[Callable[[], None]] = None
        self.on_citizen_voice: Optional[Callable[[bytes], None]] = None
        self._server: Optional[ThreadedHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self.is_running = False
        self.cloud_bridge = None
        self.on_cloud_status = None
        self.case_lock = threading.RLock()
        self.recently_completed = OrderedDict()
        self.officer_voice = queue.Queue(maxsize=40)
        self.call_lock = threading.RLock()
        from src.server.device_registry import DeviceRegistry
        self.device_registry = DeviceRegistry(self.security.directory / "devices.db", self.security.token)

    def start(self) -> None:
        if self.is_running:
            return

        server_ref = self

        class RequestHandler(BaseHTTPRequestHandler):
            def setup(self):
                self.request.settimeout(10)
                super().setup()

            def log_message(self, format, *args):
                # Suppress noisy standard HTTP logs, store important ones in DB
                pass

            def _send_json(self, data: Any, status_code: int = 200):
                encoded = json.dumps(data, ensure_ascii=False).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(encoded)))
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-API-Key")
                self.end_headers()
                self.wfile.write(encoded)

            def _check_api_key(self) -> bool:
                self.auth_device_id = None
                if self._check_officer_key():
                    return True
                provided = self.headers.get("X-API-Key", "")
                self.auth_device_id = server_ref.device_registry.authenticate(provided)
                if self.auth_device_id:
                    return True
                # Legacy LAN pairing remains available during the mobile update only.
                return not server_ref.security.officer_token and bool(provided and hmac.compare_digest(provided, server_ref.security.token))

            def _check_officer_key(self):
                expected = getattr(server_ref.security, 'officer_token', '')
                provided = self.headers.get('X-Officer-Key', '')
                return bool(expected and provided and hmac.compare_digest(expected, provided))

            def do_OPTIONS(self):
                self.send_response(200)
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-API-Key")
                self.end_headers()

            def _handle_public_data(self):
                cache = getattr(server_ref, "public_data", None)
                if cache is None:
                    self._send_json({"error": "Public data service unavailable"}, status_code=503)
                    return
                try:
                    params = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query, strict_parsing=True)
                    if set(params) - {"source", "query"} or any(len(v) != 1 for v in params.values()):
                        raise ValueError("Invalid public data parameters")
                    size = int(self.headers.get("Content-Length", 0))
                    if not 0 <= size <= 256:
                        raise ValueError("Invalid public body")
                    key = cache.key(params.get("source", [""])[0], params.get("query", [""])[0], self.rfile.read(size) if size else b"")
                except (ValueError, TypeError, KeyError):
                    self._send_json({"error": "Only approved public requests allowed"}, status_code=400)
                    return
                try:
                    raw, content_type, fetched = cache.get(key)
                except Exception:
                    self._send_json({"error": "Public upstream unavailable"}, status_code=502)
                    return
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("X-Public-Cache-Age", str(int(time.monotonic() - fetched)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                path = self.path.split("?")[0]
                if not self._check_api_key():
                    self._send_json({"error": "Pairing required"}, status_code=401)
                    return
                if (path == "/api/sos/list" and not self._check_officer_key()) or path.startswith("/recordings/"):
                    self._send_json({"error": "Available only in officer desktop"}, status_code=403)
                    return

                if path == "/api/public-data":
                    self._handle_public_data()
                    return
                if path == "/api/health":
                    self._send_json({"status": "ONLINE", "timestamp": time.time()})

                elif path == "/api/alert/active":
                    zones = server_ref.db.get_active_zones()
                    if zones:
                        self._send_json({
                            "status": "ACTIVE",
                            "count": len(zones),
                            "zone": zones[0].to_dict(),
                            "zones": [z.to_dict() for z in zones]
                        })
                    else:
                        self._send_json({"status": "NONE", "message": "No active disaster zone"})

                elif path == "/api/sos/status":
                    query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                    case = server_ref.db.get_sos_case(query.get("case_id", [""])[0])
                    if self.auth_device_id and self.auth_device_id != query.get("device_id", [""])[0]:
                        self._send_json({"error": "Device does not own this request"}, status_code=403)
                    elif not case and server_ref.was_completed(query.get("case_id", [""])[0], query.get("device_id", [""])[0]):
                        self._send_json({"status": "SUCCESS", "case_id": query.get("case_id", [""])[0], "case_status": "RESCUED_SAFE"})
                    elif not case:
                        self._send_json({"status": "ERROR", "message": "ไม่พบเคส"}, status_code=404)
                    elif case.case_type != "GENERAL" or case.device_id != query.get("device_id", [""])[0] or (self.auth_device_id and case.device_id != self.auth_device_id):
                        self._send_json({"status": "ERROR", "message": "เคสไม่ตรงกับเครื่อง"}, status_code=403)
                    else:
                        self._send_json({"status": "SUCCESS", "case_id": case.case_id, "case_status": case.status})

                elif path == "/api/cloud/attachment":
                    if not self._check_officer_key():
                        self._send_json({"error": "Officer authorization required"}, status_code=403)
                        return
                    params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                    name = params.get("name", [""])[0]
                    allowed = {value for case in server_ref.db.get_all_sos_cases() for value in (case.photo_file, case.audio_file) if value}
                    from pathlib import Path
                    if name not in allowed or Path(name).name != name or not (RECORDINGS_DIR / name).is_file():
                        self._send_json({"error": "Attachment not found"}, status_code=404)
                        return
                    self._send_json({"data": base64.b64encode((RECORDINGS_DIR / name).read_bytes()).decode()})

                elif path == "/api/sos/list":
                    if server_ref.security.officer_token and not self._check_officer_key():
                        self._send_json({"error": "Officer authorization required"}, status_code=403)
                        return
                    cases = server_ref.db.get_all_sos_cases()
                    zone = server_ref.db.get_active_zone()
                    case_dicts = []
                    for c in cases:
                        c.update_zone_status(zone)
                        case_dicts.append(c.to_dict())
                    self._send_json({"count": len(case_dicts), "cases": case_dicts, "list": case_dicts})

                elif path in ("/api/evacuation/sites", "/api/shelters"):
                    sites = server_ref.db.get_active_evacuation_sites()
                    self._send_json({
                        "status": "SUCCESS",
                        "count": len(sites),
                        "sites": [s.to_dict() for s in sites]
                    })

                elif path == "/api/news/disaster":
                    zone = server_ref.db.get_active_zone()
                    news_items = [
                        {
                            "id": zone.zone_id,
                            "title": zone.title,
                            "summary": zone.instruction,
                            "source": zone.agency,
                            "category": "CRITICAL" if zone.severity == "CRITICAL" else "WARNING",
                            "published_at": zone.created_at
                        }
                    ] if zone else []
                    self._send_json({"news": news_items})

                elif path == "/api/announcement/stream":
                    parsed_url = urllib.parse.urlparse(self.path)
                    query_params = urllib.parse.parse_qs(parsed_url.query)
                    lat_str = query_params.get("lat", [None])[0]
                    lng_str = query_params.get("lng", [None])[0]
                    lat_val = _validate_float(lat_str, -90.0, 90.0, None)
                    lng_val = _validate_float(lng_str, -180.0, 180.0, None)
                    sub = server_ref.announcer.register_subscriber(lat_val, lng_val, self.auth_device_id or "")
                    if server_ref.call_session.state == "RINGING" and self.auth_device_id == server_ref.call_session.target_device_id:
                        sub.queue.put_nowait(server_ref.announcer.build_frame(0x10, json.dumps({"caller_name": server_ref.call_session.caller_name}).encode()))
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                    self.send_header("Pragma", "no-cache")
                    self.send_header("Connection", "keep-alive")
                    self.end_headers()

                    last_heartbeat = time.time()
                    try:
                        while server_ref.is_running:
                            try:
                                data = sub.queue.get(timeout=1.0)
                                self.wfile.write(data)
                                self.wfile.flush()
                                last_heartbeat = time.time()
                            except queue.Empty:
                                if time.time() - last_heartbeat >= 3.0:
                                    heartbeat_frame = server_ref.announcer.build_frame(0x00, b"")
                                    self.wfile.write(heartbeat_frame)
                                    self.wfile.flush()
                                    last_heartbeat = time.time()
                    except (ConnectionResetError, BrokenPipeError, socket.error, Exception):
                        pass
                    finally:
                        server_ref.announcer.unregister_subscriber(sub)
                    return

                elif path == "/api/call/officer/stream":
                    if not self._check_officer_key():
                        self._send_json({"error": "Officer required"}, 403)
                        return
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.end_headers()
                    try:
                        while server_ref.is_running:
                            try:
                                pcm = server_ref.officer_voice.get(timeout=2)
                            except queue.Empty:
                                pcm = b""
                            self.wfile.write(server_ref.announcer.build_frame(0x31 if pcm else 0, pcm))
                            self.wfile.flush()
                    except (OSError, Exception):
                        pass
                    return
                elif path == "/api/call/status":
                    if self.auth_device_id and self.auth_device_id != server_ref.call_session.target_device_id:
                        self._send_json({"state": "IDLE"})
                        return
                    self._send_json({
                        "state": server_ref.call_session.state,
                        "caller_id": server_ref.call_session.caller_id,
                        "caller_name": server_ref.call_session.caller_name,
                        "target_phone": server_ref.call_session.target_phone,
                        "target_device_id": server_ref.call_session.target_device_id,
                        "connected_at": server_ref.call_session.connected_at
                    })

                elif path == "/api/announcement/active":
                    self._send_json({
                        "is_active": server_ref.announcer.is_active,
                        "announcement_id": server_ref.announcer.announcement_id,
                        "zones": server_ref.announcer.active_zones
                    })

                elif path.startswith("/recordings/"):
                    filename = os.path.basename(path)
                    # Path traversal defense
                    filename = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", filename)
                    file_path = RECORDINGS_DIR / filename
                    if file_path.exists() and file_path.is_file():
                        self.send_response(200)
                        self.send_header("Content-Type", "audio/mp4")
                        self.send_header("Content-Length", str(file_path.stat().st_size))
                        self.send_header("Accept-Ranges", "bytes")
                        self.end_headers()
                        with open(file_path, "rb") as f:
                            self.wfile.write(f.read())
                    else:
                        self._send_json({"error": "File not found"}, status_code=404)
                else:
                    self._send_json({"error": "Endpoint not found"}, status_code=404)

            def do_POST(self):
                path = self.path.split("?")[0]
                if path == "/api/device/register":
                    try:
                        size = int(self.headers.get("Content-Length", 0))
                        if not 0 < size <= 2048:
                            raise ValueError("Invalid registration size")
                        payload = json.loads(self.rfile.read(size))
                        if not isinstance(payload, dict):
                            raise ValueError("Invalid registration")
                        self._send_json(server_ref.device_registry.register(payload, self.client_address[0]))
                    except PermissionError:
                        self._send_json({"error": "Registration refused"}, status_code=403)
                    except (ValueError, TypeError):
                        self._send_json({"error": "Invalid registration"}, status_code=400)
                    return
                if not self._check_api_key():
                    self._send_json({"error": "Pairing required"}, status_code=401)
                    return
                if path == "/api/public-data":
                    self._handle_public_data()
                    return
                if path in ("/api/evacuation/sites", "/api/shelters", "/api/evacuation/sites/delete", "/api/shelters/delete", "/api/zone/broadcast", "/api/alert/broadcast", "/api/announcement/start", "/api/announcement/chunk", "/api/announcement/stop", "/api/sos/update_status", "/api/sos/complete", "/api/call/start", "/api/call/officer/voice", "/api/cloud/sync") and not self._check_officer_key():
                    self._send_json({"error": "Officer desktop required"}, status_code=403)
                    return
                try:
                    content_length = int(self.headers.get("Content-Length", 0))
                except ValueError:
                    self._send_json({"error": "Invalid content length"}, status_code=400)
                    return
                if not 0 <= content_length <= 12 * 1024 * 1024:
                    self._send_json({"error": "Body too large"}, status_code=413)
                    return

                if path == "/api/cloud/sync":
                    try:
                        payload = json.loads(self.rfile.read(content_length))
                        result = server_ref._cloud_sync(payload)
                        self._send_json(result)
                    except (ValueError, TypeError, KeyError) as exc:
                        self._send_json({"error": "Invalid synchronization payload"}, status_code=400)
                    return
                if path in ("/api/call/answer", "/api/call/hangup", "/api/call/voice/send"):
                    target = server_ref.call_session.target_device_id
                    if self.auth_device_id and (not target or self.auth_device_id != target):
                        # Drain the bounded request before closing TLS; Windows can
                        # otherwise reset the socket and discard the 403 response.
                        self.rfile.read(content_length)
                        self._send_json({"error": "Device is not the call participant"}, 403)
                        return
                if path == "/api/call/voice/send":
                    raw_pcm = self.rfile.read(content_length) if content_length > 0 else b""
                    if raw_pcm:
                        server_ref.feed_citizen_call_voice(raw_pcm)
                    self._send_json({"status": "SUCCESS", "bytes_received": len(raw_pcm)})
                    return

                body = self.rfile.read(content_length).decode("utf-8", errors="ignore")

                try:
                    payload = json.loads(body) if body else {}
                except Exception:
                    self._send_json({"error": "Invalid JSON format"}, status_code=400)
                    return

                if path == "/api/call/start":
                    phone = payload.get("target_phone", "")
                    name = payload.get("citizen_name", "ผู้ประสบภัย")
                    try:
                        server_ref.start_internet_call(phone, name, case_id=payload.get("case_id", ""))
                    except ValueError:
                        self._send_json({"error": "Case/device missing or another call active"}, 409)
                        return
                    if getattr(server_ref, "on_call_outgoing", None):
                        try:
                            server_ref.on_call_outgoing(phone, name)
                        except Exception:
                            pass
                    self._send_json({"status": "CALLING", "target_phone": phone, "citizen_name": name})

                elif path == "/api/call/officer/voice":
                    pcm = base64.b64decode(payload.get("pcm_base64", ""), validate=True)
                    if len(pcm) > 64000:
                        self._send_json({"error": "Audio chunk too large"}, 413)
                        return
                    server_ref.feed_officer_call_voice(pcm)
                    self._send_json({"status": "SUCCESS"})
                elif path == "/api/call/request":
                    if server_ref.call_session.state != "IDLE":
                        self._send_json({"error": "Another call active"}, 409)
                        return
                    cid = self.auth_device_id or payload.get("caller_id", "MOBILE")
                    cname = payload.get("caller_name", "ผู้ประสบภัย")
                    phone = payload.get("phone", "")
                    server_ref.call_session.state = "RINGING"
                    server_ref.call_session.caller_id = cid
                    server_ref.call_session.target_device_id = self.auth_device_id or cid
                    server_ref.call_session.caller_name = cname
                    server_ref.call_session.target_phone = phone
                    server_ref.call_session.started_at = time.time()
                    if server_ref.on_call_incoming:
                        server_ref.on_call_incoming(cname, phone, cid)
                    self._send_json({"status": "RINGING"})

                elif path == "/api/call/answer":
                    if server_ref.call_session.state != "RINGING":
                        self._send_json({"error": "No ringing call"}, 409)
                        return
                    cid = payload.get("client_id", "")
                    cname = payload.get("client_name", "")
                    server_ref.call_session.state = "CONNECTED"
                    server_ref.call_session.connected_at = time.time()
                    if self._check_officer_key():
                        server_ref.announcer.broadcast_call_frame(0x13, b"", server_ref.call_session.target_device_id)
                    if server_ref.on_call_answered:
                        server_ref.on_call_answered(cname, cid)
                    self._send_json({"status": "CONNECTED"})

                elif path == "/api/call/hangup":
                    server_ref.hangup_internet_call()
                    self._send_json({"status": "IDLE"})

                elif path in ("/api/sos/report", "/api/sos"):
                    if self.auth_device_id and payload.get("device_id") != self.auth_device_id:
                        self._send_json({"error": "Device does not own this request"}, status_code=403)
                        return
                    server_ref._handle_sos_report(payload, self)

                elif path in ("/api/sos/update_status", "/api/sos/complete"):
                    if not self._check_api_key():
                        self._send_json({"error": "Unauthorized: Invalid or missing X-API-Key"}, status_code=401)
                        return

                    case_id = payload.get("case_id")
                    default_status = "RESCUED_SAFE" if path == "/api/sos/complete" else "DISPATCHED"
                    status = payload.get("status", default_status)
                    team = payload.get("team", "")
                    if not case_id:
                        self._send_json({"error": "Missing case_id"}, status_code=400)
                        return
                    if status == "RESCUED_SAFE":
                        if server_ref.cloud_bridge:
                            server_ref.cloud_bridge.complete_case(case_id)
                        else:
                            server_ref.complete_case(case_id)
                        if server_ref.on_sos_updated:
                            server_ref.on_sos_updated(case_id, status)
                        self._send_json({"status": "SUCCESS", "case_id": case_id, "new_status": status})
                        return
                    updated = server_ref.db.update_case_status(case_id, status, team)
                    if updated:
                        server_ref.db.log_event("INFO", "STATUS_CHANGE", f"เปลี่ยนสถานะ {case_id} เป็น {status}", f"ทีม: {team}")
                        if server_ref.on_sos_updated:
                            server_ref.on_sos_updated(case_id, status)
                        self._send_json({"status": "SUCCESS", "case_id": case_id, "new_status": status})
                    else:
                        self._send_json({"error": "Case not found"}, status_code=404)

                elif path == "/api/alert/broadcast":
                    if not self._check_api_key():
                        self._send_json({"error": "Unauthorized: Invalid or missing X-API-Key"}, status_code=401)
                        return

                    server_ref._handle_broadcast_alert(payload, self)

                elif path == "/api/announcement/start":
                    zones = payload.get("zones")
                    if not zones:
                        active_db_zones = server_ref.db.get_active_zones()
                        zones = [z.to_dict() for z in active_db_zones if z.is_active]
                    ann_id = payload.get("announcement_id") or f"ANNOUNCE_{int(time.time()*1000)}"
                    server_ref.start_announcement(ann_id, zones)
                    self._send_json({"status": "SUCCESS", "announcement_id": ann_id, "zones": zones})

                elif path == "/api/announcement/chunk":
                    b64_data = payload.get("pcm_base64", "")
                    if b64_data:
                        try:
                            raw_pcm = base64.b64decode(b64_data)
                            server_ref.feed_announcement_chunk(raw_pcm)
                            self._send_json({"status": "SUCCESS", "bytes_sent": len(raw_pcm)})
                        except Exception as e:
                            self._send_json({"error": str(e)}, status_code=400)
                    else:
                        self._send_json({"error": "Missing pcm_base64"}, status_code=400)

                elif path == "/api/announcement/stop":
                    server_ref.stop_announcement()
                    self._send_json({"status": "SUCCESS", "message": "Announcement stopped"})

                elif path in ("/api/evacuation/sites", "/api/shelters"):
                    site_id = payload.get("site_id") or f"SITE_{int(time.time())}"
                    name = payload.get("name", "ศูนย์ช่วยเหลือ/อพยพ")
                    site_type = payload.get("site_type", "SHELTER")
                    lat = _validate_float(payload.get("latitude"), -90.0, 90.0, 0.0)
                    lng = _validate_float(payload.get("longitude"), -180.0, 180.0, 0.0)
                    capacity = _validate_int(payload.get("capacity"), 0, 100000, 100)
                    contact = payload.get("contact_phone", "")
                    notes = payload.get("notes", "")
                    is_active = _parse_bool(payload.get("is_active", True))
                    site = EvacuationSite(
                        site_id=site_id,
                        name=name,
                        site_type=site_type,
                        latitude=lat or 0.0,
                        longitude=lng or 0.0,
                        capacity=capacity,
                        contact_phone=contact,
                        notes=notes,
                        is_active=is_active
                    )
                    server_ref.db.upsert_evacuation_site(site)
                    self._send_json({"status": "SUCCESS", "site": site.to_dict()})

                elif path in ("/api/evacuation/sites/delete", "/api/shelters/delete"):
                    site_id = payload.get("site_id")
                    if not site_id:
                        self._send_json({"error": "Missing site_id"}, status_code=400)
                        return
                    server_ref.db.delete_evacuation_site(site_id)
                    self._send_json({"status": "SUCCESS", "deleted_id": site_id})

                else:
                    self._send_json({"error": "Unknown POST endpoint"}, status_code=404)

        try:
            self._server = ThreadedHTTPServer(("0.0.0.0", self.port), RequestHandler)
            self._server.socket = self.security.context.wrap_socket(
                self._server.socket, server_side=True, do_handshake_on_connect=False)
            self.is_running = True
            self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
            self._thread.start()
            from src.server.cloud_bridge import CloudBridge
            self.cloud_bridge = CloudBridge.configured(self)
            if self.cloud_bridge:
                self.security.public_url = self.cloud_bridge.url
                self.cloud_bridge.start()
            self.db.log_event("INFO", "SERVER_START", f"EOC Dispatch Server เริ่มทำงานบนพอร์ต {self.port}")
        except Exception as e:
            self.is_running = False
            self.db.log_event("ERROR", "SERVER_ERROR", f"ไม่สามารถเปิดพอร์ต {self.port}: {str(e)}")
            raise

    def _cloud_sync(self, payload):
        from dataclasses import fields
        zones = payload.get('zones', [])
        if not isinstance(zones, list) or len(zones) > 11:
            raise ValueError('Invalid zones')
        valid = {field.name for field in fields(DisasterZone)}
        parsed_zones = []
        for data in zones:
            zone = DisasterZone(**{key: value for key, value in data.items() if key in valid})
            if not (-90 <= zone.center_lat <= 90 and -180 <= zone.center_lng <= 180 and 0 < zone.radius_km <= 500):
                raise ValueError('Invalid zone geometry')
            parsed_zones.append(zone)
        mic_count = sum(zone.zone_id == "MIC_ZONE_01" for zone in parsed_zones)
        if mic_count > 1 or len(parsed_zones) - mic_count > 10:
            raise ValueError('Invalid zone groups')
        self.db.replace_active_zones(parsed_zones)
        site_fields = {field.name for field in fields(EvacuationSite)}
        sites = payload.get('sites', [])
        site_ids = set()
        for data in sites:
            site = EvacuationSite(**{key: value for key, value in data.items() if key in site_fields})
            self.db.upsert_evacuation_site(site)
            site_ids.add(site.site_id)
        for site in self.db.get_all_evacuation_sites():
            if site.site_id not in site_ids:
                self.db.delete_evacuation_site(site.site_id)
        class Receipt:
            result = None
            def _send_json(self, result, status_code=200):
                self.result = result
                if status_code >= 400:
                    raise ValueError('Case upload rejected')
        for data in payload.get('uploads', []):
            if data.get('status') == 'RESCUED_SAFE':
                self.complete_case(data['case_id'])
                continue
            receipt = Receipt()
            self._handle_sos_report(data, receipt)
            status = data.get('status', 'PENDING')
            if status in ('DISPATCHED', 'RESCUED_SAFE'):
                self.db.update_case_status(data['case_id'], status, data.get('assigned_team', ''))
        for update in payload.get('updates', []):
            status = update['status']
            if status not in ('PENDING', 'DISPATCHED', 'RESCUED_SAFE'):
                raise ValueError('Invalid case status')
            if status == 'RESCUED_SAFE':
                self.complete_case(update['case_id'])
            else:
                self.db.update_case_status(update['case_id'], status, update.get('team', ''))
        # No completed personal record, attachment or history is retained.
        for cid in payload.get('deleted', []):
            self.complete_case(cid)
        return {'status': 'SUCCESS', 'cases': [case.to_dict() for case in self.db.get_all_sos_cases()]}

    def start_announcement(self, announcement_id: str, zones: List[Dict[str, Any]]) -> None:
        """Start streaming officer microphone announcement to risk zones."""
        self.announcer.start_announcement(announcement_id, zones)
        if self.cloud_bridge:
            self.cloud_bridge.publish("start", {"announcement_id": announcement_id, "zones": zones})

    def feed_announcement_chunk(self, chunk: bytes) -> None:
        """Feed PCM audio chunk to active subscribers inside risk zones."""
        self.announcer.feed_chunk(chunk)
        if self.cloud_bridge:
            self.cloud_bridge.publish("audio", chunk)

    def stop_announcement(self) -> None:
        """End live announcement and signal all mobile clients."""
        self.announcer.stop_announcement()
        if self.cloud_bridge:
            self.cloud_bridge.publish("stop")

    def start_internet_call(self, target_phone: str, citizen_name: str = "", case_id: str = "") -> None:
        with self.call_lock:
            self._start_internet_call_locked(target_phone, citizen_name, case_id)

    def _start_internet_call_locked(self, target_phone, citizen_name, case_id):
        case = self.db.get_sos_case(case_id) if case_id else next((c for c in self.db.get_all_sos_cases() if target_phone and c.phone_number == target_phone), None)
        if case is None or not case.device_id or self.call_session.state != "IDLE":
            raise ValueError("Call target unavailable")
        if self.cloud_bridge:
            reply = self.cloud_bridge.request("/api/call/start", {"case_id": case.case_id, "target_phone": target_phone, "citizen_name": citizen_name})
            if reply.get("status") != "CALLING":
                raise ValueError("Cloud call rejected")
        while not self.officer_voice.empty():
            try:
                self.officer_voice.get_nowait()
            except queue.Empty:
                break
        self.call_session.target_device_id = case.device_id
        self.call_session.state = "RINGING"
        self.call_session.caller_id = "EOC"
        self.call_session.caller_name = "เจ้าหน้าที่ศูนย์สั่งการ EOC"
        self.call_session.target_phone = target_phone
        self.call_session.started_at = time.time()
        payload = json.dumps({
            "caller": "EOC",
            "caller_name": "เจ้าหน้าที่ศูนย์สั่งการ EOC",
            "target_phone": target_phone,
            "citizen_name": citizen_name
        }, ensure_ascii=False).encode("utf-8")
        self.announcer.broadcast_call_frame(0x10, payload, self.call_session.target_device_id)

    def answer_internet_call(self) -> None:
        if self.cloud_bridge:
            self.cloud_bridge.request("/api/call/answer", {})
        self.call_session.state = "CONNECTED"
        self.call_session.connected_at = time.time()
        self.announcer.broadcast_call_frame(0x13, b"", self.call_session.target_device_id)

    def hangup_internet_call(self) -> None:
        if self.cloud_bridge:
            self.cloud_bridge.request("/api/call/hangup", {})
            self.cloud_bridge.call_audio.clear()
        self.call_session.state = "IDLE"
        self.announcer.broadcast_call_frame(0x12, b"", self.call_session.target_device_id)
        self.call_session.target_device_id = ""
        self.call_session.target_phone = ""
        if self.on_call_ended:
            try:
                self.on_call_ended()
            except Exception:
                pass

    def feed_officer_call_voice(self, pcm_chunk: bytes) -> None:
        if self.call_session.state == "CONNECTED" and pcm_chunk:
            if self.cloud_bridge:
                self.cloud_bridge.publish("call_audio", pcm_chunk)
            else:
                self.announcer.broadcast_call_frame(0x11, pcm_chunk, self.call_session.target_device_id)

    def feed_citizen_call_voice(self, pcm_chunk: bytes) -> None:
        if self.call_session.state == "CONNECTED":
            try:
                self.officer_voice.put_nowait(pcm_chunk)
            except queue.Full:
                pass
        if self.call_session.state == "CONNECTED" and self.on_citizen_voice:
            try:
                self.on_citizen_voice(pcm_chunk)
            except Exception:
                pass

    def stop(self) -> None:
        if self.cloud_bridge:
            self.cloud_bridge.stop()
        if self.announcer:
            self.announcer.stop_announcement()
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self.is_running = False

    def _completion_key(self, case_id, device_id):
        return hmac.new(self.security.token.encode(), (str(case_id) + "\0" + str(device_id)).encode(), hashlib.sha256).digest()

    def was_completed(self, case_id, device_id):
        with self.case_lock:
            key = self._completion_key(case_id, device_id)
            expiry = self.recently_completed.get(key, 0)
            if expiry <= time.monotonic():
                self.recently_completed.pop(key, None)
                return False
            return True

    def complete_case(self, case_id, *, count=False):
        with self.case_lock:
            case = self.db.get_sos_case(case_id)
            if case is None:
                return False
            changed = self.db.finish_sos_case(case_id, count=count)
            if changed:
                self.recently_completed[self._completion_key(case_id, case.device_id)] = time.monotonic() + 86400
                while len(self.recently_completed) > 10000:
                    self.recently_completed.popitem(last=False)
            return changed

    def _handle_sos_report(self, payload: Dict[str, Any], handler: BaseHTTPRequestHandler):
        with self.case_lock:
            self._handle_sos_report_locked(payload, handler)

    def _handle_sos_report_locked(self, payload: Dict[str, Any], handler: BaseHTTPRequestHandler):
        device_id = str(payload.get("device_id") or "UNKNOWN_DEVICE")
        # Sanitize device ID
        device_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", device_id)

        case_id = payload.get("case_id") or f"CASE_{int(time.time()*1000)}_{uuid.uuid4().hex[:6]}"
        case_type = payload.get("case_type") or ("GENERAL" if payload.get("alert_id") == "OFFICER_APPROACHING_SOS" else "CRITICAL")
        if case_type not in ("GENERAL", "CRITICAL") or not isinstance(case_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,120}", case_id):
            handler._send_json({"status": "ERROR", "message": "ประเภทหรือเลขเคสไม่ถูกต้อง"}, status_code=400)
            return
        if self.was_completed(case_id, device_id):
            handler._send_json({"status": "SUCCESS", "case_id": case_id, "case_type": case_type, "case_status": "RESCUED_SAFE"})
            return
        existing = self.db.get_sos_case(case_id)
        if existing:
            if existing.device_id != device_id or existing.case_type != case_type:
                handler._send_json({"status": "ERROR", "message": "เลขเคสนี้เป็นของคำขออื่น"}, status_code=409)
            else:
                handler._send_json({"status": "SUCCESS", "case_id": case_id, "case_type": case_type, "case_status": existing.status}, status_code=200)
            return
        citizen_name = str(payload.get("contact_name") or payload.get("citizen_name") or payload.get("name") or "ผู้ประสบภัย")
        phone_number = str(payload.get("contact_phone") or payload.get("phone_number") or payload.get("phone") or "")

        lat_raw = payload.get("lat") if ("lat" in payload and payload.get("lat") is not None) else payload.get("latitude")
        lng_raw = payload.get("lng") if ("lng" in payload and payload.get("lng") is not None) else payload.get("longitude")
        lat = _validate_float(lat_raw, -90.0, 90.0, None)
        lng = _validate_float(lng_raw, -180.0, 180.0, None)

        acc_raw = payload.get("accuracy") if ("accuracy" in payload and payload.get("accuracy") is not None) else payload.get("accuracy_meters")
        acc = _validate_float(acc_raw, 0.1, 50000.0, 15.0) or 15.0

        members = _validate_int(payload.get("member_count"), 1, 100, 1)
        bedridden = _parse_bool(payload.get("is_bedridden"))
        elderly = _parse_bool(payload.get("is_elderly"))
        infant = _parse_bool(payload.get("is_infant"))
        needs = str(payload.get("urgent_needs") or "")
        note = str(payload.get("urgent_note") or "")

        # Process distress audio if present (with hard size checks, Doc 2 H-14)
        audio_filename = None
        audio_b64 = payload.get("voice_audio_base64") or payload.get("audio_base64")
        if audio_b64 and isinstance(audio_b64, str) and 100 < len(audio_b64) <= 7_000_000:
            try:
                audio_bytes = base64.b64decode(audio_b64)
                if len(audio_bytes) <= 5 * 1024 * 1024:
                    safe_case_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", case_id)
                    audio_filename = f"sos_{safe_case_id}.m4a"
                    audio_path = RECORDINGS_DIR / audio_filename
                    with open(audio_path, "wb") as f:
                        f.write(audio_bytes)
            except Exception:
                audio_filename = None

        # Validate an attached JPEG before acknowledging receipt of the report.
        photo_filename = None
        photo_b64 = payload.get("patient_photo_base64", payload.get("photo_base64"))
        if photo_b64 is not None:
            try:
                if not isinstance(photo_b64, str) or not 0 < len(photo_b64) <= 10_000_000:
                    raise ValueError("Invalid photo size")
                photo_bytes = base64.b64decode(photo_b64, validate=True)
                if not photo_bytes or len(photo_bytes) > 8 * 1024 * 1024:
                    raise ValueError("Invalid photo size")
                try:
                    from PySide6.QtGui import QImage
                    if QImage.fromData(photo_bytes, "JPEG").isNull():
                        raise ValueError("Invalid JPEG")
                except ImportError:
                    from PIL import Image
                    import io
                    with Image.open(io.BytesIO(photo_bytes)) as image:
                        if image.format != "JPEG" or image.width * image.height > 32_000_000:
                            raise ValueError("Invalid JPEG")
                        image.verify()
            except (ValueError, TypeError, OSError):
                handler._send_json({"status": "ERROR", "message": "ภาพแนบไม่ใช่ JPEG ที่ใช้ได้หรือมีขนาดเกินกำหนด"}, status_code=400)
                return
            safe_case_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", str(case_id))
            photo_filename = f"patient_{safe_case_id}.jpg"
            try:
                import tempfile
                descriptor, temporary = tempfile.mkstemp(prefix=".patient-", dir=str(RECORDINGS_DIR))
                try:
                    with os.fdopen(descriptor, "wb") as photo_file:
                        photo_file.write(photo_bytes)
                        photo_file.flush()
                        os.fsync(photo_file.fileno())
                    os.replace(temporary, RECORDINGS_DIR / photo_filename)
                finally:
                    if os.path.exists(temporary):
                        os.unlink(temporary)
            except OSError:
                handler._send_json({"status": "ERROR", "message": "บันทึกภาพแนบไม่สำเร็จ กรุณาลองใหม่"}, status_code=500)
                return

        case = SosCase(
            case_id=case_id,
            device_id=device_id,
            citizen_name=citizen_name,
            phone_number=phone_number,
            latitude=lat,
            longitude=lng,
            accuracy_meters=acc,
            member_count=members,
            is_bedridden=bedridden,
            is_elderly=elderly,
            is_infant=infant,
            urgent_needs=needs,
            urgent_note=note,
            audio_file=audio_filename,
            photo_file=photo_filename,
            case_type=case_type,
            status="PENDING",
            created_at=time.time()
        )

        # Check against active disaster circle
        zone = self.db.get_active_zone()
        case.update_zone_status(zone)

        # Persist to database
        self.db.upsert_sos_case(case)

        photo_desc = " | มีภาพที่ผู้แจ้งแนบ" if photo_filename else ""
        zone_desc = " [อยู่ในเขตอันตรายน้ำท่วม!]" if case.is_in_danger_zone else " [นอกเขตอันตราย]"
        self.db.log_event("ALERT", "NEW_SOS", f"รับแจ้งเหตุ SOS: {citizen_name} ({case_id}){zone_desc}",
                          f"พิกัด: {lat},{lng} | วิกฤต: {bedridden or bool(photo_filename)}{photo_desc} | สมาชิก: {members} คน")

        # Notify GUI callback
        if self.on_new_sos:
            try:
                self.on_new_sos(case)
            except Exception:
                pass

        handler._send_json({
            "status": "SUCCESS",
            "case_id": case_id,
            "case_type": case_type,
            "case_status": case.status,
            "in_danger_zone": case.is_in_danger_zone,
            "distance_km": case.distance_to_epicenter_km,
            "message": "บันทึกข้อมูลเหตุฉุกเฉินแล้ว รอเจ้าหน้าที่ดำเนินการ"
        }, status_code=200)

    def _handle_broadcast_alert(self, payload: Dict[str, Any], handler: BaseHTTPRequestHandler):
        zone_id = payload.get("zone_id") or f"ZONE_{int(time.time())}"
        title = payload.get("title") or "ประกาศเขตอันตรายอุทกภัยน้ำท่วมฉับพลัน"
        hazard_type = payload.get("hazard_type") or "FLOOD"
        severity = payload.get("severity") or "CRITICAL"
        center_lat = _validate_float(payload.get("center_lat"), -90.0, 90.0, 19.9072) or 19.9072
        center_lng = _validate_float(payload.get("center_lng"), -180.0, 180.0, 99.8325) or 99.8325
        radius_km = _validate_float(payload.get("radius_km"), 0.1, 500.0, 12.0) or 12.0
        instruction = payload.get("instruction") or "ขอให้อพยพขึ้นที่สูงทันที"
        agency = payload.get("agency") or "ศูนย์บัญชาการสถานการณ์ภัยพิบัติ (EOC)"

        zone = DisasterZone(
            zone_id=zone_id,
            title=title,
            hazard_type=hazard_type,
            severity=severity,
            center_lat=center_lat,
            center_lng=center_lng,
            radius_km=radius_km,
            instruction=instruction,
            agency=agency,
            created_at=time.time(),
            is_active=True
        )

        self.db.set_active_zone(zone)
        self.db.log_event("WARNING", "ZONE_BROADCAST", f"ประกาศวงกลมภัยพิบัติ: {title} (รัศมี {radius_km} กม.)",
                          f"ศูนย์กลาง: {center_lat},{center_lng}")

        if self.on_zone_broadcast:
            try:
                self.on_zone_broadcast(zone)
            except Exception:
                pass

        handler._send_json({
            "status": "SUCCESS",
            "zone": zone.to_dict(),
            "message": "กระจายสัญญาณประกาศเขตภัยพิบัติเรียบร้อยแล้ว"
        }, status_code=200)

    @staticmethod
    def get_local_ip() -> str:
        """Helper to get primary LAN IP address for connecting mobile devices."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"
