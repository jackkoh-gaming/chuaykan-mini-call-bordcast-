package com.rescue.alert.data

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.rescue.alert.model.DamItem
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Nationwide Real-Time Dam & Reservoir Monitoring Repository.
 * Fetches real telemetry for ALL dams and reservoirs nationwide from the official National Water Telemetry APIs:
 * 1. Royal Irrigation Department (กรมชลประทาน RID) Large Dams & EGAT (35 major dams)
 *    URL: https://app.rid.go.th/reservoir/api/dam/public
 * 2. RID Nationwide Medium Reservoirs (537+ reservoirs across all provinces)
 *    URL: https://app.rid.go.th/reservoir/api/rsvmiddles
 */
object DamMonitorRepository {

    private const val TAG = "DamMonitorRepo"
    private const val RID_DAM_API = "https://app.rid.go.th/reservoir/api/dam/public"
    private const val RID_RSV_MIDDLE_API = "https://app.rid.go.th/reservoir/api/rsvmiddles"
    private const val RID_RESERVOIR_GET_API = "https://app.rid.go.th/reservoir/api/reservoir/public"
    private const val CACHE_TTL_MS = 15 * 60 * 1000L // 15 minutes cache TTL

    private val cachedDams = mutableListOf<DamItem>()
    private var lastFetchTime: Long = 0L

    // Complete official province mapping for all 35 major reservoirs in Thailand
    val DAM_PROVINCE_MAP: Map<String, String> = mapOf(
        "เขื่อนแม่กวงอุดมธารา" to "เชียงใหม่",
        "เขื่อนกิ่วลม" to "ลำปาง",
        "เขื่อนกิ่วคอหมา" to "ลำปาง",
        "เขื่อนแควน้อยบำรุงแดน" to "พิษณุโลก",
        "เขื่อนแม่มอก" to "สุโขทัย",
        "เขื่อนภูมิพล" to "ตาก",
        "เขื่อนสิริกิติ์" to "อุตรดิตถ์",
        "เขื่อนแม่งัดสมบูรณ์ชล" to "เชียงใหม่",
        "เขื่อนห้วยหลวง" to "อุดรธานี",
        "เขื่อนน้ำอูน" to "สกลนคร",
        "เขื่อนลำปาว" to "กาฬสินธุ์",
        "เขื่อนลำตะคอง" to "นครราชสีมา",
        "เขื่อนลำพระเพลิง" to "นครราชสีมา",
        "เขื่อนมูลบน" to "นครราชสีมา",
        "เขื่อนลำแชะ" to "นครราชสีมา",
        "เขื่อนลำนางรอง" to "บุรีรัมย์",
        "เขื่อนน้ำพุง" to "สกลนคร",
        "เขื่อนจุฬาภรณ์" to "ชัยภูมิ",
        "เขื่อนอุบลรัตน์" to "ขอนแก่น",
        "เขื่อนสิรินธร" to "อุบลราชธานี",
        "เขื่อนป่าสักชลสิทธิ์" to "ลพบุรี",
        "เขื่อนทับเสลา" to "อุทัยธานี",
        "เขื่อนกระเสียว" to "สุพรรณบุรี",
        "เขื่อนศรีนครินทร์" to "กาญจนบุรี",
        "เขื่อนวชิราลงกรณ" to "กาญจนบุรี",
        "เขื่อนขุนด่านปราการชล" to "นครนายก",
        "เขื่อนคลองสียัด" to "ฉะเชิงเทรา",
        "เขื่อนบางพระ" to "ชลบุรี",
        "เขื่อนหนองปลาไหล" to "ระยอง",
        "เขื่อนประแสร์" to "ระยอง",
        "เขื่อนนฤบดินทรจินดา" to "ปราจีนบุรี",
        "เขื่อนปราณบุรี" to "ประจวบคีรีขันธ์",
        "เขื่อนแก่งกระจาน" to "เพชรบุรี",
        "เขื่อนรัชชประภา" to "สุราษฎร์ธานี",
        "เขื่อนบางลาง" to "ยะลา"
    )

    fun getCachedOrBaselineDams(): List<DamItem> {
        synchronized(cachedDams) {
            if (cachedDams.isNotEmpty()) {
                return cachedDams.toList()
            }
        }
        return emptyList()
    }

    fun getDams(forceRefresh: Boolean = false, callback: (List<DamItem>) -> Unit) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedDams.isNotEmpty() && (now - lastFetchTime) < CACHE_TTL_MS) {
            callback(cachedDams.toList())
            return
        }

        Thread {
            val liveItems = fetchAllRealtimeDamsAndReservoirs()
            val finalItems = if (liveItems.isNotEmpty()) {
                liveItems
            } else {
                emptyList()
            }

            synchronized(cachedDams) {
                cachedDams.clear()
                cachedDams.addAll(finalItems)
                lastFetchTime = System.currentTimeMillis()
            }

            Handler(Looper.getMainLooper()).post {
                callback(cachedDams.toList())
            }
        }.start()
    }

    /**
     * Connects to official RID & EGAT APIs to fetch ALL dams and reservoirs nationwide:
     * 1. 35 Major Dams
     * 2. 537+ Medium Reservoirs across all 77 provinces
     */
    private fun fetchAllRealtimeDamsAndReservoirs(): List<DamItem> {
        val results = mutableMapOf<String, DamItem>()
        var reportDate = getTodayDateStr()

        // 1. Fetch 35 Major Dams from RID & EGAT
        try {
            val url = URL(RID_DAM_API)
            val conn = (com.rescue.alert.network.PublicDataGateway.open(url) as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 10000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4 (Android; RID Dam Telemetry)")
                setRequestProperty("Accept", "application/json")
            }

            try {
                if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(responseText)
                    reportDate = root.optString("date", reportDate)
                    val regionsArr = root.optJSONArray("data")

                    if (regionsArr != null) {
                        for (rIdx in 0 until regionsArr.length()) {
                            val regionObj = regionsArr.optJSONObject(rIdx) ?: continue
                            val regionName = standardizeRegion(regionObj.optString("region", "ไม่ระบุ"))
                            val damArr = regionObj.optJSONArray("dam") ?: continue

                            for (dIdx in 0 until damArr.length()) {
                                val damObj = damArr.optJSONObject(dIdx) ?: continue
                                val id = damObj.optString("id", "dam_${rIdx}_$dIdx")
                                val rawName = damObj.optString("name", "").trim()
                                if (rawName.isEmpty()) continue

                                val cleanName = if (rawName.startsWith("เขื่อน") || rawName.startsWith("อ่างเก็บน้ำ")) rawName else "เขื่อน$rawName"
                                val province = DAM_PROVINCE_MAP[cleanName] ?: "ไม่ระบุ"

                                val ownerRaw = damObj.optString("owner", "กรมชลประทาน")
                                val agencyShort = if (ownerRaw.contains("ไฟฟ้า") || ownerRaw.contains("กฟผ")) "กฟผ." else "ชป."

                                val capacityMcm = parseDouble(damObj.opt("capacity")).let {
                                    if (it > 0.0) it else parseDouble(damObj.opt("storage"))
                                }
                                val storageMcm = parseDouble(damObj.opt("volume"))

                                var percent = parseDouble(damObj.opt("percent_storage"))
                                if (!percent.isFinite() && capacityMcm > 0.0 && storageMcm >= 0.0) {
                                    percent = (storageMcm / capacityMcm) * 100.0
                                }
                                if (!storageMcm.isFinite() || storageMcm < 0 || !capacityMcm.isFinite() || capacityMcm <= 0 || !percent.isFinite() || percent < 0) continue

                                val inflow = parseDouble(damObj.opt("inflow"))
                                val outflow = parseDouble(damObj.opt("outflow"))

                                results[cleanName] = DamItem(
                                    id = "DAM_$id",
                                    name = cleanName,
                                    province = province,
                                    region = regionName,
                                    agency = agencyShort,
                                    storageMcm = Math.round(storageMcm * 100.0) / 100.0,
                                    capacityMcm = Math.round(capacityMcm * 100.0) / 100.0,
                                    percent = Math.round(percent * 100.0) / 100.0,
                                    inflowMcm = kotlin.math.round(inflow * 100.0) / 100.0,
                                    releasedMcm = kotlin.math.round(outflow * 100.0) / 100.0,
                                    dateStr = reportDate,
                                    isLiveTelemetry = true
                                )
                            }
                        }
                    }
                    Log.i(TAG, "Loaded ${results.size} major dams from RID API ($reportDate)")
                }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching large dams: ${e.message}")
        }

        // 2. Fetch Medium Reservoirs (537+ Reservoirs across Thailand)
        var mediumCount = fetchMediumReservoirs(RID_RSV_MIDDLE_API, reportDate, results)
        if (mediumCount < 50) {
            val yesterday = getYesterdayDateStr()
            Log.w(TAG, "Loaded only $mediumCount medium reservoirs for $reportDate, falling back to $yesterday")
            val yCount = fetchMediumReservoirs(RID_RSV_MIDDLE_API, yesterday, results)
            mediumCount += yCount
        }

        if (mediumCount < 50) {
            Log.w(TAG, "rsvmiddles returned low count ($mediumCount), trying fallback GET reservoir/public")
            fetchMediumReservoirsFallbackGet(results, reportDate)
        }

        return results.values.sortedByDescending { it.capacityMcm }
    }

    private fun fetchMediumReservoirs(apiUrl: String, dateStr: String, results: MutableMap<String, DamItem>): Int {
        var count = 0
        try {
            val url = URL(apiUrl)
            val postData = "date=$dateStr".toByteArray(Charsets.UTF_8)
            val conn = (com.rescue.alert.network.PublicDataGateway.open(url) as HttpURLConnection).apply {
                connectTimeout = 9000
                readTimeout = 12000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4 (Android; RID Reservoir Telemetry)")
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                setRequestProperty("Accept", "application/json")
                outputStream.use { it.write(postData) }
            }

            try {
                if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(responseText)
                    val regionList = root.optJSONArray("region")

                    if (regionList != null) {
                        for (rIdx in 0 until regionList.length()) {
                            val regObj = regionList.optJSONObject(rIdx) ?: continue
                            val resArr = regObj.optJSONArray("reservoir") ?: continue

                            for (i in 0 until resArr.length()) {
                                val rsv = resArr.optJSONObject(i) ?: continue
                                val id = rsv.optString("cresv", "rsv_${rIdx}_$i")
                                val rawName = rsv.optString("nresv", "").trim()
                                if (rawName.isEmpty()) continue

                                val cleanName = if (rawName.startsWith("อ่างเก็บน้ำ") || rawName.startsWith("เขื่อน")) rawName else "อ่างเก็บน้ำ$rawName"

                                // Skip if already present from the 35 major dams
                                if (results.containsKey(cleanName) || results.containsKey("เขื่อน$rawName")) continue

                                val province = rsv.optString("tprov", "ไม่ระบุ").trim().ifEmpty { "ไม่ระบุ" }
                                val region = standardizeRegion(rsv.optString("treg", "ไม่ระบุ"))

                                val capacityMcm = parseDouble(rsv.opt("cap_resv"))
                                val storageMcm = parseDouble(rsv.opt("qdisc_curr"))
                                var percent = parseDouble(rsv.opt("percent_resv_curr"))
                                if (!percent.isFinite() && capacityMcm > 0.0 && storageMcm >= 0.0) {
                                    percent = (storageMcm / capacityMcm) * 100.0
                                }
                                if (!storageMcm.isFinite() || storageMcm < 0 || !capacityMcm.isFinite() || capacityMcm <= 0 || !percent.isFinite() || percent < 0) continue

                                val inflow = parseDouble(rsv.opt("q_info"))
                                val outflow = parseDouble(rsv.opt("q_outfo"))
                                val damDate = rsv.optString("date", dateStr)

                                results[cleanName] = DamItem(
                                    id = "RSV_$id",
                                    name = cleanName,
                                    province = province,
                                    region = region,
                                    agency = "ชป.",
                                    storageMcm = Math.round(storageMcm * 100.0) / 100.0,
                                    capacityMcm = Math.round(capacityMcm * 100.0) / 100.0,
                                    percent = Math.round(percent * 100.0) / 100.0,
                                    inflowMcm = kotlin.math.round(inflow * 100.0) / 100.0,
                                    releasedMcm = kotlin.math.round(outflow * 100.0) / 100.0,
                                    dateStr = damDate,
                                    isLiveTelemetry = true
                                )
                                count++
                            }
                        }
                        Log.i(TAG, "Loaded $count medium reservoirs for $dateStr. Total nationwide items: ${results.size}")
                    }
                } else {
                    Log.w(TAG, "rsvmiddles POST for $dateStr returned HTTP ${conn.responseCode}")
                }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching medium reservoirs for $dateStr: ${e.message}")
        }
        return count
    }

    /**
     * Fallback GET for medium reservoirs from https://app.rid.go.th/reservoir/api/reservoir/public
     */
    private fun fetchMediumReservoirsFallbackGet(results: MutableMap<String, DamItem>, defaultDate: String) {
        try {
            val url = URL(RID_RESERVOIR_GET_API)
            val conn = (com.rescue.alert.network.PublicDataGateway.open(url) as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 10000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4 (Android)")
                setRequestProperty("Accept", "application/json")
            }
            try {
                if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(responseText)
                    val dataArr = root.optJSONArray("data")
                    if (dataArr != null) {
                        for (rIdx in 0 until dataArr.length()) {
                            val regObj = dataArr.optJSONObject(rIdx) ?: continue
                            val region = standardizeRegion(regObj.optString("region", "ไม่ระบุ"))
                            val rsvArr = regObj.optJSONArray("reservoir") ?: continue

                            for (i in 0 until rsvArr.length()) {
                                val rsv = rsvArr.optJSONObject(i) ?: continue
                                val id = rsv.optString("id", "rsv_fb_${rIdx}_$i")
                                val rawName = rsv.optString("name", "").trim()
                                if (rawName.isEmpty()) continue

                                val cleanName = if (rawName.startsWith("อ่างเก็บน้ำ") || rawName.startsWith("เขื่อน")) rawName else "อ่างเก็บน้ำ$rawName"
                                if (results.containsKey(cleanName) || results.containsKey("เขื่อน$rawName")) continue

                                val capacityMcm = parseDouble(rsv.opt("storage"))
                                val storageMcm = parseDouble(rsv.opt("volume"))
                                var percent = parseDouble(rsv.opt("percent_storage"))
                                if (!percent.isFinite() && capacityMcm > 0.0 && storageMcm >= 0.0) {
                                    percent = (storageMcm / capacityMcm) * 100.0
                                }
                                if (!storageMcm.isFinite() || storageMcm < 0 || !capacityMcm.isFinite() || capacityMcm <= 0 || !percent.isFinite() || percent < 0) continue

                                val inflow = parseDouble(rsv.opt("inflow"))
                                val outflow = parseDouble(rsv.opt("outflow"))

                                results[cleanName] = DamItem(
                                    id = "RSV_$id",
                                    name = cleanName,
                                    province = "ไม่ระบุ",
                                    region = region,
                                    agency = "ชป.",
                                    storageMcm = Math.round(storageMcm * 100.0) / 100.0,
                                    capacityMcm = Math.round(capacityMcm * 100.0) / 100.0,
                                    percent = Math.round(percent * 100.0) / 100.0,
                                    inflowMcm = kotlin.math.round(inflow * 100.0) / 100.0,
                                    releasedMcm = kotlin.math.round(outflow * 100.0) / 100.0,
                                    dateStr = defaultDate,
                                    isLiveTelemetry = true
                                )
                            }
                        }
                        Log.i(TAG, "Loaded fallback medium reservoirs. Total nationwide items: ${results.size}")
                    }
                }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fallback GET failed: ${e.message}")
        }
    }

    private fun standardizeRegion(region: String): String {
        return when {
            region.contains("ตะวันออกเฉียงเหนือ") || region.contains("อีสาน") -> "ภาคตะวันออกเฉียงเหนือ"
            region.contains("ตะวันตก") -> "ภาคตะวันตก"
            region.contains("ตะวันออก") -> "ภาคตะวันออก"
            region.contains("เหนือ") -> "ภาคเหนือ"
            region.contains("ใต้") -> "ภาคใต้"
            region.contains("กลาง") -> "ภาคกลาง"
            else -> region.trim().ifEmpty { "ไม่ระบุ" }
        }
    }

    private fun parseDouble(value: Any?): Double {
        if (value == null) return Double.NaN
        val str = value.toString().replace(",", "").trim()
        return str.toDoubleOrNull()?.takeIf { it.isFinite() } ?: Double.NaN
    }

    /**
     * Filter dams by search keyword (dam name, province, or agency), province name, and region.
     */
    fun searchAndFilter(
        allDams: List<DamItem>,
        query: String,
        provinceFilter: String,
        regionFilter: String
    ): List<DamItem> {
        val q = query.trim().lowercase(Locale.ROOT)
        return allDams.filter { dam ->
            val matchQuery = if (q.isEmpty()) true else {
                dam.name.lowercase(Locale.ROOT).contains(q) ||
                dam.province.lowercase(Locale.ROOT).contains(q) ||
                dam.agency.lowercase(Locale.ROOT).contains(q) ||
                dam.region.lowercase(Locale.ROOT).contains(q)
            }

            val matchProvince = if (provinceFilter == "ทุกจังหวัด" || provinceFilter.isEmpty()) true else {
                dam.province == provinceFilter
            }

            val matchRegion = when (regionFilter) {
                "ALL" -> true
                "NORTH" -> dam.region == "ภาคเหนือ"
                "NORTHEAST" -> dam.region == "ภาคตะวันออกเฉียงเหนือ"
                "CENTRAL_WEST" -> dam.region == "ภาคกลาง" || dam.region == "ภาคตะวันตก"
                "EAST" -> dam.region == "ภาคตะวันออก"
                "SOUTH" -> dam.region == "ภาคใต้"
                else -> true
            }

            matchQuery && matchProvince && matchRegion
        }
    }

    /**
     * Extracts unique sorted provinces having dams or reservoirs.
     */
    fun getAllDamProvinces(allDams: List<DamItem>): List<String> {
        val list = mutableListOf("ทุกจังหวัด")
        val uniqueProvinces = allDams.map { it.province }.filter { it.isNotBlank() && it != "ไม่ระบุ" }.distinct().sorted()
        list.addAll(uniqueProvinces)
        return list
    }

    private fun getTodayDateStr(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun getYesterdayDateStr(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }
}
