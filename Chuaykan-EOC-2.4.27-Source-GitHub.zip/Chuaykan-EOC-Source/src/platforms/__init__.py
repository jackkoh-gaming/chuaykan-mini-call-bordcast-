"""Real Windows platform adapters; Linux continues to use its original backends."""
