package com.rescue.alert.receiver

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.rescue.alert.engine.AlertProcessingEngine
import com.rescue.alert.source.OfficialCellBroadcastSync

/**
 * FCM Data message receiver.
 * Uses AlertProcessingEngine for verification, geofencing, and notification.
 */
class AlertPushReceiver : FirebaseMessagingService() {

    companion object {
        private const val TAG = "AlertPushReceiver"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        android.util.Log.i(TAG, "FCM token updated")
        OfficialCellBroadcastSync.subscribePush(this)
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().subscribeToTopic("emergency_alerts")
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        android.util.Log.i(TAG, "Subscribed to emergency_alerts on token refresh")
                    }
                }
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Failed to subscribe to topic on token refresh: ${e.message}")
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        val data = remoteMessage.data
        if (data.isEmpty()) return
        if (data["type"] in setOf("official_feed_changed", "official_push_probe")) {
            if (!OfficialCellBroadcastSync.isValidPush(data)) return
            val receivedAt = System.currentTimeMillis()
            getSharedPreferences("official_push_status", Context.MODE_PRIVATE).edit()
                .putLong("received_at", receivedAt).putString("received_type", data["type"])
                .putString("revision", data["revision"]).apply()
            android.util.Log.i("OfficialPush", "Received type=${data["type"]} sentAt=${data["sent_at"]} receivedAt=$receivedAt")
            // A probe records transport receipt only; it cannot create an incident.
            if (data["type"] == "official_feed_changed") OfficialCellBroadcastSync.refreshFromPush(this)
            return
        }

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PowerManager.PARTIAL_WAKE_LOCK
        } else {
            PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP
        }
        val wakeLock = powerManager.newWakeLock(flags, "RescueAlert:WakeLock")
        wakeLock.acquire(15000) // 15 second processing window

        try {
            val isMuted = data["muteSound"]?.toBoolean() ?: true
            AlertProcessingEngine.processAlert(this, data, isMuted = isMuted)
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
        }
    }
}
