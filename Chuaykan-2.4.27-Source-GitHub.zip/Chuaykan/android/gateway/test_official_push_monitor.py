"""Isolated fixtures only: these tests never contact FCM or publish an alert."""
import copy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, MagicMock
import urllib.error
from gateway.official_push_monitor import Monitor, FirebaseSender, parse_snapshot, fetch_snapshot, SOURCE, MAX_BYTES


NOW = datetime(2026, 10, 2, 10, tzinfo=timezone(timedelta(hours=7))).timestamp()


def fixture(count=1):
    return {
        "fact_cb": [{"alert_id": f"CB-{i}", "date_id": "D-20261002", "time": "09:59",
            "sender_id": "S-1", "event_id": "PRA", "message_id": f"M-{i}", "disaster_id": "D-1",
            "title": "เตือนน้ำท่วม [unit test fixture]"} for i in range(count)],
        "dim_message": [{"message_id": f"M-{i}", "message_th": "ขอให้ยกของขึ้นที่สูง [unit test fixture]"} for i in range(count)],
        "dim_sender": [{"sender_id": "S-1", "sender_name": "unit test fixture"}],
        "dim_event": [{"event_id": "PRA", "event_th": "unit test fixture"}],
        "dim_disaster": [{"disaster_id": "D-1", "disaster_name": "unit test fixture"}],
        "dim_province": [], "bridge_alert_location": [],
    }


class Sender:
    def __init__(self):
        self.sent = []
        self.fail = False

    def send(self, data, priority):
        if self.fail:
            raise ConnectionError("test-only transport failure")
        self.sent.append((data, priority))
        return "test-only-ack"


class MonitorTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "state.json"
        self.sender = Sender()
        self.source = fixture()
        self.monitor = Monitor(self.path, self.sender, self.fetch, lambda: NOW)

    def fetch(self, etag):
        return copy.deepcopy(self.source), '"fixture-etag"', 100

    def test_first_start_sets_quiet_baseline(self):
        self.monitor.tick()
        self.assertEqual([], self.sender.sent)
        self.assertEqual(1, len(json.loads(self.path.read_text())["records"]))

    def test_new_record_sends_data_hint_once_and_restart_does_not_replay(self):
        self.monitor.tick()
        self.source = fixture(2)
        self.monitor.tick()
        self.monitor.tick()
        Monitor(self.path, self.sender, self.fetch, lambda: NOW).tick()
        self.assertEqual(1, len(self.sender.sent))
        data, priority = self.sender.sent[0]
        self.assertEqual("official_feed_changed", data["type"])
        self.assertEqual("high", priority)
        self.assertNotIn("notification", data)
        self.assertNotIn("title", data)

    def test_changed_record_refreshes_data_without_sending_unchanged_record_again(self):
        self.monitor.tick()
        self.source["dim_message"][0]["message_th"] += " update"
        self.monitor.tick()
        self.monitor.tick()
        self.assertEqual(1, len(self.sender.sent))

    def test_old_and_future_records_do_not_send_push(self):
        self.monitor.tick()
        self.source = fixture(3)
        self.source["fact_cb"][1]["time"] = "04:00"
        self.source["fact_cb"][2]["time"] = "11:00"
        self.monitor.tick()
        self.assertEqual([], self.sender.sent)

    def test_failure_keeps_pending_work_for_retry_after_restart_and_304(self):
        self.monitor.tick()
        self.source = fixture(2)
        self.sender.fail = True
        with self.assertRaises(ConnectionError):
            self.monitor.tick()
        self.assertTrue(json.loads(self.path.read_text())["pending"])
        self.sender.fail = False
        restarted = Monitor(self.path, self.sender, lambda etag: (None, etag, 0), lambda: NOW)
        restarted.tick()
        restarted.tick()
        self.assertEqual(1, len(self.sender.sent))
        self.assertIsNone(json.loads(self.path.read_text())["pending"])

    def test_304_does_not_send_or_change_baseline(self):
        self.monitor.tick()
        before = self.path.read_bytes()
        self.monitor.fetch = lambda etag: (None, etag, 0)
        self.assertEqual(0, self.monitor.tick()["downloaded_bytes"])
        self.assertEqual(before, self.path.read_bytes())
        self.assertEqual([], self.sender.sent)

    def test_invalid_source_preserves_state_and_does_not_send(self):
        self.monitor.tick()
        before = self.path.read_bytes()
        self.source.pop("dim_message")
        with self.assertRaises(ValueError):
            self.monitor.tick()
        self.assertEqual(before, self.path.read_bytes())
        self.assertEqual([], self.sender.sent)

    def test_source_failure_preserves_state_and_does_not_send(self):
        self.monitor.tick()
        before = self.path.read_bytes()
        def fail(etag):
            raise ConnectionError("test-only upstream failure")
        self.monitor.fetch = fail
        with self.assertRaises(ConnectionError):
            self.monitor.tick()
        self.assertEqual(before, self.path.read_bytes())
        self.assertEqual([], self.sender.sent)

    def test_corrupt_state_is_not_silently_reset(self):
        self.path.write_text("[]")
        with self.assertRaises(ValueError):
            Monitor(self.path, self.sender)
        self.assertEqual("[]", self.path.read_text())

    def test_news_and_exercises_use_normal_transport_priority(self):
        for title in ("ประชาสัมพันธ์", "ทดสอบระบบ ไม่ใช่สถานการณ์จริง"):
            with self.subTest(title=title):
                self.monitor.tick()
                self.source = fixture(2)
                self.source["fact_cb"][1]["title"] = title
                self.monitor.tick()
                self.assertEqual("normal", self.sender.sent[-1][1])
                self.source = fixture()
                self.monitor.tick()

    def test_incomplete_or_duplicate_record_is_rejected(self):
        source = fixture()
        source["fact_cb"].append(copy.deepcopy(source["fact_cb"][0]))
        with self.assertRaises(ValueError):
            parse_snapshot(source)

    @patch("firebase_admin.messaging.send")
    def test_transport_probe_cannot_replace_a_queued_official_change(self, send):
        sender = FirebaseSender.__new__(FirebaseSender)
        sender.app = object()
        sender.send({"type": "official_feed_changed"}, "high")
        official = send.call_args.args[0]
        sender.send({"type": "official_push_probe"}, "high")
        probe = send.call_args.args[0]
        self.assertNotEqual(official.android.collapse_key, probe.android.collapse_key)
        self.assertIsNone(official.notification)
        self.assertIsNone(probe.notification)

    @patch("gateway.official_push_monitor.urllib.request.urlopen")
    def test_http_conditional_request_and_304(self, open_url):
        open_url.side_effect = urllib.error.HTTPError(SOURCE, 304, "Not modified", {}, None)
        root, etag, size = fetch_snapshot('"old-etag"')
        self.assertIsNone(root)
        self.assertEqual(0, size)
        headers = dict((k.lower(), v) for k, v in open_url.call_args.args[0].header_items())
        self.assertEqual('"old-etag"', headers["if-none-match"])
        self.assertEqual("no-cache", headers["cache-control"])

    @patch("gateway.official_push_monitor.urllib.request.urlopen")
    def test_oversized_response_is_rejected(self, open_url):
        response = MagicMock(status=200, url=SOURCE, headers={})
        response.read.return_value = b"x" * (MAX_BYTES + 1)
        open_url.return_value.__enter__.return_value = response
        with self.assertRaises(ValueError):
            fetch_snapshot()


if __name__ == "__main__":
    unittest.main()
