"""Bounded live PCM playback for an explicitly accepted Bluetooth call."""
import queue
import subprocess
import threading


class CallAudioPlayer:
    def __init__(self):
        self._lock = threading.RLock()
        self._session = None

    def start(self, peer_id):
        self.stop()
        process = subprocess.Popen(
            ["aplay", "-q", "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000"],
            stdin=subprocess.PIPE, bufsize=0,
        )
        session = {"peer": peer_id, "process": process, "queue": queue.Queue(maxsize=20),
                   "stop": threading.Event(), "bytes": 0}
        with self._lock:
            self._session = session

        def play():
            try:
                while not session["stop"].is_set():
                    try:
                        pcm = session["queue"].get(timeout=0.2)
                    except queue.Empty:
                        continue
                    process.stdin.write(pcm)
                    session["bytes"] += len(pcm)
                    if session["bytes"] == len(pcm):
                        print(f"[CallAudio] Live PCM playback started peer={peer_id}", flush=True)
            except (OSError, ValueError) as exc:
                print(f"[CallAudio] Playback stopped: {exc}", flush=True)
            finally:
                session["stop"].set()
                if process.poll() is None:
                    process.terminate()

        threading.Thread(target=play, daemon=True, name="Bluetooth-Call-Playback").start()

    def feed(self, peer_id, pcm):
        with self._lock:
            session = self._session
            if not session or session["peer"] != peer_id or session["stop"].is_set():
                return False
            try:
                session["queue"].put_nowait(pcm)
            except queue.Full:
                # Discard stale sound rather than accumulating conversational delay.
                try:
                    session["queue"].get_nowait()
                except queue.Empty:
                    pass
                try:
                    session["queue"].put_nowait(pcm)
                except queue.Full:
                    return False
            return True

    def stop(self):
        with self._lock:
            session, self._session = self._session, None
        if not session:
            return
        session["stop"].set()
        process = session["process"]
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=1)
        if process.stdin:
            process.stdin.close()
        print(f"[CallAudio] End peer={session['peer']} played_bytes={session['bytes']}", flush=True)
