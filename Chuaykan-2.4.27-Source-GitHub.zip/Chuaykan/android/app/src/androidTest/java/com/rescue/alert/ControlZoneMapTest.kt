package com.rescue.alert

import android.webkit.WebView
import android.content.Intent
import android.view.View
import com.rescue.alert.ui.MainActivity
import com.rescue.alert.data.GeneralSosOutbox
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.ui.RescueMapView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Read-only verification of the existing officer area and completion receipt on the installed phone. */
@RunWith(AndroidJUnit4::class)
class ControlZoneMapTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()

    private fun query(view: RescueMapView, expression: String): String {
        val latch = CountDownLatch(1)
        var value = ""
        instrumentation.runOnMainSync {
            val web = RescueMapView::class.java.getDeclaredField("webView").apply { isAccessible = true }.get(view) as WebView
            web.evaluateJavascript(expression) { value = it; latch.countDown() }
        }
        assertTrue("JavaScript response", latch.await(3, TimeUnit.SECONDS))
        return value
    }

    private fun awaitTrue(view: RescueMapView, expression: String) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(25)
        while (System.nanoTime() < deadline) {
            if (query(view, expression) == "true") return
            Thread.sleep(100)
        }
        assertEquals("true", query(view, expression))
    }

    @Test fun liveOfficerAreaStaysVisibleWhileCompletedSosIsHidden() {
        // Uses the existing live officer area and existing completion receipt; does not create either.
        org.junit.Assume.assumeTrue(GeneralSosOutbox.isCompleted(instrumentation.targetContext))
        val activity = instrumentation.startActivitySync(Intent(instrumentation.targetContext, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
        try {
            lateinit var view: RescueMapView
            instrumentation.runOnMainSync {
                view = MainActivity::class.java.getDeclaredField("rescueMapView").apply { isAccessible = true }.get(activity) as RescueMapView
            }
            awaitTrue(view, "typeof dangerCircle !== 'undefined' && dangerCircle !== null && map.hasLayer(dangerCircle)")
            Thread.sleep(3500) // Crosses both the 1-second map sync and 2-second SOS UI update.
            assertEquals("true", query(view, "dangerCircle !== null && map.hasLayer(dangerCircle)"))
            instrumentation.runOnMainSync {
                assertFalse(activity.findViewById<View>(R.id.btnGeneralSos).isShown)
                assertFalse(activity.findViewById<View>(R.id.btnPulsingSos).isShown)
            }
        } finally { instrumentation.runOnMainSync { activity.finish() } }
    }

}
