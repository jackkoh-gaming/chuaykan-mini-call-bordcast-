"""
Disaster Alert Gateway - Live Data Feed Ingestion
Fetches real data from:
1. Thai Meteorological Department (TMD) Live RSS Feed
2. USGS Earthquakes (Global / Southeast Asia)
"""
import requests
import json
import logging
import re
import time
import urllib.request
import ssl
import xml.etree.ElementTree as ET
from typing import List, Optional
from .models import DisasterAlert, Point

logger = logging.getLogger("FeedIngester")

USGS_URL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson"
TMD_EARTHQUAKE_RSS = "https://earthquake.tmd.go.th/feed/rss.xml"


def fetch_tmd_live_disaster() -> Optional[DisasterAlert]:
    """Fetches latest real earthquake or warning announcement directly from TMD RSS feed."""
    try:
        ctx = ssl.create_default_context()

        req = urllib.request.Request(TMD_EARTHQUAKE_RSS, headers={"User-Agent": "RescueAlert-Gateway/2.0"})
        with urllib.request.urlopen(req, context=ctx, timeout=8) as res:
            xml_data = res.read()

        root = ET.fromstring(xml_data)
        items = root.find("channel").findall("item")
        if not items:
            return None

        latest = items[0]
        title = latest.find("title").text.strip() if latest.find("title") is not None else "แผ่นดินไหว"
        desc = latest.find("description").text.strip() if latest.find("description") is not None else ""
        pub_date = latest.find("pubDate").text.strip() if latest.find("pubDate") is not None else ""

        # Parse Lat, Long, Magnitude
        lat_m = re.search(r"Lat\.\s*([\-0-9\.]+)", desc)
        lng_m = re.search(r"Long\.\s*([\-0-9\.]+)", desc)
        mag_m = re.search(r"ขนาด\s*([0-9\.]+)", desc)

        if not (lat_m and lng_m and mag_m):
            logger.warning("TMD item has no complete earthquake measurements")
            return None
        lat = float(lat_m.group(1))
        lng = float(lng_m.group(1))
        mag = float(mag_m.group(1))
        if not (-90 <= lat <= 90 and -180 <= lng <= 180 and 0 <= mag <= 10):
            return None

        clean_place = title.replace("แผ่นดินไหว", "").strip()
        alert_title = f"แจ้งเตือนแผ่นดินไหว ขนาด {mag:.1f} แมกนิจูด"
        instruction = (
            f"กรมอุตุนิยมวิทยาตรวจพบแผ่นดินไหวขนาด {mag:.1f} บริเวณ {clean_place} "
            f"พิกัด {lat:.2f}, {lng:.2f} ตรวจสอบความปลอดภัย อาคารบ้านเรือน และระวังเหตุสั่นสะเทือนตามมา"
        )

        return DisasterAlert(
            alert_id=f"TMD_LIVE_{int(time.time())}",
            title=alert_title,
            instruction=instruction,
            severity="CRITICAL" if mag >= 5.0 else "WARNING",
            center_lat=lat,
            center_lng=lng,
            radius_km=max(30.0, mag * 25.0)
        )
    except Exception as e:
        logger.error(f"Error fetching live TMD alert: {e}")
        return None


def fetch_recent_earthquakes(min_magnitude: float = 4.0) -> List[DisasterAlert]:
    """Fetches recent earthquakes >= min_magnitude from USGS and converts to DisasterAlert."""
    alerts = []
    try:
        resp = requests.get(USGS_URL, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            features = data.get("features", [])
            for feat in features:
                props = feat.get("properties", {})
                geometry = feat.get("geometry", {})
                mag = props.get("mag")
                if mag and mag >= min_magnitude:
                    coords = geometry.get("coordinates")
                    if not coords or len(coords) < 3 or any(v is None for v in coords[:3]):
                        continue
                    lng, lat = coords[0], coords[1]
                    place = props.get("place", "ไม่ระบุตำแหน่ง")

                    # Dynamic radius based on magnitude
                    radius_km = max(20.0, (mag - 3.0) * 40.0)

                    alert = DisasterAlert(
                        alert_id=f"USGS_{feat.get('id')}",
                        title=f"แผ่นดินไหวขนาด {mag:.1f} ({place})",
                        instruction=f"เกิดแผ่นดินไหวรุนแรงขนาด {mag:.1f} ลึก {coords[2]:.1f} กม. โปรดระวังอาคารทรุดตัวและ Aftershock",
                        severity="CRITICAL" if mag >= 5.5 else "WARNING",
                        center_lat=lat,
                        center_lng=lng,
                        radius_km=radius_km
                    )
                    alerts.append(alert)
    except Exception as e:
        logger.error(f"Error fetching USGS earthquakes: {e}")

    return alerts

