package com.rescue.alert.ui

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Dialog
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.Window
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.rescue.alert.R
import com.rescue.alert.engine.GeoFilterEngine
import com.rescue.alert.util.AppSettings
import com.rescue.alert.model.CitizenEmergencyProfile
import com.rescue.alert.model.DisasterStateManager
import com.rescue.alert.data.EmergencyOutboxManager
import com.rescue.alert.data.EvacuationSiteRepository
import com.rescue.alert.model.EvacuationSite
import com.rescue.alert.ui.EvacuationSitesDialog
import org.json.JSONObject
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_PERMISSIONS = 101
        private const val REQUEST_AUDIO_PERMISSION = 102
        private const val REQUEST_CALL_AUDIO_PERMISSION = 103
        private const val TAG = "MainActivity"
        const val ACTION_DISASTER_ALERT = "com.rescue.alert.ACTION_DISASTER_ALERT"
        const val ACTION_DISASTER_STATE_CHANGED = "com.rescue.alert.ACTION_DISASTER_STATE_CHANGED"
        const val ACTION_RESCUE_COMPLETED = "com.rescue.alert.ACTION_RESCUE_COMPLETED"
        const val ACTION_DISASTER_RESOLVED = "com.rescue.alert.ACTION_DISASTER_RESOLVED"
        const val ACTION_OFFICER_APPROACHING = "com.rescue.alert.ACTION_OFFICER_APPROACHING"
        const val SURVIVAL_GUIDE_TITLE = "คู่มือวิธีเอาตัวรอดจากภัยพิบัติ"
        internal fun isEmergencyRiskZone(zone: JSONObject): Boolean =
            !zone.optString("hazard_type").equals("ANNOUNCEMENT", ignoreCase = true) &&
            !zone.optString("zone_id").startsWith("MIC_ZONE_", ignoreCase = true)
        // คู่มือวิธีเอาตัวรอดจากภัยพิบัติ: น้ำท่วม, ดินโคลนถล่ม, แผ่นดินไหว
        // Lifeline dispatch: HttpURLConnection POST multipart/form-data via EmergencyOutboxManager
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppSettings.applyDisplayConfiguration(newBase))
    }

    private var syncIntervalMs: Long = 25000L

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var rescueMapView: RescueMapView
    private lateinit var btnGrantPermissions: Button
    private lateinit var layoutPermissionGrantedBadge: LinearLayout
    private lateinit var layoutRescuedSafeOverlay: FrameLayout

    private var generalSosSaving = false

    // Profile Accordion Views
    private lateinit var cardEmergencyProfile: LinearLayout
    private lateinit var layoutProfileHeader: LinearLayout
    private lateinit var layoutProfileForm: LinearLayout
    private lateinit var ivProfileChevron: ImageView
    private lateinit var tvProfileStatusChip: TextView
    private lateinit var etContactName: EditText
    private lateinit var etContactPhone: EditText
    private lateinit var etMemberCount: EditText
    private lateinit var cbBedridden: CheckBox
    private lateinit var cbElderly: CheckBox
    private lateinit var cbInfant: CheckBox
    private lateinit var etUrgentNeeds: EditText
    private lateinit var btnSaveProfile: Button

    // Disaster & SOS Voice Views
    private lateinit var layoutActiveDisaster: LinearLayout
    private lateinit var tvDisasterInstruction: TextView
    private lateinit var pulseWaveRing1: View
    private lateinit var pulseWaveRing2: View
    private lateinit var btnPulsingSos: Button
    private lateinit var tvSosRecordingStatus: TextView
    private lateinit var tvSosRecordingTimer: TextView
    private lateinit var tvSosConfirmedStatus: TextView

    // Officer Live Mic Announcement Banner
    private lateinit var layoutOfficerLiveMicBanner: LinearLayout
    private lateinit var tvOfficerMicTitle: TextView
    private lateinit var tvOfficerMicSubtitle: TextView
    private lateinit var ivOfficerMicIcon: ImageView
    private var officerMicPulseAnimator: ObjectAnimator? = null

    // Active Officer Call Banner & Dialog
    private lateinit var layoutActiveOfficerCallBanner: LinearLayout
    private lateinit var tvActiveCallTitle: TextView
    private lateinit var tvActiveCallSubtitle: TextView
    private lateinit var btnActiveCallHangupQuick: Button
    private var incomingOfficerCallDialog: IncomingOfficerCallDialog? = null

    // Evacuation & Safe Parking Banner Views
    private lateinit var layoutNearestShelterBanner: LinearLayout
    private lateinit var tvShelterCountBadge: TextView
    private lateinit var tvNearestShelterInfo: TextView
    private lateinit var tvNearestParkingInfo: TextView

    private var isSoundEnabled: Boolean = true
    private var isProfileExpanded: Boolean = false
    private var ringAnimator1: ObjectAnimator? = null
    private var ringAnimator2: ObjectAnimator? = null

    private val officerPresenceHandler = Handler(Looper.getMainLooper())
    private val officerPresenceCheck = object : Runnable {
        override fun run() {
            if (com.rescue.alert.data.GeneralSosOutbox.consumeSafeScreen(this@MainActivity)) showRescuedSafeTransition()
            val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this@MainActivity)
            updateMeshStatusBadge(mesh.getNodes())
            updateGeneralSosUi()
            com.rescue.alert.data.GeneralSosOutbox.retry(this@MainActivity)
            officerPresenceHandler.postDelayed(this, 2000)
        }
    }

    private val riskZoneSyncHandler = Handler(Looper.getMainLooper())
    private var riskZoneSyncRunnable: Runnable? = null
    private val riskZoneSyncBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var mapSyncGeneration = 0L
    private var lastGatewayZone = ""

    private val takePatientPhotoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            handlePatientPhotoCaptured(bitmap)
        } else {
            tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยัน"
            Toast.makeText(this, "ยกเลิกการถ่ายภาพ (จำเป็นต้องมีภาพเพื่อส่ง SOS ผู้ป่วยวิกฤต)", Toast.LENGTH_SHORT).show()
        }
    }

    private val disasterStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val senderPkg = intent.`package`
            if (senderPkg != null && senderPkg != context.packageName) {
                Log.w(TAG, "Rejected broadcast from external package: $senderPkg")
                return
            }
            val action = intent.action
            Log.i(TAG, "Disaster receiver got action: $action")
            if (action == ACTION_DISASTER_ALERT || action == ACTION_DISASTER_STATE_CHANGED) {
                val isActive = intent.getBooleanExtra("IS_ACTIVE", action == ACTION_DISASTER_ALERT || false)
                if (isActive) {
                    val lat = intent.getStringExtra("centerLat")?.toDoubleOrNull() ?: intent.getDoubleExtra("centerLat", 0.0)
                    val lng = intent.getStringExtra("centerLng")?.toDoubleOrNull() ?: intent.getDoubleExtra("centerLng", 0.0)
                    val radiusKm = intent.getStringExtra("radiusKm")?.toDoubleOrNull() ?: intent.getDoubleExtra("radiusKm", 0.0)
                    if (lat != 0.0 && lng != 0.0 && radiusKm > 0.0) {
                        rescueMapView.setDangerZone(lat, lng, radiusKm)
                    }
                }
                updateDisasterStateUI()
            } else if (action == "com.rescue.alert.ACTION_RESCUE_COMPLETED") {
                showRescuedSafeTransition()
            } else if (action == "com.rescue.alert.ACTION_DISASTER_RESOLVED") {
                DisasterStateManager.setDisasterResolved(context)
                updateDisasterStateUI()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.applyDisplayScaleToActivity(this)
        setContentView(R.layout.activity_main)

        initViews()
        CitizenEmergencyProfile.load(this)
        registerDisasterStateReceiver()
        setupTopAppBar()
        setupMapControls()
        setupPermissions()
        setupProfileAccordion()
        setupSurvivalGuide()
        setupPulsingSosButton()
        setupGeneralSosButton()
        setupDrawerNavigation()
        subscribeFcmTopic()
        com.rescue.alert.source.OfficialCellBroadcastSync.schedule(this)
        com.rescue.alert.source.OfficialCellBroadcastSync.refreshNow(this)
        // Cancel obsolete jobs that had no connected data source.
        androidx.work.WorkManager.getInstance(this).cancelUniqueWork("google_alert_early_warning_periodic")
        androidx.work.WorkManager.getInstance(this).cancelUniqueWork("google_alert_early_warning_immediate")
        com.rescue.alert.data.DamMonitorRepository.getDams(forceRefresh = false) {}
        com.rescue.alert.data.DisasterNewsRepository.getNews(forceRefresh = false) {}
        rescueMapView.clearApproachingOfficer()
        rescueMapView.clearDangerZone()

        setupOfficerAnnouncementListener()
        setupOfficerCallListeners()
        setupEvacuationSites()
        setupAmRadioPlayerListener()

        updateLocationAndPermissions()
        updateDisasterStateUI()
        applyPowerSavingMode()

        if (intent?.getBooleanExtra("OPEN_DISASTER_NEWS", false) == true) {
            DisasterNewsDialog.show(this)
        }
        if (intent?.getBooleanExtra("OPEN_BT_MESH_CALL", false) == true) {
            intent.removeExtra("OPEN_BT_MESH_CALL")
            showBluetoothMeshCallDialog()
        }
        handleAnswerCallIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("OPEN_DISASTER_NEWS", false) == true) {
            // BUG-12 FIX: Clear extra after consuming to prevent duplicate on config change
            intent.removeExtra("OPEN_DISASTER_NEWS")
            DisasterNewsDialog.show(this)
        }
        if (intent?.getBooleanExtra("OPEN_BT_MESH_CALL", false) == true) {
            // BUG-12 FIX: Clear extra after consuming to prevent duplicate dialog on rotation
            intent.removeExtra("OPEN_BT_MESH_CALL")
            showBluetoothMeshCallDialog()
        }
        handleAnswerCallIntent(intent)
    }

    private fun handleAnswerCallIntent(callIntent: Intent?) {
        if (callIntent?.action != com.rescue.alert.bluetooth.BluetoothMeshManager.ACTION_ANSWER_CALL) return
        callIntent.action = null
        answerOfficerCall()
    }

    fun answerOfficerCall() {
        val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
        if (!mesh.isIncomingCall()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_CALL_AUDIO_PERMISSION)
            return
        }
        com.rescue.alert.bluetooth.MeshForegroundService.startService(this)
        mesh.answerIncomingCall()
    }

    override fun onResume() {
        super.onResume()
        EvacuationSiteRepository.getInstance(this).syncFromGatewayAsync()
        startPeriodicRiskZoneSync()
        officerPresenceHandler.removeCallbacks(officerPresenceCheck)
        officerPresenceHandler.post(officerPresenceCheck)
        updateLocationAndPermissions()
        updateDisasterStateUI()
        checkWifiAndSignalStatus()
        updateAmRadioIndicator()
        applyPowerSavingMode()
        EmergencyOutboxManager.flushOutbox(this)
        setupOfficerAnnouncementListener()
        setupOfficerCallListeners()

        // Sync active call banner state
        val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
        if (mesh.isIncomingCall() && !mesh.isInCall() && incomingOfficerCallDialog?.isShowing != true) {
            mesh.onIncomingCallReceived?.invoke(mesh.getIncomingCallerName(), mesh.getIncomingCallerNodeId())
        }
        if (mesh.isInCall()) {
            val node = mesh.getActiveCallNode()
            val callerTitle = node?.houseName ?: mesh.getIncomingCallerName().ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
            layoutActiveOfficerCallBanner.visibility = View.VISIBLE
            tvActiveCallTitle.text = if (mesh.isCallConnecting()) "กำลังโทรหา $callerTitle" else "กำลังสนทนาสายตรงกับ $callerTitle"
            tvActiveCallSubtitle.text = if (mesh.isCallConnecting()) "รอปลายทางรับสาย" else "เชื่อมต่อช่องสัญญาณเสียง 2 ทาง • แตะเพื่อเปิดจอสนทนา"
        } else {
            layoutActiveOfficerCallBanner.visibility = View.GONE
        }

        // Auto-start Bluetooth Mesh presence broadcasting and RFCOMM servers (F-01, F-07)
        try {
            mesh.onMeshNodesUpdated = { nodes ->
                runOnUiThread {
                    updateMeshStatusBadge(nodes)
                }
            }
            mesh.ensureServersStarted()
            updateMeshStatusBadge(mesh.getNodes())
            com.rescue.alert.bluetooth.MeshForegroundService.startService(this)
        } catch (e: Exception) {
            android.util.Log.w("MainActivity", "Bluetooth mesh auto-start: ${e.message}")
        }
    }

    private fun setupOfficerCallListeners() {
        try {
            val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
            mesh.onIncomingCallReceived = { callerName, callerNodeId ->
                runOnUiThread {
                    if (isFinishing || isDestroyed || mesh.isInCall() || incomingOfficerCallDialog?.isShowing == true) {
                        return@runOnUiThread
                    }
                    incomingOfficerCallDialog?.dismiss()
                    incomingOfficerCallDialog = IncomingOfficerCallDialog(this@MainActivity, callerName, callerNodeId) { answered ->
                        if (answered) {
                            showBluetoothMeshCallDialog()
                        }
                    }
                    incomingOfficerCallDialog?.show()
                }
            }
            mesh.onCallStateChanged = { inCall, callerName, callerNodeId ->
                runOnUiThread {
                    if (inCall) {
                        incomingOfficerCallDialog?.dismiss()
                        incomingOfficerCallDialog = null
                        layoutActiveOfficerCallBanner.visibility = View.VISIBLE
                        // BUG-20 FIX: Fallback for blank caller name
                        val displayName = callerName.ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
                        tvActiveCallTitle.text = if (mesh.isCallConnecting()) "กำลังโทรหา $displayName" else "กำลังสนทนาสายตรงกับ $displayName"
                        tvActiveCallSubtitle.text = if (mesh.isCallConnecting()) "รอปลายทางรับสาย" else "เชื่อมต่อช่องสัญญาณเสียง 2 ทาง • แตะเพื่อเปิดจอสนทนา"
                    } else {
                        incomingOfficerCallDialog?.dismiss()
                        incomingOfficerCallDialog = null
                        layoutActiveOfficerCallBanner.visibility = View.GONE
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error setting up officer call listeners: ${e.message}")
        }
    }

    private fun setupOfficerAnnouncementListener() {
        try {
            val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
            mesh.onOfficerAnnouncementStateChanged = { isAnnouncing, sourceName ->
                runOnUiThread {
                    if (isAnnouncing) {
                        layoutOfficerLiveMicBanner.visibility = View.VISIBLE
                        tvOfficerMicTitle.text = "มีไมค์ประกาศจากเจ้าหน้าที่เข้ามา"
                        tvOfficerMicSubtitle.text = "กำลังถ่ายทอดเสียงสดจาก $sourceName (กำลังเล่นเสียงอัตโนมัติ)"
                        startOfficerMicPulseAnimation()
                    } else {
                        layoutOfficerLiveMicBanner.visibility = View.GONE
                        stopOfficerMicPulseAnimation()
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error setting up officer announcement listener: ${e.message}")
        }
    }

    private fun startOfficerMicPulseAnimation() {
        try {
            if (officerMicPulseAnimator == null) {
                officerMicPulseAnimator = ObjectAnimator.ofFloat(ivOfficerMicIcon, "alpha", 1.0f, 0.3f).apply {
                    duration = 600
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                }
            }
            officerMicPulseAnimator?.start()
        } catch (e: Exception) {}
    }

    private fun stopOfficerMicPulseAnimation() {
        try {
            officerMicPulseAnimator?.cancel()
            ivOfficerMicIcon.alpha = 1.0f
        } catch (e: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        stopBackgroundPulseWaveAnimation()
        stopPeriodicRiskZoneSync()
        officerPresenceHandler.removeCallbacks(officerPresenceCheck)

        // BUG-04 FIX: Unregister call listeners to prevent memory leak.
        // BluetoothMeshManager is a singleton — if it holds lambda callbacks that
        // capture this@MainActivity, the destroyed Activity cannot be garbage collected.
        try {
            val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
            mesh.onIncomingCallReceived = null
            mesh.onCallStateChanged = null
            mesh.onOfficerAnnouncementStateChanged = null
        } catch (_: Exception) {}

        // BUG-10 FIX: Dismiss incoming call dialog to prevent WindowLeaked
        incomingOfficerCallDialog?.dismiss()
        incomingOfficerCallDialog = null
    }

    private fun registerDisasterStateReceiver() {
        val disasterFilter = IntentFilter().apply {
            addAction(ACTION_DISASTER_ALERT)
            addAction("com.rescue.alert.ACTION_DISASTER_STATE_CHANGED")
            addAction("com.rescue.alert.ACTION_RESCUE_COMPLETED")
            addAction("com.rescue.alert.ACTION_DISASTER_RESOLVED")
        }
        // M-1: ContextCompat.registerReceiver ensures RECEIVER_NOT_EXPORTED is enforced across all Android versions
        ContextCompat.registerReceiver(
            this,
            disasterStateReceiver,
            disasterFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun getDeviceCoordinates(): Pair<Double, Double>? {
        // A saved profile position must not activate a zone after GPS is unavailable.
        val location = com.rescue.alert.source.area.AreaLocation.current(this) ?: return null
        return Pair(location.latitude, location.longitude)
    }

    private fun isDeviceInCurrentRiskArea(): Boolean {
        if (DisasterStateManager.getAlertId(this).startsWith("MIC_ZONE_", ignoreCase = true)) return false
        val coords = getDeviceCoordinates() ?: return false
        return DisasterStateManager.isDisasterActive(this) &&
            DisasterStateManager.isDeviceInRiskArea(this, coords.first, coords.second)
    }

    private fun updateDisasterStateUI() {
        if (DisasterStateManager.getAlertId(this).startsWith("MIC_ZONE_", ignoreCase = true)) {
            DisasterStateManager.setDisasterResolved(this)
        }
        val shouldShowSos = isDeviceInCurrentRiskArea() && !com.rescue.alert.data.GeneralSosOutbox.suppressesSos(this)

        if (shouldShowSos) {
            layoutActiveDisaster.visibility = View.VISIBLE
            val inst = DisasterStateManager.getDisasterInstruction(this).ifBlank {
                "กด SOS เพื่อถ่ายรูปผู้ป่วยฉุกเฉิน ยืนยันพิกัดขอความช่วยเหลือ"
            }
            tvDisasterInstruction.text = inst
            if (!AppSettings.isPowerSavingActive(this)) {
                startBackgroundPulseWaveAnimation()
            }
        } else {
            layoutActiveDisaster.visibility = View.GONE
            stopBackgroundPulseWaveAnimation()
        }
    }

    private fun startPeriodicRiskZoneSync() {
        stopPeriodicRiskZoneSync()
        riskZoneSyncRunnable = object : Runnable {
            override fun run() {
                syncActiveRiskZonesFromGateway()
                EvacuationSiteRepository.getInstance(this@MainActivity).syncFromGatewayAsync()
                riskZoneSyncHandler.postDelayed(this, 1000L)
            }
        }
        riskZoneSyncHandler.post(riskZoneSyncRunnable!!)
    }

    private fun stopPeriodicRiskZoneSync() {
        mapSyncGeneration++
        riskZoneSyncRunnable?.let { riskZoneSyncHandler.removeCallbacks(it) }
        riskZoneSyncRunnable = null
    }

    private fun syncActiveRiskZonesFromGateway() {
        val gateway = AppSettings.getGatewayBaseUrl(this).trimEnd('/')
        if (gateway.isBlank() || !riskZoneSyncBusy.compareAndSet(false, true)) return
        val generation = mapSyncGeneration
        Thread {
            var connection: java.net.HttpURLConnection? = null
            try {
                val url = URL("$gateway/api/alert/active")
                val conn = (com.rescue.alert.network.SecureGateway.open(this, url)).apply {
                    connectTimeout = 3000
                    readTimeout = 3000
                    useCaches = false
                }
                connection = conn
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    val status = json.getString("status")
                    require(status == "ACTIVE" || status == "NONE")
                    val zonesArray = json.optJSONArray("zones")
                    require(status != "ACTIVE" || zonesArray != null || json.has("zone"))
                    val coords = getDeviceCoordinates()

                    var displayZone: JSONObject? = null
                    var matchedZone: JSONObject? = null
                    if (status == "ACTIVE" && zonesArray != null) {
                        for (i in 0 until zonesArray.length()) {
                            val z = zonesArray.getJSONObject(i)
                            if (!isEmergencyRiskZone(z)) continue
                            val clat = z.optDouble("center_lat", Double.NaN)
                            val clng = z.optDouble("center_lng", Double.NaN)
                            val rKm = z.optDouble("radius_km", 0.0)
                            if (!clat.isNaN() && !clng.isNaN() && rKm > 0) {
                                if (displayZone == null) displayZone = z
                                if (coords != null && GeoFilterEngine.isInsideCircle(coords.first, coords.second, clat, clng, rKm)) {
                                    matchedZone = z
                                    displayZone = z
                                    break
                                }
                            }
                        }
                    } else if (status == "ACTIVE" && json.has("zone")) {
                        val z = json.getJSONObject("zone")
                        val clat = z.optDouble("center_lat", Double.NaN)
                        val clng = z.optDouble("center_lng", Double.NaN)
                        val rKm = z.optDouble("radius_km", 0.0)
                        if (isEmergencyRiskZone(z) && !clat.isNaN() && !clng.isNaN() && rKm > 0) {
                            displayZone = z
                            if (coords != null && GeoFilterEngine.isInsideCircle(coords.first, coords.second, clat, clng, rKm)) {
                                matchedZone = z
                            }
                        }
                    }

                    val mapZone = displayZone
                    val currentZone = matchedZone
                    runOnUiThread {
                        if (generation != mapSyncGeneration || isDestroyed || gateway != AppSettings.getGatewayBaseUrl(this).trimEnd('/')) return@runOnUiThread
                        val zoneKey = currentZone?.toString().orEmpty()
                        if (currentZone != null) {
                            val matchedZone = currentZone
                            val zId = matchedZone.optString("zone_id", "RISK_ZONE")
                            val title = matchedZone.optString("title", "พื้นที่เสี่ยงภัยฉุกเฉิน")
                            val inst = matchedZone.optString("instruction", "แจ้งเหตุเฉพาะผู้ป่วยขั้นวิกฤตเท่านั้น")
                            val clat = matchedZone.optDouble("center_lat")
                            val clng = matchedZone.optDouble("center_lng")
                            val rKm = matchedZone.optDouble("radius_km")
                            if (zoneKey != lastGatewayZone || DisasterStateManager.getAlertId(this) != zId || !DisasterStateManager.isDisasterActive(this)) DisasterStateManager.setDisasterActive(
                                this@MainActivity,
                                alertId = zId,
                                title = title,
                                instruction = inst,
                                centerLat = clat,
                                centerLng = clng,
                                radiusKm = rKm
                            )
                        } else if (DisasterStateManager.isDisasterActive(this) && !DisasterStateManager.getAlertId(this@MainActivity).startsWith("DPM_")) {
                            // Either no active zones or device is outside all pinned zones
                            DisasterStateManager.setDisasterResolved(this@MainActivity)
                        }
                        lastGatewayZone = zoneKey
                        updateDisasterStateUI()
                        if (mapZone == null) rescueMapView.clearDangerZone()
                        else rescueMapView.setDangerZone(
                            mapZone.getDouble("center_lat"), mapZone.getDouble("center_lng"), mapZone.getDouble("radius_km"))
                    }
                }
            } catch (_: Exception) {} finally {
                connection?.disconnect()
                riskZoneSyncBusy.set(false)
            }
        }.start()
    }

    private fun startBackgroundPulseWaveAnimation() {
        if (AppSettings.isPowerSavingActive(this)) return
        if (ringAnimator1?.isRunning == true || ringAnimator2?.isRunning == true) return

        val pvhX1 = android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.45f)
        val pvhY1 = android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.45f)
        val pvhA1 = android.animation.PropertyValuesHolder.ofFloat("alpha", 0.7f, 0f)
        ringAnimator1 = ObjectAnimator.ofPropertyValuesHolder(pulseWaveRing1, pvhX1, pvhY1, pvhA1).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        val pvhX2 = android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.70f)
        val pvhY2 = android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.70f)
        val pvhA2 = android.animation.PropertyValuesHolder.ofFloat("alpha", 0.5f, 0f)
        ringAnimator2 = ObjectAnimator.ofPropertyValuesHolder(pulseWaveRing2, pvhX2, pvhY2, pvhA2).apply {
            duration = 2400
            startDelay = 600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stopBackgroundPulseWaveAnimation() {
        ringAnimator1?.cancel()
        ringAnimator1 = null
        ringAnimator2?.cancel()
        ringAnimator2 = null
        pulseWaveRing1.alpha = 0f
        pulseWaveRing2.alpha = 0f
    }

    private fun initViews() {
        drawerLayout = findViewById(R.id.drawerLayout)
        rescueMapView = findViewById(R.id.rescueMapView)
        btnGrantPermissions = findViewById(R.id.btnGrantPermissions)
        layoutPermissionGrantedBadge = findViewById(R.id.layoutPermissionGrantedBadge)
        layoutRescuedSafeOverlay = findViewById(R.id.layoutRescuedSafeOverlay)

        cardEmergencyProfile = findViewById(R.id.cardEmergencyProfile)
        layoutProfileHeader = findViewById(R.id.layoutProfileHeader)
        layoutProfileForm = findViewById(R.id.layoutProfileForm)
        ivProfileChevron = findViewById(R.id.ivProfileChevron)
        tvProfileStatusChip = findViewById(R.id.tvProfileStatusChip)
        etContactName = findViewById(R.id.etContactName)
        etContactPhone = findViewById(R.id.etContactPhone)
        etMemberCount = findViewById(R.id.etMemberCount)
        cbBedridden = findViewById(R.id.cbBedridden)
        cbElderly = findViewById(R.id.cbElderly)
        cbInfant = findViewById(R.id.cbInfant)
        etUrgentNeeds = findViewById(R.id.etUrgentNeeds)
        btnSaveProfile = findViewById(R.id.btnSaveProfile)

        layoutActiveDisaster = findViewById(R.id.layoutActiveDisaster)
        tvDisasterInstruction = findViewById(R.id.tvDisasterInstruction)
        pulseWaveRing1 = findViewById(R.id.pulseWaveRing1)
        pulseWaveRing2 = findViewById(R.id.pulseWaveRing2)
        btnPulsingSos = findViewById(R.id.btnPulsingSos)
        tvSosRecordingStatus = findViewById(R.id.tvSosRecordingStatus)
        tvSosRecordingTimer = findViewById(R.id.tvSosRecordingTimer)
        tvSosConfirmedStatus = findViewById(R.id.tvSosConfirmedStatus)

        layoutOfficerLiveMicBanner = findViewById(R.id.layoutOfficerLiveMicBanner)
        tvOfficerMicTitle = findViewById(R.id.tvOfficerMicTitle)
        tvOfficerMicSubtitle = findViewById(R.id.tvOfficerMicSubtitle)
        ivOfficerMicIcon = findViewById(R.id.ivOfficerMicIcon)

        layoutActiveOfficerCallBanner = findViewById(R.id.layoutActiveOfficerCallBanner)
        tvActiveCallTitle = findViewById(R.id.tvActiveCallTitle)
        tvActiveCallSubtitle = findViewById(R.id.tvActiveCallSubtitle)
        btnActiveCallHangupQuick = findViewById(R.id.btnActiveCallHangupQuick)

        layoutActiveOfficerCallBanner.setOnClickListener {
            showBluetoothMeshCallDialog()
        }
        btnActiveCallHangupQuick.setOnClickListener {
            com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this).hangupCurrentCall()
        }

        // Evacuation and Safe Parking Views
        layoutNearestShelterBanner = findViewById(R.id.layoutNearestShelterBanner)
        tvShelterCountBadge = findViewById(R.id.tvShelterCountBadge)
        tvNearestShelterInfo = findViewById(R.id.tvNearestShelterInfo)
        tvNearestParkingInfo = findViewById(R.id.tvNearestParkingInfo)

        layoutNearestShelterBanner.setOnClickListener {
            showSheltersDialog()
        }
    }

    private fun setupTopAppBar() {
        // Hamburger Drawer
        findViewById<ImageButton>(R.id.btnOpenDrawer).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // AM Radio Toggle / Dialog (ติดกับลำโพง)
        findViewById<View>(R.id.btnRadioAmLayout)?.setOnClickListener {
            showAmRadioDialog()
        }

        // Bluetooth Mesh Call Button (บนแถบ Top Bar)
        findViewById<View>(R.id.btnBtMeshLayout)?.setOnClickListener {
            showBluetoothMeshCallDialog()
        }
        updateMeshStatusBadge()

        // Speaker Toggle
        val btnSound = findViewById<ImageButton>(R.id.btnToggleSound)
        btnSound.setOnClickListener {
            isSoundEnabled = !isSoundEnabled
            if (isSoundEnabled) {
                btnSound.setImageResource(R.drawable.ic_volume_up)
                Toast.makeText(this, "เปิดเสียงการแจ้งเตือนแล้ว", Toast.LENGTH_SHORT).show()
            } else {
                btnSound.setImageResource(R.drawable.ic_volume_off)
                Toast.makeText(this, "ปิดเสียงการแจ้งเตือน (โหมดเงียบ)", Toast.LENGTH_SHORT).show()
            }
        }

        // Local Offline Signal / WiFi Mesh Info
        findViewById<View>(R.id.btnOfflineSignal)?.setOnClickListener {
            showOfflineSignalDialog()
        }

        checkWifiAndSignalStatus()
        updateAmRadioIndicator()
    }

    private fun setupMapControls() {
        findViewById<ImageButton>(R.id.btnMapRecenter).setOnClickListener {
            rescueMapView.recenter()
        }
        findViewById<ImageButton>(R.id.btnMapZoomIn).setOnClickListener {
            rescueMapView.zoomIn()
        }
        findViewById<ImageButton>(R.id.btnMapZoomOut).setOnClickListener {
            rescueMapView.zoomOut()
        }
    }

    private fun showRescuedSafeTransition() {
        runOnUiThread {
            findViewById<Button>(R.id.btnGeneralSos).visibility = View.GONE
            layoutActiveDisaster.visibility = View.GONE
            rescueMapView.clearApproachingOfficer()
            DisasterStateManager.setDisasterResolved(this)
            updateDisasterStateUI()
            layoutRescuedSafeOverlay.visibility = View.VISIBLE
            layoutRescuedSafeOverlay.alpha = 1f

            Handler(Looper.getMainLooper()).postDelayed({
                layoutRescuedSafeOverlay.animate()
                    .alpha(0f)
                    .setDuration(400)
                    .withEndAction {
                        layoutRescuedSafeOverlay.visibility = View.GONE
                    }
                    .start()
            }, 3500)
        }
    }

    private fun setupGeneralSosButton() {
        findViewById<Button>(R.id.btnGeneralSos).setOnClickListener {
            if (com.rescue.alert.data.GeneralSosOutbox.suppressesSos(this) || !isDeviceInCurrentRiskArea()) {
                updateDisasterStateUI()
                Toast.makeText(this, "ยังไม่ยืนยัน GPS ในพื้นที่แจ้งเตือน จึงยังส่งคำขอไม่ได้", Toast.LENGTH_LONG).show()
            } else sendGeneralSosConfirmation()
        }
        updateGeneralSosUi()
    }

    private fun updateGeneralSosUi() {
        val outbox = com.rescue.alert.data.GeneralSosOutbox
        if (outbox.suppressesSos(this) && layoutActiveDisaster.visibility != View.GONE) updateDisasterStateUI()
        findViewById<Button>(R.id.btnGeneralSos).apply {
            visibility = if (outbox.suppressesSos(this@MainActivity)) View.GONE else View.VISIBLE
            isEnabled = !generalSosSaving && !outbox.hasPending(this@MainActivity) && !outbox.isCompleted(this@MainActivity)
            text = "ต้องการช่วยเหลือ"
        }
        findViewById<TextView>(R.id.tvGeneralSosStatus).apply {
            text = if (generalSosSaving) "กำลังบันทึกคำขอ..." else outbox.status(this@MainActivity)
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
        }
    }

    private fun getBestDeviceLocation(): Location? {
        val locManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        var bestLoc: Location? = null
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        for (p in providers) {
            try {
                val loc = com.rescue.alert.util.LocationAccess.lastKnown(locManager, p)
                if (loc != null && (bestLoc == null || loc.time > bestLoc.time)) {
                    bestLoc = loc
                }
            } catch (e: Exception) {}
        }
        return bestLoc
    }

    private fun sendGeneralSosConfirmation() {
        if (generalSosSaving || com.rescue.alert.data.GeneralSosOutbox.hasPending(this) || com.rescue.alert.data.GeneralSosOutbox.suppressesSos(this)) return
        generalSosSaving = true
        updateGeneralSosUi()

        val name = if (CitizenEmergencyProfile.name.isNotBlank()) CitizenEmergencyProfile.name else etContactName.text.toString().trim().ifBlank { "ผู้ถือครองโทรศัพท์เครื่องนี้" }
        val phone = if (CitizenEmergencyProfile.phone.isNotBlank()) CitizenEmergencyProfile.phone else etContactPhone.text.toString().trim().ifBlank { "ไม่ระบุเบอร์ติดต่อ" }
        val members = if (CitizenEmergencyProfile.memberCount > 1) CitizenEmergencyProfile.memberCount else (etMemberCount.text.toString().trim().toIntOrNull() ?: 1)
        val isBedridden = CitizenEmergencyProfile.isBedridden || cbBedridden.isChecked
        val isElderly = CitizenEmergencyProfile.isElderly || cbElderly.isChecked
        val isInfant = CitizenEmergencyProfile.isInfant || cbInfant.isChecked
        val needs = if (CitizenEmergencyProfile.urgentNeeds.isNotBlank()) CitizenEmergencyProfile.urgentNeeds else etUrgentNeeds.text.toString().trim().ifBlank { "รอความช่วยเหลือ" }

        val devLoc = com.rescue.alert.source.area.AreaLocation.current(this@MainActivity)
        val hasGps = devLoc != null
        val lat: Double? = devLoc?.latitude
        val lng: Double? = devLoc?.longitude
        val accuracy = devLoc?.accuracy ?: -1.0f
        val alertId = DisasterStateManager.getAlertId(this)

        val batteryStatus: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100

        Thread {
            try {
                val payload = JSONObject().apply {
                    put("device_id", com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this@MainActivity).myNodeId)
                    put("alert_id", alertId)
                    if (hasGps && lat != null && lng != null) {
                        put("lat", lat)
                        put("lng", lng)
                        put("accuracy", accuracy.toDouble())
                        put("location_status", "LOCATION_AVAILABLE")
                    } else {
                        put("lat", JSONObject.NULL)
                        put("lng", JSONObject.NULL)
                        put("accuracy", -1.0)
                        put("location_status", "LOCATION_UNAVAILABLE")
                    }
                    put("battery", batteryPct)
                    put("timestamp", System.currentTimeMillis())

                    put("contact_name", name)
                    put("contact_phone", phone)
                    put("member_count", members)
                    put("is_bedridden", isBedridden)
                    put("is_elderly", isElderly)
                    put("is_infant", isInfant)
                    put("urgent_needs", needs)
                    put("urgent_note", "ขอความช่วยเหลือทั่วไปในพื้นที่แจ้งเตือน ให้เจ้าหน้าที่แนวหลังประสานงาน")
                }
                com.rescue.alert.data.GeneralSosOutbox.queue(this@MainActivity, payload)
                com.rescue.alert.data.GeneralSosOutbox.retry(this@MainActivity)
                runOnUiThread {
                    generalSosSaving = false
                    updateGeneralSosUi()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    generalSosSaving = false
                    updateGeneralSosUi()
                    Toast.makeText(this@MainActivity, "บันทึกคำขอไม่สำเร็จ กรุณาลองใหม่", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun isAccessConfirmed(): Boolean {
        val prefs = getSharedPreferences("rescue_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("user_confirmed_system_access", false)
    }

    private fun setAccessConfirmed(confirmed: Boolean) {
        val prefs = getSharedPreferences("rescue_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("user_confirmed_system_access", confirmed).apply()
    }

    private fun setupPermissions() {
        btnGrantPermissions.setOnClickListener {
            handleConfirmSystemAccess()
        }
    }

    private fun handleConfirmSystemAccess() {
        val locGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true

        if (!locGranted || !notifGranted) {
            requestAllPermissions()
        } else {
            setAccessConfirmed(true)
            updateLocationAndPermissions()
            Toast.makeText(this, "ยืนยันการเข้าถึงระบบแล้ว แสดงตำแหน่งเครื่องนี้บนแผนที่เรียบร้อย", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupProfileAccordion() {
        // Populate UI from persistent profile
        if (CitizenEmergencyProfile.name.isNotBlank()) etContactName.setText(CitizenEmergencyProfile.name)
        if (CitizenEmergencyProfile.phone.isNotBlank()) etContactPhone.setText(CitizenEmergencyProfile.phone)
        if (CitizenEmergencyProfile.memberCount > 1) etMemberCount.setText(CitizenEmergencyProfile.memberCount.toString())
        cbBedridden.isChecked = CitizenEmergencyProfile.isBedridden
        cbElderly.isChecked = CitizenEmergencyProfile.isElderly
        cbInfant.isChecked = CitizenEmergencyProfile.isInfant
        if (CitizenEmergencyProfile.urgentNeeds.isNotBlank()) etUrgentNeeds.setText(CitizenEmergencyProfile.urgentNeeds)
        if (CitizenEmergencyProfile.isSavedInRam) {
            tvProfileStatusChip.text = "บันทึกเรียบร้อย"
            tvProfileStatusChip.setTextColor(ContextCompat.getColor(this, R.color.signal_green_bright))
        }

        // Start collapsed by default
        toggleProfileAccordion(false)

        // Toggle collapse/expand on header click
        layoutProfileHeader.setOnClickListener {
            toggleProfileAccordion(!isProfileExpanded)
        }

        // View full PDPA policy link
        findViewById<TextView>(R.id.btnViewPdpaPolicy)?.setOnClickListener {
            showLegalAndAuditDialog(1)
        }

        // Save Profile Button
        btnSaveProfile.setOnClickListener {
            val name = etContactName.text.toString().trim()
            val phone = etContactPhone.text.toString().trim()
            val members = etMemberCount.text.toString().trim().toIntOrNull() ?: 1
            val needs = etUrgentNeeds.text.toString().trim()

            // Save in model and persist to SharedPreferences (Doc 1 Item 3)
            CitizenEmergencyProfile.name = name
            CitizenEmergencyProfile.phone = phone
            CitizenEmergencyProfile.memberCount = members
            CitizenEmergencyProfile.isBedridden = cbBedridden.isChecked
            CitizenEmergencyProfile.isElderly = cbElderly.isChecked
            CitizenEmergencyProfile.isInfant = cbInfant.isChecked
            CitizenEmergencyProfile.urgentNeeds = needs
            CitizenEmergencyProfile.isSavedInRam = true
            CitizenEmergencyProfile.persist(this)

            // Fold the accordion
            toggleProfileAccordion(false)
            tvProfileStatusChip.text = "บันทึกเรียบร้อย"
            tvProfileStatusChip.setTextColor(ContextCompat.getColor(this, R.color.signal_green_bright))

            Toast.makeText(
                this,
                "บันทึกข้อมูลเรียบร้อยแล้ว (จัดเก็บในเครื่องอย่างปลอดภัยเพื่อใช้ยามเกิดภัยพิบัติ)",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toggleProfileAccordion(expand: Boolean) {
        isProfileExpanded = expand
        android.transition.TransitionManager.beginDelayedTransition(cardEmergencyProfile)
        if (expand) {
            layoutProfileForm.visibility = View.VISIBLE
            ivProfileChevron.setImageResource(R.drawable.ic_chevron_up)
        } else {
            layoutProfileForm.visibility = View.GONE
            ivProfileChevron.setImageResource(R.drawable.ic_chevron_down)
        }
    }

    private fun setupSurvivalGuide() {
        findViewById<LinearLayout>(R.id.cardBtMeshCall)?.setOnClickListener {
            showBluetoothMeshCallDialog()
        }
        findViewById<LinearLayout>(R.id.cardSurvivalGuide).setOnClickListener {
            showSurvivalGuideDialog()
        }
        findViewById<LinearLayout>(R.id.cardDisasterNews)?.setOnClickListener {
            showNewsDialog()
        }
        findViewById<LinearLayout>(R.id.cardEmergencyHotlines)?.setOnClickListener {
            showHotlinesDialog()
        }
        findViewById<LinearLayout>(R.id.cardDamMonitor)?.setOnClickListener {
            showDamMonitorDialog()
        }
    }

    private fun setupPulsingSosButton() {
        btnPulsingSos.setOnClickListener {
            if (com.rescue.alert.data.GeneralSosOutbox.suppressesSos(this) || !isDeviceInCurrentRiskArea()) {
                updateDisasterStateUI()
                Toast.makeText(this, "ยังไม่ยืนยัน GPS ในพื้นที่แจ้งเตือน", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            tvSosRecordingStatus.text = "กำลังเปิดกล้องถ่ายภาพผู้ป่วยฉุกเฉิน..."
            try {
                takePatientPhotoLauncher.launch(null)
            } catch (e: Exception) {
                Log.e(TAG, "Cannot launch camera: ${e.message}")
                Toast.makeText(this, "ไม่สามารถเปิดกล้องได้: ${e.message}", Toast.LENGTH_SHORT).show()
                tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยัน"
            }
        }
    }

    private fun handlePatientPhotoCaptured(bitmap: Bitmap) {
        tvSosRecordingStatus.text = "กำลังเตรียมส่งภาพถ่ายและพิกัดผู้ป่วยวิกฤต..."
        Thread {
            try {
                val stream = java.io.ByteArrayOutputStream()
                val maxDim = 800
                val scaled = if (bitmap.width > maxDim || bitmap.height > maxDim) {
                    val ratio = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height)
                    Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                } else {
                    bitmap
                }
                scaled.compress(Bitmap.CompressFormat.JPEG, 70, stream)
                val photoBytes = stream.toByteArray()
                val photoBase64 = Base64.encodeToString(photoBytes, Base64.NO_WRAP)

                runOnUiThread { sendCriticalPatientSos(photoBase64) }
            } catch (e: Exception) {
                Log.e(TAG, "Error encoding photo: ${e.message}")
                runOnUiThread {
                    tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยัน"
                    Toast.makeText(this@MainActivity, "ไม่สามารถประมวลผลภาพถ่ายได้", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun sendCriticalPatientSos(photoBase64: String) {
        if (com.rescue.alert.data.GeneralSosOutbox.suppressesSos(this)) return
        val locManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var location: Location? = null
        val providers = listOf("fused", LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        for (p in providers) {
            try {
                val loc = com.rescue.alert.util.LocationAccess.lastKnown(locManager, p)
                if (loc != null && (location == null || loc.time > location.time)) {
                    location = loc
                }
            } catch (_: Exception) {}
        }

        val hasGps = location != null
        val lat: Double? = location?.latitude
        val lng: Double? = location?.longitude
        val accuracy = location?.accuracy ?: -1.0f

        val batteryStatus: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100

        // อ่านข้อมูลส่วนบุคคลสำหรับทีมกู้ภัย (จากโปรไฟล์ที่บันทึกไว้ และฟอร์มหน้าจอ)
        val profileName = if (CitizenEmergencyProfile.name.isNotBlank()) CitizenEmergencyProfile.name else etContactName.text.toString().trim().ifBlank { "ผู้ถือครองโทรศัพท์" }
        val profilePhone = if (CitizenEmergencyProfile.phone.isNotBlank()) CitizenEmergencyProfile.phone else etContactPhone.text.toString().trim().ifBlank { "ไม่ระบุเบอร์ติดต่อ" }
        val profileMembers = if (CitizenEmergencyProfile.memberCount > 1) CitizenEmergencyProfile.memberCount else (etMemberCount.text.toString().trim().toIntOrNull() ?: 1)
        val profileBedridden = CitizenEmergencyProfile.isBedridden || cbBedridden.isChecked
        val profileElderly = CitizenEmergencyProfile.isElderly || cbElderly.isChecked
        val profileInfant = CitizenEmergencyProfile.isInfant || cbInfant.isChecked
        val profileNeeds = if (CitizenEmergencyProfile.urgentNeeds.isNotBlank()) CitizenEmergencyProfile.urgentNeeds else etUrgentNeeds.text.toString().trim()

        Thread {
            try {
                // Submit a case only. SOS does not emit legacy voice/call-control packets.
                val payload = JSONObject().apply {
                    put("device_id", com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this@MainActivity).myNodeId)
                    put("case_id", "CRITICAL_${java.util.UUID.randomUUID()}")
                    put("alert_id", DisasterStateManager.getAlertId(this@MainActivity))
                    if (hasGps && lat != null && lng != null) {
                        put("lat", lat)
                        put("lng", lng)
                        put("accuracy", accuracy.toDouble())
                        put("location_status", "LOCATION_AVAILABLE")
                    } else {
                        put("lat", JSONObject.NULL)
                        put("lng", JSONObject.NULL)
                        put("accuracy", -1.0)
                        put("location_status", "LOCATION_UNAVAILABLE")
                    }
                    put("battery", batteryPct)
                    put("timestamp", System.currentTimeMillis())

                    put("contact_name", profileName)
                    put("contact_phone", profilePhone)
                    put("member_count", profileMembers)
                    put("is_bedridden", profileBedridden)
                    put("is_elderly", profileElderly)
                    put("is_infant", profileInfant)
                    put("urgent_needs", profileNeeds)
                    put("urgent_note", "")
                    put("case_type", "CRITICAL")
                    put("patient_photo_base64", photoBase64)
                    put("voice_audio_base64", "")
                }

                val isSent = EmergencyOutboxManager.sendSosPayload(payload.toString(), context = this@MainActivity)
                if (isSent) {
                    runOnUiThread {
                        tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยันอีกครั้ง"
                        tvSosConfirmedStatus.visibility = View.VISIBLE
                        tvSosConfirmedStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#10B981"))
                        tvSosConfirmedStatus.text = if (hasGps) "เซิร์ฟเวอร์ตอบรับข้อมูล SOS พร้อมภาพและพิกัดแล้ว"
                        else "เซิร์ฟเวอร์ตอบรับข้อมูล SOS พร้อมภาพแล้ว แต่ไม่มีพิกัด GPS จึงยังแสดงหมุดไม่ได้"
                        Toast.makeText(this@MainActivity, "เซิร์ฟเวอร์ตอบรับข้อมูล SOS แล้ว", Toast.LENGTH_LONG).show()
                    }
                } else {
                    EmergencyOutboxManager.enqueueSos(this@MainActivity, payload.toString())
                    runOnUiThread {
                        tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยันอีกครั้ง"
                        tvSosConfirmedStatus.visibility = View.VISIBLE
                        tvSosConfirmedStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#F59E0B"))
                        tvSosConfirmedStatus.text = if (hasGps) "บันทึกในคิว: รอส่งภาพและพิกัดเมื่อเชื่อมต่อศูนย์สั่งการได้"
                        else "บันทึกในคิว: รอส่งภาพและข้อมูล SOS โดยไม่มีพิกัด GPS"
                        Toast.makeText(this@MainActivity, "บันทึกข้อมูลและภาพถ่ายผู้ป่วยลงคิวฉุกเฉินแล้ว", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send patient SOS: ${e.message}")
                runOnUiThread {
                    tvSosRecordingStatus.text = "แตะเพื่อเปิดกล้องถ่ายภาพผู้ป่วยยืนยันอีกครั้ง"
                    tvSosConfirmedStatus.visibility = View.VISIBLE
                    tvSosConfirmedStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#F59E0B"))
                    tvSosConfirmedStatus.text = "เกิดข้อผิดพลาดในการส่งข้อมูล"
                }
            }
        }.start()
    }

    private fun setupDrawerNavigation() {
        // 1. News
        findViewById<LinearLayout>(R.id.drawerItemNews).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showNewsDialog()
        }

        // 2. Hotlines
        findViewById<LinearLayout>(R.id.drawerItemHotlines).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showHotlinesDialog()
        }

        // 3. Dam Water Monitoring
        findViewById<LinearLayout>(R.id.drawerItemDams).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showDamMonitorDialog()
        }

        // 4. Settings
        findViewById<LinearLayout>(R.id.drawerItemSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showSettingsDialog()
        }

        // 4.1 Legal Agreements, PDPA & Verifiable Audit
        findViewById<LinearLayout>(R.id.drawerItemLegal)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showLegalAndAuditDialog()
        }

        // 5. AM Radio
        findViewById<LinearLayout>(R.id.drawerItemAmRadio)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showAmRadioDialog()
        }

        // 6. Bluetooth Mesh Calling (Offline Multi-hop Intercom)
        findViewById<LinearLayout>(R.id.drawerItemBtMesh)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showBluetoothMeshCallDialog()
        }

        // 7. Evacuation & Safe Parking Sites
        findViewById<LinearLayout>(R.id.drawerItemShelters)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            showSheltersDialog()
        }
    }

    private fun showBluetoothMeshCallDialog() {
        if (isFinishing || isDestroyed) return
        if (BluetoothMeshCallDialog.isShowing()) return
        BluetoothMeshCallDialog(this).show()
    }

    private fun showLegalAndAuditDialog(tabIndex: Int = 0) {
        LegalAndAuditDialog.show(this, tabIndex)
    }

    private val amRadioPlayerListener: (com.rescue.alert.data.AmRadioPlayer.State, com.rescue.alert.model.AmStation?) -> Unit = { _, _ ->
        updateAmRadioIndicator()
    }

    private fun setupAmRadioPlayerListener() {
        com.rescue.alert.data.AmRadioPlayer.addListener(amRadioPlayerListener)
    }

    private fun showAmRadioDialog() {
        AmRadioDialog.show(this) {
            updateAmRadioIndicator()
        }
    }

    private fun updateAmRadioIndicator() {
        val ivIcon = findViewById<ImageView>(R.id.ivRadioAmIcon) ?: return
        val tvBadge = findViewById<TextView>(R.id.tvAmBadge) ?: return
        if (com.rescue.alert.data.AmRadioPlayer.isPlaying()) {
            ivIcon.setColorFilter(Color.parseColor("#10B981"))
            tvBadge.text = "ON AIR"
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am_active)
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#10B981"))
        } else if (com.rescue.alert.data.AmRadioPlayer.state == com.rescue.alert.data.AmRadioPlayer.State.BUFFERING) {
            ivIcon.setColorFilter(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
            tvBadge.text = "LOAD"
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am)
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
        } else {
            ivIcon.setColorFilter(ContextCompat.getColor(this, R.color.tactical_text_secondary))
            tvBadge.text = "AM"
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am)
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
        }
    }

    /**
     * Updates top-bar tvMeshBadge and ivBtMeshIcon based on active mesh telemetry.
     * Displays "EOC" (Cyan #38BDF8) when gateway is present,
     * or "MESH (N)" (Green #10B981) when neighbor nodes exist,
     * or "MESH" (Slate #94A3B8) on standby.
     */
    private fun updateMeshStatusBadge(nodes: List<com.rescue.alert.model.MeshNode> = emptyList()) {
        val ivIcon = findViewById<ImageView>(R.id.ivBtMeshIcon) ?: return
        val tvBadge = findViewById<TextView>(R.id.tvMeshBadge) ?: return
        val tvReadiness = findViewById<TextView>(R.id.tvBluetoothReadiness)
        val hasPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE)
                .all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter
        val adapterState = if (hasPermission) try { adapter?.state } catch (_: SecurityException) { null } else null
        val bluetoothState = when {
            adapter == null -> "เครื่องนี้ไม่มี Bluetooth"
            !hasPermission -> "ยังไม่ได้อนุญาตสิทธิ์ Bluetooth"
            adapterState == null -> "ยังตรวจสถานะ Bluetooth ไม่ได้"
            adapterState == android.bluetooth.BluetoothAdapter.STATE_ON -> null
            adapterState == android.bluetooth.BluetoothAdapter.STATE_OFF -> "ปิดอยู่ • เปิดก่อนใช้ Mesh"
            else -> "กำลังเปลี่ยนสถานะ • ยังไม่พร้อมใช้ Mesh"
        }
        if (bluetoothState != null) {
            tvReadiness.text = "Bluetooth: $bluetoothState"
            ivIcon.setColorFilter(ContextCompat.getColor(this, R.color.tactical_text_secondary))
            tvBadge.text = if (adapterState == android.bluetooth.BluetoothAdapter.STATE_OFF) "BT OFF" else "BT ?"
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am)
            return
        }

        val activeNodes = if (nodes.isEmpty()) {
            try {
                com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this).getNodes()
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            nodes
        }

        val hasEocGateway = activeNodes.any {
            it.nodeType == com.rescue.alert.model.MeshNodeType.RESCUE_POST ||
            it.nodeId == "EOC_GATEWAY_HQ" ||
            it.houseName.contains("EOC", ignoreCase = true)
        }

        tvReadiness.text = when {
            hasEocGateway -> "Bluetooth: เปิดอยู่ • ตรวจพบศูนย์ EOC"
            activeNodes.isNotEmpty() -> "Bluetooth: เปิดอยู่ • ตรวจพบอุปกรณ์ Mesh ${activeNodes.size} เครื่อง"
            else -> "Bluetooth: เปิดอยู่ • ยังไม่พบอุปกรณ์ Mesh"
        }

        if (hasEocGateway) {
            ivIcon.setColorFilter(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
            tvBadge.text = "EOC"
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am)
        } else if (activeNodes.isNotEmpty()) {
            ivIcon.setColorFilter(Color.parseColor("#10B981"))
            tvBadge.text = "MESH (${activeNodes.size})"
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#10B981"))
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am_active)
        } else {
            ivIcon.setColorFilter(ContextCompat.getColor(this, R.color.tactical_text_secondary))
            tvBadge.text = "MESH"
            tvBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            tvBadge.setBackgroundResource(R.drawable.bg_tactical_badge_am)
        }
    }

    private fun showNewsDialog() {
        DisasterNewsDialog.show(this)
    }

    private fun showHotlinesDialog() {
        val devLoc = getBestDeviceLocation()
        ProvinceHotlinesDialog.show(this, devLoc?.latitude, devLoc?.longitude)
    }

    private fun showDamMonitorDialog() {
        DamMonitorDialog.show(this)
    }

    private fun showSettingsDialog() {
        SettingsDialog.show(this) { scaleChanged, powerChanged ->
            EvacuationSiteRepository.getInstance(this).syncFromGatewayAsync()
            applyPowerSavingMode()
            if (scaleChanged) {
                Toast.makeText(this, "ปรับขนาดการแสดงผลสำเร็จ กำลังปรับใช้...", Toast.LENGTH_SHORT).show()
                recreate()
            } else if (powerChanged) {
                val active = AppSettings.isPowerSavingActive(this)
                val msg = if (active) "เปิดโหมดประหยัดพลังงานฉุกเฉินยามไฟดับแล้ว" else "ปิดโหมดประหยัดพลังงานแล้ว"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun applyPowerSavingMode() {
        val isPowerSaving = AppSettings.isPowerSavingActive(this)
        AppSettings.applyWindowPowerSaving(this, isPowerSaving)

        val banner = findViewById<View>(R.id.layoutUltraPowerSaveBanner)
        val tvTitle = findViewById<TextView>(R.id.tvPowerSaveTitle)
        val tvDesc = findViewById<TextView>(R.id.tvPowerSaveDesc)
        findViewById<Button>(R.id.btnQuickSettingsPower)?.setOnClickListener {
            showSettingsDialog()
        }

        if (isPowerSaving) {
            banner?.visibility = View.VISIBLE
            val batteryPct = AppSettings.getBatteryPercentage(this)
            val batteryText = if (batteryPct >= 0) "แบตเตอรี่ $batteryPct%" else "แบตเตอรี่ฉุกเฉิน"
            tvTitle?.text = "โหมดประหยัดพลังงานฉุกเฉิน ($batteryText)"
            tvDesc?.text = "ระงับแอนิเมชันคลื่นสัญญาณ ลดการใช้ชิป GPS ประหยัดแบตเตอรี่สูงสุดยามไฟดับ"

            stopBackgroundPulseWaveAnimation()
            syncIntervalMs = 300000L // 5 minutes
        } else {
            banner?.visibility = View.GONE
            syncIntervalMs = 25000L
            if (DisasterStateManager.isDisasterActive(this)) {
                startBackgroundPulseWaveAnimation()
            }
        }
    }

    private fun showSurvivalGuideDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
            setDimAmount(0.75f)
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_survival_guide, null)
        val btnDismiss = dialogView.findViewById<Button>(R.id.btnDismissSurvivalGuide)
        btnDismiss?.setOnClickListener {
            dialog.dismiss()
        }

        val btnTabAll = dialogView.findViewById<Button>(R.id.btnTabDisasterAll)
        val btnTabFlood = dialogView.findViewById<Button>(R.id.btnTabDisasterFlood)
        val btnTabEarthquake = dialogView.findViewById<Button>(R.id.btnTabDisasterEarthquake)
        val btnTabLandslide = dialogView.findViewById<Button>(R.id.btnTabDisasterLandslide)
        val btnTabWildfire = dialogView.findViewById<Button>(R.id.btnTabDisasterWildfire)

        val groupFlood = dialogView.findViewById<View>(R.id.groupDisasterFlood)
        val groupEarthquake = dialogView.findViewById<View>(R.id.groupDisasterEarthquake)
        val groupLandslide = dialogView.findViewById<View>(R.id.groupDisasterLandslide)
        val groupWildfire = dialogView.findViewById<View>(R.id.groupDisasterWildfire)
        val scrollContent = dialogView.findViewById<ScrollView>(R.id.scrollGuideContent)

        val activeTabBg = ContextCompat.getDrawable(this, R.drawable.bg_tactical_tab_active)
        val inactiveTabBg = ContextCompat.getDrawable(this, R.drawable.bg_tactical_tab_inactive)
        val activeTextColor = Color.WHITE
        val inactiveTextColor = ContextCompat.getColor(this, R.color.tactical_text_secondary)

        fun selectDisaster(selected: String) {
            btnTabAll.background = if (selected == "ALL") activeTabBg else inactiveTabBg
            btnTabAll.setTextColor(if (selected == "ALL") activeTextColor else inactiveTextColor)
            btnTabAll.setTypeface(null, if (selected == "ALL") android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

            btnTabFlood.background = if (selected == "FLOOD") activeTabBg else inactiveTabBg
            btnTabFlood.setTextColor(if (selected == "FLOOD") activeTextColor else inactiveTextColor)
            btnTabFlood.setTypeface(null, if (selected == "FLOOD") android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

            btnTabEarthquake.background = if (selected == "EARTHQUAKE") activeTabBg else inactiveTabBg
            btnTabEarthquake.setTextColor(if (selected == "EARTHQUAKE") activeTextColor else inactiveTextColor)
            btnTabEarthquake.setTypeface(null, if (selected == "EARTHQUAKE") android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

            btnTabLandslide.background = if (selected == "LANDSLIDE") activeTabBg else inactiveTabBg
            btnTabLandslide.setTextColor(if (selected == "LANDSLIDE") activeTextColor else inactiveTextColor)
            btnTabLandslide.setTypeface(null, if (selected == "LANDSLIDE") android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

            btnTabWildfire.background = if (selected == "WILDFIRE") activeTabBg else inactiveTabBg
            btnTabWildfire.setTextColor(if (selected == "WILDFIRE") activeTextColor else inactiveTextColor)
            btnTabWildfire.setTypeface(null, if (selected == "WILDFIRE") android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)

            when (selected) {
                "FLOOD" -> {
                    groupFlood.visibility = View.VISIBLE
                    groupEarthquake.visibility = View.GONE
                    groupLandslide.visibility = View.GONE
                    groupWildfire.visibility = View.GONE
                }
                "EARTHQUAKE" -> {
                    groupFlood.visibility = View.GONE
                    groupEarthquake.visibility = View.VISIBLE
                    groupLandslide.visibility = View.GONE
                    groupWildfire.visibility = View.GONE
                }
                "LANDSLIDE" -> {
                    groupFlood.visibility = View.GONE
                    groupEarthquake.visibility = View.GONE
                    groupLandslide.visibility = View.VISIBLE
                    groupWildfire.visibility = View.GONE
                }
                "WILDFIRE" -> {
                    groupFlood.visibility = View.GONE
                    groupEarthquake.visibility = View.GONE
                    groupLandslide.visibility = View.GONE
                    groupWildfire.visibility = View.VISIBLE
                }
                else -> {
                    groupFlood.visibility = View.VISIBLE
                    groupEarthquake.visibility = View.VISIBLE
                    groupLandslide.visibility = View.VISIBLE
                    groupWildfire.visibility = View.VISIBLE
                }
            }
            scrollContent.scrollTo(0, 0)
        }

        btnTabAll.setOnClickListener { selectDisaster("ALL") }
        btnTabFlood.setOnClickListener { selectDisaster("FLOOD") }
        btnTabEarthquake.setOnClickListener { selectDisaster("EARTHQUAKE") }
        btnTabLandslide.setOnClickListener { selectDisaster("LANDSLIDE") }
        btnTabWildfire.setOnClickListener { selectDisaster("WILDFIRE") }

        dialog.setContentView(dialogView)
        dialog.show()
    }

    private var currentSignalStrengthLevel = 0 // 0 means no measurement
    private var isCurrentlyWifiConnected = false
    private var currentSignalDbm = 0

    private fun checkWifiAndSignalStatus() {
        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            val connManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager

            isCurrentlyWifiConnected = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val caps = connManager?.getNetworkCapabilities(connManager.activeNetwork)
                caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
            } else {
                @Suppress("DEPRECATION")
                (connManager?.activeNetworkInfo?.type == android.net.ConnectivityManager.TYPE_WIFI)
            }

            if (isCurrentlyWifiConnected) {
                val wifiInfo = wifiManager?.connectionInfo
                val rssi = wifiInfo?.rssi?.takeIf { it in -126..-1 } ?: 0
                currentSignalDbm = rssi
                currentSignalStrengthLevel = when {
                    rssi == 0 -> 0
                    rssi >= -55 -> 4
                    rssi >= -70 -> 3
                    rssi >= -85 -> 2
                    else -> 1
                }
            } else {
                val measuredRssi = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
                    .getNodes().map { it.rssi }.filter { it in -126..-1 }.maxOrNull()
                currentSignalDbm = measuredRssi ?: 0
                currentSignalStrengthLevel = when {
                    measuredRssi == null -> 0
                    measuredRssi >= -55 -> 4
                    measuredRssi >= -70 -> 3
                    measuredRssi >= -85 -> 2
                    else -> 1
                }
            }
        } catch (e: Exception) {
            currentSignalStrengthLevel = 0
            currentSignalDbm = 0
        }

        updateWifiSignalBarUi()
    }

    private fun updateWifiSignalBarUi() {
        val bar1 = findViewById<View>(R.id.barSignal1) ?: return
        val bar2 = findViewById<View>(R.id.barSignal2) ?: return
        val bar3 = findViewById<View>(R.id.barSignal3) ?: return
        val bar4 = findViewById<View>(R.id.barSignal4) ?: return
        val ivWifi = findViewById<ImageView>(R.id.ivWifiIcon) ?: return

        val colorActive = when (currentSignalStrengthLevel) {
            4 -> Color.parseColor("#10B981") // Bright green
            3 -> com.rescue.alert.util.ThemePalette.color("#34D399") // Green
            2 -> Color.parseColor("#F59E0B") // Amber
            1 -> Color.parseColor("#EF4444") // Red
            else -> com.rescue.alert.util.ThemePalette.color("#64748B")
        }
        val colorInactive = com.rescue.alert.util.ThemePalette.color("#334155")

        if (isCurrentlyWifiConnected) {
            ivWifi.setColorFilter(ContextCompat.getColor(this, R.color.theme_38bdf8))
        } else {
            ivWifi.setColorFilter(ContextCompat.getColor(this, R.color.tactical_text_secondary))
        }

        bar1.setBackgroundColor(if (currentSignalStrengthLevel >= 1) colorActive else colorInactive)
        bar2.setBackgroundColor(if (currentSignalStrengthLevel >= 2) colorActive else colorInactive)
        bar3.setBackgroundColor(if (currentSignalStrengthLevel >= 3) colorActive else colorInactive)
        bar4.setBackgroundColor(if (currentSignalStrengthLevel >= 4) colorActive else colorInactive)
    }

    private fun showOfflineSignalDialog() {
        checkWifiAndSignalStatus()

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.75f)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_dialog_tactical_hotlines)
            setPadding(40, 36, 40, 36)
        }

        // Header
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 16)
        }

        val iconFrame = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(96, 96).apply { marginEnd = 24 }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_window_icon_frame)
            gravity = android.view.Gravity.CENTER
        }
        val ivWifi = ImageView(this).apply {
            setImageResource(R.drawable.ic_wifi)
            setColorFilter(if (isCurrentlyWifiConnected) com.rescue.alert.util.ThemePalette.color("#38BDF8") else Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(54, 54)
        }
        iconFrame.addView(ivWifi)
        headerLayout.addView(iconFrame)

        val headerTextLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(this).apply {
            text = "สถานะคลื่นสัญญาณ (Signal Telemetry)"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
        }
        val tvSubtitle = TextView(this).apply {
            text = if (isCurrentlyWifiConnected) "เชื่อมต่อเครือข่ายไวไฟแล้ว" else "โหมดสัญญาณไร้สายเฉพาะกิจ (ฉุกเฉินไร้เน็ต)"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
        }
        headerTextLayout.addView(tvTitle)
        headerTextLayout.addView(tvSubtitle)
        headerLayout.addView(headerTextLayout)
        container.addView(headerLayout)

        // Divider
        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2).apply {
                bottomMargin = 24
            }
            setBackgroundColor(com.rescue.alert.util.ThemePalette.color("#1E2B40"))
        }
        container.addView(divider)

        // Signal Status Box (Tactical Elevated Card)
        val statusBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_card_elevated)
            setPadding(28, 24, 28, 24)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 20
            }
        }

        // Connection State Badge
        val tvConnState = TextView(this).apply {
            if (isCurrentlyWifiConnected) {
                text = "สถานะ: เชื่อมต่อไวไฟ (ONLINE)"
                setBackgroundResource(R.drawable.bg_badge_dam_status_green)
            } else {
                text = "สถานะ: ไม่ได้เชื่อมต่อไวไฟ (OFFLINE / DIRECT)"
                setBackgroundResource(R.drawable.bg_tactical_rect_btn_amber)
            }
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(20, 8, 20, 8)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 14
            }
        }
        statusBox.addView(tvConnState)

        val signalLevelColor = when (currentSignalStrengthLevel) {
            4 -> Color.parseColor("#10B981")
            3 -> com.rescue.alert.util.ThemePalette.color("#34D399")
            2 -> Color.parseColor("#F59E0B")
            1 -> Color.parseColor("#EF4444")
            else -> com.rescue.alert.util.ThemePalette.color("#64748B")
        }

        val signalLabel = when (currentSignalStrengthLevel) {
            4 -> "สัญญาณแรงมาก (4/4)"
            3 -> "สัญญาณดี (3/4)"
            2 -> "สัญญาณปานกลาง (2/4)"
            1 -> "สัญญาณอ่อน (1/4)"
            else -> "กำลังค้นหาสัญญาณ..."
        }

        val tvSignalStrength = TextView(this).apply {
            text = if (currentSignalDbm != 0) "ระดับความแรงสัญญาณ: $signalLabel • $currentSignalDbm dBm" else "ยังไม่มีค่าความแรงสัญญาณที่ตรวจวัดได้"
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(signalLevelColor)
            setPadding(0, 0, 0, 10)
        }
        statusBox.addView(tvSignalStrength)

        // Large 4-bar indicator in dialog
        val barContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 16).apply {
                bottomMargin = 10
            }
        }
        for (i in 1..4) {
            val bar = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    if (i < 4) marginEnd = 6
                }
                setBackgroundColor(if (currentSignalStrengthLevel >= i) signalLevelColor else com.rescue.alert.util.ThemePalette.color("#334155"))
            }
            barContainer.addView(bar)
        }
        statusBox.addView(barContainer)
        container.addView(statusBox)

        val tvBody = TextView(this).apply {
            text = if (isCurrentlyWifiConnected) {
                "อุปกรณ์ของคุณกำลังเชื่อมต่ออินเทอร์เน็ตผ่าน Wi-Fi ข้อมูลระดับน้ำ ข่าวสาร และประกาศเตือนภัยจะได้รับการอัปเดตแบบเรียลไทม์"
            } else {
                "ในกรณีที่ไม่ได้เชื่อมต่อไวไฟ แถบสีบนปุ่มจะแสดงความแรงสัญญาณของคลื่นวิทยุสื่อสารเฉพาะกิจและโครงข่ายไร้สายกู้ภัยรอบตัว (Tactical Mesh) เพื่อให้คุณทราบว่าอยู่ในรัศมีที่สามารถส่งพิกัด SOS ไปยังทีมกู้ภัยได้หรือไม่"
            }
            textSize = 13f
            setLineSpacing(4f, 1f)
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_secondary))
            setPadding(0, 0, 0, 24)
        }
        container.addView(tvBody)

        val btnClose = Button(this).apply {
            text = "เข้าใจแล้ว / ปิดหน้าต่าง (CLOSE)"
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_tactical_btn_dismiss)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 110)
            setOnClickListener { dialog.dismiss() }
        }
        container.addView(btnClose)

        dialog.setContentView(container)
        dialog.show()
    }

    private fun setupEvacuationSites() {
        val repo = EvacuationSiteRepository.getInstance(this)
        rescueMapView.setEvacuationSites(repo.getAllActiveSites())
        updateNearestShelterBanner()

        repo.addListener(sitesListener)
        com.rescue.alert.source.EvacuationSiteSync.schedule(this)

        // Background HTTP sync from EOC Gateway if connected
        repo.syncFromGatewayAsync()
    }

    private val sitesListener: (List<EvacuationSite>) -> Unit = { sites ->
        if (!isDestroyed) {
            rescueMapView.setEvacuationSites(sites)
            updateNearestShelterBanner()
        }
    }

    private fun updateNearestShelterBanner() {
        try {
            val repo = EvacuationSiteRepository.getInstance(this)
            val allSites = repo.getAllActiveSites()
            tvShelterCountBadge.text = "${allSites.size} แห่ง"

            val userLat = CitizenEmergencyProfile.lastLatitude ?: Double.NaN
            val userLng = CitizenEmergencyProfile.lastLongitude ?: Double.NaN
            if (!EvacuationSiteRepository.hasLocation(userLat, userLng)) {
                tvNearestShelterInfo.text = "รอตำแหน่ง GPS เพื่อหาศูนย์พักพิงใกล้คุณ"
                tvNearestParkingInfo.text = "เปิดรายการเพื่อดูสถานที่ที่ได้รับจากศูนย์สั่งการ"
                return
            }

            val nearestShelter = repo.getNearestShelter(userLat, userLng)
            if (nearestShelter != null) {
                tvNearestShelterInfo.text = "ศูนย์พักพิงใกล้สุด: ${nearestShelter.first.name} (ห่าง ${nearestShelter.second} กม.)"
            } else {
                tvNearestShelterInfo.text = "ศูนย์พักพิงใกล้สุด: ไม่มีข้อมูล"
            }

            val nearestParking = repo.getNearestParking(userLat, userLng)
            if (nearestParking != null) {
                tvNearestParkingInfo.text = "ที่จอดรถปลอดภัย: ${nearestParking.first.name} (ห่าง ${nearestParking.second} กม.)"
            } else {
                tvNearestParkingInfo.text = "ที่จอดรถปลอดภัย: ไม่มีข้อมูล"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating nearest shelter banner", e)
        }
    }

    private fun showSheltersDialog() {
        val userLat = CitizenEmergencyProfile.lastLatitude ?: Double.NaN
        val userLng = CitizenEmergencyProfile.lastLongitude ?: Double.NaN
        EvacuationSitesDialog.show(this, userLat, userLng) { lat, lng ->
            rescueMapView.focusLocation(lat, lng, 16)
            findViewById<ScrollView>(R.id.mainContentScrollView)?.smoothScrollTo(0, 0)
        }
    }

    private fun requestAllPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                REQUEST_PERMISSIONS
            )
        }

        // Battery optimization exemption
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }

        // Android 14 full screen intent
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!notifManager.canUseFullScreenIntent()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun updateLocationAndPermissions() {
        val locGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true

        val isConfirmed = isAccessConfirmed() && locGranted

        if (isConfirmed) {
            com.rescue.alert.source.area.AreaAlertService.start(this)
            btnGrantPermissions.visibility = if (notifGranted) View.GONE else View.VISIBLE
            layoutPermissionGrantedBadge.visibility = if (notifGranted) View.VISIBLE else View.GONE

            val locManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var location: Location? = null
            val providers = listOf("fused", LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            for (p in providers) {
                try {
                    val loc = com.rescue.alert.util.LocationAccess.lastKnown(locManager, p)
                    if (loc != null && (location == null || loc.time > location.time)) {
                        location = loc
                    }
                } catch (e: Exception) {}
            }
            if (location != null) {
                rescueMapView.setLocationPermissionGranted(true, location.latitude, location.longitude, location.accuracy)
                CitizenEmergencyProfile.lastLatitude = location.latitude
                CitizenEmergencyProfile.lastLongitude = location.longitude
                updateDisasterStateUI()
                updateNearestShelterBanner()
            } else {
                rescueMapView.setLocationPermissionGranted(true, 0.0, 0.0, -1f)
            }

            // Request precise location from Google Play Services FusedLocationProvider
            try {
                val fusedClient = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(this)
                fusedClient.getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener(this) { loc ->
                    if (loc != null) {
                        com.rescue.alert.source.area.AreaLocation.accept(loc)
                        rescueMapView.setLocationPermissionGranted(true, loc.latitude, loc.longitude, loc.accuracy)
                        CitizenEmergencyProfile.lastLatitude = loc.latitude
                        CitizenEmergencyProfile.lastLongitude = loc.longitude
                        updateDisasterStateUI()
                        updateNearestShelterBanner()
                    }
                }
            } catch (e: Exception) {}
        } else {
            // Unconfirmed or permissions not granted: hide user location dot
            btnGrantPermissions.visibility = View.VISIBLE
            layoutPermissionGrantedBadge.visibility = View.GONE
            rescueMapView.clearUserLocation()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            val locGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (locGranted) {
                setAccessConfirmed(true)
                Toast.makeText(this, "ยืนยันการเข้าถึงระบบแล้ว แสดงตำแหน่งเครื่องนี้บนแผนที่เรียบร้อย", Toast.LENGTH_SHORT).show()
            }
            updateLocationAndPermissions()

            // F-01 & F-07: Ensure Bluetooth servers and foreground service are started immediately after permission grant
            try {
                val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
                mesh.ensureServersStarted()
                com.rescue.alert.bluetooth.MeshForegroundService.startService(this)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to start mesh servers after permissions grant: ${e.message}")
            }
        } else if (requestCode == REQUEST_CALL_AUDIO_PERMISSION) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) answerOfficerCall()
            else Toast.makeText(this, "อนุญาตไมโครโฟนเพื่อสนทนากับเจ้าหน้าที่", Toast.LENGTH_LONG).show()
        }
    }

    private fun subscribeFcmTopic() {
        try {
            com.rescue.alert.source.OfficialCellBroadcastSync.subscribePush(this)
            com.google.firebase.messaging.FirebaseMessaging.getInstance()
                .subscribeToTopic("emergency_alerts")
        } catch (e: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        com.rescue.alert.data.AmRadioPlayer.removeListener(amRadioPlayerListener)
        EvacuationSiteRepository.getInstance(this).removeListener(sitesListener)
        try {
            unregisterReceiver(disasterStateReceiver)
        } catch (e: Exception) {}
        stopBackgroundPulseWaveAnimation()
        try {
            rescueMapView.destroy()
        } catch (e: Exception) {}
        // The foreground service owns the radio lifetime, including activity recreation.
        val mesh = com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(this)
        mesh.onIncomingCallReceived = null
        mesh.onCallStateChanged = null
        mesh.onOfficerAnnouncementStateChanged = null
        mesh.onMeshNodesUpdated = null
        incomingOfficerCallDialog?.dismiss()
    }
}
