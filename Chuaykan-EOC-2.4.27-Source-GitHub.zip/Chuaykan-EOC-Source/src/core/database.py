#!/usr/bin/env python3
"""
SQLite Storage for SOS Emergency Cases, Disaster Circles, and Operations Logs
"""
from __future__ import annotations
import json
import sqlite3
import threading
import time
from typing import List, Optional, Dict, Any
from src.core.config import DATABASE_PATH, RECORDINGS_DIR
from pathlib import Path
from src.core.models import SosCase, DisasterZone, EvacuationSite

_lock = threading.Lock()

class Database:
    def __init__(self, db_path=DATABASE_PATH):
        self.db_path = str(db_path)
        self._init_schema()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.execute("PRAGMA secure_delete=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS sos_cases (
                    case_id TEXT PRIMARY KEY,
                    device_id TEXT NOT NULL,
                    citizen_name TEXT,
                    phone_number TEXT,
                    latitude REAL,
                    longitude REAL,
                    accuracy_meters REAL,
                    member_count INTEGER,
                    is_bedridden INTEGER,
                    is_elderly INTEGER,
                    is_infant INTEGER,
                    urgent_needs TEXT,
                    urgent_note TEXT,
                    audio_file TEXT,
                    audio_duration_sec REAL,
                    status TEXT,
                    created_at REAL,
                    dispatched_at REAL,
                    rescued_at REAL,
                    assigned_team TEXT,
                    photo_file TEXT
                );
            """)

            try:
                cur.execute("ALTER TABLE sos_cases ADD COLUMN photo_file TEXT")
            except sqlite3.OperationalError:
                pass

            if "case_type" not in {row[1] for row in cur.execute("PRAGMA table_info(sos_cases)")}:
                cur.execute("ALTER TABLE sos_cases ADD COLUMN case_type TEXT NOT NULL DEFAULT 'CRITICAL'")

            if "completion_pending" not in {row[1] for row in cur.execute("PRAGMA table_info(sos_cases)")}:
                cur.execute("ALTER TABLE sos_cases ADD COLUMN completion_pending INTEGER NOT NULL DEFAULT 0")

            cur.execute("""
                CREATE TABLE IF NOT EXISTS disaster_zones (
                    zone_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    hazard_type TEXT,
                    severity TEXT,
                    center_lat REAL,
                    center_lng REAL,
                    radius_km REAL,
                    instruction TEXT,
                    agency TEXT,
                    created_at REAL,
                    is_active INTEGER
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS operation_logs (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL,
                    level TEXT,
                    event_type TEXT,
                    message TEXT,
                    details TEXT
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS evacuation_sites (
                    site_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    site_type TEXT NOT NULL,
                    latitude REAL NOT NULL,
                    longitude REAL NOT NULL,
                    capacity INTEGER DEFAULT 100,
                    contact_phone TEXT,
                    notes TEXT,
                    is_active INTEGER DEFAULT 1,
                    created_at REAL
                );
            """)

            conn.commit()
            conn.close()

    def upsert_sos_case(self, case: SosCase) -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO sos_cases (
                    case_id, device_id, citizen_name, phone_number, latitude, longitude,
                    accuracy_meters, member_count, is_bedridden, is_elderly, is_infant,
                    urgent_needs, urgent_note, audio_file, audio_duration_sec,
                    status, created_at, dispatched_at, rescued_at, assigned_team, photo_file, case_type
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(case_id) DO UPDATE SET
                    status=excluded.status,
                    dispatched_at=excluded.dispatched_at,
                    rescued_at=excluded.rescued_at,
                    assigned_team=excluded.assigned_team,
                    audio_file=coalesce(excluded.audio_file, sos_cases.audio_file),
                    photo_file=coalesce(excluded.photo_file, sos_cases.photo_file)
                    WHERE sos_cases.case_type = 'CRITICAL' AND excluded.case_type = 'CRITICAL'
            """, (
                case.case_id, case.device_id, case.citizen_name, case.phone_number,
                case.latitude, case.longitude, case.accuracy_meters, case.member_count,
                1 if case.is_bedridden else 0,
                1 if case.is_elderly else 0,
                1 if case.is_infant else 0,
                case.urgent_needs, case.urgent_note, case.audio_file, case.audio_duration_sec,
                case.status, case.created_at, case.dispatched_at, case.rescued_at, case.assigned_team,
                case.photo_file, case.case_type
            ))
            conn.commit()
            conn.close()

    def add_sos_case(self, case: SosCase) -> None:
        """Alias for upsert_sos_case for backward compatibility."""
        self.upsert_sos_case(case)

    def save_sos_case(self, case: SosCase) -> None:
        """Alias for upsert_sos_case for backward compatibility."""
        self.upsert_sos_case(case)

    def update_case_status(self, case_id: str, new_status: str, team: str = "") -> bool:
        if new_status == "RESCUED_SAFE":
            return self.finish_sos_case(case_id)
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            now = time.time()
            if new_status == "DISPATCHED":
                cur.execute("UPDATE sos_cases SET status = ?, dispatched_at = ?, assigned_team = ? WHERE case_id = ?",
                            (new_status, now, team, case_id))
            elif new_status == "RESCUED_SAFE":
                cur.execute("UPDATE sos_cases SET status = ?, rescued_at = ? WHERE case_id = ?",
                            (new_status, now, case_id))
            else:
                cur.execute("UPDATE sos_cases SET status = ? WHERE case_id = ?", (new_status, case_id))
            changed = cur.rowcount > 0
            conn.commit()
            conn.close()
            return changed

    def cleanup_orphan_sos_cache(self) -> int:
        """Startup-only cleanup before accepting uploads; preserve every referenced file."""
        with _lock:
            conn = self._get_conn()
            try:
                referenced = {name for row in conn.execute("SELECT audio_file, photo_file FROM sos_cases") for name in row if name}
                active_ids = [row[0] for row in conn.execute("SELECT case_id FROM sos_cases")]
                stale_logs = []
                for row in conn.execute("SELECT log_id, message FROM operation_logs WHERE event_type IN ('NEW_SOS', 'STATUS_CHANGE')"):
                    message = row[1] or ""
                    if not any("(" + cid + ")" in message or " " + cid + " " in message for cid in active_ids):
                        stale_logs.append((row[0],))
                conn.executemany("DELETE FROM operation_logs WHERE log_id=?", stale_logs)
                conn.commit()
                # Rewrite legacy free pages that may predate secure_delete.
                conn.execute("VACUUM")
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            finally:
                conn.close()
            removed = 0
            for path in RECORDINGS_DIR.glob("sos_*"):
                if path.name not in referenced and path.suffix in (".jpg", ".m4a", ".part") and path.is_file():
                    path.unlink()
                    removed += 1
            return removed

    def request_completion(self, case_id: str) -> None:
        with _lock:
            conn = self._get_conn()
            try:
                conn.execute("UPDATE sos_cases SET completion_pending=1 WHERE case_id=?", (case_id,))
                conn.commit()
            finally:
                conn.close()

    def pending_completions(self):
        with _lock:
            conn = self._get_conn()
            try:
                return [row[0] for row in conn.execute("SELECT case_id FROM sos_cases WHERE completion_pending=1")]
            finally:
                conn.close()

    def finish_sos_case(self, case_id: str, *, count=False) -> bool:
        """Delete one case, its attachments/logs; optionally retain only a local total."""
        with _lock:
            conn = self._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute("SELECT audio_file, photo_file FROM sos_cases WHERE case_id=?", (case_id,)).fetchone()
                if row is None:
                    conn.rollback()
                    return False
                conn.execute("DELETE FROM sos_cases WHERE case_id=?", (case_id,))
                conn.execute("DELETE FROM operation_logs WHERE instr(message, ?) > 0 OR instr(details, ?) > 0", (case_id, case_id))
                for name in row:
                    if name and Path(name).name == name:
                        shared = conn.execute("SELECT 1 FROM sos_cases WHERE audio_file=? OR photo_file=? LIMIT 1", (name, name)).fetchone()
                        if not shared:
                            (RECORDINGS_DIR / name).unlink(missing_ok=True)
                if count:
                    conn.execute("CREATE TABLE IF NOT EXISTS rescue_cache_total (id INTEGER PRIMARY KEY CHECK(id=1), total INTEGER NOT NULL)")
                    conn.execute("INSERT INTO rescue_cache_total VALUES (1, 1) ON CONFLICT(id) DO UPDATE SET total=total+1")
                conn.commit()
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                return True
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def rescued_total(self) -> int:
        with _lock:
            conn = self._get_conn()
            try:
                table = conn.execute("SELECT 1 FROM sqlite_master WHERE name='rescue_cache_total'").fetchone()
                row = conn.execute("SELECT total FROM rescue_cache_total WHERE id=1").fetchone() if table else None
                return row[0] if row else 0
            finally:
                conn.close()

    def clear_rescued_total(self) -> None:
        with _lock:
            conn = self._get_conn()
            try:
                if conn.execute("SELECT 1 FROM sqlite_master WHERE name='rescue_cache_total'").fetchone():
                    conn.execute("DELETE FROM rescue_cache_total")
                    conn.commit()
            finally:
                conn.close()

    def get_all_sos_cases(self) -> List[SosCase]:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM sos_cases ORDER BY created_at DESC")
            rows = cur.fetchall()
            cases = []
            for r in rows:
                cases.append(SosCase(
                    case_id=r["case_id"],
                    device_id=r["device_id"],
                    citizen_name=r["citizen_name"] or "ไม่ระบุชื่อ",
                    phone_number=r["phone_number"] or "ไม่มีเบอร์",
                    latitude=r["latitude"],
                    longitude=r["longitude"],
                    accuracy_meters=r["accuracy_meters"] or 15.0,
                    member_count=r["member_count"] or 1,
                    is_bedridden=bool(r["is_bedridden"]),
                    is_elderly=bool(r["is_elderly"]),
                    is_infant=bool(r["is_infant"]),
                    urgent_needs=r["urgent_needs"] or "",
                    urgent_note=r["urgent_note"] or "",
                    audio_file=r["audio_file"],
                    audio_duration_sec=r["audio_duration_sec"] or 0.0,
                    status=r["status"] or "PENDING",
                    created_at=r["created_at"],
                    dispatched_at=r["dispatched_at"],
                    rescued_at=r["rescued_at"],
                    assigned_team=r["assigned_team"] or "",
                    photo_file=r["photo_file"] if "photo_file" in r.keys() else None,
                    case_type=r["case_type"] if "case_type" in r.keys() else "CRITICAL"
                ))
            conn.close()
            return cases

    def get_sos_case(self, case_id: str) -> Optional[SosCase]:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM sos_cases WHERE case_id = ?", (case_id,))
            r = cur.fetchone()
            conn.close()
            if not r:
                return None
            return SosCase(
                case_id=r["case_id"],
                device_id=r["device_id"],
                citizen_name=r["citizen_name"] or "ไม่ระบุชื่อ",
                phone_number=r["phone_number"] or "ไม่มีเบอร์",
                latitude=r["latitude"],
                longitude=r["longitude"],
                accuracy_meters=r["accuracy_meters"] or 15.0,
                member_count=r["member_count"] or 1,
                is_bedridden=bool(r["is_bedridden"]),
                is_elderly=bool(r["is_elderly"]),
                is_infant=bool(r["is_infant"]),
                urgent_needs=r["urgent_needs"] or "",
                urgent_note=r["urgent_note"] or "",
                audio_file=r["audio_file"],
                audio_duration_sec=r["audio_duration_sec"] or 0.0,
                status=r["status"] or "PENDING",
                created_at=r["created_at"],
                dispatched_at=r["dispatched_at"],
                rescued_at=r["rescued_at"],
                assigned_team=r["assigned_team"] or "",
                photo_file=r["photo_file"] if "photo_file" in r.keys() else None,
                    case_type=r["case_type"] if "case_type" in r.keys() else "CRITICAL"
            )

    def set_active_zone(self, zone: DisasterZone) -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("UPDATE disaster_zones SET is_active = 0")
            cur.execute("""
                INSERT OR REPLACE INTO disaster_zones (
                    zone_id, title, hazard_type, severity, center_lat, center_lng,
                    radius_km, instruction, agency, created_at, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, (
                zone.zone_id, zone.title, zone.hazard_type, zone.severity,
                zone.center_lat, zone.center_lng, zone.radius_km, zone.instruction,
                zone.agency, zone.created_at
            ))
            conn.commit()
            conn.close()

    def get_active_zone(self) -> Optional[DisasterZone]:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM disaster_zones WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1")
            row = cur.fetchone()
            conn.close()
            if not row:
                return None
            return DisasterZone(
                zone_id=row["zone_id"],
                title=row["title"],
                hazard_type=row["hazard_type"],
                severity=row["severity"],
                center_lat=row["center_lat"],
                center_lng=row["center_lng"],
                radius_km=row["radius_km"],
                instruction=row["instruction"],
                agency=row["agency"],
                created_at=row["created_at"],
                is_active=bool(row["is_active"])
            )

    def replace_active_zones(self, zones: List[DisasterZone], *, microphone=None) -> None:
        """Atomically replace the operator-selected active risk areas (maximum ten)."""
        clean_zones = [zone for zone in zones if zone.is_active]
        if microphone is not None:
            clean_zones = [zone for zone in clean_zones
                           if (zone.zone_id == "MIC_ZONE_01") == microphone]
        controls = [zone for zone in clean_zones if zone.zone_id != "MIC_ZONE_01"][:10]
        mic_zones = [zone for zone in clean_zones if zone.zone_id == "MIC_ZONE_01"][:1]
        clean_zones = controls + mic_zones
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            if microphone is None:
                cur.execute("UPDATE disaster_zones SET is_active = 0")
            else:
                operator = "=" if microphone else "!="
                cur.execute(
                    f"UPDATE disaster_zones SET is_active = 0 WHERE zone_id {operator} ?",
                    ("MIC_ZONE_01",),
                )
            for zone in clean_zones:
                cur.execute("""
                    INSERT OR REPLACE INTO disaster_zones (
                        zone_id, title, hazard_type, severity, center_lat, center_lng,
                        radius_km, instruction, agency, created_at, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """, (
                    zone.zone_id, zone.title, zone.hazard_type, zone.severity,
                    zone.center_lat, zone.center_lng, zone.radius_km, zone.instruction,
                    zone.agency, zone.created_at
                ))
            conn.commit()
            conn.close()

    def get_active_zones(self) -> List[DisasterZone]:
        """Return every enabled risk area, without inventing defaults."""
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM disaster_zones WHERE is_active = 1 ORDER BY zone_id ASC")
            rows = cur.fetchall()
            conn.close()
        return [
            DisasterZone(
                zone_id=row["zone_id"],
                title=row["title"],
                hazard_type=row["hazard_type"],
                severity=row["severity"],
                center_lat=row["center_lat"],
                center_lng=row["center_lng"],
                radius_km=row["radius_km"],
                instruction=row["instruction"],
                agency=row["agency"],
                created_at=row["created_at"],
                is_active=bool(row["is_active"])
            )
            for row in rows
        ]

    def log_event(self, level: str, event_type: str, message: str, details: str = "") -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO operation_logs (timestamp, level, event_type, message, details)
                VALUES (?, ?, ?, ?, ?)
            """, (time.time(), level, event_type, message, details))
            conn.commit()
            conn.close()

    def get_recent_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM operation_logs ORDER BY log_id DESC LIMIT ?", (limit,))
            rows = cur.fetchall()
            logs = [dict(r) for r in rows]
            conn.close()
            return logs

    def clear_all(self) -> None:
        self.clear_rescued_total()
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("DELETE FROM sos_cases")
            cur.execute("DELETE FROM disaster_zones")
            cur.execute("DELETE FROM evacuation_sites")
            cur.execute("DELETE FROM operation_logs")
            conn.commit()
            conn.close()

    def upsert_evacuation_site(self, site: EvacuationSite) -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO evacuation_sites (
                    site_id, name, site_type, latitude, longitude,
                    capacity, contact_phone, notes, is_active, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(site_id) DO UPDATE SET
                    name=excluded.name,
                    site_type=excluded.site_type,
                    latitude=excluded.latitude,
                    longitude=excluded.longitude,
                    capacity=excluded.capacity,
                    contact_phone=excluded.contact_phone,
                    notes=excluded.notes,
                    is_active=excluded.is_active
            """, (
                site.site_id, site.name, site.site_type, site.latitude, site.longitude,
                site.capacity, site.contact_phone, site.notes, int(site.is_active), site.created_at
            ))
            conn.commit()
            conn.close()

    def delete_evacuation_site(self, site_id: str) -> None:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("DELETE FROM evacuation_sites WHERE site_id = ?", (site_id,))
            conn.commit()
            conn.close()

    def get_all_evacuation_sites(self) -> List[EvacuationSite]:
        with _lock:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM evacuation_sites ORDER BY site_id ASC")
            rows = cur.fetchall()
            sites = []
            for r in rows:
                sites.append(EvacuationSite(
                    site_id=r["site_id"],
                    name=r["name"],
                    site_type=r["site_type"],
                    latitude=float(r["latitude"]),
                    longitude=float(r["longitude"]),
                    capacity=int(r["capacity"] or 100),
                    contact_phone=r["contact_phone"] or "",
                    notes=r["notes"] or "",
                    is_active=bool(r["is_active"]),
                    created_at=float(r["created_at"] or time.time())
                ))
            conn.close()
            return sites

    def get_active_evacuation_sites(self) -> List[EvacuationSite]:
        return [s for s in self.get_all_evacuation_sites() if s.is_active]
