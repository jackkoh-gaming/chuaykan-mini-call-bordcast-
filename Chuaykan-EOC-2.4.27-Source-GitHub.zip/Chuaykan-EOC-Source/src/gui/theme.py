"""Persistent light/dark appearance for Qt panels and existing inline styles."""
import re
from pathlib import Path
from PySide6.QtCore import QObject, QSettings, QTimer, QByteArray
from PySide6.QtGui import QColor, QPalette, QPixmap, QPainter, QIcon
from PySide6.QtWidgets import QApplication, QWidget, QLabel
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWebEngineWidgets import QWebEngineView

DAY = {'#0B0F19': '#F1F5F9', '#0B1120': '#F1F5F9', '#090E17': '#F1F5F9', '#090D16': '#F1F5F9', '#0A0F1D': '#F1F5F9', '#0A0F1E': '#F1F5F9', '#0F172A': '#FFFFFF', '#131D31': '#FFFFFF', '#111827': '#FFFFFF', '#0F1828': '#FFFFFF', '#121D30': '#FFFFFF', '#1A263E': '#E8EEF6', '#17233B': '#E8EEF6', '#1A2844': '#E8EEF6', '#1E293B': '#E8EEF6', '#18243C': '#E8EEF6', '#1E2B40': '#E8EEF6', '#1E2B45': '#E8EEF6', '#0F213A': '#E8EEF6', '#203152': '#E8EEF6', '#202F4D': '#E8EEF6', '#24344D': '#B6C5D8', '#253554': '#B6C5D8', '#334155': '#B6C5D8', '#33476E': '#B6C5D8', '#2A3C60': '#B6C5D8', '#2B3E64': '#B6C5D8', '#1E293F': '#B6C5D8', '#FFFFFF': '#172033', '#F8FAFC': '#172033', '#F1F5F9': '#172033', '#E2E8F0': '#172033', '#CBD5E1': '#475569', '#94A3B8': '#475569', '#64748B': '#52627A', '#38BDF8': '#0369A1', '#00F2FE': '#0369A1', '#60A5FA': '#0369A1', '#BAE6FD': '#0369A1', '#7DD3FC': '#0369A1', '#FDE68A': '#854D0E', '#FBBF24': '#854D0E', '#FFD54F': '#854D0E', '#FCA5A5': '#B91C1C', '#F87171': '#B91C1C', '#FF617B': '#B91C1C', '#A7F3D0': '#047857', '#6EE7B7': '#047857', '#34D399': '#047857', '#69F0AE': '#047857', '#1F1116': '#FFF1F2', '#09231B': '#ECFDF5'}

def theme_style(source, light):
    if not light:
        return source
    def block(match):
        selector, body = match.group(1), match.group(2)
        background = re.search(r'(?<![\w-])background(?:-color)?\s*:\s*(#[0-9a-fA-F]{6})', body)
        accent = any(name in selector for name in ('#btnPrimary', '#btnEmergency', '#btnSuccess'))
        accent = accent or bool(background and background[1].upper() not in DAY)
        def colour(found):
            value = found[0].upper()
            if re.search(r'selection-color\s*:\s*$', body[:found.start()]):
                return value
            if accent and value in ('#FFFFFF', '#F8FAFC', '#F1F5F9'):
                return value
            return DAY.get(value, value)
        return selector + '{' + re.sub(r'#[0-9a-fA-F]{6}\b', colour, body) + '}'
    if '{' not in source:
        return block(type('Inline', (), {'group': lambda _, n: '' if n == 1 else source})())[1:-1]
    return re.sub(r'([^{}]+)\{([^{}]*)\}', block, source)

class ThemeManager(QObject):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.settings = QSettings()
        self.light = self.settings.value('appearance/theme', 'light') == 'light'
        self.busy = False
        self.icon_cache = {}
        self.icon_sources = {}
        # Avoid application event filters: PySide can re-enter its native wrapper
        # creation when handling events from newly constructed WebEngine objects.
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(250)
        self.refresh_timer.timeout.connect(self.refresh_widgets)
        self.refresh_timer.start()
        self.apply()

    def set_light(self, light):
        self.light = bool(light)
        self.settings.setValue('appearance/theme', 'light' if self.light else 'dark')
        self.settings.sync()
        self.apply()

    def style_widget(self, widget):
        raw = widget.styleSheet()
        if raw != widget.property('_theme_applied'):
            widget.setProperty('_theme_original', raw)
        original = widget.property('_theme_original') or ''
        styled = theme_style(original, self.light)
        widget.setProperty('_theme_applied', styled)
        if raw != styled:
            widget.setStyleSheet(styled)
        if widget.property('_theme_icon_path'):
            self.update_icon(widget)

    def set_icon(self, widget, path, size):
        widget.setProperty('_theme_icon_path', str(path))
        widget.setProperty('_theme_icon_size', size)
        self.update_icon(widget)

    def update_icon(self, widget):
        path = widget.property('_theme_icon_path')
        size = widget.property('_theme_icon_size')
        background = re.search(r'(?<![\w-])background(?:-color)?\s*:\s*(#[0-9a-fA-F]{6})', widget.styleSheet())
        accent = bool(background and background[1].upper() not in DAY and
                      background[1].upper() not in DAY.values())
        key = (path, size, self.light, accent)
        if widget.property('_theme_icon_applied') == repr(key):
            return
        if key not in self.icon_cache:
            if path not in self.icon_sources:
                self.icon_sources[path] = Path(path).read_text()
            source = self.icon_sources[path]
            if accent:
                source = re.sub(r'#[0-9a-fA-F]{6}\b', '#FFFFFF', source)
            elif self.light:
                palette = {**DAY, '#10B981':'#047857', '#F59E0B':'#854D0E',
                           '#FFC61B':'#854D0E', '#FEE187':'#854D0E', '#EF4444':'#B91C1C'}
                source = re.sub(r'#[0-9a-fA-F]{6}\b', lambda m: palette.get(m[0].upper(), m[0]), source)
            pixmap = QPixmap(size, size)
            pixmap.fill(QColor('transparent'))
            painter = QPainter(pixmap)
            QSvgRenderer(QByteArray(source.encode())).render(painter)
            painter.end()
            self.icon_cache[key] = pixmap
        pixmap = self.icon_cache[key]
        if isinstance(widget, QLabel):
            widget.setPixmap(pixmap)
        else:
            widget.setIcon(QIcon(pixmap))
        widget.setProperty('_theme_icon_applied', repr(key))

    def map_theme(self, view):
        view.page().runJavaScript("if(window.setAppTheme) window.setAppTheme(" +
                                  ('true' if self.light else 'false') + ");")

    def apply(self):
        self.busy = True
        try:
            palette = QPalette()
            colours = {'Window':'#0B1120', 'WindowText':'#FFFFFF', 'Base':'#0F172A',
                       'AlternateBase':'#1E293B', 'Text':'#FFFFFF', 'Button':'#202F4D',
                       'ButtonText':'#FFFFFF', 'ToolTipBase':'#0F172A', 'ToolTipText':'#FFFFFF'}
            for role, value in colours.items():
                palette.setColor(getattr(QPalette.ColorRole, role), QColor(DAY.get(value,value) if self.light else value))
            palette.setColor(QPalette.ColorRole.Highlight, QColor('#0369A1'))
            palette.setColor(QPalette.ColorRole.HighlightedText, QColor('#FFFFFF'))
            self.app.setPalette(palette)
            for widget in self.app.allWidgets():
                self.style_widget(widget)
                if isinstance(widget, QWebEngineView):
                    self.map_theme(widget)
        finally:
            self.busy = False

    def refresh_widgets(self):
        if self.busy:
            return
        self.busy = True
        try:
            for widget in self.app.allWidgets():
                if not isinstance(widget, QWebEngineView):
                    self.style_widget(widget)
        finally:
            self.busy = False
