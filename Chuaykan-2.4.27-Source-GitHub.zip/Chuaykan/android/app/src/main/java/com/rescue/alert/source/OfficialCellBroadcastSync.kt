package com.rescue.alert.source

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.rescue.alert.engine.AlertProcessingEngine
import java.util.concurrent.TimeUnit

/**
 * Direct reader for the public National Disaster Warning Center Cell Broadcast feed.
 * It uses HTTPS only and never needs the desktop EOC to be running.
 */
object OfficialCellBroadcastSync {
    const val PUSH_TOPIC = "official_feed_changes_v1"
    private const val UNIQUE_PERIODIC_WORK = "official_cell_broadcast_periodic"
    private const val UNIQUE_IMMEDIATE_WORK = "official_cell_broadcast_immediate"

    fun subscribePush(context: Context) {
        com.google.firebase.messaging.FirebaseMessaging.getInstance().subscribeToTopic(PUSH_TOPIC)
            .addOnCompleteListener { task ->
                context.getSharedPreferences("official_push_status", Context.MODE_PRIVATE).edit()
                    .putBoolean("subscribed", task.isSuccessful).apply()
                Log.i("OfficialPush", if (task.isSuccessful) "Subscribed to official feed changes" else "Push subscription failed")
            }
    }

    fun isValidPush(data: Map<String, String>): Boolean {
        if (data["type"] !in setOf("official_feed_changed", "official_push_probe")) return false
        if (data["protocol"] != "1") return false
        if (!Regex("[a-f0-9]{64}").matches(data["revision"].orEmpty())) return false
        val sentAt = data["sent_at"]?.toLongOrNull() ?: return false
        return System.currentTimeMillis() - sentAt in -60_000L..300_000L
    }

    fun refreshFromPush(context: Context) {
        val builder = OneTimeWorkRequestBuilder<OfficialCellBroadcastWorker>()
            .setInputData(workDataOf("official_only" to true))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        // Android 12+ supports expedited jobs without a foreground service.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
        }
        WorkManager.getInstance(context).enqueueUniqueWork(
            "official_cell_broadcast_push", ExistingWorkPolicy.APPEND_OR_REPLACE, builder.build()
        )
    }

    fun schedule(context: Context) {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<OfficialCellBroadcastWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_PERIODIC_WORK, ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    fun refreshNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<OfficialCellBroadcastWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_IMMEDIATE_WORK, ExistingWorkPolicy.KEEP, request
        )
    }
}

class OfficialCellBroadcastWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            sync(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Log.w(TAG, "Official Cell Broadcast sync failed: " + e.message)
            if (inputData.getBoolean("official_only", false) && runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    private fun sync(context: Context) {
        com.rescue.alert.source.area.AreaAlertRepository.refresh(context, force = true)
        if (inputData.getBoolean("official_only", false)) {
            context.getSharedPreferences("official_push_status", Context.MODE_PRIVATE).edit()
                .putLong("evaluated_at", System.currentTimeMillis()).apply()
            Log.i("OfficialPush", "Official source refreshed and GPS policy evaluated")
            return
        }
        // Oracle refreshes public news and dam sources; screens read the shared cache on demand.
        // Keep this worker only as a fallback for locally GPS-scoped official alerts.
    }

    companion object {
        private const val TAG = "OfficialCellBroadcast"
    }
}
