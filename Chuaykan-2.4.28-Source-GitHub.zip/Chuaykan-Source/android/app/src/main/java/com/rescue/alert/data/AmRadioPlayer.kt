package com.rescue.alert.data

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.rescue.alert.model.AmStation
import java.util.Collections
import java.util.LinkedHashSet

/**
 * Real-Time Audio Streaming Manager for Thailand National Emergency AM Radio.
 * Supports HLS (.m3u8) live audio feeds from the PRD and EGAT broadcast network.
 */
object AmRadioPlayer {
    private const val TAG = "AmRadioPlayer"

    enum class State {
        IDLE,
        BUFFERING,
        PLAYING,
        PAUSED,
        ERROR
    }

    private var mediaPlayer: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    var currentStation: AmStation? = null
        private set

    var state: State = State.IDLE
        private set

    var errorMessage: String? = null
        private set

    private val listeners = Collections.synchronizedSet(LinkedHashSet<(State, AmStation?) -> Unit>())

    fun addListener(listener: (State, AmStation?) -> Unit) {
        listeners.add(listener)
        mainHandler.post { listener(state, currentStation) }
    }

    fun removeListener(listener: (State, AmStation?) -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        mainHandler.post {
            val list = synchronized(listeners) { listeners.toList() }
            for (listener in list) {
                listener(state, currentStation)
            }
        }
    }

    private var resolvedStreamUrl: String? = null

    // MediaPlayer and its callbacks must share one looper. A superseded player
    // must never start playback or overwrite the current station's state.
    private fun onMain(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) action() else mainHandler.post(action)
    }

    private fun releasePlayer() {
        val old = mediaPlayer
        mediaPlayer = null
        old?.setOnPreparedListener(null)
        old?.setOnErrorListener(null)
        old?.setOnCompletionListener(null)
        try { old?.release() } catch (e: Exception) { Log.w(TAG, "Release failed", e) }
    }

    fun play(station: AmStation, streamUrl: String) = onMain {
        releasePlayer()
        currentStation = station
        resolvedStreamUrl = streamUrl
        errorMessage = null
        state = State.BUFFERING
        notifyListeners()
        try {
            val player = MediaPlayer()
            mediaPlayer = player
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setOnPreparedListener { prepared ->
                if (mediaPlayer === prepared && state == State.BUFFERING) {
                    try {
                        prepared.start()
                        state = State.PLAYING
                        notifyListeners()
                    } catch (e: Exception) {
                        failPlayback("ไม่สามารถเริ่มเล่นเสียงได้", e)
                    }
                }
            }
            player.setOnErrorListener { failed, what, extra ->
                if (mediaPlayer === failed) failPlayback("สัญญาณถ่ายทอดสดขัดข้อง ($what:$extra)")
                true
            }
            player.setOnCompletionListener { completed ->
                if (mediaPlayer === completed) {
                    releasePlayer()
                    state = State.IDLE
                    notifyListeners()
                }
            }
            player.setDataSource(streamUrl)
            player.prepareAsync()
        } catch (e: Exception) {
            failPlayback("เกิดข้อผิดพลาดในการโหลดคลื่น: ${e.message}", e)
        }
    }

    private fun failPlayback(message: String, error: Exception? = null) {
        Log.e(TAG, message, error)
        releasePlayer()
        state = State.ERROR
        errorMessage = message
        notifyListeners()
    }

    fun pause() = onMain {
        try {
            if (state == State.BUFFERING) {
                releasePlayer()
                state = State.PAUSED
                notifyListeners()
            } else if (state == State.PLAYING) {
                mediaPlayer?.pause()
                state = State.PAUSED
                notifyListeners()
            }
        } catch (e: Exception) {
            failPlayback("ไม่สามารถพักเสียงได้", e)
        }
    }

    fun resume() = onMain {
        try {
            if (state == State.PAUSED && mediaPlayer != null) {
                mediaPlayer?.start()
                state = State.PLAYING
                notifyListeners()
            } else if (state != State.PLAYING && state != State.BUFFERING) {
                val station = currentStation
                val url = resolvedStreamUrl
                if (station != null && !url.isNullOrBlank()) play(station, url)
            }
        } catch (e: Exception) {
            failPlayback("ไม่สามารถเล่นเสียงต่อได้", e)
        }
    }

    fun stop() = onMain {
        releasePlayer()
        state = State.IDLE
        errorMessage = null
        notifyListeners()
    }

    fun isPlaying(): Boolean = state == State.PLAYING
}
