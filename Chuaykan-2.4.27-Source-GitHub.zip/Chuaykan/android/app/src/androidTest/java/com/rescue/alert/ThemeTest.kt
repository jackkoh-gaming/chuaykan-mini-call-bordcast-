package com.rescue.alert

import android.content.res.Configuration
import android.graphics.Color
import androidx.core.graphics.ColorUtils
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.util.ThemePalette
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ThemeTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun bothModesHaveReadablePrimaryAndSecondaryText() {
        for (mode in listOf(Configuration.UI_MODE_NIGHT_NO, Configuration.UI_MODE_NIGHT_YES)) {
            val configuration = Configuration(context.resources.configuration)
            configuration.uiMode = (configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or mode
            val resources = context.createConfigurationContext(configuration).resources
            @Suppress("DEPRECATION")
            val background = resources.getColor(R.color.tactical_card_surface)
            @Suppress("DEPRECATION")
            val primary = resources.getColor(R.color.tactical_text_primary)
            @Suppress("DEPRECATION")
            val secondary = resources.getColor(R.color.tactical_text_secondary)
            assertTrue(ColorUtils.calculateContrast(primary, background) >= 7.0)
            assertTrue(ColorUtils.calculateContrast(secondary, background) >= 4.5)
        }
    }

    @Test fun choicePersistsAndDoesNotDependOnGatewayPairing() {
        val original = ThemePalette.isLight(context)
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        try {
            for (light in listOf(true, false)) {
                instrumentation.runOnMainSync { ThemePalette.setLight(context, light) }
                val otherContext = context.createConfigurationContext(Configuration(context.resources.configuration))
                assertEquals(light, ThemePalette.isLight(otherContext))
            }
        } finally { instrumentation.runOnMainSync { ThemePalette.setLight(context, original) } }
    }

    @Test fun dynamicTextChangesWhileEmergencyButtonKeepsItsColour() {
        val original = ThemePalette.isLight(context)
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        try {
            instrumentation.runOnMainSync { ThemePalette.setLight(context, true) }
            assertEquals(Color.parseColor("#475569"), ThemePalette.color("#94A3B8"))
            assertEquals(Color.parseColor("#DC2626"), ThemePalette.color("#DC2626"))
            instrumentation.runOnMainSync { ThemePalette.setLight(context, false) }
            assertEquals(Color.parseColor("#94A3B8"), ThemePalette.color("#94A3B8"))
        } finally { instrumentation.runOnMainSync { ThemePalette.setLight(context, original) } }
    }
}
