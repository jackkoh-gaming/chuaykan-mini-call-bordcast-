"""Read-only view of the public NDWC/DPM Cell Broadcast feed."""
from __future__ import annotations
from datetime import timedelta
from typing import List

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QPlainTextEdit

from src.server.zone_cloud_dispatcher import OfficialCellBroadcastAlert, OfficialCellBroadcastFeed


class OfficialFeedPanel(QWidget):
    refresh_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        title = QLabel("ประกาศ Cell Broadcast ทางการ • 3 วันล่าสุด")
        title.setObjectName("headerTitle")
        layout.addWidget(title)
        help_text = QLabel(
            "แหล่งข้อมูล: ศูนย์เตือนภัยพิบัติแห่งชาติ/ปภ. • "
            "อ่านข้อมูลสาธารณะเท่านั้น • มือถือ RescueAlert ตรวจ feed นี้โดยตรง"
        )
        help_text.setObjectName("subText")
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
        self.status = QLabel("ยังไม่ได้ตรวจข้อมูล")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.refresh_button = QPushButton("ตรวจประกาศทางการตอนนี้")
        self.refresh_button.clicked.connect(self.refresh_requested.emit)
        layout.addWidget(self.refresh_button)
        self.content = QPlainTextEdit()
        self.content.setReadOnly(True)
        self.content.setPlaceholderText("ไม่มีประกาศใน 3 วันล่าสุด หรือกำลังเชื่อมต่อแหล่งข้อมูล")
        layout.addWidget(self.content, 1)

    def set_loading(self) -> None:
        self.refresh_button.setEnabled(False)
        self.status.setText("กำลังดึง feed Cell Broadcast ทางการ...")
    
    def set_alerts(self, alerts: List[OfficialCellBroadcastAlert]) -> None:
        self.refresh_button.setEnabled(True)
        today = OfficialCellBroadcastFeed.current_day()
        first_day = today - timedelta(days=2)
        self.status.setText(f"ประกาศ 3 วันล่าสุด ({first_day.isoformat()} ถึง {today.isoformat()} เวลาไทย): {len(alerts)} รายการ • EOC เป็นหน้าจอติดตามเท่านั้น")
        if not alerts:
            self.content.setPlainText("ไม่มีประกาศ Cell Broadcast ใน 3 วันล่าสุดตามเวลาไทย")
            return
        records = []
        for item in alerts:
            records.append(
                f"[{item.issued_at}] {item.alert_id}\n"
                f"แหล่งข้อมูล: {item.sender}\n"
                f"ประเภท: {item.event_type} / {item.disaster_type}\n"
                f"พื้นที่: {item.area_summary}\n"
                f"{item.title}\n{item.message}"
            )
        self.content.setPlainText("\n\n" + ("\n" + "─" * 44 + "\n\n").join(records))

    def set_error(self, message: str) -> None:
        self.refresh_button.setEnabled(True)
        self.status.setText("อ่าน feed ทางการไม่สำเร็จ")
        self.content.setPlainText(message)
