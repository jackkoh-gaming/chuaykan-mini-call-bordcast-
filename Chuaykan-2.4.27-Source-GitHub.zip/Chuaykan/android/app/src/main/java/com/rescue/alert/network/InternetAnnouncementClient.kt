package com.rescue.alert.network

import android.content.Context
import android.util.Log
import com.rescue.alert.bluetooth.BluetoothMeshManager
import com.rescue.alert.engine.GeoFilterEngine
import com.rescue.alert.model.CitizenEmergencyProfile
import com.rescue.alert.model.MeshVoicePacket
import com.rescue.alert.source.area.AreaLocation
import com.rescue.alert.util.AppSettings
import org.json.JSONObject
import java.io.DataInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * InternetAnnouncementClient
 *
 * Connects to EOC DispatchServer over LAN/Internet (/api/announcement/stream)
 * and streams live officer microphone announcements.
 *
 * GEO-FILTERING ENFORCEMENT:
 * Evaluates active pinned risk zones from server metadata against real on-device GPS
 * coordinates using GeoFilterEngine.isInsideCircle(). Only plays audio when the device
 * is genuinely inside a pinned risk zone.
 */
object InternetAnnouncementClient {

    private const val TAG = "InternetAnnounceClient"
    private val isRunning = AtomicBoolean(false)
    private var workerThread: Thread? = null
    private var activeConnection: HttpURLConnection? = null

    data class CachedRiskZone(
        val zoneId: String,
        val title: String,
        val centerLat: Double,
        val centerLng: Double,
        val radiusKm: Double
    )

    @Volatile
    private var activeZones: List<CachedRiskZone> = emptyList()

    @Volatile
    private var activeZoneTitle: String = ""

    fun start(context: Context) {
        if (isRunning.getAndSet(true)) return
        val appContext = context.applicationContext
        workerThread = Thread({
            Log.i(TAG, "Internet Announcement Client background thread started")
            while (isRunning.get()) {
                try {
                    streamAnnouncementLoop(appContext)
                } catch (e: Exception) {
                    if (isRunning.get()) {
                        Log.w(TAG, "Stream loop exception: ${e.message}, reconnecting in 5s...")
                    }
                }
                if (isRunning.get()) {
                    try {
                        Thread.sleep(5000L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
            Log.i(TAG, "Internet Announcement Client background thread stopped")
        }, "EOC-Internet-Announcement-Client").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            activeConnection?.disconnect()
        } catch (_: Exception) {}
        activeConnection = null
        workerThread?.interrupt()
        workerThread = null
        activeZones = emptyList()
        activeZoneTitle = ""
    }

    private fun streamAnnouncementLoop(context: Context) {
        val baseUrl = AppSettings.getGatewayBaseUrl(context).trimEnd('/')
        if (baseUrl.isBlank()) return

        // Obtain real on-device GPS coordinates
        val loc = AreaLocation.current(context)
        val lat = loc?.latitude ?: CitizenEmergencyProfile.lastLatitude
        val lng = loc?.longitude ?: CitizenEmergencyProfile.lastLongitude

        val streamUrl = if (lat != null && lng != null) {
            "$baseUrl/api/announcement/stream?lat=$lat&lng=$lng"
        } else {
            "$baseUrl/api/announcement/stream"
        }

        var conn: HttpURLConnection? = null
        try {
            val url = URL(streamUrl)
            conn = (com.rescue.alert.network.SecureGateway.open(context, url)).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 30000
                setRequestProperty("Accept", "application/octet-stream")
                setRequestProperty("Connection", "keep-alive")
                useCaches = false
            }
            activeConnection = conn

            val responseCode = conn.responseCode
            if (responseCode != 200) {
                Log.w(TAG, "Server returned HTTP $responseCode for announcement stream")
                return
            }

            Log.i(TAG, "Connected to EOC live announcement stream at $baseUrl (lat=$lat, lng=$lng)")
            val inStream = DataInputStream(conn.inputStream)

            while (isRunning.get()) {
                val frameType = inStream.read()
                if (frameType == -1) {
                    Log.i(TAG, "Announcement stream EOF from server")
                    break
                }
                val payloadLen = inStream.readInt()
                if (payloadLen < 0 || payloadLen > 10 * 1024 * 1024) {
                    Log.w(TAG, "Invalid payload length $payloadLen, aborting stream")
                    break
                }

                val payload = ByteArray(payloadLen)
                if (payloadLen > 0) {
                    inStream.readFully(payload)
                }

                when (frameType) {
                    0x00 -> {
                        // Reconnect when a fresh GPS fix arrives or the device moves; the server scopes audio at subscription time.
                        val latest = AreaLocation.current(context)
                        if (latest != null && (lat == null || lng == null ||
                            kotlin.math.abs(latest.latitude - lat) > 0.0005 ||
                            kotlin.math.abs(latest.longitude - lng) > 0.0005)) {
                            Log.i(TAG, "GPS changed; refreshing announcement subscription")
                            break
                        }
                    }
                    0x01 -> {
                        // Metadata frame: JSON payload containing announcement_id and active disaster zones
                        handleMetadataFrame(payload)
                    }
                    0x02 -> {
                        // Audio PCM chunk: verify local geofence before playing through speaker
                        handleAudioFrame(context, payload)
                    }
                    0x03 -> {
                        // Announcement end frame: officer stopped speaking
                        handleEndFrame(context)
                    }
                    0x10 -> {
                        // Incoming call request from EOC officer
                        handleIncomingCallRequest(context, payload)
                    }
                    0x11 -> {
                        // Call voice PCM chunk from EOC officer
                        handleCallVoiceFrame(context, payload)
                    }
                    0x12 -> {
                        // Officer hung up call
                        handleCallHangupFrame(context)
                    }
                    0x13 -> {
                        // Officer answered citizen call
                        handleCallAnsweredFrame(context)
                    }
                    else -> {
                        Log.w(TAG, "Unknown frame type: $frameType")
                    }
                }
            }
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {}
            activeConnection = null
        }
    }

    private fun handleMetadataFrame(payload: ByteArray) {
        try {
            val jsonStr = String(payload, Charsets.UTF_8)
            val json = JSONObject(jsonStr)
            val zonesArray = json.optJSONArray("zones") ?: return
            val list = mutableListOf<CachedRiskZone>()
            for (i in 0 until zonesArray.length()) {
                val z = zonesArray.getJSONObject(i)
                val zId = z.optString("zone_id", "ZONE_$i")
                val title = z.optString("title", "พื้นที่เสี่ยงภัย")
                val clat = z.optDouble("center_lat", Double.NaN)
                val clng = z.optDouble("center_lng", Double.NaN)
                val rKm = z.optDouble("radius_km", 0.0)
                if (!clat.isNaN() && !clng.isNaN() && rKm > 0) {
                    list.add(CachedRiskZone(zId, title, clat, clng, rKm))
                }
            }
            activeZones = list
            Log.i(TAG, "Updated active pinned risk zones from server: ${list.size} zones")
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing announcement metadata: ${e.message}")
        }
    }

    private fun handleAudioFrame(context: Context, audioBytes: ByteArray) {
        if (audioBytes.isEmpty()) return

        // Dual Geofence Verification: Verify device GPS is inside at least one pinned risk zone
        if (isInsideActiveRiskZone(context)) {
            val sourceTitle = if (activeZoneTitle.isNotBlank()) {
                "ศูนย์สั่งการ EOC [$activeZoneTitle]"
            } else {
                "ศูนย์สั่งการ EOC (อินเทอร์เน็ต)"
            }
            BluetoothMeshManager.getInstance(context).handleOfficerAnnouncementChunk(
                sourceTitle,
                audioBytes
            )
        } else {
            // Device is outside all pinned risk zones -> Remain completely silent
        }
    }

    private fun handleEndFrame(context: Context) {
        activeZoneTitle = ""
        BluetoothMeshManager.getInstance(context).handleOfficerAnnouncementEnded()
        Log.i(TAG, "Received announcement end from EOC")
    }

    /**
     * Checks whether device GPS is currently inside any of the active pinned disaster zones.
     */
    private fun isInsideActiveRiskZone(context: Context): Boolean {
        val zones = activeZones
        if (zones.isEmpty()) return false

        val loc = AreaLocation.current(context)
        val devLat = loc?.latitude ?: CitizenEmergencyProfile.lastLatitude
        val devLng = loc?.longitude ?: CitizenEmergencyProfile.lastLongitude

        if (devLat == null || devLng == null) {
            // Unknown device location: do not trigger audible alarm
            return false
        }

        for (zone in zones) {
            if (GeoFilterEngine.isInsideCircle(
                    deviceLat = devLat,
                    deviceLng = devLng,
                    centerLat = zone.centerLat,
                    centerLng = zone.centerLng,
                    radiusKm = zone.radiusKm
                )
            ) {
                activeZoneTitle = zone.title
                return true
            }
        }
        return false
    }

    private fun handleIncomingCallRequest(context: Context, payload: ByteArray) {
        try {
            val json = JSONObject(String(payload, Charsets.UTF_8))
            val callerName = json.optString("caller_name", "เจ้าหน้าที่ศูนย์สั่งการ EOC")
            BluetoothMeshManager.getInstance(context).handleIncomingOfficerCall("EOC_GATEWAY", "$callerName (อินเทอร์เน็ต)")
            Log.i(TAG, "Incoming internet call request from $callerName")
        } catch (e: Exception) {
            Log.w(TAG, "Error handling call request: ${e.message}")
        }
    }

    private fun handleCallVoiceFrame(context: Context, payload: ByteArray) {
        if (payload.isNotEmpty()) {
            BluetoothMeshManager.getInstance(context).playAudioData(payload)
        }
    }

    private fun handleCallHangupFrame(context: Context) {
        BluetoothMeshManager.getInstance(context).handleOfficerCallEnded("EOC_GATEWAY", "เจ้าหน้าที่ศูนย์สั่งการ EOC")
        Log.i(TAG, "Received call hangup from EOC")
    }

    private fun handleCallAnsweredFrame(context: Context) {
        BluetoothMeshManager.getInstance(context).handleCallAnsweredByRemote("EOC_GATEWAY", "เจ้าหน้าที่ศูนย์สั่งการ EOC")
        Log.i(TAG, "Call answered by EOC remote")
    }

    private val callExecutor = Executors.newSingleThreadExecutor()
    internal fun newVoiceExecutor() = java.util.concurrent.ThreadPoolExecutor(
        1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
        java.util.concurrent.ArrayBlockingQueue<Runnable>(4),
        java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy()
    )
    private val voiceExecutor = newVoiceExecutor()

    fun sendCallPacket(context: Context, packet: MeshVoicePacket) {
        val baseUrl = AppSettings.getGatewayBaseUrl(context).trimEnd('/')
        if (baseUrl.isBlank()) return

        val pid = packet.packetId
        val audio = packet.audioData

        val voice = pid.startsWith("EOC_CALL_VOICE") && audio.isNotEmpty()
        if (pid.startsWith("EOC_CALL_HANGUP") || pid.startsWith("EOC_CALL_DECLINE")) voiceExecutor.queue.clear()
        val executor = if (voice) voiceExecutor else callExecutor
        executor.execute {
            try {
                if (pid.startsWith("EOC_CALL_VOICE") && audio.isNotEmpty()) {
                    val url = URL("$baseUrl/api/call/voice/send")
                    val conn = (com.rescue.alert.network.SecureGateway.open(context, url)).apply {
                        requestMethod = "POST"
                        connectTimeout = 3000
                        readTimeout = 3000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/octet-stream")
                        setRequestProperty("Connection", "keep-alive")
                        setFixedLengthStreamingMode(audio.size)
                    }
                    conn.outputStream.use { it.write(audio) }
                    conn.responseCode
                    conn.inputStream.close()
                    conn.disconnect()
                } else if (pid.startsWith("EOC_CALL_ANSWER")) {
                    sendJsonPost(context, "$baseUrl/api/call/answer", JSONObject().apply {
                        put("client_id", packet.sourceNodeId)
                        put("client_name", packet.sourceHouseName)
                    })
                } else if (pid.startsWith("EOC_CALL_HANGUP") || pid.startsWith("EOC_CALL_DECLINE")) {
                    sendJsonPost(context, "$baseUrl/api/call/hangup", JSONObject().apply {
                        put("reason", "citizen_hangup")
                    })
                } else if (pid.startsWith("EOC_CALL_REQUEST") || pid.startsWith("CALL_REQUEST")) {
                    sendJsonPost(context, "$baseUrl/api/call/request", JSONObject().apply {
                        put("caller_id", packet.sourceNodeId)
                        put("caller_name", packet.sourceHouseName)
                    })
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error sending call packet ${packet.packetId}: ${e.message}")
            }
        }
    }

    private fun sendJsonPost(context: Context, urlString: String, json: JSONObject) {
        val url = URL(urlString)
        val conn = (com.rescue.alert.network.SecureGateway.open(context, url)).apply {
            requestMethod = "POST"
            connectTimeout = 4000
            readTimeout = 4000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        conn.outputStream.use { it.write(bytes) }
        conn.responseCode
        conn.inputStream.close()
        conn.disconnect()
    }
}
