package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.*
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.data.DisasterNewsRepository
import com.rescue.alert.model.DisasterNewsItem

/**
 * Interactive Disaster News Center Dialog.
 * Displays official news bulletins from DDPM (ปภ.) and TMD (กรมอุตุนิยมวิทยา).
 * Features:
 * - Real-time daily news updates
 * - Filter tabs (ทั้งหมด / ปภ. / กรมอุตุฯ)
 * - Direct external web links to official news pages
 * - Smooth scrollable cards
 */
object DisasterNewsDialog {

    fun show(context: Context) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_disaster_news, null)
        dialog.setContentView(dialogView)

        // Make dialog window wide and responsive
        dialog.window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.94).toInt(),
            (context.resources.displayMetrics.heightPixels * 0.88).toInt()
        )

        val btnTabAll = dialogView.findViewById<Button>(R.id.btnTabAll)
        val btnTabDdpm = dialogView.findViewById<Button>(R.id.btnTabDdpm)
        val btnTabTmd = dialogView.findViewById<Button>(R.id.btnTabTmd)
        val btnRefreshNews = dialogView.findViewById<ImageButton>(R.id.btnRefreshNews)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseNewsDialog)
        val cardsContainer = dialogView.findViewById<LinearLayout>(R.id.layoutNewsCardsContainer)

        var currentFilter: String? = null // null = ALL, "DDPM" = DDPM, "TMD" = TMD
        var currentNewsList = listOf<DisasterNewsItem>()

        fun renderCards() {
            currentNewsList = DisasterNewsRepository.recentOnly(currentNewsList)
            val scroll = cardsContainer.parent as? ScrollView
            val previousScroll = scroll?.scrollY ?: 0
            cardsContainer.removeAllViews()
            val checked = if (DisasterNewsRepository.lastFetchTime > 0)
                SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("Asia/Bangkok")
                }.format(Date(DisasterNewsRepository.lastFetchTime)) else "ยังไม่สำเร็จ"
            cardsContainer.addView(TextView(context).apply {
                text = "ข่าว 3 วันล่าสุด (วันนี้และย้อนหลัง 2 วัน เวลาไทย)\nตรวจข่าวทุก 10 วินาทีขณะเปิดหน้านี้ • ตรวจล่าสุด $checked เวลาไทย" +
                    (DisasterNewsRepository.lastError?.let { "\n$it" } ?: "")
                textSize = 11f
                setTextColor(com.rescue.alert.util.ThemePalette.color("#CBD5E1"))
                setPadding(0, 8, 0, 16)
            })
            cardsContainer.post { scroll?.scrollTo(0, previousScroll) }
            val filtered = if (currentFilter == null) {
                currentNewsList
            } else {
                currentNewsList.filter { it.sourceCode.equals(currentFilter, ignoreCase = true) }
            }

            if (filtered.isEmpty()) {
                val tvEmpty = TextView(context).apply {
                    text = "ไม่มีข่าวใน 3 วันล่าสุดในหมวดนี้ (เวลาไทย)"
                    textSize = 14f
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                    gravity = android.view.Gravity.CENTER
                    setPadding(0, 48, 0, 48)
                }
                cardsContainer.addView(tvEmpty)
                return
            }

            for (item in filtered) {
                val cardView = inflater.inflate(R.layout.item_disaster_news_card, cardsContainer, false)

                val tvSourceBadge = cardView.findViewById<TextView>(R.id.tvNewsSourceBadge)
                val tvCategoryBadge = cardView.findViewById<TextView>(R.id.tvNewsCategoryBadge)
                val tvDate = cardView.findViewById<TextView>(R.id.tvNewsDate)
                val tvTitle = cardView.findViewById<TextView>(R.id.tvNewsTitle)
                val tvSummary = cardView.findViewById<TextView>(R.id.tvNewsSummary)
                val tvDetails = cardView.findViewById<TextView>(R.id.tvNewsDetails)
                val btnReadFullNews = cardView.findViewById<Button>(R.id.btnReadFullNews)
                val btnOpenWeb = cardView.findViewById<Button>(R.id.btnOpenWebNews)

                // Source badge styling
                if (item.sourceCode.equals("DDPM", ignoreCase = true)) {
                    tvSourceBadge.text = "ปภ. 1784"
                    tvSourceBadge.setBackgroundResource(R.drawable.bg_badge_ddpm)
                } else {
                    tvSourceBadge.text = "กรมอุตุฯ (TMD)"
                    tvSourceBadge.setBackgroundResource(R.drawable.bg_badge_tmd)
                }

                // Category styling
                tvCategoryBadge.text = item.category
                if (item.severity == "CRITICAL") {
                    tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_critical)
                    tvCategoryBadge.setTextColor(Color.parseColor("#FFFFFF"))
                } else if (item.severity == "EARLY_WARNING") {
                    tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_early_warning)
                    tvCategoryBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#FDE68A"))
                } else {
                    tvCategoryBadge.setBackgroundResource(R.drawable.bg_status_chip)
                    tvCategoryBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                }

                val liveStatusBadge = "[ประกาศต้นทาง]"
                tvDate.text = "$liveStatusBadge ${item.dateStr}"
                tvTitle.text = item.title
                tvSummary.text = item.summary
                tvDetails.text = item.details

                btnOpenWeb.text = if (item.id.startsWith("TMD_")) "เปิดประกาศกรมอุตุฯ" else "เปิดแหล่งประกาศ"

                // Actions: Tapping card or 'Read Full' opens in-app bulletin reader with 100% details
                val openDetailAction = View.OnClickListener {
                    DisasterNewsDetailDialog.show(context, item)
                }
                cardView.setOnClickListener(openDetailAction)
                btnReadFullNews.setOnClickListener(openDetailAction)

                // Open official web directly via safe browser launcher
                btnOpenWeb.setOnClickListener {
                    com.rescue.alert.util.WebLinkHelper.openUrl(context, item.webUrl)
                }

                cardsContainer.addView(cardView)
            }
        }

        fun updateTabs(activeFilter: String?) {
            currentFilter = activeFilter
            btnTabAll.setBackgroundResource(if (activeFilter == null) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabDdpm.setBackgroundResource(if (activeFilter == "DDPM") R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabTmd.setBackgroundResource(if (activeFilter == "TMD") R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)

            btnTabAll.setTextColor(if (activeFilter == null) Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            btnTabDdpm.setTextColor(if (activeFilter == "DDPM") Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            btnTabTmd.setTextColor(if (activeFilter == "TMD") Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            renderCards()
        }

        fun loadNews(forceRefresh: Boolean = false, manual: Boolean = false) {
            btnRefreshNews.isEnabled = false
            btnRefreshNews.animate().rotationBy(360f).setDuration(600).start()

            DisasterNewsRepository.getNews(context, forceRefresh) { news ->
                if (!dialog.isShowing) return@getNews
                currentNewsList = news
                btnRefreshNews.isEnabled = true
                renderCards()
                if (manual) {
                    Toast.makeText(context, DisasterNewsRepository.lastError ?: "ตรวจข้อมูลจากต้นทางแล้ว", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnTabAll.setOnClickListener { updateTabs(null) }
        btnTabDdpm.setOnClickListener { updateTabs("DDPM") }
        btnTabTmd.setOnClickListener { updateTabs("TMD") }

        btnRefreshNews.setOnClickListener {
            loadNews(forceRefresh = true, manual = true)
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        val pollHandler = Handler(Looper.getMainLooper())
        var lastPoll = System.currentTimeMillis()
        val poll = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val daily = DisasterNewsRepository.recentOnly(currentNewsList)
                if (daily != currentNewsList) {
                    currentNewsList = daily
                    renderCards()
                }
                val now = System.currentTimeMillis()
                if (dialog.window?.decorView?.hasWindowFocus() == true && btnRefreshNews.isEnabled &&
                    now - lastPoll >= DisasterNewsRepository.REFRESH_INTERVAL_MS) {
                    lastPoll = now
                    loadNews(forceRefresh = true)
                }
                pollHandler.postDelayed(this, 1000L)
            }
        }
        dialog.setOnDismissListener { pollHandler.removeCallbacks(poll) }
        dialog.show()
        loadNews(forceRefresh = true)
        pollHandler.postDelayed(poll, 1000L)
    }
}
