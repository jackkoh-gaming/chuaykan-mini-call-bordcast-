"""Real Windows RFCOMM sockets/SDP and WinRT BLE advertisements."""
import asyncio
import ctypes
import socket
import threading
import time
import uuid
from pathlib import Path

_dll = None
_invalid = ctypes.c_size_t(-1).value


def native():
    global _dll
    if _dll is not None:
        return _dll
    dll = ctypes.CDLL(str(Path(__file__).resolve().parents[2] / "native/chuaykan_bluetooth.dll"))
    handle = ctypes.c_size_t
    dll.ck_listen.restype = handle
    dll.ck_accept.argtypes = [handle, ctypes.c_void_p, ctypes.c_int]
    dll.ck_accept.restype = handle
    for name in ("ck_recv", "ck_send"):
        fn = getattr(dll, name)
        fn.argtypes = [handle, ctypes.c_void_p, ctypes.c_int]
        fn.restype = ctypes.c_int
    dll.ck_timeout.argtypes = [handle, ctypes.c_int]
    dll.ck_timeout.restype = ctypes.c_int
    dll.ck_shutdown.argtypes = [handle, ctypes.c_int]
    dll.ck_close.argtypes = [handle]
    dll.ck_error.restype = ctypes.c_int
    dll.ck_discoverable.argtypes = [ctypes.c_int]
    dll.ck_discoverable.restype = ctypes.c_int
    _dll = dll
    return dll


def failed(dll, operation):
    error = dll.ck_error()
    if error == 10060:
        raise socket.timeout(operation + " timed out")
    raise OSError(error, operation + " failed (Windows socket error " + str(error) + ")")


class WindowsSocket:
    def __init__(self, handle):
        self.dll = native()
        self.handle = handle
        self.lock = threading.Lock()

    def recv(self, size):
        if self.handle == _invalid:
            return b""
        buffer = ctypes.create_string_buffer(size)
        count = self.dll.ck_recv(self.handle, buffer, size)
        if count < 0:
            failed(self.dll, "Bluetooth recv")
        return buffer.raw[:count]

    def sendall(self, data):
        view = memoryview(data)
        while view:
            block = bytes(view)
            count = self.dll.ck_send(self.handle, block, len(block))
            if count < 0:
                failed(self.dll, "Bluetooth send")
            if count == 0:
                raise ConnectionError("Bluetooth closed during send")
            view = view[count:]

    def settimeout(self, timeout):
        if self.dll.ck_timeout(self.handle, int(timeout * 1000)) < 0:
            failed(self.dll, "Bluetooth timeout")

    def shutdown(self, how):
        if self.handle != _invalid:
            self.dll.ck_shutdown(self.handle, how)

    def close(self):
        with self.lock:
            handle, self.handle = self.handle, _invalid
        if handle != _invalid:
            self.dll.ck_shutdown(handle, socket.SHUT_RDWR)
            self.dll.ck_close(handle)


async def ble_presence(service_uuid, is_running, report):
    from winrt.windows.devices.bluetooth import BluetoothError
    from winrt.windows.devices.bluetooth.genericattributeprofile import (
        GattServiceProvider, GattServiceProviderAdvertisingParameters,
        GattServiceProviderAdvertisementStatus)
    from winrt.windows.storage.streams import DataWriter
    result = await GattServiceProvider.create_async(uuid.UUID(service_uuid))
    if result.error != BluetoothError.SUCCESS or result.service_provider is None:
        raise OSError("Windows GATT service creation failed: " + str(result.error))
    provider = result.service_provider
    params = GattServiceProviderAdvertisingParameters()
    params.is_discoverable = True
    params.is_connectable = True
    writer = DataWriter()
    writer.write_bytes(b"RAEOC_HQ")  # Existing compact beacon; Android recognizes EOC in service data.
    params.service_data = writer.detach_buffer()
    provider.start_advertising(params)
    try:
        deadline = time.monotonic() + 10
        while is_running() and provider.advertisement_status != GattServiceProviderAdvertisementStatus.STARTED:
            if provider.advertisement_status == GattServiceProviderAdvertisementStatus.ABORTED or time.monotonic() > deadline:
                raise OSError("Windows BLE advertisement was not accepted by the adapter")
            await asyncio.sleep(0.2)
        if not is_running():
            return
        report("Windows BLE กระจาย UUID ศูนย์ EOC แล้ว • RFCOMM ช่อง 4 พร้อม")
        while is_running():
            if provider.advertisement_status != GattServiceProviderAdvertisementStatus.STARTED:
                raise OSError("Windows BLE advertisement stopped")
            await asyncio.sleep(0.5)
    finally:
        provider.stop_advertising()


def advertise(service_uuid, rfcomm_uuid, on_connection, on_pairing_request, is_running, report, is_app_peer=None):
    # Pairing is mediated by Windows, never automatically approve an unknown device.
    if rfcomm_uuid.lower() != "16690002-fa01-2026-8a8c-2c50f1587bfc":
        raise ValueError("Rebuild the Windows native DLL after changing the RFCOMM UUID")
    from winrt.runtime import init_apartment, uninit_apartment, ApartmentType
    init_apartment(ApartmentType.MULTI_THREADED)
    try:
        dll = native()
        listener_handle = dll.ck_listen()
        if listener_handle == _invalid:
            failed(dll, "RFCOMM listen/SDP registration")
        listener = WindowsSocket(listener_handle)
    except Exception:
        uninit_apartment()
        raise
    error = dll.ck_discoverable(1)
    if error:
        report("Windows เปิดการค้นพบ Bluetooth ไม่สำเร็จ: " + str(error))
    report("Windows ลงทะเบียน RFCOMM UUID ช่อง 4 สำเร็จ")
    stopping = threading.Event()

    def accept_worker():
        while is_running() and not stopping.is_set():
            address = ctypes.create_string_buffer(18)
            handle = dll.ck_accept(listener.handle, address, len(address))
            if handle == _invalid:
                if not stopping.is_set():
                    report("Windows RFCOMM รับการเชื่อมต่อไม่สำเร็จ: " + str(dll.ck_error()))
                return
            on_connection(WindowsSocket(handle), address.value.decode("ascii"))

    def watch_stop():
        while is_running() and not stopping.wait(0.2):
            pass
        listener.close()

    threading.Thread(target=accept_worker, daemon=True, name="Windows-RFCOMM").start()
    threading.Thread(target=watch_stop, daemon=True, name="Windows-BT-Stop").start()
    try:
        asyncio.run(ble_presence(service_uuid, is_running, report))
    finally:
        stopping.set()
        listener.close()
        dll.ck_unregister()
        uninit_apartment()
