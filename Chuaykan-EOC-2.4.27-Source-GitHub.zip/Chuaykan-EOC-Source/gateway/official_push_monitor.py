"""Monitor the public NDWC snapshot and send change hints, never invented alerts."""
import argparse
import hashlib
import json
import logging
import os
from pathlib import Path
import tempfile
import time
from datetime import datetime, timedelta, timezone
import urllib.error
import urllib.request

SOURCE = "https://academicndwc.github.io/CBS-DashBoard/data/data.json"
TOPIC = "official_feed_changes_v1"
MAX_BYTES = 8 * 1024 * 1024
TABLES = ("fact_cb", "dim_message", "dim_sender", "dim_event", "dim_disaster", "dim_province", "bridge_alert_location")
LOG = logging.getLogger("OfficialPush")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()


def parse_snapshot(root):
    if not isinstance(root, dict) or any(not isinstance(root.get(k), list) for k in TABLES):
        raise ValueError("Invalid official feed schema")
    if any(not isinstance(row, dict) for table in TABLES for row in root[table]):
        raise ValueError("Invalid official feed row")
    messages = {r["message_id"]: r for r in root["dim_message"]}
    senders = {r["sender_id"]: r for r in root["dim_sender"]}
    events = {r["event_id"]: r for r in root["dim_event"]}
    disasters = {r["disaster_id"]: r for r in root["dim_disaster"]}
    areas = {}
    for row in root["bridge_alert_location"]:
        areas.setdefault(row["alert_id"], []).append(row)
    fingerprints, records = {}, {}
    for row in root["fact_cb"]:
        alert_id = row["alert_id"]
        message = messages[row["message_id"]]["message_th"]
        if not alert_id or alert_id in records or not row["title"] or not message:
            raise ValueError("Incomplete or duplicate official alert")
        issued = datetime.strptime(row["date_id"].removeprefix("D-") + " " + row["time"][:5], "%Y%m%d %H:%M")
        issued = issued.replace(tzinfo=timezone(timedelta(hours=7))).timestamp()
        content = [row, messages[row["message_id"]], senders[row["sender_id"]], events[row["event_id"]],
                   disasters[row["disaster_id"]], sorted(areas.get(alert_id, []), key=lambda v: json.dumps(v, sort_keys=True))]
        fingerprints[alert_id] = digest(content)
        records[alert_id] = (row, message, issued)
    return fingerprints, records


def warning_priority(record):
    """Transport priority only; the phone remains the authority for GPS/alarms."""
    row, message, _ = record
    heading, text = row["title"].lower(), (row["title"] + " " + message).lower()
    if any(w in text for w in ("ทดสอบ", "ฝึกซ้อม", "ซักซ้อม", "test message", "exercise", "ไม่ใช่สถานการณ์จริง")):
        return "normal"
    if row["event_id"] == "ALL" or any(w in heading for w in ("ประชาสัมพันธ์", "แถลงข่าว", "จัดประชุม", "เยี่ยมชม", "มอบถุงยังชีพ")):
        return "normal"
    if row["event_id"] in ("EXA", "ASA", "PRA"):
        return "high"
    actionable = any(w in heading for w in ("เตือน", "เฝ้าระวัง", "อพยพ", "ระวัง", "หลีกเลี่ยง"))
    hazard = any(w in heading for w in ("น้ำท่วม", "น้ำป่า", "ล้นตลิ่ง", "ดินโคลนถล่ม", "แผ่นดินไหว", "สึนามิ", "ฝนตกหนัก", "พายุ", "กราดยิง", "ไฟไหม้", "สารเคมี", "pm2.5"))
    instruction = any(w in message for w in ("ขอให้", "ให้ประชาชน", "อพยพ", "ยกของ", "ยกสิ่งของ", "ระวัง", "หลีกเลี่ยง", "เคลื่อนย้าย", "เตือน"))
    return "high" if row["event_id"] == "ACI" and (actionable or hazard and instruction) else "normal"


def fetch_snapshot(etag=None):
    headers = {"Cache-Control": "no-cache", "Accept": "application/json", "User-Agent": "RescueAlert-OfficialPush/2.4.6"}
    if etag:
        headers["If-None-Match"] = etag
    request = urllib.request.Request(SOURCE, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            if response.status != 200 or response.url != SOURCE:
                raise ValueError("Unexpected official source response")
            body = response.read(MAX_BYTES + 1)
            if len(body) > MAX_BYTES:
                raise ValueError("Official feed too large")
            return json.loads(body), response.headers.get("ETag"), len(body)
    except urllib.error.HTTPError as error:
        error.close()
        if error.code == 304:
            return None, etag, 0
        raise


class FirebaseSender:
    def __init__(self):
        from gateway.dispatcher import FCMDispatcher
        self.app = FCMDispatcher._get_app()

    def send(self, data, priority):
        from firebase_admin import messaging
        # No notification payload: Android must run the strict official GPS path.
        message = messaging.Message(data=data, topic=TOPIC, android=messaging.AndroidConfig(
            priority=priority, ttl=timedelta(seconds=120), collapse_key=data["type"]))
        return messaging.send(message, app=self.app)


class Monitor:
    def __init__(self, state_path, sender, fetch=fetch_snapshot, clock=time.time):
        self.path, self.sender, self.fetch, self.clock = Path(state_path), sender, fetch, clock
        self.state = json.loads(self.path.read_text()) if self.path.exists() else {}
        if not isinstance(self.state, dict) or self.state and not isinstance(self.state.get("records"), dict):
            raise ValueError("Invalid monitor state; refusing to reset it")

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", dir=self.path.parent, delete=False) as output:
                temporary = output.name
                json.dump(self.state, output, ensure_ascii=False, sort_keys=True)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def tick(self):
        root, etag, size = self.fetch(self.state.get("etag"))
        changed = []
        if root is not None:
            fingerprints, records = parse_snapshot(root)
            now = self.clock()
            if "records" in self.state:
                changed = [key for key, value in fingerprints.items()
                           if self.state["records"].get(key) != value and 0 <= now - records[key][2] <= 4 * 3600]
            else:
                LOG.info("Quiet baseline: %d records; no historical push", len(records))
            if changed:
                self.state["pending"] = {"revision": digest(fingerprints), "detected_at": int(now * 1000),
                    "priority": "high" if any(warning_priority(records[key]) == "high" for key in changed) else "normal"}
            self.state.update(records=fingerprints, etag=etag)
            self.save()
        pending = self.state.get("pending")
        if pending:
            data = {"type": "official_feed_changed", "protocol": "1", "revision": pending["revision"],
                    "detected_at": str(pending["detected_at"]), "sent_at": str(int(self.clock() * 1000))}
            message_id = self.sender.send(data, pending["priority"])
            if not message_id:
                raise RuntimeError("FCM did not acknowledge the message")
            self.state.update(pending=None, last_fcm_accepted_at=int(self.clock() * 1000))
            self.save()
            LOG.info("FCM accepted change hint; device receipt still requires verification")
        return {"changed": len(changed), "downloaded_bytes": size, "pending": bool(self.state.get("pending"))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", default=str(Path.home() / ".local/state/rescuealert/official-push.json"))
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--check-source", action="store_true", help="Read-only source check; does not send push or change state")
    parser.add_argument("--probe", action="store_true", help="Send a labelled transport probe; never creates an emergency")
    args = parser.parse_args()
    if not 1 <= args.interval <= 300:
        parser.error("interval must be between 1 and 300 seconds")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        if args.check_source:
            start = time.monotonic()
            root, _, size = fetch_snapshot()
            _, records = parse_snapshot(root)
            print(json.dumps({"source_ok": True, "records": len(records), "downloaded_bytes": size,
                              "fetch_seconds": round(time.monotonic() - start, 3), "push_sent": False}))
            return 0
        sender = FirebaseSender()  # Fail closed if credentials are absent/invalid.
        if args.probe:
            now = str(int(time.time() * 1000))
            sender.send({"type": "official_push_probe", "protocol": "1", "revision": digest(now), "sent_at": now}, "high")
            LOG.info("FCM accepted transport probe; verify receipt on the device")
            return 0
        monitor = Monitor(args.state, sender)
    except Exception as error:
        LOG.error("NOT_CONNECTED: startup/source check failed (%s); no success claimed", type(error).__name__)
        return 2
    failures = 0
    last_health_report = 0.0
    while True:
        start = time.monotonic()
        try:
            result = monitor.tick()
            failures = 0
            if start - last_health_report >= 60:
                LOG.info("Source check OK; interval=%.1fs, downloaded_bytes=%d, pending=%s",
                         args.interval, result["downloaded_bytes"], result["pending"])
                last_health_report = start
        except Exception as error:
            failures += 1
            LOG.error("Poll/push failed (%s); pending state retained", type(error).__name__)
            if args.once:
                return 1
        if args.once:
            return 0
        delay = min(60, args.interval * 2 ** min(failures, 6))
        time.sleep(max(0, delay - (time.monotonic() - start)))


if __name__ == "__main__":
    raise SystemExit(main())
