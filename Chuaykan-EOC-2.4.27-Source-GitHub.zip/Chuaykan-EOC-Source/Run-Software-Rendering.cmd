@echo off
set QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu --disable-gpu-compositing
set QSG_RHI_BACKEND=software
start "" "%~dp0Chuaykan.exe"
