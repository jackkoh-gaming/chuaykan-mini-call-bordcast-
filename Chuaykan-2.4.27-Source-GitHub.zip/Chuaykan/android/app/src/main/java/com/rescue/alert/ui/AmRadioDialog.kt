package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.media.AudioManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.data.AmRadioPlayer
import com.rescue.alert.data.AmRadioRepository
import com.rescue.alert.model.AmStation
import com.rescue.alert.util.WebLinkHelper
import java.util.Locale

/**
 * Thailand National Emergency AM/FM Radio Broadcast Center Dialog.
 * Direct live HLS streaming of government disaster alert stations (สวท. / กรมประชาสัมพันธ์),
 * integrated with official NBTC (สำนักงาน กสทช.) Open Data technical radio catalog,
 * and complete offline transistor radio frequency tuning directory for blackout crises.
 */
object AmRadioDialog {

    private enum class TabMode {
        AM_ONLY,
        NBTC_CATALOG,
        ALL_STATIONS,
        TRANSISTOR_GUIDE
    }

    fun show(context: Context, onDismissCallback: (() -> Unit)? = null) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setVolumeControlStream(AudioManager.STREAM_MUSIC)
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_am_radio, null)
        dialog.setContentView(dialogView)

        dialog.window?.let { window ->
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.setLayout(
                (context.resources.displayMetrics.widthPixels * 0.95).toInt(),
                (context.resources.displayMetrics.heightPixels * 0.88).toInt()
            )
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.setDimAmount(0.75f)
        }

        // View Bindings
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseRadioDialog)
        val btnTabAmOnly = dialogView.findViewById<Button>(R.id.btnTabAmOnly)
        val btnTabNbtc = dialogView.findViewById<Button>(R.id.btnTabNbtc)
        val btnTabAllRadio = dialogView.findViewById<Button>(R.id.btnTabAllRadio)
        val btnTabOfflineGuide = dialogView.findViewById<Button>(R.id.btnTabOfflineGuide)
        val etSearchRadio = dialogView.findViewById<EditText>(R.id.etSearchRadio)
        val tvStationCount = dialogView.findViewById<TextView>(R.id.tvStationCount)
        val btnPrdeeWebLink = dialogView.findViewById<Button>(R.id.btnPrdeeWebLink)
        val stationsContainer = dialogView.findViewById<LinearLayout>(R.id.layoutStationsContainer)

        // Mini Player Views
        val layoutNowPlaying = dialogView.findViewById<LinearLayout>(R.id.layoutNowPlaying)
        val pbPlayerBuffering = dialogView.findViewById<ProgressBar>(R.id.pbPlayerBuffering)
        val ivPlayerWave = dialogView.findViewById<ImageView>(R.id.ivPlayerWave)
        val tvPlayerStationName = dialogView.findViewById<TextView>(R.id.tvPlayerStationName)
        val tvPlayerStatus = dialogView.findViewById<TextView>(R.id.tvPlayerStatus)
        val btnPlayerPlayPause = dialogView.findViewById<ImageButton>(R.id.btnPlayerPlayPause)
        val btnPlayerStop = dialogView.findViewById<ImageButton>(R.id.btnPlayerStop)

        var currentMode = TabMode.AM_ONLY
        var allLoadedStations = AmRadioRepository.getCachedStations()
        var nbtcStations: List<AmStation> = emptyList()
        var isFetchingNbtc = false

        // Helper to update mini player bar
        fun updateMiniPlayer(state: AmRadioPlayer.State, station: AmStation?) {
            if (station == null || state == AmRadioPlayer.State.IDLE) {
                layoutNowPlaying.visibility = View.GONE
                return
            }

            layoutNowPlaying.visibility = View.VISIBLE
            tvPlayerStationName.text = "${station.name} (${station.modulation} ${station.frequency} KHz)"

            when (state) {
                AmRadioPlayer.State.BUFFERING -> {
                    pbPlayerBuffering.visibility = View.VISIBLE
                    ivPlayerWave.visibility = View.GONE
                    tvPlayerStatus.text = "กำลังเชื่อมต่อสัญญาณสด • กรุณารอสักครู่..."
                    tvPlayerStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
                    btnPlayerPlayPause.setImageResource(R.drawable.ic_pause)
                }
                AmRadioPlayer.State.PLAYING -> {
                    pbPlayerBuffering.visibility = View.GONE
                    ivPlayerWave.visibility = View.VISIBLE
                    tvPlayerStatus.text = "กำลังรับฟังเสียงสดจากสถานี • ON AIR"
                    tvPlayerStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#10B981"))
                    btnPlayerPlayPause.setImageResource(R.drawable.ic_pause)
                }
                AmRadioPlayer.State.PAUSED -> {
                    pbPlayerBuffering.visibility = View.GONE
                    ivPlayerWave.visibility = View.VISIBLE
                    tvPlayerStatus.text = "หยุดการถ่ายทอดชั่วคราว (PAUSED)"
                    tvPlayerStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#F59E0B"))
                    btnPlayerPlayPause.setImageResource(R.drawable.ic_play_arrow)
                }
                AmRadioPlayer.State.ERROR -> {
                    pbPlayerBuffering.visibility = View.GONE
                    ivPlayerWave.visibility = View.VISIBLE
                    tvPlayerStatus.text = AmRadioPlayer.errorMessage ?: "สัญญาณถ่ายทอดสดขัดข้อง"
                    tvPlayerStatus.setTextColor(com.rescue.alert.util.ThemePalette.color("#EF4444"))
                    btnPlayerPlayPause.setImageResource(R.drawable.ic_play_arrow)
                }
                AmRadioPlayer.State.IDLE -> {
                    layoutNowPlaying.visibility = View.GONE
                }
            }
        }

        // Connect player listener
        val playerListener: (AmRadioPlayer.State, AmStation?) -> Unit = { state, station ->
            updateMiniPlayer(state, station)
        }
        AmRadioPlayer.addListener(playerListener)

        // Player Bar Controls
        btnPlayerPlayPause.setOnClickListener {
            if (AmRadioPlayer.isPlaying()) {
                AmRadioPlayer.pause()
            } else {
                AmRadioPlayer.resume()
            }
        }

        btnPlayerStop.setOnClickListener {
            AmRadioPlayer.stop()
        }

        // Render Transistor Guide (Offline Disaster Radio)
        fun renderTransistorGuide() {
            stationsContainer.removeAllViews()
            etSearchRadio.visibility = View.GONE
            tvStationCount.text = "ตารางความถี่วิทยุ AM แห่งชาติ สำหรับเครื่องรับวิทยุทรานซิสเตอร์ใส่ถ่าน (กสทช. 526.5 - 1606.5 KHz)"

            val guideLayout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(4, 8, 4, 16)
            }

            // Info Banner
            val tvBanner = TextView(context).apply {
                text = "⚡ เมื่อเกิดภัยพิบัติรุนแรง เสาสัญญาณมือถือล่ม ไฟฟ้าดับทั้งเมือง คลื่นวิทยุ AM (Medium Wave ตามตารางคลื่นความถี่ กสทช.) สามารถเดินทางเลียบผิวดินข้ามภูเขาและข้ามจังหวัดได้ไกลหลายร้อยกิโลเมตร แนะนำให้ใช้เครื่องรับวิทยุทรานซิสเตอร์แบบหมุนหาคลื่นและใส่ถ่านไฟฉายในการรับฟังข่าวสาร"
                setTextColor(com.rescue.alert.util.ThemePalette.color("#E2E8F0"))
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
                setBackgroundResource(R.drawable.bg_tactical_radio_tuner)
                setPadding(16, 14, 16, 14)
                val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 16) }
                layoutParams = lp
            }
            guideLayout.addView(tvBanner)

            val regions = listOf(
                "กรุงเทพฯ และภาคกลาง (แม่ข่ายระดับชาติ)" to listOf(
                    "AM 819 KHz" to "สวท. กรุงเทพฯ — แม่ข่ายเตือนภัยฉุกเฉินระดับชาติ (กสทช./สวท. กำลังส่งสูงสุด 100 kW)",
                    "AM 891 KHz" to "สวท. กรุงเทพฯ — แม่ข่ายถ่ายทอดเสียงรายการข่าวสารหลักและแถลงการณ์รัฐบาล",
                    "AM 1467 KHz" to "สวท. กรุงเทพฯ — ข้อมูลสาธารณภัยและการศึกษาชุมชน",
                    "AM 1107 KHz" to "วิทยุ ม.เกษตรศาสตร์ บางเขน — ข้อมูลการเกษตรและสภาพอากาศ",
                    "AM 540 KHz" to "วิทยุกรมการรักษาดินแดน (วรศ.) — ความมั่นคงและการป้องกันภัยฝ่ายพลเรือน",
                    "AM 1575 KHz" to "วิทยุสราญรมย์ (กต.) — กระจายเสียงระหว่างประเทศ (กำลังส่ง 1000 kW)"
                ),
                "ภาคเหนือ (17 จังหวัด)" to listOf(
                    "AM 549 KHz" to "สวท.เพื่อการเรียนรู้และเตือนภัยภาคเหนือ (เสาส่งลำปาง) — ศูนย์เตือนภัยน้ำท่วม ดินโคลนถล่ม",
                    "AM 639 KHz" to "สวท. เชียงใหม่ — ครอบคลุมลุ่มน้ำปิงและภาคเหนือตอนบน",
                    "AM 1476 KHz" to "สวท. เชียงใหม่ ภาคการศึกษา",
                    "AM 612 KHz" to "วิทยุ ม.เกษตรศาสตร์ เชียงใหม่",
                    "AM 1026 KHz" to "สวท. พิษณุโลก — ครอบคลุมลุ่มน้ำน่านและภาคเหนือตอนล่าง",
                    "AM 864 KHz" to "สวท. ตาก — ชายแดนตะวันตกและแม่น้ำปิง"
                ),
                "ภาคตะวันออกเฉียงเหนือ (อีสาน)" to listOf(
                    "AM 621 KHz" to "สวท. ขอนแก่น — สถานีแม่ข่ายหลักภาคอีสาน ครอบคลุมพื้นที่กว้างไกล",
                    "AM 729 KHz" to "สวท. นครราชสีมา — ศูนย์เตือนภัยลุ่มน้ำมูลและอีสานตอนล่าง",
                    "AM 1341 KHz" to "สวท. อุบลราชธานี — เฝ้าระวังน้ำท่วมแม่น้ำมูล-ชี และชายแดนอีสานใต้",
                    "AM 810 KHz" to "สวท. หนองคาย — เฝ้าระวังน้ำโขงล้นตลิ่งตลอดแนวลำน้ำ",
                    "AM 1314 KHz" to "วิทยุ ม.เกษตรศาสตร์ ขอนแก่น",
                    "AM 1341 KHz" to "สวท. เลย — ครอบคลุมพื้นที่ภูเขาสูง",
                    "AM 909 KHz" to "สวท. ด่านซ้าย จ.เลย"
                ),
                "ภาคใต้" to listOf(
                    "AM 1242 KHz" to "สวท. สุราษฎร์ธานี — ศูนย์กลางเตือนภัยพายุ มรสุม ฝั่งอ่าวไทย",
                    "AM 1062 KHz" to "สวท. ภูเก็ต — ศูนย์เตือนภัยสึนามิและคลื่นลมทะเลฝั่งอันดามัน",
                    "AM 981 KHz" to "สวท. ยะลา — ศูนย์เตือนภัย 3 จังหวัดชายแดนใต้และลุ่มน้ำปัตตานี",
                    "AM 783 KHz" to "สวท. ระนอง — พื้นที่ฝั่งทะเลอันดามัน",
                    "AM 810 KHz" to "สวท. ตรัง — ฝั่งอันดามันตอนล่าง",
                    "AM 1269 KHz" to "วิทยุ ม.เกษตรศาสตร์ สงขลา"
                ),
                "ภาคตะวันออก และภาคตะวันตก" to listOf(
                    "AM 1125 KHz" to "สวท. จันทบุรี — ชายฝั่งทะเลตะวันออก",
                    "AM 558 KHz" to "สวท. กาญจนบุรี — ลุ่มน้ำแควน้อย-แควใหญ่",
                    "AM 1593 KHz" to "สวท. ราชบุรี — ลุ่มน้ำแม่กลอง"
                )
            )

            for ((regionTitle, stationList) in regions) {
                val tvRegion = TextView(context).apply {
                    text = "📻 $regionTitle"
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
                    setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(8, 12, 8, 6)
                }
                guideLayout.addView(tvRegion)

                val box = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundResource(R.drawable.bg_tactical_radio_script)
                    setPadding(12, 10, 12, 10)
                    val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 14) }
                    layoutParams = lp
                }

                for ((freq, desc) in stationList) {
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(0, 4, 0, 4)
                        gravity = android.view.Gravity.CENTER_VERTICAL
                    }
                    val tvFreq = TextView(context).apply {
                        text = freq
                        setTextColor(com.rescue.alert.util.ThemePalette.color("#F59E0B"))
                        setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12.5f)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        layoutParams = LinearLayout.LayoutParams(110, -2)
                    }
                    val tvDesc = TextView(context).apply {
                        text = desc
                        setTextColor(com.rescue.alert.util.ThemePalette.color("#CBD5E1"))
                        setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11.5f)
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    }
                    row.addView(tvFreq)
                    row.addView(tvDesc)
                    box.addView(row)
                }

                guideLayout.addView(box)
            }

            stationsContainer.addView(guideLayout)
        }

        // Render Station Cards
        fun renderStations() {
            if (currentMode == TabMode.TRANSISTOR_GUIDE) {
                renderTransistorGuide()
                return
            }

            etSearchRadio.visibility = View.VISIBLE
            stationsContainer.removeAllViews()

            val sourceList = if (currentMode == TabMode.NBTC_CATALOG) {
                if (nbtcStations.isNotEmpty()) nbtcStations else allLoadedStations.filter { it.source.contains("กสทช") }
            } else {
                allLoadedStations
            }

            val query = etSearchRadio.text.toString().trim().lowercase(Locale.ROOT)
            val filtered = sourceList.filter { station ->
                val matchesTab = when (currentMode) {
                    TabMode.AM_ONLY -> station.modulation == "AM"
                    TabMode.NBTC_CATALOG -> true
                    TabMode.ALL_STATIONS -> true
                    TabMode.TRANSISTOR_GUIDE -> false
                }
                if (!matchesTab) return@filter false

                if (query.isEmpty()) true else {
                    station.name.lowercase(Locale.ROOT).contains(query) ||
                    station.frequency.lowercase(Locale.ROOT).contains(query) ||
                    station.location.lowercase(Locale.ROOT).contains(query) ||
                    station.description.lowercase(Locale.ROOT).contains(query) ||
                    station.source.lowercase(Locale.ROOT).contains(query) ||
                    (station.callsign?.lowercase(Locale.ROOT)?.contains(query) ?: false)
                }
            }

            tvStationCount.text = when (currentMode) {
                TabMode.AM_ONLY -> "พบ ${filtered.size} สถานี AM เตือนภัยฉุกเฉินแห่งชาติ (กสทช. / สวท.)"
                TabMode.NBTC_CATALOG -> "พบ ${filtered.size} สถานีวิทยุกระจายเสียงในฐานข้อมูล กสทช. (NBTC Open Data)"
                TabMode.ALL_STATIONS -> "พบ ${filtered.size} สถานีวิทยุกระจายเสียงทั่วประเทศ (AM/FM)"
                TabMode.TRANSISTOR_GUIDE -> ""
            }

            if (currentMode != TabMode.NBTC_CATALOG && AmRadioRepository.lastDirectoryError != null) {
                tvStationCount.append("\nอัปเดตรายการสดไม่ได้ • แสดงข้อมูลสถานีที่บันทึกไว้\n" + AmRadioRepository.lastDirectoryError)
            }
            if (filtered.isEmpty()) {
                val tvEmpty = TextView(context).apply {
                    text = if (currentMode == TabMode.NBTC_CATALOG && isFetchingNbtc)
                        "กำลังดาวน์โหลดข้อมูลสถานีจาก API สำนักงาน กสทช. ..."
                    else
                        "ไม่พบสถานีวิทยุที่ตรงกับคำค้นหา"
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                    textSize = 13f
                    gravity = android.view.Gravity.CENTER
                    setPadding(0, 48, 0, 48)
                }
                stationsContainer.addView(tvEmpty)
                return
            }

            for (station in filtered) {
                val cardView = inflater.inflate(R.layout.item_am_station_card, stationsContainer, false)

                val tvModulation = cardView.findViewById<TextView>(R.id.tvCardModulation)
                val tvFrequency = cardView.findViewById<TextView>(R.id.tvCardFrequency)
                val tvFreqUnit = cardView.findViewById<TextView>(R.id.tvCardFreqUnit)
                val tvStationName = cardView.findViewById<TextView>(R.id.tvCardStationName)
                val tvStationLocation = cardView.findViewById<TextView>(R.id.tvCardStationLocation)
                val tvEmergencyTag = cardView.findViewById<TextView>(R.id.tvCardEmergencyTag)
                val btnPlay = cardView.findViewById<Button>(R.id.btnCardPlay)
                val badgeLayout = cardView.findViewById<LinearLayout>(R.id.badgeFrequencyLayout)

                tvModulation.text = station.modulation
                tvFrequency.text = station.frequency
                tvFreqUnit.text = if (station.modulation == "AM") "KHz" else "MHz"
                tvStationName.text = station.name
                
                val callsignText = if (!station.callsign.isNullOrBlank()) " • Callsign: ${station.callsign}" else ""
                tvStationLocation.text = "📍 ${station.location}$callsignText • ${station.description.ifBlank { station.source }}"

                if (station.isEmergencyPrimary) {
                    tvEmergencyTag.visibility = View.VISIBLE
                    tvEmergencyTag.text = "🚨 แม่ข่ายเตือนภัยฉุกเฉินระดับชาติ (กสทช./สวท.)"
                    badgeLayout.setBackgroundResource(R.drawable.bg_chip_am_station_selected)
                } else if (station.source.contains("กสทช. (NBTC Open Data)")) {
                    tvEmergencyTag.visibility = View.VISIBLE
                    tvEmergencyTag.text = "🏛️ กสทช. ขึ้นทะเบียนทางการ (NBTC Data Catalog)"
                    badgeLayout.setBackgroundResource(R.drawable.bg_chip_am_station)
                } else if (station.modulation == "AM") {
                    tvEmergencyTag.visibility = View.VISIBLE
                    tvEmergencyTag.text = "📻 เครือข่ายวิทยุคลื่นยาว AM (${station.source})"
                    badgeLayout.setBackgroundResource(R.drawable.bg_chip_am_station)
                } else {
                    tvEmergencyTag.visibility = View.GONE
                    badgeLayout.setBackgroundResource(R.drawable.bg_chip_am_station)
                }

                // Check if this station is currently playing
                val isThisPlaying = AmRadioPlayer.currentStation?.id == station.id && AmRadioPlayer.isPlaying()
                if (isThisPlaying) {
                    btnPlay.text = "กำลังฟัง"
                    btnPlay.setBackgroundResource(R.drawable.bg_button_safe)
                    btnPlay.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_volume_up, 0, 0, 0)
                } else {
                    btnPlay.text = if (!station.streamUrl.isNullOrBlank() || station.supportsStreamLookup) "ฟังสด" else "ข้อมูลคลื่น"
                    btnPlay.setBackgroundResource(R.drawable.bg_tactical_btn_call)
                    btnPlay.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_play_arrow, 0, 0, 0)
                }

                val onPlayClicked = View.OnClickListener {
                    if (AmRadioPlayer.currentStation?.id == station.id && AmRadioPlayer.isPlaying()) {
                        AmRadioPlayer.pause()
                    } else if (!station.streamUrl.isNullOrBlank() || station.supportsStreamLookup) {
                        // Start buffering & streaming
                        btnPlay.text = "โหลด..."
                        btnPlay.isEnabled = false
                        AmRadioRepository.fetchStreamUrl(station) { resolvedUrl ->
                            btnPlay.isEnabled = true
                            if (!resolvedUrl.isNullOrBlank()) {
                                if (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
                                    Toast.makeText(context, "เสียงสื่อปิดอยู่ กดปุ่มเพิ่มเสียงเพื่อรับฟังข่าว", Toast.LENGTH_LONG).show()
                                }
                                AmRadioPlayer.play(station, resolvedUrl)
                                renderStations()
                            } else {
                                Toast.makeText(context, "ไม่สามารถเชื่อมต่อสัญญาณสดของ ${station.name} ได้ในขณะนี้", Toast.LENGTH_SHORT).show()
                                btnPlay.text = "ฟังสด"
                            }
                        }
                    } else {
                        // Offline info or frequency details
                        val unit = if (station.modulation == "AM") "KHz" else "MHz"
                        val info = "${station.name}\nความถี่: ${station.frequency} $unit\nพิกัด: ${station.location}\nแหล่งข้อมูล: ${station.source}\n${station.description}"
                        Toast.makeText(context, info, Toast.LENGTH_LONG).show()
                    }
                }

                btnPlay.setOnClickListener(onPlayClicked)
                cardView.setOnClickListener(onPlayClicked)

                stationsContainer.addView(cardView)
            }
        }

        // Tab selection logic
        fun updateTabs() {
            btnTabAmOnly.setBackgroundResource(if (currentMode == TabMode.AM_ONLY) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabAmOnly.setTextColor(if (currentMode == TabMode.AM_ONLY) com.rescue.alert.util.ThemePalette.color("#38BDF8") else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            btnTabNbtc.setBackgroundResource(if (currentMode == TabMode.NBTC_CATALOG) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabNbtc.setTextColor(if (currentMode == TabMode.NBTC_CATALOG) com.rescue.alert.util.ThemePalette.color("#38BDF8") else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            btnTabAllRadio.setBackgroundResource(if (currentMode == TabMode.ALL_STATIONS) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabAllRadio.setTextColor(if (currentMode == TabMode.ALL_STATIONS) com.rescue.alert.util.ThemePalette.color("#38BDF8") else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            btnTabOfflineGuide.setBackgroundResource(if (currentMode == TabMode.TRANSISTOR_GUIDE) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabOfflineGuide.setTextColor(if (currentMode == TabMode.TRANSISTOR_GUIDE) com.rescue.alert.util.ThemePalette.color("#38BDF8") else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            btnPrdeeWebLink.text = if (currentMode == TabMode.NBTC_CATALOG) "เว็บ กสทช." else "เว็บ PRDEE"

            if (currentMode == TabMode.NBTC_CATALOG && nbtcStations.isEmpty() && !isFetchingNbtc) {
                isFetchingNbtc = true
                tvStationCount.text = "กำลังดึงข้อมูลสถานีวิทยุกระจายเสียงจาก Open Data กสทช. ..."
                AmRadioRepository.fetchNbtcStations(300) { fetched ->
                    isFetchingNbtc = false
                    if (dialog.isShowing) {
                        nbtcStations = fetched
                        if (currentMode == TabMode.NBTC_CATALOG) {
                            renderStations()
                        }
                    }
                }
            }

            renderStations()
        }

        btnTabAmOnly.setOnClickListener {
            currentMode = TabMode.AM_ONLY
            updateTabs()
        }

        btnTabNbtc.setOnClickListener {
            currentMode = TabMode.NBTC_CATALOG
            updateTabs()
        }

        btnTabAllRadio.setOnClickListener {
            currentMode = TabMode.ALL_STATIONS
            updateTabs()
        }

        btnTabOfflineGuide.setOnClickListener {
            currentMode = TabMode.TRANSISTOR_GUIDE
            updateTabs()
        }

        // Search text change listener
        etSearchRadio.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (currentMode != TabMode.TRANSISTOR_GUIDE) {
                    renderStations()
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Web Link fallback (NBTC or PRDEE)
        btnPrdeeWebLink.setOnClickListener {
            val url = if (currentMode == TabMode.NBTC_CATALOG) AmRadioRepository.NBTC_CATALOG_URL else AmRadioRepository.PLAYER_URL
            WebLinkHelper.openUrl(context, url)
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.setOnDismissListener {
            AmRadioPlayer.removeListener(playerListener)
            onDismissCallback?.invoke()
        }

        // Initial render
        updateMiniPlayer(AmRadioPlayer.state, AmRadioPlayer.currentStation)
        updateTabs()
        dialog.show()

        // Fetch live station list from network in background
        AmRadioRepository.getStations { freshStations ->
            if (dialog.isShowing) {
                allLoadedStations = freshStations
                if (currentMode != TabMode.TRANSISTOR_GUIDE && currentMode != TabMode.NBTC_CATALOG) {
                    renderStations()
                }
            }
        }
    }
}
