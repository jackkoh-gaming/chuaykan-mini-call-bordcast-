package com.rescue.alert.data

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.rescue.alert.model.AmStation
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Repository for Thailand National Radio Network (PRD & NBTC / กสทช. Open Data).
 * Integrates:
 * 1. NBTC Open Data Catalog API (สำนักงาน กสทช.): https://datacatalog.nbtc.go.th
 * 2. PRD Live Audio Streaming OTT API (กรมประชาสัมพันธ์): https://api-ott.prd.go.th
 * 3. Complete National AM Emergency & Educational Broadcasting Registry.
 */
object AmRadioRepository {
    private const val TAG = "AmRadioRepository"
    const val PLAYER_URL = "https://prdee.prd.go.th/radio"
    const val NBTC_CATALOG_URL = "https://datacatalog.nbtc.go.th/dataset/dataset68_11_45"

    // PRD Streaming API Endpoints
    private const val API_ALL_URL = "https://api-ott.prd.go.th/api/v1/radio/all"
    private const val API_DETAIL_URL = "https://api-ott.prd.go.th/api/v1/home/radio/detail"

    // NBTC (สำนักงาน กสทช.) Open Data CKAN API Endpoints
    const val NBTC_DATASTORE_API = "https://datacatalog.nbtc.go.th/api/3/action/datastore_search"
    const val NBTC_RADIO_RESOURCE_ID = "fffc25e6-660f-4874-a874-a8f15e5303df"
    const val NBTC_NFAT_RESOURCE_ID = "378a544e-ddf0-4019-b896-a5a49cfb530f"

    // Cache for station stream URLs: stationId -> streamUrl
    private val streamUrlCache = ConcurrentHashMap<String, String>()
    @Volatile var lastDirectoryError: String? = null
        private set

    /**
     * Official AM Stations of the Public Relations Department (สวท.) & Licensed Agencies
     * according to the National Frequency Allocation Plan of NBTC (กสทช. 526.5 - 1606.5 KHz).
     */
    val BASELINE_AM_STATIONS = listOf(
        AmStation(
            id = "691c47c484b24f001225ce8f",
            name = "สวท. กรุงเทพฯ (AM 819 KHz)",
            frequency = "819",
            modulation = "AM",
            isLive = true,
            location = "กรุงเทพมหานคร",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/4275-2b54-7c27-1e5a-9fd6/playlist.m3u8",
            description = "แม่ข่ายวิทยุเตือนภัยฉุกเฉินระดับชาติ (กสทช. / กรมประชาสัมพันธ์ กำลังส่ง 100 kW)",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSD"
        ),
        AmStation(
            id = "691c481584b24f001225cef0",
            name = "สวท. กรุงเทพฯ (AM 891 KHz)",
            frequency = "891",
            modulation = "AM",
            isLive = true,
            location = "กรุงเทพมหานคร",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/51dd-90a9-c6ae-c7f7-49d4/playlist.m3u8",
            description = "แม่ข่ายถ่ายทอดเสียงแห่งประเทศไทย รายการข่าวสารหลักและแถลงการณ์รัฐบาล",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSA"
        ),
        AmStation(
            id = "6916f9bfda505900121073e3",
            name = "สวท.เพื่อการเรียนรู้และเตือนภัยภาคเหนือ (AM 549 KHz)",
            frequency = "549",
            modulation = "AM",
            isLive = true,
            location = "ลำปาง",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/e41b-e358-214f-64bf-cc24/playlist.m3u8",
            description = "ศูนย์เตือนภัยน้ำท่วม ดินโคลนถล่ม 17 จังหวัดภาคเหนือ (เสาส่งลำปาง กำลังส่ง 100 kW)",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSLT"
        ),
        AmStation(
            id = "6916f76ada5059001210738d",
            name = "สวท. เชียงใหม่ (AM 639 KHz)",
            frequency = "639",
            modulation = "AM",
            isLive = true,
            location = "เชียงใหม่",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/f07f-6251-3629-74d8-6dcb/playlist.m3u8",
            description = "สถานีวิทยุกระจายเสียงแห่งประเทศไทย จ.เชียงใหม่ ลุ่มน้ำปิง",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSCM"
        ),
        AmStation(
            id = "6916d576fff5560012704f84",
            name = "สวท. ขอนแก่น (AM 621 KHz)",
            frequency = "621",
            modulation = "AM",
            isLive = true,
            location = "ขอนแก่น",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/2345-c4db-a645-4675-ba3f/playlist.m3u8",
            description = "สถานีแม่ข่ายหลักภาคตะวันออกเฉียงเหนือ ครอบคลุมพื้นที่กว้างไกล",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSKK"
        ),
        AmStation(
            id = "6916d321fff5560012704f17",
            name = "สวท. นครราชสีมา (AM 729 KHz)",
            frequency = "729",
            modulation = "AM",
            isLive = true,
            location = "นครราชสีมา",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/97f0-9ffc-3517-7204-51ec/playlist.m3u8",
            description = "ศูนย์เตือนภัยลุ่มน้ำมูลและอีสานตอนล่าง (ประตูสู่อีสาน)",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSNM"
        ),
        AmStation(
            id = "691ad0b24869a1001231f913",
            name = "สวท. กรุงเทพฯ ภาคการศึกษา (AM 1467 KHz)",
            frequency = "1467",
            modulation = "AM",
            isLive = true,
            location = "กรุงเทพมหานคร",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/559b-c353-7002-963c-3668/playlist.m3u8",
            description = "รายการข้อมูลสาธารณภัยและการศึกษาชุมชน",
            isEmergencyPrimary = false,
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "6916f250da505900121072f0",
            name = "สวท. อุบลราชธานี (AM 1341 KHz)",
            frequency = "1341",
            modulation = "AM",
            isLive = true,
            location = "อุบลราชธานี",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/2ceb-75e9-315b-3ff7-230c/playlist.m3u8",
            description = "สถานีวิทยุกระจายเสียงแห่งประเทศไทย จ.อุบลราชธานี ลุ่มน้ำมูล-ชี",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSUB"
        ),
        AmStation(
            id = "6916d084fff5560012704eca",
            name = "สวท. หนองคาย (AM 810 KHz)",
            frequency = "810",
            modulation = "AM",
            isLive = true,
            location = "หนองคาย",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/5ec2-d813-baaf-b8fd-f473/playlist.m3u8",
            description = "สวท. หนองคาย ริมแม่น้ำโขง ติดตามสถานการณ์น้ำโขงล้นตลิ่ง",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "6916cf51fff5560012704ea0",
            name = "สวท. เลย (AM 1341 KHz)",
            frequency = "1341",
            modulation = "AM",
            isLive = true,
            location = "เลย",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/d1cc-7068-7996-9e37-2355/playlist.m3u8",
            description = "สวท. จ.เลย ครอบคลุมพื้นที่ภูเขาสูง",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "6916cf9dfff5560012704ea9",
            name = "สวท. ด่านซ้าย จ.เลย (AM 909 KHz)",
            frequency = "909",
            modulation = "AM",
            isLive = true,
            location = "เลย",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/2bf0-7b4e-9a3e-c754-1136/playlist.m3u8",
            description = "สวท. ด่านซ้าย จ.เลย",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "6916f7abda5059001210739a",
            name = "สวท. เชียงใหม่ เพื่อการศึกษา (AM 1476 KHz)",
            frequency = "1476",
            modulation = "AM",
            isLive = true,
            location = "เชียงใหม่",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/5bcb-fbf2-b30d-cd20-84a0/playlist.m3u8",
            description = "สวท. เชียงใหม่ เครือข่ายการศึกษาและข้อมูลชุมชน",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691a95fd4869a1001231f720",
            name = "สวท. พิษณุโลก (AM 1026 KHz)",
            frequency = "1026",
            modulation = "AM",
            isLive = true,
            location = "พิษณุโลก",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/5e08-830a-e6e9-9fb3-97ff/playlist.m3u8",
            description = "ศูนย์กลางข่าวสารภาคเหนือตอนล่างและลุ่มน้ำน่าน",
            source = "กสทช. / สวท.",
            callsign = "HSPL"
        ),
        AmStation(
            id = "691a96814869a1001231f732",
            name = "สวท. ตาก (AM 864 KHz)",
            frequency = "864",
            modulation = "AM",
            isLive = true,
            location = "ตาก",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/6d57-fa0e-2324-8bb0-4680/playlist.m3u8",
            description = "สวท. ตาก แนวชายแดนตะวันตกและลุ่มน้ำปิง",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691a9efd4869a1001231f784",
            name = "สวท. สุราษฎร์ธานี (AM 1242 KHz)",
            frequency = "1242",
            modulation = "AM",
            isLive = true,
            location = "สุราษฎร์ธานี",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/0bb5-7c2d-30c8-89e5-7e29/playlist.m3u8",
            description = "ศูนย์กลางภาคใต้ตอนบนและอ่าวไทย เตือนภัยมรสุม",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSSR"
        ),
        AmStation(
            id = "691aa2644869a1001231f7b4",
            name = "สวท. ภูเก็ต (AM 1062 KHz)",
            frequency = "1062",
            modulation = "AM",
            isLive = true,
            location = "ภูเก็ต",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/d965-d803-7355-134b-c92b/playlist.m3u8",
            description = "เครือข่ายเตือนภัยสึนามิและภัยพิบัติทางทะเลอันดามัน",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSPK"
        ),
        AmStation(
            id = "691aa44f4869a1001231f7f4",
            name = "สวท. ระนอง (AM 783 KHz)",
            frequency = "783",
            modulation = "AM",
            isLive = true,
            location = "ระนอง",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/798e-062f-a4c3-36fc-1157/playlist.m3u8",
            description = "สวท. ระนอง พื้นที่ฝนแปดแดดสี่ แนวชายฝั่งอันดามัน",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691aaa7a4869a1001231f82d",
            name = "สวท. ยะลา (AM 981 KHz)",
            frequency = "981",
            modulation = "AM",
            isLive = true,
            location = "ยะลา",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/8561-a909-6d9f-f5a5-5098/playlist.m3u8",
            description = "ศูนย์เตือนภัย 3 จังหวัดชายแดนใต้และลุ่มน้ำปัตตานี",
            isEmergencyPrimary = true,
            source = "กสทช. / สวท.",
            callsign = "HSYL"
        ),
        AmStation(
            id = "691ac5494869a1001231f86a",
            name = "สวท. ตรัง (AM 810 KHz)",
            frequency = "810",
            modulation = "AM",
            isLive = true,
            location = "ตรัง",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/62bf-a59d-a1bf-55bf-bb9a/playlist.m3u8",
            description = "สวท. ตรัง ครอบคลุมฝั่งอันดามันตอนล่าง",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691acd534869a1001231f89b",
            name = "สวท. จันทบุรี (AM 1125 KHz)",
            frequency = "1125",
            modulation = "AM",
            isLive = true,
            location = "จันทบุรี",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/c9c2-c5d8-edb1-4fd3-92df/playlist.m3u8",
            description = "ศูนย์กระจายเสียงภาคตะวันออก ชายฝั่งทะเลและสวนผลไม้",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691ace914869a1001231f8c8",
            name = "สวท. กาญจนบุรี (AM 558 KHz)",
            frequency = "558",
            modulation = "AM",
            isLive = true,
            location = "กาญจนบุรี",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/5992-f1ad-264e-a2b2-d0af/playlist.m3u8",
            description = "ศูนย์กระจายเสียงภาคตะวันตก ลุ่มน้ำแควน้อย-แควใหญ่",
            source = "กสทช. / สวท."
        ),
        AmStation(
            id = "691acfad4869a1001231f8ee",
            name = "สวท. ราชบุรี (AM 1593 KHz)",
            frequency = "1593",
            modulation = "AM",
            isLive = true,
            location = "ราชบุรี",
            streamUrl = "https://cdn-edge.iiptvcdn.com/radio_edge/159f-f6a2-9a3d-27de-d926/playlist.m3u8",
            description = "สวท. ราชบุรี ลุ่มน้ำแม่กลอง",
            source = "กสทช. / สวท."
        ),
        // Additional Licensed AM Stations registered with NBTC (กสทช.)
        AmStation(
            id = "nbtc_ku_bkk",
            name = "วิทยุ ม.เกษตรศาสตร์ บางเขน (AM 1107 KHz)",
            frequency = "1107",
            modulation = "AM",
            isLive = false,
            location = "กรุงเทพฯ / สมุทรสาคร",
            description = "สถานีวิทยุกระจายเสียง ม.ก. ข้อมูลการเกษตรและภัยธรรมชาติ",
            source = "กสทช. (ม.เกษตรฯ)",
            callsign = "KUR"
        ),
        AmStation(
            id = "nbtc_ku_cmi",
            name = "วิทยุ ม.เกษตรศาสตร์ เชียงใหม่ (AM 612 KHz)",
            frequency = "612",
            modulation = "AM",
            isLive = false,
            location = "เชียงใหม่",
            description = "สถานีวิทยุ ม.ก. เชียงใหม่ เครือข่ายการเตือนภัยภาคเหนือ",
            source = "กสทช. (ม.เกษตรฯ)",
            callsign = "KUR-N"
        ),
        AmStation(
            id = "nbtc_ku_kkn",
            name = "วิทยุ ม.เกษตรศาสตร์ ขอนแก่น (AM 1314 KHz)",
            frequency = "1314",
            modulation = "AM",
            isLive = false,
            location = "ขอนแก่น",
            description = "สถานีวิทยุ ม.ก. ขอนแก่น เครือข่ายอีสาน",
            source = "กสทช. (ม.เกษตรฯ)",
            callsign = "KUR-NE"
        ),
        AmStation(
            id = "nbtc_ku_ska",
            name = "วิทยุ ม.เกษตรศาสตร์ สงขลา (AM 1269 KHz)",
            frequency = "1269",
            modulation = "AM",
            isLive = false,
            location = "สงขลา",
            description = "สถานีวิทยุ ม.ก. สงขลา เครือข่ายภาคใต้",
            source = "กสทช. (ม.เกษตรฯ)",
            callsign = "KUR-S"
        ),
        AmStation(
            id = "nbtc_doae_pt",
            name = "วิทยุเพื่อการเกษตร กรมส่งเสริมการเกษตร (AM 1386 KHz)",
            frequency = "1386",
            modulation = "AM",
            isLive = false,
            location = "ปทุมธานี",
            description = "สถานีวิทยุเตือนภัยศัตรูพืชและสภาพอากาศเพื่อเกษตรกร",
            source = "กสทช. (กษ.)"
        ),
        AmStation(
            id = "nbtc_army_bkk",
            name = "วิทยุกรมการรักษาดินแดน วรศ. (AM 540 KHz)",
            frequency = "540",
            modulation = "AM",
            isLive = false,
            location = "กรุงเทพมหานคร",
            description = "วิทยุสื่อสารความมั่นคงและการป้องกันภัยฝ่ายพลเรือน",
            source = "กสทช. (ทบ.)"
        ),
        AmStation(
            id = "nbtc_mfa_aya",
            name = "วิทยุสราญรมย์ กระทรวงการต่างประเทศ (AM 1575 KHz)",
            frequency = "1575",
            modulation = "AM",
            isLive = false,
            location = "พระนครศรีอยุธยา",
            description = "สถานีวิทยุกระจายเสียงระหว่างประเทศและข้อมูลสาธารณะ (กำลังส่ง 1000 kW)",
            source = "กสทช. (กต.)"
        )
    )

    private val cachedStations = mutableListOf<AmStation>()

    init {
        for (st in BASELINE_AM_STATIONS) {
            st.streamUrl?.let { streamUrlCache[st.id] = it }
        }
        cachedStations.addAll(BASELINE_AM_STATIONS)
    }

    fun getCachedStations(): List<AmStation> {
        synchronized(cachedStations) {
            return if (cachedStations.isNotEmpty()) cachedStations.toList() else BASELINE_AM_STATIONS
        }
    }

    /**
     * Direct query to NBTC (สำนักงาน กสทช.) Open Data CKAN API for registered broadcasting stations.
     * Endpoint: https://datacatalog.nbtc.go.th/api/3/action/datastore_search
     */
    fun fetchNbtcStations(limit: Int = 300, callback: (List<AmStation>) -> Unit) {
        Thread({
            var connection: HttpURLConnection? = null
            val nbtcList = try {
                val records = JSONArray()
                val pageSize = limit.coerceIn(1, 1000)
                var offset = 0
                do {
                    val urlStr = "$NBTC_DATASTORE_API?resource_id=$NBTC_RADIO_RESOURCE_ID&limit=$pageSize&offset=$offset"
                    connection = (com.rescue.alert.network.PublicDataGateway.open(URL(urlStr)) as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 8000
                        readTimeout = 8000
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4 (NBTC-Client)")
                    }
                    val status = connection.responseCode
                    check(status == 200) { "NBTC HTTP $status" }
                    val resp = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val json = JSONObject(resp)
                    check(json.optBoolean("success")) { "NBTC datastore request failed" }
                    val result = json.getJSONObject("result")
                    val page = result.getJSONArray("records")
                    for (i in 0 until page.length()) records.put(page.getJSONObject(i))
                    offset += page.length()
                    val total = result.optInt("total", offset)
                    connection.disconnect()
                    connection = null
                    check(page.length() > 0 || offset >= total) { "NBTC pagination stopped before total" }
                } while (offset < total)
                val stations = mutableListOf<AmStation>()

                    for (i in 0 until records.length()) {
                        val r = records.optJSONObject(i) ?: continue
                        val stId = r.optString("Station_ID", "nbtc_$i")
                        val transmitterName = r.optString("Transmitter_Name", r.optString("Station_Name", "")).trim()
                        val freqStr = r.optString("Frequency", "").trim()
                        val province = r.optString("Province", "ไม่ระบุ").trim()
                        val callsign = r.optString("Callsign", "").trim()
                        val antHeight = r.optInt("Ant_Height", 0)

                        if (transmitterName.isBlank()) continue

                        val freqVal = freqStr.toDoubleOrNull() ?: 0.0
                        val isAm = freqVal > 500 && freqVal < 1700
                        val mod = if (isAm) "AM" else "FM"

                        val desc = "สถานีวิทยุกระจายเสียง กสทช. (Callsign: ${callsign.ifBlank { "-" }}, เสาสูง $antHeight ม.)"

                        stations.add(
                            AmStation(
                                id = "nbtc_$stId",
                                name = transmitterName,
                                frequency = freqStr,
                                modulation = mod,
                                isLive = true,
                                location = province,
                                streamUrl = null,
                                description = desc,
                                isEmergencyPrimary = transmitterName.contains("กรมประชาสัมพันธ์") || isAm,
                                source = "กสทช. (NBTC Open Data)",
                                callsign = callsign.ifBlank { null },
                                licenseStatus = "กสทช. ขึ้นทะเบียนทางการ"
                            )
                        )
                    }
                    Log.i(TAG, "Fetched ${stations.size} radio stations from NBTC Open Data Catalog")
                    stations
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch from NBTC API: ${e.message}")
                emptyList()
            } finally {
                connection?.disconnect()
            }

            Handler(Looper.getMainLooper()).post { callback(nbtcList) }
        }, "nbtc-radio-fetch").start()
    }

    /**
     * Fetches and merges live station data from both PRD OTT API and NBTC Open Data Catalog.
     */
    fun getStations(callback: (List<AmStation>) -> Unit) {
        Thread({
            val baselineMap = BASELINE_AM_STATIONS.associateBy { it.id }
            val resultMap = LinkedHashMap<String, AmStation>()

            // 1. Preload baseline AM emergency stations
            for (st in BASELINE_AM_STATIONS) {
                resultMap[st.id] = st
            }

            lastDirectoryError = null
            // 2. Fetch Live PRD OTT Streams
            var prdConnection: HttpURLConnection? = null
            try {
                prdConnection = (com.rescue.alert.network.PublicDataGateway.open(URL(API_ALL_URL)) as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4")
                }
                prdConnection.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }

                if (prdConnection.responseCode == 200) {
                    val jsonStr = prdConnection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val array = JSONArray(jsonStr)

                    for (i in 0 until array.length()) {
                        val item = array.optJSONObject(i) ?: continue
                        val id = item.optString("id")
                        val name = item.optString("title").trim()
                        if (!id.matches(Regex("[a-zA-Z0-9_-]+")) || name.isBlank()) continue

                        val freq = item.optString("frequency")
                        val modulation = item.optString("modulation", "FM").uppercase()
                        val isLive = item.optBoolean("live", true)
                        val location = item.optString("location", "ไม่ระบุ")
                        val desc = item.optString("desc", "")

                        val baseline = baselineMap[id]
                        val streamUrl = streamUrlCache[id] ?: baseline?.streamUrl
                        val isEmergency = baseline?.isEmergencyPrimary ?: (modulation == "AM")

                        resultMap[id] = AmStation(
                            id = id,
                            name = if (baseline != null) baseline.name else name,
                            frequency = freq,
                            modulation = modulation,
                            isLive = isLive,
                            location = if (baseline != null) baseline.location else location,
                            streamUrl = streamUrl,
                            description = if (baseline != null && baseline.description.isNotBlank()) baseline.description else desc,
                            isEmergencyPrimary = isEmergency,
                            source = "สวท. / กสทช.",
                            supportsStreamLookup = isLive,
                            callsign = baseline?.callsign
                        )
                    }
                } else {
                    lastDirectoryError = "ต้นทางตอบ HTTP ${prdConnection.responseCode}"
                }
            } catch (e: Exception) {
                lastDirectoryError = "เชื่อม API สถานีไม่ได้: ${e.message}"
                Log.w(TAG, "PRD API fetch failed: ${e.message}")
            } finally {
                prdConnection?.disconnect()
            }

            val finalStations = resultMap.values.sortedWith(
                compareByDescending<AmStation> { it.isEmergencyPrimary }
                    .thenByDescending { it.modulation == "AM" }
                    .thenBy { it.location }
            )

            synchronized(cachedStations) {
                cachedStations.clear()
                cachedStations.addAll(finalStations)
            }

            Handler(Looper.getMainLooper()).post { callback(finalStations) }
        }, "prd-radio-directory").start()
    }

    /**
     * Resolves the HLS (.m3u8) live stream URL for a given station.
     */
    fun fetchStreamUrl(station: AmStation, callback: (String?) -> Unit) {
        val cached = streamUrlCache[station.id] ?: station.streamUrl
        if (!station.supportsStreamLookup && !cached.isNullOrBlank()) {
            callback(cached)
            return
        }

        Thread({
            var connection: HttpURLConnection? = null
            val resolvedUrl = try {
                connection = (com.rescue.alert.network.PublicDataGateway.open(URL(API_DETAIL_URL)) as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4")
                }
                val payload = JSONObject().apply { put("radio", station.id) }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

                if (connection.responseCode == 200) {
                    val resp = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val json = JSONObject(resp)
                    val url = json.optString("stream_url", "").trim()
                    if (url.isNotBlank()) {
                        streamUrlCache[station.id] = url
                        station.streamUrl = url
                        url
                    } else null
                } else null
            } catch (e: Exception) {
                Log.w(TAG, "Error fetching detail for station ${station.id}: ${e.message}")
                null
            } finally {
                connection?.disconnect()
            }

            Handler(Looper.getMainLooper()).post { callback(resolvedUrl ?: cached) }
        }, "prd-radio-detail").start()
    }
}
