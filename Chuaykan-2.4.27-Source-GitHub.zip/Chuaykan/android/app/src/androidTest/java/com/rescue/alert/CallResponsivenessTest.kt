package com.rescue.alert

import android.os.Handler
import android.os.Looper
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.bluetooth.BluetoothMeshManager
import com.rescue.alert.network.InternetAnnouncementClient
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Blocking transports are test fixtures only; these tests send no network packets. */
@RunWith(AndroidJUnit4::class)
class CallResponsivenessTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()

    @Test fun microphoneStopReturnsPromptlyAndReleasesNativeRecorder() {
        val context = instrumentation.targetContext
        @Suppress("DEPRECATION")
        val bluetooth = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        org.junit.Assume.assumeTrue("Microphone-only test requires Bluetooth disabled", bluetooth?.isEnabled != true)
        org.junit.Assume.assumeTrue(androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
        val mesh = BluetoothMeshManager.getInstance(context)
        val recorderField = mesh.javaClass.getDeclaredField("audioRecord").apply { isAccessible = true }
        try {
            repeat(5) {
                instrumentation.runOnMainSync { mesh.startPttTransmission("LOCAL_MIC_TEST", false) }
                var recorder: android.media.AudioRecord? = null
                val startDeadline = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < startDeadline) {
                    recorder = recorderField.get(mesh) as? android.media.AudioRecord
                    if (recorder?.recordingState == android.media.AudioRecord.RECORDSTATE_RECORDING) break
                    Thread.sleep(20)
                }
                val native = requireNotNull(recorder)
                assertEquals(android.media.AudioRecord.RECORDSTATE_RECORDING, native.recordingState)
                val stopped = CountDownLatch(1)
                Handler(Looper.getMainLooper()).post { mesh.stopPttTransmission(); stopped.countDown() }
                assertTrue("Microphone stop blocked UI", stopped.await(500, TimeUnit.MILLISECONDS))
                val releaseDeadline = System.currentTimeMillis() + 3000
                while (native.state != android.media.AudioRecord.STATE_UNINITIALIZED &&
                    System.currentTimeMillis() < releaseDeadline) Thread.sleep(20)
                assertEquals("Native recorder leaked", android.media.AudioRecord.STATE_UNINITIALIZED, native.state)
            }
        } finally { instrumentation.runOnMainSync { mesh.stopPttTransmission() } }
    }

    @Test fun blockedTransportDoesNotBlockUiOrReorderControls() {
        val gate = CountDownLatch(1)
        val started = CountDownLatch(1)
        val done = CountDownLatch(2)
        val order = java.util.Collections.synchronizedList(mutableListOf<Int>())
        try {
            instrumentation.runOnMainSync {
                BluetoothMeshManager.dispatchTransportWrite {
                    assertNotEquals(Looper.getMainLooper(), Looper.myLooper())
                    started.countDown()
                    gate.await(3, TimeUnit.SECONDS)
                    order.add(1); done.countDown()
                }
                BluetoothMeshManager.dispatchTransportWrite { order.add(2); done.countDown() }
            }
            assertTrue(started.await(1, TimeUnit.SECONDS))
            val ui = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post { ui.countDown() }
            assertTrue("UI stalled behind transport", ui.await(500, TimeUnit.MILLISECONDS))
        } finally { gate.countDown() }
        assertTrue(done.await(2, TimeUnit.SECONDS))
        assertEquals(listOf(1, 2), order)
    }

    @Test fun stalledWriteTimesOutAndFollowingWriteCanProceed() {
        val released = CountDownLatch(1)
        val timedOut = AtomicBoolean(false)
        BluetoothMeshManager.writeWithDeadline({ timedOut.set(true); released.countDown() }, 100L) {
            assertTrue(released.await(2, TimeUnit.SECONDS))
        }
        assertTrue(timedOut.get())
        val unexpectedTimeout = AtomicBoolean(false)
        BluetoothMeshManager.writeWithDeadline({ unexpectedTimeout.set(true) }, 100L) { }
        Thread.sleep(200)
        assertFalse("Completed write watchdog not cancelled", unexpectedTimeout.get())
    }

    @Test fun slowInternetKeepsVoiceQueueBoundedAndKeepsLatestFrame() {
        val executor = InternetAnnouncementClient.newVoiceExecutor()
        val gate = CountDownLatch(1)
        val started = CountDownLatch(1)
        val latest = CountDownLatch(1)
        try {
            executor.execute { started.countDown(); gate.await(3, TimeUnit.SECONDS) }
            assertTrue(started.await(1, TimeUnit.SECONDS))
            repeat(1000) { index ->
                executor.execute { if (index == 999) latest.countDown() }
                assertTrue(executor.queue.size <= 4)
            }
            gate.countDown()
            assertTrue(latest.await(2, TimeUnit.SECONDS))
        } finally { gate.countDown(); executor.shutdownNow() }
    }
}
