#!/usr/bin/env python3
"""
Data Models for Citizen SOS Reports and Disaster Zones
"""
from __future__ import annotations
import math
import time
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any

EARTH_RADIUS_KM = 6371.0

def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Calculate great-circle distance in kilometers between two GPS coordinates."""
    d_lat = math.radians(lat2 - lat1)
    d_lng = math.radians(lng2 - lng1)
    a = (math.sin(d_lat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lng / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return EARTH_RADIUS_KM * c


@dataclass
class DisasterZone:
    zone_id: str
    title: str
    hazard_type: str  # e.g. "FLOOD", "FLASH_FLOOD"
    severity: str    # "CRITICAL", "WARNING"
    center_lat: float
    center_lng: float
    radius_km: float
    instruction: str
    agency: str
    created_at: float = field(default_factory=time.time)
    is_active: bool = True

    def contains(self, lat: float, lng: float) -> bool:
        """Returns True if the GPS coordinate falls inside this disaster circle."""
        return haversine_km(self.center_lat, self.center_lng, lat, lng) <= self.radius_km

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SosCase:
    case_id: str
    device_id: str
    citizen_name: str
    phone_number: str
    latitude: Optional[float]
    longitude: Optional[float]
    accuracy_meters: float = 15.0
    member_count: int = 1
    is_bedridden: bool = False
    is_elderly: bool = False
    is_infant: bool = False
    urgent_needs: str = ""
    urgent_note: str = ""
    audio_file: Optional[str] = None  # Filename of saved .m4a/.wav
    audio_duration_sec: float = 0.0
    status: str = "PENDING"  # PENDING, DISPATCHED, RESCUED_SAFE
    created_at: float = field(default_factory=time.time)
    dispatched_at: Optional[float] = None
    rescued_at: Optional[float] = None
    assigned_team: str = ""
    photo_file: Optional[str] = None  # Filename of saved patient photo .jpg
    case_type: str = "CRITICAL"  # GENERAL waiting for rescue, or CRITICAL patient

    # Computed attributes
    distance_to_epicenter_km: Optional[float] = None
    is_in_danger_zone: bool = False

    def update_zone_status(self, zone: Optional[DisasterZone | list[DisasterZone]]) -> None:
        """Mark the SOS case as in danger when it is inside any active risk area."""
        if isinstance(zone, DisasterZone):
            zones = [zone]
        else:
            zones = [item for item in (zone or []) if item is not None and item.is_active]

        if self.latitude is None or self.longitude is None or not zones:
            self.distance_to_epicenter_km = None
            self.is_in_danger_zone = False
            return

        distances = [
            haversine_km(item.center_lat, item.center_lng, self.latitude, self.longitude)
            for item in zones
        ]
        self.distance_to_epicenter_km = round(min(distances), 2)
        self.is_in_danger_zone = any(
            distance <= item.radius_km for distance, item in zip(distances, zones)
        )

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if not d.get("photo_file"):
            try:
                import re
                from src.core.config import RECORDINGS_DIR
                safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", self.case_id)
                candidate = f"patient_{safe_id}.jpg"
                if (RECORDINGS_DIR / candidate).exists():
                    d["photo_file"] = candidate
                    self.photo_file = candidate
            except Exception:
                pass
        return d


@dataclass
class EvacuationSite:
    site_id: str
    name: str
    site_type: str  # "SHELTER" (ศูนย์พักพิง/อพยพ), "PARKING" (จุดจอดรถปลอดภัย), "RELIEF" (ศูนย์ช่วยเหลือ/ปฐมพยาบาล)
    latitude: float
    longitude: float
    capacity: int = 100  # Number of people or cars
    contact_phone: str = ""
    notes: str = ""
    is_active: bool = True
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

