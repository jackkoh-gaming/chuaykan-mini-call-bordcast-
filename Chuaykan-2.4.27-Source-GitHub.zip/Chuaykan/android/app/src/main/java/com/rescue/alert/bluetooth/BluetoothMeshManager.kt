package com.rescue.alert.bluetooth

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import com.rescue.alert.model.MeshNode
import com.rescue.alert.model.MeshNodeType
import com.rescue.alert.model.MeshVoicePacket
import java.io.InputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import java.util.Collections
import java.util.LinkedHashSet
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.sin

/**
 * Manages Bluetooth Mesh communication, multi-hop relay networking,
 * and genuine peer-to-peer audio Walkie-Talkie / voice calling between neighboring devices
 * during disasters when internet and cellular towers are disrupted.
 *
 * AUTHENTIC BLUETOOTH TRANSPORT ARCHITECTURE:
 * 1. Dedicated 128-bit Service UUID: 16690000-fa01-2026-8a8c-2c50f1587bfc
 * 2. Dedicated 128-bit Characteristic UUID: 16690001-fa01-2026-8a8c-2c50f1587bfc
 * 3. Dynamic Real BLE Scan & Discovery: Nodes are discovered dynamically from real nearby devices.
 * 4. Dual Real Transport:
 *    - BLE GATT Server / Client characteristic writes for control & packet transport.
 *    - Unpaired RFCOMM Sockets (SPP) for high-bandwidth, low-latency live PCM audio streaming.
 * 5. Authentic Multi-Hop Flooding: Forwards received packets with TTL decrement to neighbor nodes.
 * 6. Nodes and audio are created only from Bluetooth discovery and received packets.
 */
class BluetoothMeshManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothMeshManager"
        const val SAMPLE_RATE = 8000 // 8kHz PCM Mono - minimal memory & CPU footprint for Android Go
        private const val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
        private const val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_FACTOR = 2

        // Dedicated App-Exclusive Service & Characteristic UUIDs
        val RESCUE_MESH_SERVICE_UUID: UUID = UUID.fromString("16690000-fa01-2026-8a8c-2c50f1587bfc")
        val RESCUE_MESH_CHAR_UUID: UUID = UUID.fromString("16690001-fa01-2026-8a8c-2c50f1587bfc")
        val RESCUE_RFCOMM_UUID: UUID = UUID.fromString("16690002-fa01-2026-8a8c-2c50f1587bfc")
        const val APP_PROTOCOL_MAGIC = "RESCUE_ALERT_THAI_DISASTER_MESH_v2"
        private const val HEADER_MAGIC_INT = 0x54484149 // "THAI" in ASCII

        // App-Only Discovery Handshake Beacon (must match desktop bluetooth_mesh_service.py)
        // Both mobile and desktop MUST embed this prefix in BLE Service Data.
        // Devices without this beacon are invisible to each other.
        val APP_HANDSHAKE_BEACON: ByteArray = "RA_APP_v2".toByteArray(Charsets.UTF_8)

        const val EOC_GATEWAY_NAME = "RescueAlert-EOC-Gateway"
        const val EOC_GATEWAY_NODE_ID = "EOC_GATEWAY_HQ"
        const val EOC_GATEWAY_DISPLAY_NAME = "ศูนย์สั่งการ EOC (RescueAlert-EOC-Gateway)"

        const val NOTIF_ID_OFFICER_ANNOUNCEMENT = 20265
        const val CHANNEL_ID_OFFICER_ANNOUNCEMENT = "rescue_officer_announcement_channel"

        const val NOTIF_ID_OFFICER_CALL = 20266
        const val CHANNEL_ID_OFFICER_CALL = "rescue_officer_call_channel"

        const val ACTION_ANSWER_CALL = "com.rescue.alert.ACTION_ANSWER_CALL"
        const val ACTION_DECLINE_CALL = "com.rescue.alert.ACTION_DECLINE_CALL"
        const val ACTION_HANGUP_CALL = "com.rescue.alert.ACTION_HANGUP_CALL"
        const val EXTRA_CALLER_NAME = "com.rescue.alert.EXTRA_CALLER_NAME"
        const val EXTRA_CALLER_NODE_ID = "com.rescue.alert.EXTRA_CALLER_NODE_ID"

        @Volatile
        private var instance: BluetoothMeshManager? = null

        fun getInstance(context: Context): BluetoothMeshManager {
            return instance ?: synchronized(this) {
                instance ?: BluetoothMeshManager(context.applicationContext).also { instance = it }
            }
        }

        private val uiTransportExecutor = Executors.newSingleThreadExecutor { task ->
            Thread(task, "mesh-control-io")
        }
        private val writeTimeoutExecutor = Executors.newSingleThreadScheduledExecutor()

        internal fun dispatchTransportWrite(task: () -> Unit) {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                uiTransportExecutor.execute(task)
            } else task()
        }

        internal fun writeWithDeadline(timeout: () -> Unit, timeoutMs: Long = 5000L, write: () -> Unit) {
            val watchdog = writeTimeoutExecutor.schedule({ timeout() }, timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            try { write() } finally { watchdog.cancel(false) }
        }

        internal fun serializePacket(packet: MeshVoicePacket): ByteArray? {
            return try {
                val audioBytes = packet.audioData
                // F-04: Enforce max 65535 bytes to prevent 16-bit integer wrap
                if (audioBytes.size > 65535) {
                    Log.e(TAG, "serializePacket rejected: audio length (${audioBytes.size}) exceeds 16-bit max (65535)")
                    return null
                }

                val pidBytes = packet.packetId.toByteArray(Charsets.UTF_8)
                val srcBytes = packet.sourceNodeId.toByteArray(Charsets.UTF_8)
                val nameBytes = packet.sourceHouseName.toByteArray(Charsets.UTF_8)
                val tgtBytes = packet.targetNodeId.toByteArray(Charsets.UTF_8)
                if (listOf(pidBytes, srcBytes, nameBytes, tgtBytes).any { it.size > 255 } ||
                    packet.hopCount !in 0..255 || packet.ttl !in 1..255) return null

                // F-17: Header is exactly 13 bytes (4 magic + 1 hop + 1 ttl + 1 isSos + 4 lens + 2 audioLen = 13)
                val buf = ByteBuffer.allocate(13 + pidBytes.size + srcBytes.size + nameBytes.size + tgtBytes.size + audioBytes.size)
                buf.putInt(HEADER_MAGIC_INT)
                buf.put(packet.hopCount.toByte())
                buf.put(packet.ttl.toByte())
                buf.put(if (packet.isSosEmergency) 1.toByte() else 0.toByte())
                buf.put(pidBytes.size.toByte())
                buf.put(srcBytes.size.toByte())
                buf.put(nameBytes.size.toByte())
                buf.put(tgtBytes.size.toByte())
                buf.putShort(audioBytes.size.toShort())

                buf.put(pidBytes)
                buf.put(srcBytes)
                buf.put(nameBytes)
                buf.put(tgtBytes)
                buf.put(audioBytes)

                buf.array()
            } catch (e: Exception) {
                null
            }
        }

        internal fun parsePacket(bytes: ByteArray): MeshVoicePacket? {
            if (bytes.size < 13) return null
            return try {
                val buf = ByteBuffer.wrap(bytes)
                val magic = buf.int
                if (magic != HEADER_MAGIC_INT) return null

                val hopCount = buf.get().toInt() and 0xFF
                val ttl = buf.get().toInt() and 0xFF
                if (ttl == 0) return null
                val isSos = buf.get().toInt() == 1
                val pidLen = buf.get().toInt() and 0xFF
                val srcLen = buf.get().toInt() and 0xFF
                val nameLen = buf.get().toInt() and 0xFF
                val tgtLen = buf.get().toInt() and 0xFF
                val audioLen = buf.short.toInt() and 0xFFFF

                if (buf.remaining() != (pidLen + srcLen + nameLen + tgtLen + audioLen)) return null

                val pidBytes = ByteArray(pidLen)
                buf.get(pidBytes)
                val srcBytes = ByteArray(srcLen)
                buf.get(srcBytes)
                val nameBytes = ByteArray(nameLen)
                buf.get(nameBytes)
                val tgtBytes = ByteArray(tgtLen)
                buf.get(tgtBytes)
                val audioBytes = ByteArray(audioLen)
                buf.get(audioBytes)

                val packetId = String(pidBytes, Charsets.UTF_8).ifBlank { "${String(srcBytes, Charsets.UTF_8)}_${System.currentTimeMillis()}" }
                val srcNodeId = String(srcBytes, Charsets.UTF_8)
                val srcHouseName = String(nameBytes, Charsets.UTF_8)
                val tgtNodeId = String(tgtBytes, Charsets.UTF_8)

                MeshVoicePacket(
                    packetId = packetId,
                    sourceNodeId = srcNodeId,
                    sourceHouseName = srcHouseName,
                    targetNodeId = tgtNodeId,
                    hopCount = hopCount,
                    ttl = ttl,
                    isSosEmergency = isSos,
                    audioData = audioBytes
                )
            } catch (e: Exception) {
                null
            }
        }

        fun generateRandomNodeId(): String {
            val randomHex = java.util.UUID.randomUUID().toString().replace("-", "").take(6).uppercase()
            return "NODE_$randomHex"
        }

        /**
         * Computes distance from RSSI using standard log-distance path loss model (F-09).
         */
        fun calculateLogDistance(rssi: Int, txPower: Int = -59, n: Double = 2.5): Int {
            if (rssi == 0) return 10
            return try {
                val ratio = (txPower - rssi) / (10.0 * n)
                val dist = Math.pow(10.0, ratio)
                Math.max(1, Math.min(100, Math.round(dist).toInt()))
            } catch (e: Exception) {
                10
            }
        }
    }

    // Node identity (F-11: Persistent random 6-char UUID avoids collision across same phone models)
    val myNodeId: String = run {
        val prefs = context.getSharedPreferences("mesh_node_identity_prefs", Context.MODE_PRIVATE)
        val existing = prefs.getString("persistent_node_id", null)
        if (!existing.isNullOrBlank()) {
            existing
        } else {
            val newId = generateRandomNodeId()
            prefs.edit().putString("persistent_node_id", newId).apply()
            newId
        }
    }
    val myHouseName: String = "เครื่องของคุณ (${Build.MODEL})"

    /**
     * Reads real device battery percentage from Android BatteryManager (F-10).
     */
    fun getDeviceBatteryPercent(): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
            val cap = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            if (cap in 0..100) return cap
            val filter = android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter)
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) (level * 100) / scale else -1
        } catch (e: Exception) {
            -1
        }
    }

    /**
     * Computes distance from RSSI using standard log-distance path loss model (F-09).
     */
    fun calculateLogDistance(rssi: Int, txPower: Int = -59, n: Double = 2.5): Int {
        return Companion.calculateLogDistance(rssi, txPower, n)
    }

    // State
    private val isTransmitting = AtomicBoolean(false)
    private val isInCall = AtomicBoolean(false)
    private var activeCallNode: MeshNode? = null
    @Volatile private var awaitingCallAnswer = false
    private var activeScanCallback: ScanCallback? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // Mesh Nodes List & Cache
    private val meshNodes = mutableListOf<MeshNode>()
    private val processedPacketCache = Collections.synchronizedSet(LinkedHashSet<String>())
    private val gattReassemblyBuffers = ConcurrentHashMap<String, MutableMap<Int, ByteArray>>()
    private val gattReassemblyTimestamps = ConcurrentHashMap<String, Long>()

    // P-1: MTU tracking and async GATT transmission
    private val deviceMtuMap = ConcurrentHashMap<String, Int>()
    private val packetSeqCounter = AtomicInteger(0)
    private val gattSendExecutor = Executors.newSingleThreadExecutor()

    private fun handleGattIncomingBytes(deviceAddress: String, value: ByteArray) {
        if (value.isEmpty()) return

        val now = System.currentTimeMillis()
        // Prune stale reassembly buffers (> 10 sec) to prevent memory leak (HIGH-5)
        val staleIter = gattReassemblyTimestamps.entries.iterator()
        while (staleIter.hasNext()) {
            val entry = staleIter.next()
            if (now - entry.value > 10_000L) {
                gattReassemblyBuffers.remove(entry.key)
                staleIter.remove()
            }
        }

        if (value.size >= 4 && value[0] == 0xAA.toByte()) {
            val seqId = value[1].toInt() and 0xFF
            val chunkIdx = value[2].toInt() and 0xFF
            val totalChunks = value[3].toInt() and 0xFF
            val chunkData = if (value.size > 4) value.copyOfRange(4, value.size) else ByteArray(0)

            // P-1: When MTU 517 is active, entire packet arrives in 1 chunk - process immediately with 0 buffering
            if (totalChunks <= 1) {
                processIncomingPacketBytes(chunkData)
                return
            }

            // Sequence-isolated reassembly buffer prevents interleaving packet corruption (P-1)
            val bufferKey = "$deviceAddress-$seqId"
            gattReassemblyTimestamps[bufferKey] = now
            val devMap = gattReassemblyBuffers.getOrPut(bufferKey) { ConcurrentHashMap() }
            devMap[chunkIdx] = chunkData

            // F-12: Ensure every chunk index from 0 until totalChunks is present
            val hasAllChunks = (0 until totalChunks).all { devMap.containsKey(it) }
            if (hasAllChunks) {
                var totalBytes = 0
                for (i in 0 until totalChunks) {
                    totalBytes += devMap[i]?.size ?: 0
                }
                val fullPacket = ByteBuffer.allocate(totalBytes)
                for (i in 0 until totalChunks) {
                    devMap[i]?.let { fullPacket.put(it) }
                }
                gattReassemblyBuffers.remove(bufferKey)
                gattReassemblyTimestamps.remove(bufferKey)
                processIncomingPacketBytes(fullPacket.array())
            }
        } else {
            processIncomingPacketBytes(value)
        }
    }

    // Bluetooth Hardware & Connections
    private val bluetoothManager: BluetoothManager? by lazy {
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    }
    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        bluetoothManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
    }

    // GATT Server & Connected Clients
    private var gattServer: BluetoothGattServer? = null
    private val connectedGattDevices = java.util.Collections.newSetFromMap(ConcurrentHashMap<BluetoothDevice, Boolean>())
    private val activeGattClients = ConcurrentHashMap<String, BluetoothGatt>()

    // RFCOMM Socket Server & Connected Client Sockets for Continuous Voice Streaming
    private var rfcommServerSocket: BluetoothServerSocket? = null
    private val activeRfcommSockets = ConcurrentHashMap<String, BluetoothSocket>()
    private val connectingAddresses = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val lastConnectAttempt = ConcurrentHashMap<String, Long>()
    private var isRfcommServerRunning = AtomicBoolean(false)

    // SOS Pending Queue for delayed retransmission when peers connect (Doc 1 Item 4)
    private val pendingSosPackets = mutableListOf<MeshVoicePacket>()

    private fun flushPendingSosPackets() {
        val packetsToSend = synchronized(pendingSosPackets) {
            val list = pendingSosPackets.toList()
            pendingSosPackets.clear()
            list
        }
        if (packetsToSend.isNotEmpty()) {
            Thread {
                for (pkt in packetsToSend) {
                    broadcastPacketOverBluetooth(pkt)
                }
                mainHandler.post {
                    onMeshLogMessage?.invoke("ส่งสัญญาณ SOS ที่ค้างอยู่ (${packetsToSend.size} ฉบับ) ไปยังอุปกรณ์ที่เชื่อมต่อใหม่เรียบร้อย")
                }
            }.start()
        }
    }

    // Audio components
    private val audioRecordLock = Any()
    @Volatile private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var recordingThread: Thread? = null
    private var callReceivedBytes = 0L
    private val recordBufferSize: Int

    // Listeners
    var onMeshNodesUpdated: ((List<MeshNode>) -> Unit)? = null
    var onTransmissionStateChanged: ((Boolean, String) -> Unit)? = null
    var onAudioLevelChanged: ((Int) -> Unit)? = null
    var onIncomingVoiceReceived: ((sourceName: String, hopCount: Int, isSos: Boolean) -> Unit)? = null
    var onMeshLogMessage: ((String) -> Unit)? = null
    var onOfficerAnnouncementStateChanged: ((isAnnouncing: Boolean, sourceName: String) -> Unit)? = null
    var onIncomingCallReceived: ((callerName: String, callerNodeId: String) -> Unit)? = null
    var onCallStateChanged: ((isInCall: Boolean, callerName: String, callerNodeId: String) -> Unit)? = null

    @Volatile private var officerPosition: org.json.JSONObject? = null
    fun getOfficerPosition(): org.json.JSONObject? = officerPosition?.takeIf {
        System.currentTimeMillis() - it.optLong("timestamp") in 0L..30_000L
    }

    fun queryGeneralSos(caseId: String) {
        val payload = org.json.JSONObject().put("case_id", caseId).toString().toByteArray(Charsets.UTF_8)
        broadcastPacketOverBluetooth(MeshVoicePacket(
            packetId = "SOS_STATUS_QUERY_${myNodeId}_${System.currentTimeMillis()}", sourceNodeId = myNodeId,
            sourceHouseName = myHouseName, targetNodeId = EOC_GATEWAY_NODE_ID,
            hopCount = 0, ttl = 5, audioData = payload))
    }

    fun sendGeneralSos(payload: org.json.JSONObject) {
        val bytes = payload.toString().toByteArray(Charsets.UTF_8)
        require(bytes.size <= 32000) { "SOS profile is too large" }
        broadcastPacketOverBluetooth(MeshVoicePacket(
            packetId = "SOS_PROFILE_${myNodeId}_${System.currentTimeMillis()}", sourceNodeId = myNodeId,
            sourceHouseName = payload.optString("contact_name", myHouseName),
            targetNodeId = EOC_GATEWAY_NODE_ID, hopCount = 0, ttl = 5,
            audioData = bytes, isSosEmergency = true))
    }

    private var isOfficerAnnouncing: Boolean = false
    private val announcementWatchdogHandler = Handler(Looper.getMainLooper())
    private var announcementWatchdogRunnable: Runnable? = null

    private val isIncomingCall = AtomicBoolean(false)
    private var incomingCallerName: String = ""
    private var incomingCallerNodeId: String = ""
    private var incomingCallWatchdogRunnable: Runnable? = null
    private val incomingCallWatchdogHandler = Handler(Looper.getMainLooper())
    private var incomingCallRingtone: android.media.Ringtone? = null
    private var incomingCallVibrator: android.os.Vibrator? = context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
    @Volatile private var lastHangupTimestamp: Long = 0L
    @Volatile private var lastHangupPeerId: String = ""

    init {
        val minRecordBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, AUDIO_FORMAT)
        recordBufferSize = if (minRecordBuf > 0) minRecordBuf * BUFFER_FACTOR else 1024

        initAudioTrack()
        ensureServersStarted()
        startPruningLoop()
    }

    /**
     * Ensures both GATT Server and RFCOMM Server are started (F-01).
     * Safe to call repeatedly (idempotent). Called after Bluetooth permissions are granted.
     */
    @Synchronized
    fun ensureServersStarted() {
        if (!hasBluetoothPermissions()) return
        if (gattServer == null) {
            initGattServer()
        }
        if (!isRfcommServerRunning.get()) {
            startRfcommServer()
        }
    }

    /**
     * Starts all Bluetooth Mesh services (servers, advertising, and scanning) in one call.
     */
    @Synchronized
    fun startBleMeshServices() {
        ensureServersStarted()
        startBleMeshAdvertising()
        startBleMeshScan()
    }

    fun getNodes(maxAgeMs: Long = 15_000L): List<MeshNode> = synchronized(meshNodes) {
        val now = System.currentTimeMillis()
        meshNodes.removeAll { (now - it.lastSeenMs) > maxAgeMs && activeRfcommSockets[it.deviceAddress]?.isConnected != true }
        ArrayList(meshNodes)
    }

    fun clearNodes() {
        synchronized(meshNodes) {
            meshNodes.clear()
        }
        mainHandler.post {
            onMeshNodesUpdated?.invoke(emptyList())
        }
    }

    private val pruningRunnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            var changed = false
            synchronized(meshNodes) {
                val before = meshNodes.size
                meshNodes.removeAll { (now - it.lastSeenMs) > 15_000L && activeRfcommSockets[it.deviceAddress]?.isConnected != true }
                changed = (meshNodes.size != before)
            }
            if (changed) {
                mainHandler.post {
                    onMeshNodesUpdated?.invoke(getNodes())
                }
            }
            com.rescue.alert.data.GeneralSosOutbox.retry(context)
            mainHandler.postDelayed(this, 1500L)
        }
    }

    private fun startPruningLoop() {
        mainHandler.removeCallbacks(pruningRunnable)
        mainHandler.postDelayed(pruningRunnable, 1500L)
    }

    private fun initAudioTrack() {
        try {
            val minPlayBuf = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, AUDIO_FORMAT)
            val playBufSize = if (minPlayBuf > 0) minPlayBuf * 2 else 2048

            audioTrack = AudioTrack(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_OUT)
                        .build(),
                playBufSize, AudioTrack.MODE_STREAM, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
            )

            audioTrack?.play()
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack init error", e)
        }
    }

    /**
     * Set up local BLE GATT Server to accept incoming packet writes from other devices
     */
    private fun initGattServer() {
        if (!hasBluetoothPermissions()) return
        try {
            gattServer = bluetoothManager?.openGattServer(context, object : BluetoothGattServerCallback() {
                override fun onConnectionStateChange(device: BluetoothDevice?, status: Int, newState: Int) {
                    device ?: return
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        connectedGattDevices.add(device)
                        mainHandler.post {
                            onMeshLogMessage?.invoke("อุปกรณ์เชื่อมต่อ GATT: ${device.name ?: device.address}")
                        }
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        connectedGattDevices.remove(device)
                    }
                }

                override fun onCharacteristicWriteRequest(
                    device: BluetoothDevice?,
                    requestId: Int,
                    characteristic: BluetoothGattCharacteristic?,
                    preparedWrite: Boolean,
                    responseNeeded: Boolean,
                    offset: Int,
                    value: ByteArray?
                ) {
                    if (responseNeeded) {
                        try {
                            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
                        } catch (e: SecurityException) {}
                    }
                    if (value != null && value.isNotEmpty()) {
                        val devAddr = device?.address ?: "UNKNOWN"
                        handleGattIncomingBytes(devAddr, value)
                    }
                }
            })

            val service = BluetoothGattService(RESCUE_MESH_SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            val charWrite = BluetoothGattCharacteristic(
                RESCUE_MESH_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or
                        BluetoothGattCharacteristic.PROPERTY_WRITE or
                        BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_WRITE or BluetoothGattCharacteristic.PERMISSION_READ
            )
            service.addCharacteristic(charWrite)
            gattServer?.addService(service)
            Log.i(TAG, "GATT Server initialized with Service UUID: $RESCUE_MESH_SERVICE_UUID")
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException initializing GATT Server", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing GATT Server", e)
        }
    }

    /**
     * Start background RFCOMM listener for live audio stream connections
     */
    private fun startRfcommServer() {
        if (!hasBluetoothPermissions() || isRfcommServerRunning.get()) return
        Thread {
            try {
                isRfcommServerRunning.set(true)
                rfcommServerSocket = bluetoothAdapter?.listenUsingInsecureRfcommWithServiceRecord(
                    "RescueAlertVoiceMesh",
                    RESCUE_RFCOMM_UUID
                )
                Log.i(TAG, "RFCOMM Server listening on UUID: $RESCUE_RFCOMM_UUID")

                while (isRfcommServerRunning.get()) {
                    val socket = try {
                        rfcommServerSocket?.accept()
                    } catch (e: Exception) {
                        null
                    } ?: break

                    val remoteDev = socket.remoteDevice
                    val devKey = remoteDev.address
                    activeRfcommSockets[devKey] = socket
                    flushPendingSosPackets()
                    mainHandler.post {
                        onMeshLogMessage?.invoke("เชื่อมต่อช่องสัญญาณเสียงตรงกับ: ${remoteDev.name ?: devKey}")
                    }

                    // Start socket reading loop in dedicated thread
                    Thread {
                        handleIncomingRfcommSocket(socket, devKey)
                    }.start()
                }
            } catch (e: SecurityException) {
                Log.w(TAG, "SecurityException starting RFCOMM server", e)
            } catch (e: Exception) {
                Log.e(TAG, "RFCOMM server error", e)
            } finally {
                isRfcommServerRunning.set(false)
            }
        }.start()
    }

    private fun handleIncomingRfcommSocket(socket: BluetoothSocket, devKey: String) {
        val inStream = DataInputStream(socket.inputStream)
        try {
            while (socket.isConnected) {
                val magic = inStream.readInt()
                if (magic == 0x52455343) { // "RESC": peer's exact protocol handshake.
                    val expected = (APP_PROTOCOL_MAGIC.substring(4) + "\u0000").toByteArray(Charsets.UTF_8)
                    val received = ByteArray(expected.size)
                    inStream.readFully(received)
                    if (!received.contentEquals(expected)) throw IOException("Invalid mesh handshake")
                    continue
                }
                val payloadLen = inStream.readInt()
                if (magic != HEADER_MAGIC_INT || payloadLen !in 1..66568) throw IOException("Invalid mesh frame")
                val payloadBuf = ByteArray(payloadLen)
                inStream.readFully(payloadBuf)
                processIncomingPacketBytes(payloadBuf, incomingSocketKey = devKey)
            }
        } catch (e: Exception) {
            Log.w(TAG, "RFCOMM socket read ended: ${e.message}")
        } finally {
            activeRfcommSockets.remove(devKey, socket)
            try { socket.close() } catch (e: Exception) {}
            if (activeRfcommSockets.isEmpty() && (isInCall.get() || isIncomingCall.get())) {
                val peerId = activeCallNode?.nodeId ?: incomingCallerNodeId
                val peerName = activeCallNode?.houseName ?: incomingCallerName
                mainHandler.post { handleOfficerCallEnded(peerId, peerName) }
            }
        }
    }

    /**
     * Start Push-to-Talk (PTT) voice transmission through the mesh network
     */
    fun startPttTransmission(targetNodeId: String = "BROADCAST", isEmergency: Boolean = false) {
        if (isTransmitting.get()) return

        if (!hasAudioPermission()) {
            onMeshLogMessage?.invoke("ข้อผิดพลาด: ยังไม่ได้รับสิทธิ์บันทึกเสียง (RECORD_AUDIO)")
            return
        }

        isTransmitting.set(true)
        playTone(frequencyHz = 880, durationMs = 100) // Tactical Mic Click Chime

        val statusText = if (isEmergency) {
            "บรอดแคสต์เสียงเตือนภัยฉุกเฉิน (SOS) ข้ามบลูทูธ..."
        } else {
            val targetDesc = if (targetNodeId == "BROADCAST") "ทุกอุปกรณ์ในระยะบลูทูธ" else targetNodeId
            "กำลังส่งสัญญาณเสียงไปยัง $targetDesc..."
        }
        onTransmissionStateChanged?.invoke(true, statusText)

        startRecordingLoop(targetNodeId, isEmergency)
    }

    /**
     * Stop PTT voice transmission and broadcast "over" roger beep
     */
    fun stopPttTransmission() {
        if (!isTransmitting.get()) return
        isTransmitting.set(false)

        recordingThread?.interrupt()
        recordingThread = null

        val recorder = synchronized(audioRecordLock) {
            audioRecord.also { audioRecord = null }
        }
        // Native microphone stop may wait for a read; keep that wait off the UI.
        if (recorder != null) Thread({
            try { synchronized(recorder) { recorder.stop() } }
            catch (e: Exception) { Log.w(TAG, "Error stopping AudioRecord", e) }
        }, "mesh-mic-stop").start()

        playTone(frequencyHz = 550, durationMs = 120) // Tactical Roger Beep
        onTransmissionStateChanged?.invoke(false, "สแตนด์บายรับฟังเครือข่ายบลูทูธ (IDLE)")
        onAudioLevelChanged?.invoke(0)

        val nodeCount = getNodes().size
        if (nodeCount > 0) {
            onMeshLogMessage?.invoke("ส่งสัญญาณเสียงสำเร็จ กระจายสู่ $nodeCount โหนดในระยะ")
        } else {
            onMeshLogMessage?.invoke("ส่งสัญญาณเสียงออกช่องสัญญาณบลูทูธแล้ว (กำลังรอโหนดปลายทางตอบรับ)")
        }
    }

    /**
     * Start continuous two-way call with a specific neighbor node
     */
    fun startDirectCall(targetNode: MeshNode) {
        if (isInCall.get() || isIncomingCall.get()) return
        if (activeRfcommSockets.values.none { it.isConnected }) {
            onMeshLogMessage?.invoke("ยังไม่มีช่องเสียง Bluetooth ที่เชื่อมต่อสำเร็จ กรุณารอการเชื่อมต่อแล้วโทรอีกครั้ง")
            return
        }
        if (!hasAudioPermission()) {
            onMeshLogMessage?.invoke("กรุณาอนุญาตไมโครโฟนก่อนโทร")
            return
        }
        isInCall.set(true)
        activeCallNode = targetNode
        awaitingCallAnswer = true

        playTone(frequencyHz = 1050, durationMs = 150)
        onTransmissionStateChanged?.invoke(false, "กำลังรอ ${targetNode.houseName} รับสาย")
        onMeshLogMessage?.invoke("กำลังโทรหา ${targetNode.houseName} • รอปลายทางรับสาย")

        showActiveCallNotification(targetNode.houseName, targetNode.nodeId)

        // Send Wire packet EOC_CALL_REQUEST to start call
        val callReqPacket = MeshVoicePacket(
            packetId = "EOC_CALL_REQUEST_${System.currentTimeMillis()}",
            sourceNodeId = myNodeId,
            sourceHouseName = myHouseName,
            targetNodeId = targetNode.nodeId,
            hopCount = 0,
            ttl = 3,
            isSosEmergency = false,
            audioData = ByteArray(0)
        )
        broadcastPacketOverBluetooth(callReqPacket)

        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        incomingCallWatchdogRunnable = Runnable {
            if (awaitingCallAnswer && isInCall.get()) {
                hangupCurrentCall()
                onMeshLogMessage?.invoke("ปลายทางไม่รับสายหรือเชื่อมต่อไม่ได้ภายใน 30 วินาที")
            }
        }
        incomingCallWatchdogHandler.postDelayed(incomingCallWatchdogRunnable!!, 30_000L)
        mainHandler.post {
            onCallStateChanged?.invoke(true, targetNode.houseName, targetNode.nodeId)
        }
    }

    @Volatile private var callQueuePosition: Int? = null
    private var queueRefreshRunnable: Runnable? = null
    fun getCallQueuePosition(): Int? = callQueuePosition

    private fun stopQueueWaiting() {
        queueRefreshRunnable?.let { mainHandler.removeCallbacks(it) }
        queueRefreshRunnable = null
        callQueuePosition = null
    }

    fun handleCallQueuedByRemote(sourceNodeId: String, position: Int) {
        mainHandler.post {
            if (!isCallConnecting() || activeCallNode?.nodeId != sourceNodeId || position !in 0..50) return@post
            callQueuePosition = position
            incomingCallWatchdogRunnable?.let {
                incomingCallWatchdogHandler.removeCallbacks(it)
                incomingCallWatchdogHandler.postDelayed(it, 30_000L)
            }
            val status = if (position == 0) "ถึงคิวแล้ว • รอเจ้าหน้าที่รับสาย" else "กำลังรอคิวที่ $position"
            onTransmissionStateChanged?.invoke(false, status)
            showActiveCallNotification(activeCallNode?.houseName ?: "เจ้าหน้าที่", sourceNodeId)
            if (queueRefreshRunnable == null) {
                queueRefreshRunnable = object : Runnable {
                    override fun run() {
                        if (!isCallConnecting() || activeCallNode?.nodeId != sourceNodeId) return
                        broadcastPacketOverBluetooth(MeshVoicePacket(
                            packetId = "EOC_CALL_REQUEST_${System.nanoTime()}",
                            sourceNodeId = myNodeId, sourceHouseName = myHouseName,
                            targetNodeId = sourceNodeId, hopCount = 0, ttl = 3,
                            isSosEmergency = false, audioData = ByteArray(0)
                        ))
                        mainHandler.postDelayed(this, 10_000L)
                    }
                }
                mainHandler.postDelayed(queueRefreshRunnable!!, 10_000L)
            }
        }
    }

    fun endDirectCall() {
        hangupCurrentCall()
    }

    fun isIncomingCall(): Boolean = isIncomingCall.get()
    fun isInCall(): Boolean = isInCall.get()
    fun isCallConnecting(): Boolean = isInCall.get() && awaitingCallAnswer
    fun isTransmitting(): Boolean = isTransmitting.get()
    fun getActiveCallNode(): MeshNode? = activeCallNode
    fun getIncomingCallerName(): String = incomingCallerName
    fun getIncomingCallerNodeId(): String = incomingCallerNodeId

    fun handleIncomingOfficerCall(sourceNodeId: String, sourceHouseName: String) {
        if (isInCall.get() || isIncomingCall.get()) return
        val now = System.currentTimeMillis()
        if (sourceNodeId == lastHangupPeerId && (now - lastHangupTimestamp) < 3500L) {
            Log.i(TAG, "Suppressed duplicate incoming call request from $sourceNodeId (cooldown active)")
            return
        }
        val cleanName = if (sourceHouseName.isNotBlank()) sourceHouseName else "เจ้าหน้าที่ศูนย์สั่งการ EOC"
        isIncomingCall.set(true)
        incomingCallerName = cleanName
        incomingCallerNodeId = sourceNodeId

        startIncomingCallRingtone()
        showIncomingCallNotification(cleanName, sourceNodeId)

        mainHandler.post {
            onIncomingCallReceived?.invoke(cleanName, sourceNodeId)
            onMeshLogMessage?.invoke("[สายเรียกเข้า] มีสายเรียกเข้าจาก $cleanName (กรุณากดรับสายหรือวางสาย)")
        }

        // 30-second watchdog timer: If citizen does not answer or decline within 30s, stop ringing
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        incomingCallWatchdogRunnable = Runnable {
            if (isIncomingCall.get()) {
                Log.i(TAG, "Incoming call timed out after 30s")
                stopIncomingCallRingtone()
                hideOfficerCallNotification()
                isIncomingCall.set(false)
                mainHandler.post {
                    onCallStateChanged?.invoke(false, cleanName, sourceNodeId)
                    onMeshLogMessage?.invoke("[สายเรียกเข้า] ไม่ได้รับสายจาก $cleanName (หมดเวลา)")
                }
            }
        }
        incomingCallWatchdogHandler.postDelayed(incomingCallWatchdogRunnable!!, 30_000L)
    }

    fun answerIncomingCall(targetNodeId: String? = null, targetName: String? = null) {
        if (!isIncomingCall.get() || !hasAudioPermission()) return
        stopQueueWaiting()
        awaitingCallAnswer = false
        stopIncomingCallRingtone()
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        isIncomingCall.set(false)
        isInCall.set(true)
        callReceivedBytes = 0

        val callerId = targetNodeId ?: incomingCallerNodeId.ifBlank { EOC_GATEWAY_NODE_ID }
        val callerTitle = targetName ?: incomingCallerName.ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }

        showActiveCallNotification(callerTitle, callerId)

        // Send Wire packet EOC_CALL_ANSWER to notify officer desktop and network
        val answerPacket = MeshVoicePacket(
            packetId = "EOC_CALL_ANSWER_${System.currentTimeMillis()}",
            sourceNodeId = myNodeId,
            sourceHouseName = myHouseName,
            targetNodeId = callerId,
            hopCount = 0,
            ttl = 3,
            isSosEmergency = false,
            audioData = ByteArray(0)
        )
        broadcastPacketOverBluetooth(answerPacket)

        // Start continuous two-way audio recording & streaming
        startPttTransmission(callerId, false)

        mainHandler.post {
            onCallStateChanged?.invoke(true, callerTitle, callerId)
            onMeshLogMessage?.invoke("[รับสาย] รับสายเจ้าหน้าที่ $callerTitle แล้ว (เปิดช่องสนทนา 2 ทาง)")
        }
    }

    fun declineIncomingCall(targetNodeId: String? = null, targetName: String? = null) {
        stopIncomingCallRingtone()
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        isIncomingCall.set(false)
        hideOfficerCallNotification()

        val callerId = targetNodeId ?: incomingCallerNodeId.ifBlank { EOC_GATEWAY_NODE_ID }
        val callerTitle = targetName ?: incomingCallerName.ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
        lastHangupTimestamp = System.currentTimeMillis()
        lastHangupPeerId = callerId
        incomingCallerNodeId = ""
        incomingCallerName = ""

        // Send Wire packet EOC_CALL_DECLINE
        val declinePacket = MeshVoicePacket(
            packetId = "EOC_CALL_DECLINE_${System.currentTimeMillis()}",
            sourceNodeId = myNodeId,
            sourceHouseName = myHouseName,
            targetNodeId = callerId,
            hopCount = 0,
            ttl = 3,
            isSosEmergency = false,
            audioData = ByteArray(0)
        )
        broadcastPacketOverBluetooth(declinePacket)

        mainHandler.post {
            onCallStateChanged?.invoke(false, callerTitle, callerId)
            onMeshLogMessage?.invoke("[ปฏิเสธสาย] ปฏิเสธสายเรียกเข้าจาก $callerTitle")
        }
    }

    fun hangupCurrentCall() {
        stopQueueWaiting()
        stopIncomingCallRingtone()
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        val wasIncoming = isIncomingCall.getAndSet(false)
        stopQueueWaiting()
        awaitingCallAnswer = false

        val endedNode = activeCallNode
        val targetId = endedNode?.nodeId ?: incomingCallerNodeId.ifBlank { EOC_GATEWAY_NODE_ID }
        val callerTitle = endedNode?.houseName ?: incomingCallerName.ifBlank { "เจ้าหน้าที่ศูนย์สั่งการ EOC" }
        
        lastHangupTimestamp = System.currentTimeMillis()
        lastHangupPeerId = targetId

        // BUG FIX: Stop PTT transmission first so recording thread halts BEFORE isInCall is cleared
        stopPttTransmission()

        val wasInCall = isInCall.getAndSet(false)
        activeCallNode = null
        // BUG-15 FIX: Clear stale caller variables to prevent wrong info on next call
        incomingCallerNodeId = ""
        incomingCallerName = ""

        hideOfficerCallNotification()

        // BUG-14 FIX: Only send hangup packet and play tone if we were actually in a call
        if (!wasInCall && !wasIncoming) {
            return
        }
        playTone(frequencyHz = 400, durationMs = 200)

        // Send Wire packet EOC_CALL_HANGUP
        val hangupPacket = MeshVoicePacket(
            packetId = "EOC_CALL_HANGUP_${System.currentTimeMillis()}",
            sourceNodeId = myNodeId,
            sourceHouseName = myHouseName,
            targetNodeId = targetId,
            hopCount = 0,
            ttl = 3,
            isSosEmergency = false,
            audioData = ByteArray(0)
        )
        broadcastPacketOverBluetooth(hangupPacket)

        mainHandler.post {
            onCallStateChanged?.invoke(false, callerTitle, targetId)
            onTransmissionStateChanged?.invoke(false, "วางสายเรียบร้อยแล้ว")
            onMeshLogMessage?.invoke("[วางสาย] สิ้นสุดการสนทนากับ $callerTitle")
        }
    }

    fun handleOfficerCallEnded(sourceNodeId: String, sourceName: String) {
        val peerId = activeCallNode?.nodeId ?: incomingCallerNodeId
        if (sourceNodeId != peerId) return
        
        lastHangupTimestamp = System.currentTimeMillis()
        lastHangupPeerId = sourceNodeId

        stopQueueWaiting()
        awaitingCallAnswer = false
        stopIncomingCallRingtone()
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        
        // Stop audio transmission first before clearing call state
        stopPttTransmission()

        isIncomingCall.set(false)
        isInCall.set(false)
        activeCallNode = null
        // BUG-15 FIX: Clear stale caller variables
        incomingCallerNodeId = ""
        incomingCallerName = ""

        hideOfficerCallNotification()

        val cleanName = if (sourceName.isNotBlank()) sourceName else "เจ้าหน้าที่ศูนย์สั่งการ EOC"
        mainHandler.post {
            onCallStateChanged?.invoke(false, cleanName, sourceNodeId)
            onTransmissionStateChanged?.invoke(false, "เจ้าหน้าที่วางสายแล้ว")
            onMeshLogMessage?.invoke("[สายตัด] เจ้าหน้าที่ $cleanName วางสายแล้ว (สิ้นสุดการสนทนา)")
        }
    }

    fun handleCallAnsweredByRemote(sourceNodeId: String, sourceName: String) {
        if (!isInCall.get() || !awaitingCallAnswer || activeCallNode?.nodeId != sourceNodeId) return
        stopQueueWaiting()
        awaitingCallAnswer = false
        callReceivedBytes = 0
        incomingCallWatchdogRunnable?.let { incomingCallWatchdogHandler.removeCallbacks(it) }
        stopIncomingCallRingtone()
        isInCall.set(true)
        startPttTransmission(sourceNodeId, false)
        val cleanName = if (sourceName.isNotBlank()) sourceName else "ปลายสาย"
        showActiveCallNotification(cleanName, sourceNodeId)
        mainHandler.post {
            onCallStateChanged?.invoke(true, cleanName, sourceNodeId)
            onMeshLogMessage?.invoke("[เชื่อมต่อสาย] $cleanName ตอบรับสายแล้ว • กำลังสนทนาสด")
        }
    }

    fun handleCallDeclinedByRemote(sourceNodeId: String, sourceName: String) {
        handleOfficerCallEnded(sourceNodeId, sourceName)
        val cleanName = if (sourceName.isNotBlank()) sourceName else "ปลายสาย"
        mainHandler.post {
            onMeshLogMessage?.invoke("[สายถูกปฏิเสธ] $cleanName ปฏิเสธการรับสาย")
        }
    }

    private fun startIncomingCallRingtone() {
        try {
            stopIncomingCallRingtone()
            val ringtoneUri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            incomingCallRingtone = android.media.RingtoneManager.getRingtone(context, ringtoneUri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    isLooping = true
                }
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                play()
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                incomingCallVibrator?.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 1000, 1000), 0))
            } else {
                @Suppress("DEPRECATION")
                incomingCallVibrator?.vibrate(longArrayOf(0, 1000, 1000), 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error playing ringtone: ${e.message}")
        }
    }

    private fun stopIncomingCallRingtone() {
        try {
            incomingCallRingtone?.stop()
            incomingCallRingtone = null
            incomingCallVibrator?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping ringtone: ${e.message}")
        }
    }

    fun showIncomingCallNotification(callerName: String, callerNodeId: String) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID_OFFICER_CALL,
                    "สายเรียกเข้าจากเจ้าหน้าที่ (Officer Incoming Call)",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "แจ้งเตือนเมื่อเจ้าหน้าที่ศูนย์สั่งการโทรเข้าผ่านเครือข่ายบลูทูธฉุกเฉิน"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 1000, 1000, 1000)
                    setBypassDnd(true)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }

            // Launch Intent
            val launchIntent = Intent(context, com.rescue.alert.ui.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("OPEN_BT_MESH_CALL", true)
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALLER_NODE_ID, callerNodeId)
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context, 201, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Action: Answer
            val answerIntent = Intent(context, com.rescue.alert.ui.MainActivity::class.java).apply {
                action = ACTION_ANSWER_CALL
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALLER_NODE_ID, callerNodeId)
            }
            val answerPendingIntent = PendingIntent.getActivity(
                context, 202, answerIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Action: Decline
            val declineIntent = Intent(context, com.rescue.alert.receiver.CallActionReceiver::class.java).apply {
                action = ACTION_DECLINE_CALL
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALLER_NODE_ID, callerNodeId)
            }
            val declinePendingIntent = PendingIntent.getBroadcast(
                context, 203, declineIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = NotificationCompat.Builder(context, CHANNEL_ID_OFFICER_CALL)
                .setContentTitle("สายเรียกเข้า: $callerName")
                .setContentText("เจ้าหน้าที่กำลังโทรเข้า • กดรับสายเพื่อสนทนา 2 ทาง")
                .setSmallIcon(R.drawable.ic_phone)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(contentPendingIntent)
                .setFullScreenIntent(contentPendingIntent, true)
                .addAction(R.drawable.ic_phone, "รับสาย (Answer)", answerPendingIntent)
                .addAction(R.drawable.ic_call_end, "วางสาย (Decline)", declinePendingIntent)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("เจ้าหน้าที่ศูนย์สั่งการ EOC ($callerName) กำลังโทรเข้ามายังเครื่องของคุณผ่านเครือข่ายบลูทูธฉุกเฉิน\nกดปุ่ม 'รับสาย' เพื่อเปิดการสนทนา 2 ทางทันที")
                )
                .setColor(0xFF10B981.toInt())
                .build()

            notificationManager.notify(NOTIF_ID_OFFICER_CALL, notif)
        } catch (e: Exception) {
            Log.e(TAG, "Error showing incoming call notification: ${e.message}")
        }
    }

    fun showActiveCallNotification(callerName: String, callerNodeId: String) {
        try {
            val activeChannelId = "rescue_active_call_channel"
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    activeChannelId,
                    "สถานะสายสนทนา Bluetooth",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "แจ้งเตือนเมื่อเจ้าหน้าที่ศูนย์สั่งการโทรเข้าผ่านเครือข่ายบลูทูธฉุกเฉิน"
                    enableVibration(false)
                    setBypassDnd(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(context, com.rescue.alert.ui.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("OPEN_BT_MESH_CALL", true)
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALLER_NODE_ID, callerNodeId)
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context, 204, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Action: Hang Up
            val hangupIntent = Intent(context, com.rescue.alert.receiver.CallActionReceiver::class.java).apply {
                action = ACTION_HANGUP_CALL
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALLER_NODE_ID, callerNodeId)
            }
            val hangupPendingIntent = PendingIntent.getBroadcast(
                context, 205, hangupIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = NotificationCompat.Builder(context, activeChannelId)
                .setContentTitle(if (awaitingCallAnswer) "กำลังโทรหาเจ้าหน้าที่" else "กำลังสนทนาสายตรงกับเจ้าหน้าที่")
                .setContentText(if (awaitingCallAnswer) callQueuePosition?.let { if (it == 0) "ถึงคิวแล้ว • รอเจ้าหน้าที่รับสาย" else "กำลังรอคิวที่ $it • $callerName" } ?: "กำลังรอ $callerName รับสาย" else "เชื่อมต่อสัญญาณเสียง 2 ทางกับ $callerName")
                .setSmallIcon(R.drawable.ic_phone)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setAutoCancel(false)
                .setContentIntent(contentPendingIntent)
                .addAction(R.drawable.ic_call_end, "วางสาย (Hang Up)", hangupPendingIntent)
                .setColor(0xFF10B981.toInt())
                .build()

            notificationManager.notify(NOTIF_ID_OFFICER_CALL, notif)
        } catch (e: Exception) {
            Log.e(TAG, "Error showing active call notification: ${e.message}")
        }
    }

    fun hideOfficerCallNotification() {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(NOTIF_ID_OFFICER_CALL)
        } catch (e: Exception) {
            Log.e(TAG, "Error hiding officer call notification: ${e.message}")
        }
    }

    private fun startRecordingLoop(targetNodeId: String, isEmergency: Boolean) {
        recordingThread = Thread {
            var recorder: AudioRecord? = null
            try {
                if (!hasAudioPermission()) return@Thread

                val sessionRecorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_IN,
                    AUDIO_FORMAT,
                    recordBufferSize
                )

                recorder = sessionRecorder
                if (sessionRecorder.state != AudioRecord.STATE_INITIALIZED) {
                    mainHandler.post {
                        onMeshLogMessage?.invoke("ไมโครโฟนไม่พร้อมใช้งาน")
                    }
                    return@Thread
                }

                synchronized(audioRecordLock) {
                    if (!isTransmitting.get() || Thread.currentThread().isInterrupted) return@Thread
                    audioRecord = sessionRecorder
                }
                sessionRecorder.startRecording()
                val audioBuffer = ShortArray(recordBufferSize / 2)
                var packetSeq = 0

                while (isTransmitting.get() && !Thread.currentThread().isInterrupted) {
                    val readShorts = sessionRecorder.read(audioBuffer, 0, audioBuffer.size)
                    if (readShorts > 0) {
                        // Calculate amplitude for UI meter
                        var sum = 0.0
                        for (i in 0 until readShorts) {
                            sum += Math.abs(audioBuffer[i].toInt())
                        }
                        val avgAmp = (sum / readShorts).toInt()
                        val level = Math.min(100, avgAmp / 350)
                        mainHandler.post { onAudioLevelChanged?.invoke(level) }

                        // Convert shorts to bytes
                        val byteBuf = ByteArray(readShorts * 2)
                        for (i in 0 until readShorts) {
                            val sample = audioBuffer[i]
                            byteBuf[i * 2] = (sample.toInt() and 0xFF).toByte()
                            byteBuf[i * 2 + 1] = ((sample.toInt() shr 8) and 0xFF).toByte()
                        }

                        // Create authentic mesh voice packet
                        val packet = MeshVoicePacket(
                            packetId = if (isInCall.get()) "EOC_CALL_VOICE_${myNodeId}_${System.currentTimeMillis()}_${packetSeq++}" else "${myNodeId}_${System.currentTimeMillis()}_${packetSeq++}",
                            sourceNodeId = myNodeId,
                            sourceHouseName = myHouseName,
                            targetNodeId = targetNodeId,
                            hopCount = 0,
                            ttl = 5,
                            audioData = byteBuf,
                            isSosEmergency = isEmergency
                        )

                        // Broadcast packet out across real Bluetooth transports only if still transmitting
                        if (isTransmitting.get()) {
                            broadcastPacketOverBluetooth(packet)
                            if (packetSeq == 1 && isInCall.get()) Log.i(TAG, "Call microphone PCM sending peer=$targetNodeId bytes=${byteBuf.size}")
                        }
                    }
                }
            } catch (e: SecurityException) {
                isTransmitting.set(false)
                Log.w(TAG, "Microphone permission revoked", e)
            } catch (e: Exception) {
                Log.e(TAG, "Recording loop exception", e)
            } finally {
                synchronized(audioRecordLock) {
                    if (audioRecord === recorder) audioRecord = null
                }
                recorder?.let { stopped ->
                    synchronized(stopped) {
                        try { stopped.stop() } catch (_: Exception) {}
                        stopped.release()
                    }
                }
            }
        }.apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    /**
     * Broadcasts an emergency SOS alert packet across all active Bluetooth mesh transports
     * (Direct RFCOMM Channel 4 to EOC Gateway + connected peer BLE GATT clients).
     *
     * @param audioBytes Optional recorded voice audio bytes (e.g. PCM or AAC up to 32KB)
     * @param customHouseName Optional custom display name (defaults to CitizenEmergencyProfile.name or device model)
     * @return true if broadcast packet was queued/sent, false otherwise
     */
    fun broadcastEmergencyAlert(
        audioBytes: ByteArray = ByteArray(0),
        customHouseName: String? = null
    ): Boolean {
        return try {
            // Ensure Bluetooth radio scanning & advertising are active
            if (hasBluetoothPermissions()) {
                try {
                    startBleMeshAdvertising()
                    startBleMeshScan()
                } catch (e: Exception) {
                    Log.w(TAG, "Error ensuring BLE advertising/scan for emergency alert: ${e.message}")
                }
            }

            val displayName = customHouseName?.takeIf { it.isNotBlank() }
                ?: com.rescue.alert.model.CitizenEmergencyProfile.name.takeIf { it.isNotBlank() }
                ?: myHouseName

            // Bound audio bytes to <= 32000 bytes to prevent 16-bit length overflow
            val safeAudio = if (audioBytes.size <= 32000) audioBytes else audioBytes.copyOf(32000)
            val packetId = "SOS_${myNodeId}_${System.currentTimeMillis()}"

            // Attach GPS coordinates if available (F-05)
            val gpsTarget = if (com.rescue.alert.model.CitizenEmergencyProfile.lastLatitude != null &&
                com.rescue.alert.model.CitizenEmergencyProfile.lastLongitude != null) {
                "GPS:${com.rescue.alert.model.CitizenEmergencyProfile.lastLatitude},${com.rescue.alert.model.CitizenEmergencyProfile.lastLongitude}"
            } else {
                "BROADCAST"
            }

            val packet = MeshVoicePacket(
                packetId = packetId,
                sourceNodeId = myNodeId,
                sourceHouseName = displayName,
                targetNodeId = gpsTarget,
                hopCount = 0,
                ttl = 5,
                audioData = safeAudio,
                isSosEmergency = true
            )

            broadcastPacketOverBluetooth(packet)

            val reachedPeers = activeRfcommSockets.values.count { it.isConnected } + activeGattClients.size
            if (reachedPeers == 0) {
                synchronized(pendingSosPackets) {
                    if (pendingSosPackets.size < 20) {
                        pendingSosPackets.add(packet)
                    }
                }
                mainHandler.post {
                    onMeshLogMessage?.invoke("[คำเตือน] ยังไม่พบอุปกรณ์ในระยะบลูทูธ - สัญญาณ SOS ทางแมชจะถูกเก็บไว้ส่งซ้ำอัตโนมัติเมื่อพบอุปกรณ์")
                }
            } else {
                mainHandler.post {
                    onMeshLogMessage?.invoke("[ฉุกเฉิน SOS] กระจายสัญญาณขอความช่วยเหลือข้ามบลูทูธแมชไปยัง $reachedPeers อุปกรณ์เรียบร้อยแล้ว")
                }
            }
            Log.i(TAG, "Broadcasted emergency SOS mesh packet: $packetId (audio: ${safeAudio.size} bytes, peers: $reachedPeers)")
            reachedPeers > 0
        } catch (e: Exception) {
            Log.e(TAG, "Failed to broadcast emergency SOS mesh packet: ${e.message}", e)
            false
        }
    }

    /**
     * Alias for broadcastEmergencyAlert to support emergency mesh packet dispatch.
     */
    fun sendEmergencyMeshPacket(
        audioBytes: ByteArray = ByteArray(0),
        customHouseName: String? = null
    ): Boolean {
        return broadcastEmergencyAlert(audioBytes, customHouseName)
    }

    /**
     * Serializes and broadcasts a MeshVoicePacket across all real Bluetooth transports
     */
    fun broadcastPacketOverBluetooth(packet: MeshVoicePacket, excludeSocketKey: String? = null) {
        dispatchTransportWrite { writePacketOverBluetooth(packet, excludeSocketKey) }
    }

    private fun writePacketOverBluetooth(packet: MeshVoicePacket, excludeSocketKey: String?) {
        if (packet.packetId.startsWith("EOC_CALL_")) {
            com.rescue.alert.network.InternetAnnouncementClient.sendCallPacket(context, packet)
        }
        val serialized = serializePacket(packet) ?: return

        // 1. Send via active Unpaired RFCOMM Sockets (High Throughput Audio Streaming)
        val rfcommHeader = ByteBuffer.allocate(8)
            .putInt(HEADER_MAGIC_INT)
            .putInt(serialized.size)
            .array()

        for ((key, socket) in activeRfcommSockets) {
            if (excludeSocketKey != null && key == excludeSocketKey) continue
            try {
                if (socket.isConnected) {
                    val out = socket.outputStream
                    writeWithDeadline(timeout = {
                        Log.w(TAG, "RFCOMM write timed out; closing blocked transport")
                        activeRfcommSockets.remove(key, socket)
                        try { socket.close() } catch (_: Exception) {}
                    }) {
                        synchronized(socket) {
                            out.write(rfcommHeader)
                            out.write(serialized)
                            out.flush()
                        }
                    }
                    if (packet.packetId.startsWith("EOC_CALL_") && !packet.packetId.startsWith("EOC_CALL_VOICE")) {
                        Log.i(TAG, "Call TX ${packet.packetId} peer=${packet.targetNodeId} via=$key")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error writing to RFCOMM socket: ${e.message}")
                activeRfcommSockets.remove(key, socket)
                try { socket.close() } catch (_: Exception) {}
            }
        }

        // 2. Send via connected BLE GATT Clients with negotiated MTU & sequence IDs (P-1)
        if (activeGattClients.isNotEmpty()) {
            val seqId = (packetSeqCounter.incrementAndGet() and 0xFF).toByte()
            gattSendExecutor.execute {
                for ((devAddr, gatt) in activeGattClients) {
                    if (activeRfcommSockets[devAddr]?.isConnected == true || packet.packetId.startsWith("EOC_CALL_VOICE")) continue
                    try {
                        val service = gatt.getService(RESCUE_MESH_SERVICE_UUID)
                        val characteristic = service?.getCharacteristic(RESCUE_MESH_CHAR_UUID)
                        if (characteristic != null) {
                            val mtu = deviceMtuMap[devAddr] ?: 23
                            // Usable payload: MTU - 3 ATT header - 4 chunk header
                            val chunkSize = maxOf(16, mtu - 7)
                            val totalChunks = (serialized.size + chunkSize - 1) / chunkSize

                            for (chunkIdx in 0 until totalChunks) {
                                val start = chunkIdx * chunkSize
                                val end = minOf(start + chunkSize, serialized.size)
                                val slice = serialized.copyOfRange(start, end)
                                val chunkPacket = ByteArray(4 + slice.size).apply {
                                    this[0] = 0xAA.toByte()
                                    this[1] = seqId
                                    this[2] = chunkIdx.toByte()
                                    this[3] = totalChunks.toByte()
                                    System.arraycopy(slice, 0, this, 4, slice.size)
                                }
                                characteristic.value = chunkPacket
                                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                                gatt.writeCharacteristic(characteristic)
                                if (chunkIdx < totalChunks - 1) {
                                    try { Thread.sleep(8) } catch (e: InterruptedException) {}
                                }
                            }
                        }
                    } catch (e: SecurityException) {
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    private fun processIncomingPacketBytes(bytes: ByteArray, incomingSocketKey: String? = null) {
        val packet = parsePacket(bytes) ?: return
        val packetId = packet.packetId
        val srcNodeId = packet.sourceNodeId
        val srcHouseName = packet.sourceHouseName
        val tgtNodeId = packet.targetNodeId
        val hopCount = packet.hopCount
        val ttl = packet.ttl
        val isSos = packet.isSosEmergency
        val audioBytes = packet.audioData

        try {
            // Ignore self-echoes
            if (srcNodeId == myNodeId) return

            // Every packet type must be deduplicated and relayed, including EOC control/site packets.
            synchronized(processedPacketCache) {
                if (!processedPacketCache.add(packetId)) return
                if (processedPacketCache.size > 500) {
                    val oldest = processedPacketCache.iterator()
                    if (oldest.hasNext()) { oldest.next(); oldest.remove() }
                }
            }
            if (ttl > 1) {
                broadcastPacketOverBluetooth(packet.copy(hopCount = hopCount + 1, ttl = ttl - 1), incomingSocketKey)
            }
            if (tgtNodeId != "BROADCAST" && tgtNodeId != myNodeId) return
            if (packetId.startsWith("SOS_PROFILE_") || packetId.startsWith("SOS_STATUS_QUERY_")) return // Data already relayed; never play JSON as audio.
            if (srcNodeId == EOC_GATEWAY_NODE_ID && (packetId.startsWith("EOC_SOS_ACK_") || packetId.startsWith("EOC_SOS_STATUS_"))) {
                val receipt = org.json.JSONObject(audioBytes.toString(Charsets.UTF_8))
                if (receipt.optString("status") == "SUCCESS") {
                    com.rescue.alert.data.GeneralSosOutbox.applyStatus(context, receipt.getString("case_id"), receipt.optString("case_status", "PENDING"))
                }
                return
            }
            if (srcNodeId == EOC_GATEWAY_NODE_ID && packetId.startsWith("EOC_POSITION_")) {
                val fix = org.json.JSONObject(audioBytes.toString(Charsets.UTF_8))
                val lat = fix.optDouble("lat", Double.NaN)
                val lng = fix.optDouble("lng", Double.NaN)
                if (lat.isFinite() && lng.isFinite() && lat in -90.0..90.0 && lng in -180.0..180.0 &&
                    fix.optDouble("accuracy", Double.POSITIVE_INFINITY) in 0.0..250.0 &&
                    System.currentTimeMillis() - fix.optLong("timestamp") in 0L..30_000L) officerPosition = fix
                return
            }
            if (packetId.startsWith("MESH_HELLO") || packetId.startsWith("MESH_READY")) {
                Log.i(TAG, "Mesh peer ready node=$srcNodeId via=$incomingSocketKey")
                return
            }
            if (packetId.startsWith("EOC_CALL_") && !packetId.startsWith("EOC_CALL_VOICE")) {
                Log.i(TAG, "Call RX $packetId peer=$srcNodeId")
            }

            // BUG-02 FIX: Check call signaling FIRST (before announcement),
            // because call packets also originate from EOC_GATEWAY_NODE_ID.
            // Without this fix, call packets were caught by the announcement handler
            // and the entire incoming call feature was non-functional.
            if (packetId.startsWith("EOC_CALL_QUEUE")) {
                if (tgtNodeId == myNodeId) {
                    try {
                        val position = org.json.JSONObject(String(audioBytes, Charsets.UTF_8)).getInt("position")
                        handleCallQueuedByRemote(srcNodeId, position)
                    } catch (e: org.json.JSONException) {
                        Log.w(TAG, "Invalid call queue control")
                    }
                }
                return
            } else if (packetId.startsWith("EOC_CALL_REQUEST") || packetId.startsWith("EOC_CALL_REQ") || packetId.startsWith("CALL_REQUEST")) {
                if (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId) {
                    handleIncomingOfficerCall(srcNodeId, srcHouseName)
                }
                return  // Don't fall through to announcement or walkie-talkie
            } else if (packetId.startsWith("EOC_CALL_HANGUP") || packetId.startsWith("EOC_CALL_END")) {
                if (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId) {
                    handleOfficerCallEnded(srcNodeId, srcHouseName)
                }
                return
            } else if (packetId.startsWith("EOC_CALL_ANSWER")) {
                if (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId) {
                    handleCallAnsweredByRemote(srcNodeId, srcHouseName)
                }
                return
            } else if (packetId.startsWith("EOC_CALL_DECLINE")) {
                if (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId) {
                    handleCallDeclinedByRemote(srcNodeId, srcHouseName)
                }
                return
            } else if (packetId.startsWith("EOC_CALL_VOICE")) {
                if (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId) {
                    val peerId = activeCallNode?.nodeId ?: incomingCallerNodeId
                    if (isInCall.get() && srcNodeId == peerId && audioBytes.isNotEmpty()) {
                        playAudioData(audioBytes)
                        callReceivedBytes += audioBytes.size
                        if (callReceivedBytes == audioBytes.size.toLong()) Log.i(TAG, "Call PCM playback started peer=$srcNodeId bytes=${audioBytes.size}")
                    }
                }
                return
            } else if (packetId.startsWith("EOC_SITE") || packetId.startsWith("EOC_SHELTER")) {
                if (audioBytes.isNotEmpty()) {
                    try {
                        val jsonStr = String(audioBytes, Charsets.UTF_8)
                        val repo = com.rescue.alert.data.EvacuationSiteRepository.getInstance(context)
                        repo.processMeshSiteJson(jsonStr)
                        mainHandler.post {
                            onMeshLogMessage?.invoke("[ศูนย์อพยพ] ได้รับข้อมูลจุดปลอดภัย/ที่จอดรถผ่านบลูทูธแมช")
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing mesh site packet", e)
                    }
                }
                return
            }

            // Check if this is an officer announcement from EOC gateway or officer mic (excluding direct call and site packets)
            val isOfficerAnnouncement = srcNodeId == EOC_GATEWAY_NODE_ID &&
                    packetId.startsWith("EOC_ANNOUNCE_")

            if (isOfficerAnnouncement) {
                if (packetId.startsWith("EOC_ANNOUNCE_END") || (audioBytes.isEmpty() && packetId.contains("END"))) {
                    handleOfficerAnnouncementEnded()
                    return
                } else {
                    handleOfficerAnnouncementChunk(srcHouseName, audioBytes)
                    return  // BUG-02 FIX: Explicit return to prevent fall-through
                }
            }

            // Unknown EOC control packets are neither microphone audio nor SOS events.
            if (srcNodeId == EOC_GATEWAY_NODE_ID) return

            // Play voice stream for general walkie-talkie calls (if not already handled as officer announcement)
            if (!isOfficerAnnouncement && (tgtNodeId == "BROADCAST" || tgtNodeId == myNodeId)) {
                playAudioData(audioBytes)
                mainHandler.post {
                    onIncomingVoiceReceived?.invoke(srcHouseName, hopCount + 1, isSos)
                }
            }

        } catch (e: Exception) {
            Log.w(TAG, "Error parsing incoming packet", e)
        }
    }

    fun handleOfficerAnnouncementChunk(sourceName: String, audioBytes: ByteArray) {
        if (audioBytes.isEmpty()) return
        val cleanName = if (sourceName.isNotBlank()) sourceName else "ศูนย์สั่งการ EOC"

        // 1. Play audio automatically through speaker/AudioTrack without requiring user interaction
        if (audioBytes.isNotEmpty()) {
            playAudioData(audioBytes)
        }

        // 2. Trigger prominent ongoing notification and in-app banner if not already active
        if (!isOfficerAnnouncing) {
            isOfficerAnnouncing = true
            showOfficerAnnouncementNotification(cleanName)
            mainHandler.post {
                onOfficerAnnouncementStateChanged?.invoke(true, cleanName)
                onMeshLogMessage?.invoke("[ไมค์ประกาศ] มีไมค์ประกาศจากเจ้าหน้าที่เข้ามา ($cleanName) กำลังเล่นเสียงอัตโนมัติ")
            }
            Log.i(TAG, "Officer live mic announcement started from $cleanName")
        }

        // 3. Reset auto-dismiss watchdog timer (if officer releases mic / no audio for 2.8s, clear notification)
        announcementWatchdogRunnable?.let { announcementWatchdogHandler.removeCallbacks(it) }
        announcementWatchdogRunnable = Runnable {
            handleOfficerAnnouncementEnded()
        }
        announcementWatchdogHandler.postDelayed(announcementWatchdogRunnable!!, 2800L)
    }

    fun handleOfficerAnnouncementEnded() {
        if (!isOfficerAnnouncing) return
        isOfficerAnnouncing = false
        announcementWatchdogRunnable?.let { announcementWatchdogHandler.removeCallbacks(it) }
        hideOfficerAnnouncementNotification()
        mainHandler.post {
            onOfficerAnnouncementStateChanged?.invoke(false, "EOC")
            onMeshLogMessage?.invoke("[ไมค์ประกาศ] เจ้าหน้าที่ปิดไมค์ประกาศแล้ว (สิ้นสุดการถ่ายทอดเสียง)")
        }
        Log.i(TAG, "Officer announcement ended (mic closed)")
    }

    private fun showOfficerAnnouncementNotification(sourceName: String) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID_OFFICER_ANNOUNCEMENT,
                    "เสียงประกาศจากไมค์เจ้าหน้าที่ (Officer Live Announcement)",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "แจ้งเตือนเมื่อเจ้าหน้าที่เปิดไมค์ประกาศสดผ่านระบบสื่อสารฉุกเฉิน"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 300, 150, 300)
                    setBypassDnd(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(context, com.rescue.alert.ui.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 0, launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = NotificationCompat.Builder(context, CHANNEL_ID_OFFICER_ANNOUNCEMENT)
                .setContentTitle("มีไมค์ประกาศจากเจ้าหน้าที่เข้ามา")
                .setContentText("กำลังถ่ายทอดเสียงประกาศสดจาก $sourceName (กำลังเล่นเสียงอัตโนมัติ)")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(pendingIntent)
                .build()

            notificationManager.notify(NOTIF_ID_OFFICER_ANNOUNCEMENT, notif)
        } catch (e: Exception) {
            Log.e(TAG, "Error showing officer announcement notification: ${e.message}")
        }
    }

    private fun hideOfficerAnnouncementNotification() {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(NOTIF_ID_OFFICER_ANNOUNCEMENT)
        } catch (e: Exception) {
            Log.e(TAG, "Error hiding officer announcement notification: ${e.message}")
        }
    }

    fun playAudioData(audioBytes: ByteArray) {
        if (audioBytes.isEmpty()) return
        try {
            if (audioTrack == null || audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                initAudioTrack()
            }
            if (audioTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                audioTrack?.play()
            }
            audioTrack?.write(audioBytes, 0, audioBytes.size)
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio", e)
        }
    }

    private fun playTone(frequencyHz: Int, durationMs: Int) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * durationMs) / 1000
                val sample = DoubleArray(numSamples)
                val generatedSnd = ByteArray(2 * numSamples)

                for (i in 0 until numSamples) {
                    sample[i] = sin(2.0 * Math.PI * i / (SAMPLE_RATE / frequencyHz))
                }

                var idx = 0
                for (dVal in sample) {
                    val valShort = (dVal * 32767).toInt().toShort()
                    generatedSnd[idx++] = (valShort.toInt() and 0x00FF).toByte()
                    generatedSnd[idx++] = ((valShort.toInt() and 0xFF00) ushr 8).toByte()
                }

                val track = AudioTrack(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                        AudioFormat.Builder()
                            .setEncoding(AUDIO_FORMAT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(CHANNEL_OUT)
                            .build(),
                    generatedSnd.size, AudioTrack.MODE_STATIC, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
                )

                track.write(generatedSnd, 0, generatedSnd.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 50)
                track.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error playing tone", e)
            }
        }.start()
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Start Bluetooth LE scanning strictly filtered by app UUID.
     * Detection callback verifies APP_HANDSHAKE_BEACON in Service Data.
     * Only devices with BOTH the UUID AND the handshake beacon are accepted.
     * Rejects all non-app devices (headphones, cars, TVs, speakers).
     */
    fun startBleMeshScan() {
        if (!hasBluetoothPermissions()) {
            onMeshLogMessage?.invoke("ความปลอดภัย: ล็อคช่องสัญญาณเฉพาะแอพ (UUID: 16690000-FA01) เครือข่าย P2P")
            return
        }

        try {
            val scanner = bluetoothAdapter?.bluetoothLeScanner
            if (scanner == null) {
                onMeshLogMessage?.invoke("บลูทูธไม่พร้อมใช้งาน หรือปิดอยู่")
                return
            }

            // Stop existing scan if active to prevent callback accumulation
            activeScanCallback?.let {
                try { scanner.stopScan(it) } catch (e: Exception) {}
            }

            // Hardware filters: devices with app Service UUID OR the EOC Gateway name
            val uuidFilter = ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(RESCUE_MESH_SERVICE_UUID))
                .build()

            val nameFilter = ScanFilter.Builder()
                .setDeviceName(EOC_GATEWAY_NAME)
                .build()

            val scanFilters = listOf(uuidFilter, nameFilter)

            val scanSettings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()

            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult?) {
                    result?.let {
                        val record = it.scanRecord
                        val dev = it.device
                        val serviceUuids = record?.serviceUuids
                        val serviceData = record?.getServiceData(ParcelUuid(RESCUE_MESH_SERVICE_UUID))
                        val advertisedName = record?.deviceName ?: dev.name ?: ""

                        // Step 1: Strict App Verification — ONLY accept RescueAlert app nodes & EOC Gateway
                        val isUuidMatch = serviceUuids?.any { u -> u.uuid == RESCUE_MESH_SERVICE_UUID } == true
                        val hasServiceData = serviceData != null
                        val beaconStr = serviceData?.let { sd -> String(sd, Charsets.UTF_8) } ?: ""
                        val isEocGateway = advertisedName.contains("EOC-Gateway", ignoreCase = true) ||
                            advertisedName.contains(EOC_GATEWAY_NAME, ignoreCase = true) ||
                            beaconStr.contains("EOC")

                        if (!isUuidMatch && !hasServiceData) return

                        // === VERIFIED APP NODE (RescueAlert App Installed) ===
                        val rssi = it.rssi
                        val distance = calculateLogDistance(rssi)

                        val nodeType = if (isEocGateway) MeshNodeType.RESCUE_POST else MeshNodeType.DIRECT_NEIGHBOR
                        val displayName = if (isEocGateway) {
                            EOC_GATEWAY_DISPLAY_NAME
                        } else {
                            val fallbackName = if (advertisedName.isNotBlank()) advertisedName else "บ้านเรือนเพื่อนบ้าน"
                            "$fallbackName (${dev.address.takeLast(5)})"
                        }
                        val nodeId = when {
                            isEocGateway -> EOC_GATEWAY_NODE_ID
                            beaconStr.startsWith("RA") && beaconStr.length >= 8 -> "NODE_${beaconStr.substring(2, 8)}"
                            beaconStr.startsWith("NODE_") -> beaconStr.take(16)
                            else -> "NODE_${dev.address.replace(":", "").takeLast(6)}"
                        }
                        val battery = -1 // Peer battery is not present in the discovery beacon.

                        val node = MeshNode(
                            nodeId = nodeId,
                            houseName = displayName,
                            distanceMeters = distance,
                            rssi = rssi,
                            hopCount = 1,
                            relayVia = null,
                            nodeType = nodeType,
                            batteryPercent = battery,
                            isOnline = true,
                            lastSeenMs = System.currentTimeMillis(),
                            deviceAddress = dev.address
                        )

                        addOrUpdateDiscoveredNode(node, dev)
                    }
                }

                override fun onScanFailed(errorCode: Int) {
                    mainHandler.post {
                        onMeshLogMessage?.invoke("สแกนเนอร์บลูทูธสแตนด์บาย (Code $errorCode)")
                    }
                }
            }

            activeScanCallback = callback
            scanner.startScan(scanFilters, scanSettings, callback)

            // Also advertise self presence so other phones running this app can detect us
            startBleMeshAdvertising()
            onMeshLogMessage?.invoke("เปิดสแกน (UUID + App Handshake Beacon) • ตรวจจับเฉพาะอุปกรณ์ที่โหลดแอป RescueAlert")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException during BLE scan", e)
        } catch (e: Exception) {
            Log.e(TAG, "BLE scan error", e)
        }
    }

    /**
     * Deduplicates and updates discovered mesh nodes.
     * Resolves RPA address rotations from EOC Gateway to guarantee 1 physical gateway = 1 card.
     */
    private fun addOrUpdateDiscoveredNode(node: MeshNode, dev: BluetoothDevice) {
        synchronized(meshNodes) {
            // Anti-RPA Deduplication: Match by exact MAC address OR MeshNodeType.RESCUE_POST
            val existing = meshNodes.find {
                it.deviceAddress == node.deviceAddress ||
                (node.nodeType == MeshNodeType.RESCUE_POST && it.nodeType == MeshNodeType.RESCUE_POST)
            }

            if (existing != null) {
                if (existing.nodeType == MeshNodeType.RESCUE_POST && existing.deviceAddress != node.deviceAddress) {
                    // RPA Rotation Detected for EOC Gateway!
                    val oldAddress = existing.deviceAddress

                    // Close and purge stale connection handles for obsolete rotated MAC
                    activeRfcommSockets.remove(oldAddress)?.let { oldSocket ->
                        try { oldSocket.close() } catch (e: Exception) {
                            Log.d(TAG, "Error closing stale RFCOMM socket for rotated RPA $oldAddress: ${e.message}")
                        }
                    }
                    activeGattClients.remove(oldAddress)?.let { oldGatt ->
                        try { oldGatt.close() } catch (e: SecurityException) {
                            Log.w(TAG, "Bluetooth permission revoked while closing GATT", e)
                        } catch (e: Exception) {
                            Log.d(TAG, "Error closing stale GATT client for rotated RPA $oldAddress: ${e.message}")
                        }
                    }
                    deviceMtuMap.remove(oldAddress)

                    // In-place replacement retains topology order and prevents duplicate cards
                    val smoothedRssi = if (existing.rssi != 0) ((existing.rssi * 0.4) + (node.rssi * 0.6)).toInt() else node.rssi
                    node.rssi = smoothedRssi
                    node.distanceMeters = calculateLogDistance(smoothedRssi)

                    val idx = meshNodes.indexOf(existing)
                    if (idx >= 0) {
                        meshNodes[idx] = node
                    }

                    // Update active call node reference if mid-call
                    if (activeCallNode?.nodeType == MeshNodeType.RESCUE_POST) {
                        activeCallNode = node
                    }

                    // Reconnect to the new rotated RPA address
                    connectToDiscoveredNode(dev)
                    mainHandler.post {
                        onMeshLogMessage?.invoke("อัปเดตช่องทางเชื่อมต่อศูนย์สั่งการ EOC (RPA หมุนเวียน MAC สำเร็จ)")
                    }
                    Unit
                } else {
                    // Standard heartbeat refresh for same physical address
                    val smoothedRssi = if (existing.rssi != 0) ((existing.rssi * 0.4) + (node.rssi * 0.6)).toInt() else node.rssi
                    node.rssi = smoothedRssi
                    node.distanceMeters = calculateLogDistance(smoothedRssi)

                    val idx = meshNodes.indexOf(existing)
                    if (idx >= 0) {
                        meshNodes[idx] = node
                    }
                    Unit
                }
            } else {
                // Newly discovered physical node
                if (node.nodeType == MeshNodeType.RESCUE_POST) {
                    // Pin EOC Gateway to index 0 so it always appears at the top of the list
                    meshNodes.add(0, node)
                } else {
                    meshNodes.add(node)
                }

                connectToDiscoveredNode(dev)
                mainHandler.post {
                    val typeLabel = if (node.nodeType == MeshNodeType.RESCUE_POST) "ศูนย์สั่งการ EOC" else "อุปกรณ์เพื่อนบ้าน"
                    onMeshLogMessage?.invoke("ตรวจพบ$typeLabel: ${node.houseName} [VERIFIED] (${node.distanceMeters} ม.)")
                }
                Unit
            }
            Unit
        }
        mainHandler.post {
            onMeshNodesUpdated?.invoke(getNodes())
        }
        connectToDiscoveredNode(dev)
    }

    private val gattClientCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val devAddr = gatt.device.address
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                activeGattClients[devAddr] = gatt
                flushPendingSosPackets()
                Log.i(TAG, "GATT client connected to $devAddr. Requesting MTU 517 (P-1)...")
                try {
                    // P-1: Request maximum BLE MTU (517)
                    val requested = gatt.requestMtu(517)
                    if (!requested) {
                        gatt.discoverServices()
                    }
                } catch (e: SecurityException) {
                    activeGattClients.remove(devAddr, gatt)
                    Log.w(TAG, "Bluetooth permission revoked during GATT discovery", e)
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                activeGattClients.remove(devAddr)
                deviceMtuMap.remove(devAddr)
                try { gatt.close() } catch (e: SecurityException) {
                    Log.w(TAG, "Bluetooth permission revoked while closing GATT", e)
                } catch (e: Exception) {}
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            val devAddr = gatt.device.address
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "P-1: GATT MTU negotiated to $mtu bytes for $devAddr")
                deviceMtuMap[devAddr] = mtu
            } else {
                Log.w(TAG, "P-1: GATT MTU negotiation failed, status=$status")
            }
            try {
                gatt.discoverServices()
            } catch (e: SecurityException) {}
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            Log.i(TAG, "GATT services discovered for ${gatt.device.address}")
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            Log.d(TAG, "GATT chunk write ACK from ${gatt.device.address}")
        }
    }

    /**
     * Connects to a discovered Bluetooth device.
     * Uses the advertised SDP UUID for both Android peers and the EOC.
     * GATT is supplementary for Android peers; the EOC voice service uses RFCOMM.
     */
    private fun connectToDiscoveredNode(device: BluetoothDevice) {
        if (!hasBluetoothPermissions()) return

        // Prevent duplicate connection attempts if socket is already active
        if (activeRfcommSockets[device.address]?.isConnected == true) {
            return
        }
        val now = System.currentTimeMillis()
        if (now - (lastConnectAttempt[device.address] ?: 0L) < 10_000L || !connectingAddresses.add(device.address)) return
        lastConnectAttempt[device.address] = now
        val isEocPeer = synchronized(meshNodes) {
            meshNodes.any { it.deviceAddress == device.address && it.nodeType == MeshNodeType.RESCUE_POST }
        }

        Thread {
            var socket: BluetoothSocket? = null

            // Public Android API: resolve the service channel from the peer's SDP record.
            if (socket == null || !socket.isConnected) {
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(RESCUE_RFCOMM_UUID)
                    socket.connect()
                    Log.i(TAG, "Successfully connected via SDP Service Record UUID to ${device.address}")
                } catch (e: SecurityException) {
                    Log.w(TAG, "Bluetooth permission revoked during RFCOMM connect", e)
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                } catch (e: Exception) {
                    Log.w(TAG, "SDP fallback RFCOMM connection failed to ${device.address}: ${e.message}")
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                }
            }

            // Register active socket, send handshake, and start reader daemon thread
            if (socket != null && socket.isConnected) {
                val devKey = device.address

                // Send APP_PROTOCOL_MAGIC handshake to identify as RescueAlert app
                // Desktop EOC requires this before accepting any mesh packets
                try {
                    val handshakeBytes = (APP_PROTOCOL_MAGIC + "\u0000").toByteArray(Charsets.UTF_8)
                    socket.outputStream.write(handshakeBytes)
                    socket.outputStream.flush()
                    Log.i(TAG, "Sent APP_PROTOCOL_MAGIC handshake to $devKey")
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to send handshake to $devKey: ${e.message}")
                }

                activeRfcommSockets[devKey] = socket
                broadcastPacketOverBluetooth(MeshVoicePacket(
                    packetId = "MESH_HELLO_${myNodeId}_${System.currentTimeMillis()}",
                    sourceNodeId = myNodeId, sourceHouseName = myHouseName,
                    targetNodeId = "BROADCAST", hopCount = 0, ttl = 1,
                    isSosEmergency = false, audioData = ByteArray(0)
                ))
                flushPendingSosPackets()
                mainHandler.post {
                    val peerLabel = synchronized(meshNodes) {
                        meshNodes.find { it.deviceAddress == devKey }?.houseName
                    } ?: (safeDeviceName(device) ?: devKey)
                    onMeshLogMessage?.invoke("เชื่อมต่อช่องสัญญาณเสียงตรงกับ: $peerLabel")
                }

                // Start dedicated socket reader daemon to handle incoming packets and socket lifecycle
                Thread {
                    handleIncomingRfcommSocket(socket, devKey)
                }.apply {
                    name = "RFCOMM-Reader-$devKey"
                    start()
                }
            }
            connectingAddresses.remove(device.address)
        }.apply {
            name = "RFCOMM-Connect-${device.address}"
            start()
        }

        // The EOC has no RescueAlert GATT characteristic; an unnecessary LE connection
        // also prevents legacy controllers from restarting their connectable advertisement.
        if (isEocPeer) return
        // P-1: Connect BLE GATT client with MTU 517 negotiation
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(context, false, gattClientCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                device.connectGatt(context, false, gattClientCallback)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException connecting GATT to ${device.address}", e)
        } catch (e: Exception) {
            Log.w(TAG, "Error connecting GATT client to ${device.address}", e)
        }
    }

    /**
     * Advertise this device's presence with app-exclusive UUID AND handshake beacon.
     * Both UUID and APP_HANDSHAKE_BEACON in Service Data are REQUIRED for
     * other devices (mobile + desktop EOC) to detect this phone.
     * Without the beacon, this device is invisible to the mesh network.
     */
    fun startBleMeshAdvertising() {
        if (!hasBluetoothPermissions()) return
        try {
            val advertiser = bluetoothAdapter?.bluetoothLeAdvertiser ?: return
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(true)
                .build()

            // Primary advertisement: 128-bit Service UUID only (21 bytes <= 31 bytes)
            val data = AdvertiseData.Builder()
                .addServiceUuid(ParcelUuid(RESCUE_MESH_SERVICE_UUID))
                .setIncludeDeviceName(false)
                .build()

            // Scan response: App handshake beacon + node ID in Service Data (26 bytes <= 31 bytes)
            // Compact beacon format "RA" + 6-char node ID ensures it never exceeds 31-byte limit
            val compactNodeId = myNodeId.replace("NODE_", "").take(6).padEnd(6, '0')
            val serviceDataPayload = "RA".toByteArray(Charsets.UTF_8) + compactNodeId.toByteArray(Charsets.UTF_8)

            val scanResponse = AdvertiseData.Builder()
                .addServiceData(ParcelUuid(RESCUE_MESH_SERVICE_UUID), serviceDataPayload)
                .setIncludeDeviceName(false)
                .build()

            advertiser.startAdvertising(settings, data, scanResponse, object : AdvertiseCallback() {
                override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                    Log.i(TAG, "BLE Mesh advertising started successfully (UUID: $RESCUE_MESH_SERVICE_UUID, Beacon: RA$compactNodeId)")
                }

                override fun onStartFailure(errorCode: Int) {
                    Log.w(TAG, "BLE Mesh advertising failed: $errorCode")
                }
            })
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException starting BLE advertising", e)
        } catch (e: Exception) {
            Log.w(TAG, "Error starting BLE advertising", e)
        }
    }

    private fun hasBluetoothPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val scanGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED
            val connectGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
            val advertiseGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ) == PackageManager.PERMISSION_GRANTED
            return scanGranted && connectGranted && advertiseGranted
        }
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun safeDeviceName(device: BluetoothDevice): String? = try {
        device.name
    } catch (_: SecurityException) {
        null
    }

    fun stopBleMeshScan() {
        activeScanCallback?.let {
            try {
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(it)
            } catch (e: SecurityException) {
                Log.w(TAG, "Bluetooth permission revoked while stopping scan", e)
            } catch (e: Exception) {}
            activeScanCallback = null
        }
        clearNodes()
    }

    fun release() {
        mainHandler.removeCallbacks(pruningRunnable)
        stopBleMeshScan()
        stopPttTransmission()
        isRfcommServerRunning.set(false)
        try { rfcommServerSocket?.close() } catch (e: Exception) {}
        for ((_, socket) in activeRfcommSockets) {
            try { socket.close() } catch (e: Exception) {}
        }
        activeRfcommSockets.clear()

        try { gattServer?.close() } catch (e: SecurityException) {
            Log.w(TAG, "Bluetooth permission revoked while closing server", e)
        } catch (e: Exception) {}
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing audioTrack", e)
        }
    }
}
