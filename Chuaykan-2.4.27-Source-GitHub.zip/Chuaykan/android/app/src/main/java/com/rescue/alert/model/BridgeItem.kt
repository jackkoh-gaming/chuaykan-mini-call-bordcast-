package com.rescue.alert.model

enum class WaterLevelStatus(val label: String, val code: String) {
    CRITICAL_HIGH("วิกฤตน้ำล้นตลิ่ง", "CRITICAL_HIGH"),  // over bank or level 5
    WARNING_HIGH("เฝ้าระวังน้ำสูง", "WARNING_HIGH"),       // within 0.5m of bank or level 4
    NORMAL("เกณฑ์ปกติ", "NORMAL"),                         // level 3
    CRITICAL_LOW("ระดับน้ำต่ำ", "CRITICAL_LOW")            // level 1 or 2
}

data class BridgeItem(
    val id: String,
    val name: String,
    val province: String,
    val region: String,
    val river: String,
    val waterLevelMsl: Double,
    val diffBankM: Double,
    val diffBankText: String,
    val situationLevel: Int,
    val dateStr: String,
    val isLiveTelemetry: Boolean = false
) {
    val status: WaterLevelStatus
        get() = when {
            situationLevel >= 5 || diffBankM <= 0.0 -> WaterLevelStatus.CRITICAL_HIGH
            situationLevel == 4 || diffBankM <= 0.5 -> WaterLevelStatus.WARNING_HIGH
            situationLevel == 3 -> WaterLevelStatus.NORMAL
            else -> WaterLevelStatus.CRITICAL_LOW
        }
}
