package com.rescue.alert.bluetooth

import com.rescue.alert.model.MeshNode
import com.rescue.alert.model.MeshNodeType

/**
 * Shared helper for formatting Bluetooth Mesh status headers, badges, and telemetry.
 * Used by both UI dialogs and unit tests (F-14).
 */
object MeshTelemetryHelper {

    fun formatStatusHeader(nodes: List<MeshNode>): Pair<String, String> {
        val hasEoc = nodes.any {
            it.nodeType == MeshNodeType.RESCUE_POST ||
            it.nodeId == "EOC_GATEWAY_HQ" ||
            it.houseName.contains("EOC", ignoreCase = true)
        }
        val eocNode = nodes.find {
            it.nodeType == MeshNodeType.RESCUE_POST ||
            it.nodeId == "EOC_GATEWAY_HQ" ||
            it.houseName.contains("EOC", ignoreCase = true)
        }
        val neighborCount = nodes.count { it != eocNode }

        return when {
            hasEoc && neighborCount > 0 -> Pair(
                "เชื่อมต่อศูนย์สั่งการ EOC (RescueAlert-EOC-Gateway) [VERIFIED] • เมช $neighborCount หลัง",
                "#38BDF8"
            )
            hasEoc -> Pair(
                "เชื่อมต่อศูนย์สั่งการ EOC (RescueAlert-EOC-Gateway) [VERIFIED]",
                "#38BDF8"
            )
            nodes.isNotEmpty() -> Pair(
                "เครือข่ายบลูทูธเมช: เชื่อมต่อ ${nodes.size} หลังคาเรือน",
                "#34D399"
            )
            else -> Pair(
                "เครือข่ายบลูทูธเมช: กำลังสแกนค้นหาอุปกรณ์...",
                "#94A3B8"
            )
        }
    }

    fun formatTopBarBadge(nodes: List<MeshNode>): Pair<String, String> {
        val hasEoc = nodes.any {
            it.nodeType == MeshNodeType.RESCUE_POST ||
            it.nodeId == "EOC_GATEWAY_HQ" ||
            it.houseName.contains("EOC", ignoreCase = true)
        }
        return when {
            hasEoc -> Pair("EOC", "#38BDF8")
            nodes.isNotEmpty() -> Pair("MESH (${nodes.size})", "#10B981")
            else -> Pair("MESH", "#94A3B8")
        }
    }

    fun getDistanceRangeLabel(distanceMeters: Int): String {
        return when {
            distanceMeters <= 4 -> "ใกล้"
            distanceMeters <= 15 -> "กลาง"
            else -> "ไกล"
        }
    }
}
