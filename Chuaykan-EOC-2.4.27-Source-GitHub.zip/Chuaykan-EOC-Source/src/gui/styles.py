#!/usr/bin/env python3
"""
Cyber-Tactical Command Deck Theme & Styling (QSS)
Ultra-Modern C4I Operations Center Design System
Unified Slate Navy & Cyber Accent Palette - Zero Black Insets
"""

from src.core.config import (
    COLOR_BG_DARK, COLOR_CARD_BG, COLOR_CARD_ELEVATED, COLOR_INPUT_BG,
    COLOR_BTN_SURFACE, COLOR_BTN_HOVER, COLOR_BORDER, COLOR_BORDER_FOCUS,
    COLOR_EMERGENCY_RED, COLOR_EMERGENCY_RED_PULSE, COLOR_FLOOD_BLUE,
    COLOR_FLOOD_CYAN, COLOR_ALERT_AMBER, COLOR_SIGNAL_GREEN,
    COLOR_TEXT_WHITE, COLOR_TEXT_SECONDARY, COLOR_TEXT_MUTED
)

TACTICAL_QSS = f"""
/* ============================================================ */
/* GLOBAL BASE & TYPOGRAPHY                                    */
/* ============================================================ */
QWidget {{
    color: {COLOR_TEXT_WHITE};
    font-family: 'Sarabun', 'Ubuntu', 'Segoe UI', sans-serif;
    font-size: 13px;
    selection-background-color: {COLOR_FLOOD_BLUE};
    selection-color: #FFFFFF;
}}

QMainWindow, QWidget#centralWidget, QDialog {{
    background-color: {COLOR_BG_DARK};
}}

QLabel {{
    background: transparent;
}}

/* ============================================================ */
/* CARDS & GLASS PANELS                                         */
/* ============================================================ */
QFrame#panelCard {{
    background-color: {COLOR_CARD_BG};
    border: 1px solid {COLOR_BORDER};
    border-radius: 8px;
}}

QFrame#elevatedCard {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {COLOR_CARD_ELEVATED}, stop:1 #1A2844);
    border: 1px solid rgba(0, 242, 254, 0.3);
    border-radius: 8px;
}}

QFrame#dangerCard {{
    background-color: rgba(239, 68, 68, 0.12);
    border: 1px solid rgba(239, 68, 68, 0.55);
    border-radius: 8px;
}}

/* KPI Monolith Card */
QFrame#kpiCard {{
    background-color: {COLOR_CARD_ELEVATED};
    border: 1px solid {COLOR_BORDER};
    border-radius: 6px;
    padding: 4px 8px;
}}

QFrame#kpiCardRed {{
    background-color: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.6);
    border-radius: 6px;
}}

QFrame#kpiCardAmber {{
    background-color: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.6);
    border-radius: 6px;
}}

QFrame#kpiCardGreen {{
    background-color: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.6);
    border-radius: 6px;
}}

QFrame#kpiCardCyan {{
    background-color: rgba(2, 132, 199, 0.18);
    border: 1px solid rgba(0, 242, 254, 0.5);
    border-radius: 6px;
}}

/* ============================================================ */
/* HEADERS & LABELS                                             */
/* ============================================================ */
QLabel#headerTitle {{
    font-size: 14px;
    font-weight: 800;
    color: #FFFFFF;
    letter-spacing: 0.5px;
}}

QLabel#sectionTitle {{
    font-size: 12px;
    font-weight: bold;
    color: {COLOR_FLOOD_CYAN};
    text-transform: uppercase;
    letter-spacing: 0.8px;
}}

QLabel#subText {{
    font-size: 11.5px;
    color: {COLOR_TEXT_SECONDARY};
}}

QLabel#telemetryClock {{
    font-family: monospace, 'Sarabun';
    font-size: 12.5px;
    font-weight: bold;
    color: {COLOR_FLOOD_CYAN};
}}

/* ============================================================ */
/* TAB BAR & NAVIGATION                                         */
/* ============================================================ */
QTabWidget::pane {{
    border: 1px solid {COLOR_BORDER};
    background-color: {COLOR_CARD_BG};
    border-radius: 6px;
    top: -1px;
}}

QTabBar::tab {{
    background-color: {COLOR_CARD_ELEVATED};
    color: {COLOR_TEXT_SECONDARY};
    border: 1px solid {COLOR_BORDER};
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 7px 12px;
    margin-right: 2px;
    font-weight: bold;
    font-size: 11.5px;
}}

QTabBar::tab:selected {{
    background-color: {COLOR_CARD_BG};
    color: {COLOR_FLOOD_CYAN};
    border-top: 2px solid {COLOR_FLOOD_CYAN};
    border-left: 1px solid rgba(0, 242, 254, 0.35);
    border-right: 1px solid rgba(0, 242, 254, 0.35);
}}

QTabBar::tab:hover:!selected {{
    background-color: {COLOR_BTN_SURFACE};
    color: #FFFFFF;
}}

/* ============================================================ */
/* BUTTONS - UNIFIED SLATE NAVY SURFACES (NO BLACK INSETS)      */
/* ============================================================ */
QPushButton {{
    background-color: {COLOR_BTN_SURFACE};
    color: #F1F5F9;
    border: 1px solid #33476E;
    border-radius: 6px;
    padding: 6px 14px;
    font-weight: bold;
    min-height: 24px;
}}

QPushButton:hover {{
    background-color: {COLOR_BTN_HOVER};
    border-color: {COLOR_FLOOD_CYAN};
    color: #FFFFFF;
}}

QPushButton:pressed {{
    background-color: #18243C;
    border-color: {COLOR_FLOOD_BLUE};
}}

QPushButton#btnPrimary {{
    background-color: {COLOR_FLOOD_BLUE};
    border: 1px solid #38BDF8;
    color: #FFFFFF;
    font-weight: bold;
    border-radius: 6px;
}}
QPushButton#btnPrimary:hover {{
    background-color: #0369A1;
    border-color: #7DD3FC;
}}
QPushButton#btnPrimary:pressed {{
    background-color: #075985;
}}

QPushButton#btnEmergency {{
    background-color: #DC2626;
    border: 1px solid #F87171;
    color: #FFFFFF;
    font-size: 13px;
    font-weight: bold;
    border-radius: 6px;
}}
QPushButton#btnEmergency:hover {{
    background-color: #B91C1C;
    border-color: #FCA5A5;
}}
QPushButton#btnEmergency:pressed {{
    background-color: #991B1B;
}}

QPushButton#btnSuccess {{
    background-color: #059669;
    border: 1px solid #34D399;
    color: #FFFFFF;
    font-weight: bold;
    border-radius: 6px;
}}
QPushButton#btnSuccess:hover {{
    background-color: #047857;
    border-color: #6EE7B7;
}}
QPushButton#btnSuccess:pressed {{
    background-color: #065F46;
}}


/* ============================================================ */
/* INPUTS & CONTROLS - HARMONIZED WITH CARD ELEVATION           */
/* ============================================================ */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background-color: {COLOR_INPUT_BG};
    color: #FFFFFF;
    border: 1px solid #2A3C60;
    border-radius: 6px;
    padding: 5px 8px;
    font-family: 'Sarabun', 'Ubuntu', sans-serif;
    font-size: 12.5px;
    min-height: 26px;
}}

QDoubleSpinBox {{
    padding-right: 24px;
}}

QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    subcontrol-origin: border;
    width: 20px;
    background-color: {COLOR_BTN_SURFACE};
    border-left: 1px solid #2A3C60;
}}
QDoubleSpinBox::up-button {{
    subcontrol-position: top right;
}}
QDoubleSpinBox::down-button {{
    subcontrol-position: bottom right;
}}

QTextEdit {{
    background-color: {COLOR_INPUT_BG};
    color: #FFFFFF;
    border: 1px solid #2A3C60;
    border-radius: 6px;
    padding: 6px 8px;
    font-family: 'Sarabun', 'Ubuntu', sans-serif;
    font-size: 12px;
}}

QLineEdit:focus, QDoubleSpinBox:focus, QComboBox:focus, QTextEdit:focus {{
    border-color: {COLOR_BORDER_FOCUS};
    background-color: #203152;
}}

QComboBox::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: 1px solid #2A3C60;
}}

QComboBox QAbstractItemView {{
    background-color: {COLOR_CARD_ELEVATED};
    color: #FFFFFF;
    border: 1px solid #2B3E64;
    selection-background-color: {COLOR_FLOOD_BLUE};
    selection-color: #FFFFFF;
}}

/* ============================================================ */
/* SLIDERS                                                      */
/* ============================================================ */
QSlider::groove:horizontal {{
    height: 6px;
    background: {COLOR_INPUT_BG};
    border-radius: 3px;
}}
QSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {COLOR_FLOOD_BLUE}, stop:1 {COLOR_FLOOD_CYAN});
    border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background: #FFFFFF;
    border: 2px solid {COLOR_FLOOD_CYAN};
    width: 16px;
    margin-top: -5px;
    margin-bottom: -5px;
    border-radius: 8px;
}}

/* ============================================================ */
/* SCROLLBARS                                                   */
/* ============================================================ */
QScrollBar:vertical {{
    border: none;
    background: {COLOR_BG_DARK};
    width: 7px;
    margin: 0px;
}}
QScrollBar::handle:vertical {{
    background: #253554;
    min-height: 24px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLOR_FLOOD_CYAN};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}

/* ============================================================ */
/* TACTICAL BADGES                                              */
/* ============================================================ */
QLabel#badgeCritical {{
    background-color: rgba(239, 68, 68, 0.2);
    color: #FCA5A5;
    border: 1px solid {COLOR_EMERGENCY_RED};
    border-radius: 4px;
    padding: 2px 6px;
    font-size: 11px;
    font-weight: bold;
}}

QLabel#badgeWarning {{
    background-color: rgba(245, 158, 11, 0.2);
    color: #FDE68A;
    border: 1px solid {COLOR_ALERT_AMBER};
    border-radius: 4px;
    padding: 2px 6px;
    font-size: 11px;
    font-weight: bold;
}}

QLabel#badgeSafe {{
    background-color: rgba(16, 185, 129, 0.2);
    color: #A7F3D0;
    border: 1px solid {COLOR_SIGNAL_GREEN};
    border-radius: 4px;
    padding: 2px 6px;
    font-size: 11px;
    font-weight: bold;
}}

/* ============================================================ */
/* SPLITTER                                                     */
/* ============================================================ */
QSplitter::handle {{
    background-color: {COLOR_CARD_BG};
    border-left: 1px solid {COLOR_BORDER};
    border-right: 1px solid {COLOR_BORDER};
    width: 6px;
}}
"""
