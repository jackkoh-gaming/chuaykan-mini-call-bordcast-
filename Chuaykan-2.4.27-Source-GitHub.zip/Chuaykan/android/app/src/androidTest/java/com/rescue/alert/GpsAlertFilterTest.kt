package com.rescue.alert

import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.location.Location
import android.os.SystemClock
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.engine.AlertProcessingEngine
import com.rescue.alert.model.DisasterStateManager
import com.rescue.alert.source.area.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Synthetic inputs exercise decisions only; these tests never sound an alert. */
@RunWith(AndroidJUnit4::class)
class GpsAlertFilterTest {
    private val here = DeviceArea("57", "5701", "570102", "เชียงราย")
    private fun target(level: String = "tambon", p: String = "57", d: String = "5701", s: String = "570102") = AlertArea(level, p, d, s)
    private fun bulletin(event: String, areas: List<AlertArea>) = AreaBulletin(
        "test-gps-only", "แจ้งเตือนน้ำท่วม", "ขอให้ยกของขึ้นที่สูง", "ปภ.", event, event,
        System.currentTimeMillis(), areas, BulletinKind.WARNING, "น้ำท่วม")

    @Test fun exactSubdistrictMatches() {
        assertTrue(AreaAlertPolicy.matches(target(), here))
    }
    @Test fun otherProvinceDistrictAndSubdistrictStaySilent() {
        assertFalse(AreaAlertPolicy.matches(target(p = "50"), here))
        assertFalse(AreaAlertPolicy.matches(target(d = "5702"), here))
        assertFalse(AreaAlertPolicy.matches(target(s = "570103"), here))
    }
    @Test fun provinceAndDistrictAnnouncementsUseTheirDeclaredScope() {
        assertTrue(AreaAlertPolicy.matches(target("province", d = "", s = ""), here))
        assertTrue(AreaAlertPolicy.matches(target("amphoe", s = ""), here))
        assertFalse(AreaAlertPolicy.matches(target("amphoe", d = "5702", s = ""), here))
    }
    @Test fun missingOrUnknownCodesNeverBecomeNationwide() {
        assertFalse(AreaAlertPolicy.matches(target(p = ""), here))
        assertFalse(AreaAlertPolicy.matches(target(s = ""), here))
        assertFalse(AreaAlertPolicy.matches(target("nationwide"), here))
        assertFalse(AreaAlertPolicy.matches(target(), here.copy(subdistrict = null)))
        assertFalse(AreaAlertPolicy.matches(target(), here.copy(district = null)))
    }
    @Test fun praAndExaMustMatchAreaToo() {
        for (event in listOf("PRA", "EXA", "ASA", "ACI")) {
            assertFalse(bulletin(event, listOf(target(p = "50"))).isFor(here))
            assertFalse(bulletin(event, emptyList()).isFor(here))
            assertTrue(bulletin(event, listOf(target())).isFor(here))
        }
    }
    @Test fun newsExercisesAndAllClearDoNotRaiseDangerAlarms() {
        assertEquals(BulletinKind.EXERCISE, AreaAlertPolicy.classify("PRA", "ทดสอบระบบ", "ไม่ใช่สถานการณ์จริง"))
        assertEquals(BulletinKind.ALL_CLEAR, AreaAlertPolicy.classify("ALL", "ยุติแจ้งเตือน", ""))
        assertEquals(BulletinKind.INFORMATION, AreaAlertPolicy.classify("ACI", "ประชาสัมพันธ์", "ข่าวประจำวัน"))
        assertEquals(BulletinKind.WARNING, AreaAlertPolicy.classify("ACI", "เตือนน้ำท่วม", "ขอให้ยกของขึ้นที่สูง"))
    }
    @Test fun oldAndFutureRecordsStaySilent() {
        val now = System.currentTimeMillis()
        assertTrue(AreaAlertPolicy.isCurrent(now, now))
        assertFalse(AreaAlertPolicy.isCurrent(now + 1, now))
        assertFalse(AreaAlertPolicy.isCurrent(now - AreaAlertPolicy.NOTIFICATION_WINDOW_MS - 1, now))
    }
    @Test fun newMatchingAlertNotifiesOnceAndWaitsForGpsWithoutBroadeningArea() {
        val b = bulletin("EXA", listOf(target()))
        val now = System.currentTimeMillis()
        assertFalse(AreaAlertPolicy.canNotify(b, null, now, false))
        assertFalse(AreaAlertPolicy.canNotify(b, here.copy(province = "50"), now, false))
        assertTrue(AreaAlertPolicy.canNotify(b, here, now, false))
        assertFalse(AreaAlertPolicy.canNotify(b, here, now, true))
        assertFalse(AreaAlertPolicy.canNotify(b.copy(kind = BulletinKind.INFORMATION), here, now, false))
    }
    private fun fix() = Location("gps").apply {
        latitude = 19.91; longitude = 99.84; accuracy = 10f
        elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
        time = System.currentTimeMillis()
    }
    @Test fun freshGpsAcceptedButStaleInaccurateOrInvalidGpsRejected() {
        assertTrue(AreaLocation.usable(fix()))
        assertFalse(AreaLocation.usable(fix().apply { elapsedRealtimeNanos -= (AreaLocation.MAX_AGE_MS + 1000) * 1_000_000 }))
        assertFalse(AreaLocation.usable(fix().apply { accuracy = 1000f }))
        assertFalse(AreaLocation.usable(fix().apply { latitude = Double.NaN }))
        assertFalse(AreaLocation.usable(fix().apply { elapsedRealtimeNanos += 60_000_000_000 }))
        assertFalse(AreaLocation.usable(Location("gps")))
    }
    @Test fun permissionDeniedCannotUseCachedGpsOrRaiseOfficialAlarm() {
        val context = object : ContextWrapper(InstrumentationRegistry.getInstrumentation().targetContext) {
            override fun checkPermission(permission: String, pid: Int, uid: Int) = PackageManager.PERMISSION_DENIED
        }
        AreaLocation.accept(fix())
        assertNull(AreaLocation.current(context))
        val before = DisasterStateManager.getAlertId(context)
        assertEquals(AlertProcessingEngine.ProcessResult.DROPPED_LOCATION_UNAVAILABLE,
            AlertProcessingEngine.processOfficialCellBroadcast(context, bulletin("PRA", listOf(target())), JSONArray()))
        assertEquals(before, DisasterStateManager.getAlertId(context))
    }
    @Test fun notificationBoundaryRejectsExpiredAndExerciseRecords() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val b = bulletin("EXA", listOf(target()))
        assertEquals(AlertProcessingEngine.ProcessResult.DROPPED_EXPIRED_OR_REPLAY,
            AlertProcessingEngine.processOfficialCellBroadcast(context, b.copy(issuedAt = 1L), JSONArray()))
        assertEquals(AlertProcessingEngine.ProcessResult.DROPPED_NOT_ACTIONABLE,
            AlertProcessingEngine.processOfficialCellBroadcast(context, b.copy(kind = BulletinKind.EXERCISE), JSONArray()))
    }
    @Test fun officialNumericAreaCodesParseWithoutLosingScope() {
        val root = JSONObject("""{
          "fact_cb":[{"alert_id":"x","title":"เตือนน้ำท่วม","message_id":"m","sender_id":"s","event_id":"EXA","date_id":"D-20260929","time":"10:00"}],
          "dim_message":[{"message_id":"m","message_th":"ขอให้ยกของขึ้นที่สูง"}],
          "dim_sender":[{"sender_id":"s","sender_name":"ปภ."}],"dim_event":[],"dim_disaster":[],"dim_province":[],
          "bridge_alert_location":[{"alert_id":"x","level":"tambon","province_code":57,"amphoe_code":5701,"tambon_code":570102}]
        }""")
        val b = OfficialAreaFeed.parse(root).bulletins.single()
        assertTrue(b.isFor(here))
        assertFalse(b.isFor(here.copy(subdistrict = "570103")))
        assertFalse(b.isFor(here.copy(province = "50")))
    }
}
