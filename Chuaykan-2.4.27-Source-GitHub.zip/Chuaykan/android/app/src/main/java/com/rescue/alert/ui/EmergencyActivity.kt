package com.rescue.alert.ui

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.rescue.alert.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * Emergency Cell Broadcast Activity presented as a White Pop-up Box Modal
 * floating over a dimmed translucent backdrop with an official close button.
 * Zero emojis, clean typography, and strict official disaster information.
 */
class EmergencyActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private val TAG = "EmergencyActivity"
    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var vibrator: Vibrator? = null
    private var alertId: String? = null
    private var ttsInitRunnable: Runnable? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private val speechExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var speechClosed = false
    private var speechText = ""

    private lateinit var rootEmergencyLayout: FrameLayout
    private lateinit var cardEmergencyPopup: LinearLayout
    private lateinit var headerDangerBox: LinearLayout
    private lateinit var tvAlertHeaderBadge: TextView
    private lateinit var tvAlertTitle: TextView
    private lateinit var tvAlertTimestamp: TextView
    private lateinit var tvAlertInstruction: TextView
    private lateinit var tvAlertSubHeader: TextView
    private lateinit var tvAlertArea: TextView
    private lateinit var btnAcknowledgeEmergency: Button

    private var isRescued: Boolean = false

    private val rescueReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val senderPkg = intent.`package`
            if (senderPkg != null && senderPkg != context.packageName) {
                return
            }
            if (intent.action == "com.rescue.alert.ACTION_RESCUE_COMPLETED") {
                onRescueCompletedTransition()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Wake screen and display over lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? android.app.KeyguardManager
            if (km?.isKeyguardLocked == true) {
                km.requestDismissKeyguard(this, null)
            }
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_emergency)

        alertId = intent.getStringExtra("ALERT_ID") ?: "CRITICAL_ALERT"
        val rawTitle = intent.getStringExtra("TITLE") ?: "แจ้งเตือนภัยพิบัติฉุกเฉินระดับวิกฤตสูงสุด"
        val rawInstruction = intent.getStringExtra("INSTRUCTION") ?: "โปรดอพยพขึ้นสู่ที่ดอนหรืออาคารสูงทันที ยกสิ่งของขึ้นที่สูง ตัดกระแสไฟฟ้า และหลีกเลี่ยงเส้นทางน้ำหลากโดยเด็ดขาด"
        val sender = intent.getStringExtra("SENDER")?.takeIf { it.isNotBlank() } ?: "Thai Disaster EOC"
        val eventType = intent.getStringExtra("EVENT_TYPE")?.takeIf { it.isNotBlank() } ?: "GENERAL"
        val areaDesc = intent.getStringExtra("AREA_DESC")?.takeIf { it.isNotBlank() } ?: "พื้นที่ที่ระบุในประกาศ"

        // Strip any residual emoji characters for strict compliance
        val strippedTitle = stripEmojis(rawTitle)
        val cleanTitle = if (strippedTitle.isBlank()) "แจ้งเตือนภัยฉุกเฉิน" else strippedTitle
        val cleanInstruction = stripEmojis(rawInstruction)
        speechText = "$cleanTitle. $cleanInstruction"

        rootEmergencyLayout = findViewById(R.id.rootEmergencyLayout)
        cardEmergencyPopup = findViewById(R.id.cardEmergencyPopup)
        headerDangerBox = findViewById(R.id.headerDangerBox)
        tvAlertHeaderBadge = findViewById(R.id.tvAlertHeaderBadge)
        tvAlertTitle = findViewById(R.id.tvAlertTitle)
        tvAlertTimestamp = findViewById(R.id.tvAlertTimestamp)
        tvAlertInstruction = findViewById(R.id.tvAlertInstruction)
        tvAlertSubHeader = findViewById(R.id.tvAlertSubHeader)
        tvAlertArea = findViewById(R.id.tvAlertArea)
        btnAcknowledgeEmergency = findViewById(R.id.btnAcknowledgeEmergency)

        tvAlertTitle.text = cleanTitle
        tvAlertInstruction.text = cleanInstruction
        tvAlertSubHeader.text = "ออกประกาศโดย: " + sender
        tvAlertArea.text = "พื้นที่: " + areaDesc
        tvAlertHeaderBadge.text = "ช่วยกัน • แจ้งเตือน " + eventType.replace("_", " ")

        val timeFormat = SimpleDateFormat("HH:mm น.", Locale("th", "TH"))
        val formattedTime = timeFormat.format(Date())
        tvAlertTimestamp.text = "เวลาที่ออกประกาศ: วันนี้ $formattedTime"

        // Single Dismiss / Close Button
        btnAcknowledgeEmergency.setOnClickListener {
            dismissAlert()
        }

        // Sound & Vibration handling
        val isMuted = intent.getBooleanExtra("MUTE_SOUND", false)
        if (!isMuted) {
            startSirenSound()
            startSosVibration()
            ttsInitRunnable = Runnable {
                if (!isFinishing && !isDestroyed) {
                    enqueueSpeech {
                        if (!speechClosed) tts = TextToSpeech(applicationContext, this)
                    }
                }
            }
            uiHandler.postDelayed(ttsInitRunnable!!, 1800)
        }

        // Register Rescue Receiver
        // M-1: ContextCompat.registerReceiver ensures RECEIVER_NOT_EXPORTED is enforced across all Android versions
        val rescueFilter = IntentFilter("com.rescue.alert.ACTION_RESCUE_COMPLETED")
        ContextCompat.registerReceiver(
            this,
            rescueReceiver,
            rescueFilter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    /**
     * Requirement: Modal transitions to safe green state, displays "คุณปลอดภัยแล้ว ได้รับการช่วยเหลือเรียบร้อย",
     * shows for 3-4 seconds, and automatically finishes back to main screen.
     */
    private fun onRescueCompletedTransition() {
        runOnUiThread {
            isRescued = true
            cleanupSound()

            // Resolve active disaster state
            com.rescue.alert.model.DisasterStateManager.setDisasterResolved(this)
            val stateIntent = Intent("com.rescue.alert.ACTION_DISASTER_STATE_CHANGED").apply {
                putExtra("IS_ACTIVE", false)
                setPackage(packageName)
            }
            sendBroadcast(stateIntent)

            // Transition header to Safe Green
            headerDangerBox.setBackgroundColor(Color.parseColor("#ECFDF5"))

            tvAlertHeaderBadge.text = "RESCUE OPERATION COMPLETED"
            tvAlertHeaderBadge.setTextColor(Color.parseColor("#059669"))

            tvAlertTitle.text = getString(R.string.emergency_rescued_title)
            tvAlertTitle.setTextColor(Color.parseColor("#065F46"))

            tvAlertInstruction.text = getString(R.string.emergency_rescued_closing)
            tvAlertInstruction.setTextColor(Color.parseColor("#1E293B"))

            btnAcknowledgeEmergency.text = "ตกลง (ปิดอัตโนมัติใน 3 วินาที...)"
            btnAcknowledgeEmergency.isEnabled = false
            btnAcknowledgeEmergency.setBackgroundColor(Color.parseColor("#059669"))
            btnAcknowledgeEmergency.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#047857"))

            // Automatically close back to main screen after 3.5 seconds
            uiHandler.postDelayed({
                dismissAlert()
            }, 3500)
        }
    }

    private fun dismissAlert() {
        alertId?.let {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(it.hashCode())
        }
        cleanupResources()
        finish()
    }

    private fun startSirenSound() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxVolume, 0)

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(
                    this@EmergencyActivity,
                    Uri.parse("android.resource://$packageName/${R.raw.siren_critical}")
                )
                isLooping = true
                setOnPreparedListener { mp ->
                    try {
                        mp.start()
                    } catch (e: Exception) {}
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Siren playback failed: ${e.message}")
        }
    }

    private fun startSosVibration() {
        val pattern = longArrayOf(
            0, 200, 200, 200, 200, 200, 400,
            600, 200, 600, 200, 600, 400,
            200, 200, 200, 200, 200, 1000
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
            vibrator = vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(android.os.VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS && !speechClosed) {
            enqueueSpeech {
                if (!speechClosed) {
                    tts?.language = Locale("th", "TH")
                    tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "ALERT_TTS")
                }
            }
            uiHandler.post {
                if (!speechClosed) mediaPlayer?.setVolume(0.25f, 0.25f)
            }
        }
    }

    private fun enqueueSpeech(action: () -> Unit) {
        try { speechExecutor.execute(action) }
        catch (_: RejectedExecutionException) { /* Activity has already closed. */ }
    }

    private fun stripEmojis(text: String): String {
        return text.replace(Regex("[\\p{So}\\p{Cn}\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\u2600-\\u26FF\\u2700-\\u27BF\\uFE00-\\uFE0F\\u200D\\u20E3\\u2139]+"), "").trim()
    }

    private fun cleanupSound() {
        speechClosed = true
        ttsInitRunnable?.let { uiHandler.removeCallbacks(it) }
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {}

        try {
            vibrator?.cancel()
            vibrator = null
        } catch (e: Exception) {}

        enqueueSpeech {
            val speech = tts
            tts = null
            try { speech?.stop() } catch (e: Exception) { Log.w(TAG, "Speech stop failed", e) }
            try { speech?.shutdown() } catch (e: Exception) { Log.w(TAG, "Speech shutdown failed", e) }
        }
    }

    private fun cleanupResources() {
        cleanupSound()
        try {
            unregisterReceiver(rescueReceiver)
        } catch (e: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacksAndMessages(null)
        cleanupResources()
        speechExecutor.shutdown()
    }
}
