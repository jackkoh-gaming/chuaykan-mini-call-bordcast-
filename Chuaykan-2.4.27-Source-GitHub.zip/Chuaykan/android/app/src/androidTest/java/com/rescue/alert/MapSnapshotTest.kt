package com.rescue.alert

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.data.EvacuationSiteRepository
import com.rescue.alert.model.EvacuationSite
import com.rescue.alert.util.AppSettings
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

/** Isolated preferences/repository: never adds a site to the operating EOC or phone map. */
@RunWith(AndroidJUnit4::class)
class MapSnapshotTest {
    private fun isolated(action: (Context, EvacuationSiteRepository) -> Unit) {
        val app = InstrumentationRegistry.getInstrumentation().targetContext
        val prefix = "map_snapshot_${UUID.randomUUID()}_"
        val names = mutableSetOf<String>()
        val context = object : ContextWrapper(app) {
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                names.add(prefix + name)
                return app.getSharedPreferences(prefix + name, mode)
            }
        }
        val constructor = EvacuationSiteRepository::class.java.getDeclaredConstructor(Context::class.java)
            .apply { isAccessible = true }
        try { action(context, constructor.newInstance(context)) } finally {
            names.forEach { app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit() }
        }
    }

    @Test fun emptySnapshotRemovesSitesAndNotifiesWithoutRestart() = isolated { context, repo ->
        val gateway = AppSettings.getGatewayBaseUrl(context)
        val site = EvacuationSite("ISOLATED_SITE", "isolated", "SHELTER", 13.0, 100.0)
        assertTrue(repo.applyGatewaySnapshot(JSONObject().put("sites", JSONArray().put(site.toJsonObject())), 0, gateway))
        val notifications = mutableListOf<List<EvacuationSite>>()
        repo.addListener { notifications.add(it) }
        assertTrue(repo.applyGatewaySnapshot(JSONObject().put("sites", JSONArray()), 0, gateway))
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        assertTrue(repo.getAllActiveSites().isEmpty())
        assertTrue(notifications.any { it.isEmpty() })
        assertEquals("[]", context.getSharedPreferences("evacuation_sites_prefs", Context.MODE_PRIVATE)
            .getString("verified_sites_json_v2", null))
    }

    @Test fun invalidOrStaleSnapshotCannotEraseNewerSites() = isolated { context, repo ->
        val site = EvacuationSite("ISOLATED_SITE", "isolated", "SHELTER", 13.0, 100.0)
        repo.upsertSite(site)
        assertFalse(repo.applyGatewaySnapshot(JSONObject().put("sites", JSONArray()), 0, AppSettings.getGatewayBaseUrl(context)))
        try { repo.applyGatewaySnapshot(JSONObject(), 1, AppSettings.getGatewayBaseUrl(context)); fail("Malformed snapshot must fail") }
        catch (_: org.json.JSONException) { }
        assertEquals(listOf(site), repo.getAllActiveSites())
    }

    @Test fun unchangedSnapshotDoesNotRedrawMap() = isolated { context, repo ->
        val gateway = AppSettings.getGatewayBaseUrl(context)
        val snapshot = JSONObject().put("sites", JSONArray())
        var redraws = 0
        repo.addListener { redraws++ }
        assertTrue(repo.applyGatewaySnapshot(snapshot, 0, gateway))
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        assertEquals(0, redraws)
    }
}
