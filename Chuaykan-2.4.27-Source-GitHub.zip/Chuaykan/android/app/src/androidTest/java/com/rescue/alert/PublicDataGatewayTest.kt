package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rescue.alert.network.PublicDataGateway
import com.rescue.alert.network.SecureGateway
import com.rescue.alert.util.AppSettings
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.net.URL

/** Read-only public data and rejected private parameters; never submits SOS. */
@RunWith(AndroidJUnit4::class)
class PublicDataGatewayTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun officialRecordsComeThroughOracle() {
        PublicDataGateway.initialize(context)
        val conn = PublicDataGateway.open(URL("https://academicndwc.github.io/CBS-DashBoard/data/data.json"))
        conn.connectTimeout = 10000; conn.readTimeout = 20000
        try {
            assertEquals("gateway.example.org", conn.url.host)
            assertEquals(200, conn.responseCode)
            assertNotNull(conn.getHeaderField("X-Public-Cache-Age"))
            val data = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            assertNotNull(data.optJSONArray("fact_cb"))
        } finally { conn.disconnect() }
    }

    @Test fun privateParametersAreRefusedByServer() {
        val conn = SecureGateway.open(context, URL(AppSettings.DEFAULT_GATEWAY_URL + "/api/public-data?source=official&name=isolated_private_fixture"))
        conn.connectTimeout = 5000; conn.readTimeout = 5000
        try { assertEquals(400, conn.responseCode) } finally { conn.disconnect() }
    }

    @Test fun nbtcPublicCatalogStillWorksOnPhone() {
        PublicDataGateway.initialize(context)
        val conn = PublicDataGateway.open(URL("https://datacatalog.nbtc.go.th/api/3/action/datastore_search?resource_id=fffc25e6-660f-4874-a874-a8f15e5303df&limit=1&offset=0"))
        conn.connectTimeout = 10000; conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "RescueAlert-Tactical/2.4 (NBTC-Client)")
        try {
            assertEquals(200, conn.responseCode)
            val data = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            assertTrue(data.getBoolean("success"))
            assertTrue(data.getJSONObject("result").getJSONArray("records").length() > 0)
        } finally { conn.disconnect() }
    }

    @Test fun unrelatedHostsAndPersonalQueriesAreRejectedLocally() {
        PublicDataGateway.initialize(context)
        for (value in listOf("http://app.rid.go.th/reservoir/api/dam/public",
            "https://unapproved.invalid/private", "https://app.rid.go.th/reservoir/api/dam/public?name=fixture")) {
            try { PublicDataGateway.open(URL(value)); fail("Unsafe request accepted") }
            catch (_: IllegalArgumentException) {} catch (_: IllegalStateException) {}
        }
    }
}
