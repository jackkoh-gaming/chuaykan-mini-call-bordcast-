package com.rescue.alert.source.area

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class AreaBulletin(
    val id: String, val title: String, val message: String, val sender: String,
    val event: String, val eventName: String, val issuedAt: Long, val areas: List<AlertArea>,
    val kind: BulletinKind, val disaster: String
) {
    fun isFor(device: DeviceArea) = areas.any { AreaAlertPolicy.matches(it, device) }
    val notificationKey: String get() = "$id:${(title + message + areas.toString()).hashCode()}"
}

data class AreaFeed(val bulletins: List<AreaBulletin>, val provinces: JSONArray)

object OfficialAreaFeed {
    const val DASHBOARD = "https://academicndwc.github.io/CBS-DashBoard/"
    private const val SNAPSHOT = "${DASHBOARD}data/data.json"
    private const val API = "https://script.google.com/macros/s/AKfycbypPalKcGpXQXvrGqo3-NFTRfGdhShklY_vrGMwLRsAvQugFaV6-gApi6M-S6MBI5hE6Q/exec?type=data"
    @Volatile private var cached: AreaFeed? = null
    @Volatile var fetchedAt = 0L
        private set

    @Synchronized fun fetch(context: Context, force: Boolean = false): AreaFeed {
        if (!force && cached != null && System.currentTimeMillis() - fetchedAt < 15 * 60_000) return cached!!
        val body = try { readHttps(SNAPSHOT) } catch (_: Exception) { readHttps(API) }
        val result = parse(JSONObject(body))
        // Only a successfully parsed official response replaces the last source snapshot.
        val saved = android.util.AtomicFile(java.io.File(context.filesDir, "official_cb_snapshot.json"))
        val output = saved.startWrite()
        try {
            output.write(body.toByteArray(Charsets.UTF_8))
            saved.finishWrite(output)
        } catch (error: Exception) { saved.failWrite(output); throw error }
        fetchedAt = System.currentTimeMillis()
        cached = result
        android.util.Log.i("AreaAlerts", "SOURCE_REFRESH records=${result.bulletins.size} fetchedAt=$fetchedAt")
        return result
    }

    fun parse(root: JSONObject): AreaFeed {
        val facts = root.getJSONArray("fact_cb")
        val messages = index(root.getJSONArray("dim_message"), "message_id")
        val senders = index(root.getJSONArray("dim_sender"), "sender_id")
        val events = index(root.getJSONArray("dim_event"), "event_id")
        val disasters = index(root.getJSONArray("dim_disaster"), "disaster_id")
        val areas = rows(root.getJSONArray("bridge_alert_location")).groupBy { it.optString("alert_id") }
        val dateFormat = SimpleDateFormat("yyyyMMdd HH:mm", Locale.US).apply {
            isLenient = false; timeZone = TimeZone.getTimeZone("Asia/Bangkok")
        }
        val result = rows(facts).mapNotNull { row ->
            val id = row.optString("alert_id")
            val title = row.optString("title")
            val message = messages[row.optString("message_id")]?.optString("message_th").orEmpty()
            val sender = senders[row.optString("sender_id")]?.optString("sender_name").orEmpty()
            val event = row.optString("event_id")
            if (id.isBlank() || title.isBlank() || message.isBlank() || sender.isBlank()) return@mapNotNull null
            val date = row.optString("date_id").removePrefix("D-")
            val time = row.optString("time")
            if (!Regex("[0-9]{8}").matches(date) || !Regex("[0-9]{2}:[0-9]{2}(:[0-9]{2})?").matches(time)) return@mapNotNull null
            val issued = try { dateFormat.parse("$date ${time.take(5)}")?.time } catch (_: Exception) { null } ?: return@mapNotNull null
            AreaBulletin(id, title, message, sender, event, events[event]?.optString("event_th").orEmpty(), issued,
                areas[id].orEmpty().map { AlertArea(it.optString("level"), code(it, "province_code"), code(it, "amphoe_code"), code(it, "tambon_code")) },
                AreaAlertPolicy.classify(event, title, message), disasters[row.optString("disaster_id")]?.optString("disaster_name").orEmpty())
        }.sortedByDescending { it.issuedAt }
        return AreaFeed(result, root.getJSONArray("dim_province"))
    }

    private fun code(row: JSONObject, key: String): String = row.optString(key).takeIf { it.matches(Regex("[0-9]+")) }.orEmpty()
    private fun rows(array: JSONArray) = (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    private fun index(array: JSONArray, key: String) = rows(array).associateBy { it.optString(key) }

    private fun readHttps(start: String): String {
        var url = URL(start)
        repeat(6) {
            check(url.protocol == "https" && (url.host == "academicndwc.github.io" || url.host == "script.google.com" || url.host == "script.googleusercontent.com")) { "Untrusted feed redirect" }
            val connection = (com.rescue.alert.network.PublicDataGateway.open(url) as HttpURLConnection).apply {
                connectTimeout = 12_000; readTimeout = 20_000; instanceFollowRedirects = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "RescueAlert/${com.rescue.alert.BuildConfig.VERSION_NAME}")
                setRequestProperty("Cache-Control", "no-cache")
                useCaches = false
            }
            try {
                val status = connection.responseCode
                if (status in 300..399) {
                    url = URL(url, connection.getHeaderField("Location") ?: error("Missing redirect"))
                } else {
                    check(status == 200) { "Official feed HTTP $status" }
                    val bytes = connection.inputStream.use { it.readBytes() }
                    check(bytes.size <= 8 * 1024 * 1024) { "Feed too large" }
                    return bytes.toString(Charsets.UTF_8)
                }
            } finally { connection.disconnect() }
        }
        error("Too many feed redirects")
    }
}
