Third-party notices

The root MIT license applies to original project code only. It does not replace
licenses of dependencies, map data, public news, fonts or third-party assets.

Leaflet 1.9.4: BSD-2-Clause; see licenses/Leaflet-BSD-2-Clause.txt.
Gradle wrapper, AndroidX and Firebase/Google Android SDK components: retain
upstream notices; see licenses/Apache-2.0.txt and each dependency's license.
PySide6/Qt: LGPLv3/GPLv3/commercial terms, installed separately, not bundled in
this source archive. https://doc.qt.io/qtforpython-6/licenses.html
Python: PSF license. BlueZ/D-Bus/GObject components use their upstream licenses.
Map tiles and OpenStreetMap data retain their provider attribution and terms.
Official Thai disaster data remains subject to its source terms; it is not
relicensed by this project's MIT license. Source reference is included with
android/app/src/main/assets/official_cb_geo.source.txt.
Do not remove map attribution when modifying or redistributing.
