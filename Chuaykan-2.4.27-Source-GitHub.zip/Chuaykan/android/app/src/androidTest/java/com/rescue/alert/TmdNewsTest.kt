package com.rescue.alert

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.rescue.alert.data.TmdNewsFeed
import com.rescue.alert.data.DisasterNewsRepository as News
import com.rescue.alert.model.DisasterNewsItem
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class TmdNewsTest {
    @Test fun channelClockDoesNotInventItemPublicationDate() {
        val xml = """<rss><channel><pubDate>Thu, 01 Oct 2026 23:59:59 +0700</pubDate><item><title>ฝนตกหนัก</title><guid>T1</guid><link>https://www.tmd.go.th/uploads/CAP/T1.xml</link><description>ข้อความต้นทาง</description><pubDate>Wed, 30 Sep 2026 09:32:00 +0700</pubDate></item></channel></rss>"""
        val item = TmdNewsFeed.parse(xml).single()
        assertEquals("20260930 09:32", item.dateStr)
        assertEquals("ข้อความต้นทาง", item.details)
        assertEquals("https://www5.tmd.go.th/uploads/CAP/T1.xml", item.webUrl)
        assertFalse(item.isLive)
    }
    @Test fun missingDatesAndNonOfficialLinksAreNotInvented() {
        val xml = """<rss><channel><item><title>test</title><guid>1</guid><link>https://example.com/a</link><pubDate>Wed, 30 Sep 2026 09:32:00 +0700</pubDate></item><item><title>test</title><guid>2</guid><link>https://www.tmd.go.th/uploads/CAP/2.xml</link></item></channel></rss>"""
        assertTrue(TmdNewsFeed.parse(xml).isEmpty())
        assertTrue(TmdNewsFeed.parse("<rss><channel/></rss>").isEmpty())
    }
    @Test fun realPhoneTmdNewsAndDocumentIdentifiersMatch() {
        val raw = URL(TmdNewsFeed.URL).openConnection().apply { connectTimeout=10000; readTimeout=15000 }
            .getInputStream().bufferedReader().use { it.readText() }
        val original = TmdNewsFeed.parse(raw)
        assertTrue("No real TMD CAP news", original.isNotEmpty())
        val latch = CountDownLatch(1)
        var merged = emptyList<DisasterNewsItem>()
        News.getNews(true) { merged=it; latch.countDown() }
        assertTrue(latch.await(90, TimeUnit.SECONDS))
        assertFalse(News.lastError.orEmpty().contains("กรมอุตุฯ"))
        val today = News.recentOnly(original)
        assertEquals(today, merged.filter { it.id.startsWith("TMD_") })
        val item = original.first()
        val document = URL(item.webUrl).openConnection().apply { connectTimeout=10000; readTimeout=15000 }
            .getInputStream().bufferedReader().use { it.readText() }
        assertTrue("CAP document does not match RSS identifier", document.contains(item.id.removePrefix("TMD_")))
    }
}
