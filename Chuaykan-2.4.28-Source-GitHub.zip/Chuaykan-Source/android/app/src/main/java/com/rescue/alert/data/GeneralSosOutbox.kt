package com.rescue.alert.data

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import com.rescue.alert.bluetooth.BluetoothMeshManager
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import com.rescue.alert.model.DisasterStateManager
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/** One durable general rescue request, independent of the critical-patient outbox. */
object GeneralSosOutbox {
    internal const val RESCUE_COOLDOWN_MS = 3L * 24 * 60 * 60 * 1000
    private val busy = AtomicBoolean(false)
    @Volatile private var lastAttempt = 0L
    private fun file(context: Context) = AtomicFile(File(context.filesDir, "general_sos_pending.json"))
    private fun prefs(context: Context) = context.getSharedPreferences("general_sos_receipts", Context.MODE_PRIVATE)

    @Synchronized fun queue(context: Context, payload: JSONObject): String {
        check(!isCompleted(context)) { "SOS is hidden after rescue completion" }
        val saved = file(context)
        val existing = prefs(context).getString("latest", "").orEmpty()
        if (existing.isNotBlank() && !prefs(context).getBoolean("needs_resend", false)) return existing
        if (saved.baseFile.exists()) return JSONObject(saved.readFully().toString(Charsets.UTF_8)).getString("case_id")
        val id = "GENERAL_${UUID.randomUUID()}"
        payload.put("case_id", id).put("case_type", "GENERAL")
        require(payload.toString().toByteArray(Charsets.UTF_8).size <= 32000 &&
            payload.optString("contact_name").toByteArray(Charsets.UTF_8).size <= 255) { "SOS profile is too large" }
        val output = saved.startWrite()
        try {
            output.write(payload.toString().toByteArray(Charsets.UTF_8))
            saved.finishWrite(output)
        } catch (error: Exception) { saved.failWrite(output); throw error }
        check(prefs(context).edit().putString("latest", id).putBoolean("accepted", false).putBoolean("needs_resend", false).putBoolean("has_gps", !payload.isNull("lat") && !payload.isNull("lng")).commit())
        lastAttempt = 0L
        return id
    }

    @Synchronized fun acknowledge(context: Context, id: String) {
        val saved = file(context)
        if (!saved.baseFile.exists()) return
        val pending = JSONObject(saved.readFully().toString(Charsets.UTF_8))
        if (pending.getString("case_id") != id) return
        check(prefs(context).edit().putString("latest", id).putBoolean("accepted", true).commit())
        // Keep the original request until rescue completes, so it survives a gateway migration.
    }

    fun hasPending(context: Context): Boolean = !isCompleted(context) && prefs(context).getString("latest", "").orEmpty().isNotBlank() && !prefs(context).getBoolean("needs_resend", false)
    @Synchronized fun isCompleted(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        val state = prefs(context)
        if (!state.getBoolean("completed", false)) return false
        if (!state.contains("completed_at")) {
            // Legacy completed receipts did not record a time; start their cooldown once.
            check(state.edit().putLong("completed_at", now).commit())
            return true
        }
        val completedAt = state.getLong("completed_at", now)
        if (now >= completedAt && now - completedAt >= RESCUE_COOLDOWN_MS) {
            file(context).delete()
            check(state.edit().clear().commit())
            lastAttempt = 0L
            return false
        }
        return true
    }
    fun suppressesSos(context: Context): Boolean = isCompleted(context)

    @Synchronized fun acknowledgeCritical(context: Context, id: String, status: String) {
        if (!id.startsWith("CRITICAL_") || isCompleted(context)) return
        check(prefs(context).edit().putString("critical_latest", id).commit())
        applyStatus(context, id, status)
    }

    @Synchronized fun applyStatus(context: Context, id: String, status: String) {
        val completed = isCompleted(context)
        if (id != prefs(context).getString("latest", "") && id != prefs(context).getString("critical_latest", "")) return
        if (status == "RESCUED_SAFE") {
            if (!completed) {
                check(prefs(context).edit().putBoolean("completed", true).putBoolean("show_safe", true)
                    .putLong("completed_at", System.currentTimeMillis())
                    .putString("resolved_alert", DisasterStateManager.getAlertId(context)).commit())
            }
            file(context).delete()
        } else if (!completed) acknowledge(context, id)
    }

    @Synchronized fun consumeSafeScreen(context: Context): Boolean {
        if (!isCompleted(context)) return false
        if (!prefs(context).getBoolean("show_safe", false)) return false
        return prefs(context).edit().putBoolean("show_safe", false).commit()
    }

    fun status(context: Context): String {
        val state = prefs(context)
        return when {
            isCompleted(context) -> "คุณปลอดภัย ได้รับการช่วยเหลือแล้ว"
            state.getBoolean("needs_resend", false) -> "คำขอเดิมไม่อยู่ในคิวแล้ว • พร้อมส่งคำขอใหม่"
            state.getBoolean("accepted", false) -> "ศูนย์ EOC ตอบรับข้อมูลแล้ว • อยู่ในคิวรอช่วยเหลือทั่วไป" +
                if (state.getBoolean("has_gps", false)) "" else " • ไม่มีพิกัด GPS ผู้ขอช่วยเหลือ"
            file(context).baseFile.exists() -> "บันทึกคำขอแล้ว • รอศูนย์ EOC ตอบรับ จะส่งซ้ำเมื่อเชื่อมต่อได้"
            else -> ""
        }
    }

    @Synchronized fun pendingUpload(context: Context): JSONObject? =
        if (!prefs(context).getBoolean("accepted", false) && file(context).baseFile.exists())
            JSONObject(file(context).readFully().toString(Charsets.UTF_8)) else null

    @Synchronized fun markMissing(context: Context, id: String) {
        if (prefs(context).getString("latest", "") == id && !isCompleted(context)) {
            file(context).delete()
            check(prefs(context).edit().putBoolean("accepted", false).putBoolean("needs_resend", true).commit())
        }
    }

    fun retry(context: Context) {
        val app = context.applicationContext
        if (isCompleted(app)) return
        val criticalId = prefs(app).getString("critical_latest", "").orEmpty()
        if ( (!hasPending(app) && criticalId.isBlank()) || System.currentTimeMillis() - lastAttempt < 10_000 || !busy.compareAndSet(false, true)) return
        lastAttempt = System.currentTimeMillis()
        Thread {
            try {
                val payload = if (hasPending(app)) pendingUpload(app) else null
                val mesh = BluetoothMeshManager.getInstance(app)
                val caseId = if (hasPending(app)) prefs(app).getString("latest", "").orEmpty() else criticalId
                if (payload != null) mesh.sendGeneralSos(payload) else mesh.queryGeneralSos(caseId)
                if (criticalId.isNotBlank() && criticalId != caseId && EmergencyOutboxManager.isNetworkAvailable(app)) {
                    val statusUrl = com.rescue.alert.util.AppSettings.getGatewayBaseUrl(app).trimEnd('/') +
                        "/api/sos/status?case_id=" + URLEncoder.encode(criticalId, "UTF-8") +
                        "&device_id=" + URLEncoder.encode(mesh.myNodeId, "UTF-8")
                    val statusConn = com.rescue.alert.network.SecureGateway.open(app, URL(statusUrl))
                    try {
                        statusConn.connectTimeout = 5000; statusConn.readTimeout = 5000
                        if (statusConn.responseCode in 200..299) {
                            val result = JSONObject(statusConn.inputStream.bufferedReader().use { it.readText() })
                            if (result.optString("status") == "SUCCESS" && result.optString("case_id") == criticalId)
                                applyStatus(app, criticalId, result.optString("case_status", "PENDING"))
                        }
                    } finally { statusConn.disconnect() }
                }
                if (!isCompleted(app) && EmergencyOutboxManager.isNetworkAvailable(app)) {
                    val endpoint = if (payload != null) EmergencyOutboxManager.getPrimarySosUrl(app) else
                        com.rescue.alert.util.AppSettings.getGatewayBaseUrl(app).trimEnd('/') + "/api/sos/status?case_id=" +
                        URLEncoder.encode(caseId, "UTF-8") + "&device_id=" + URLEncoder.encode(mesh.myNodeId, "UTF-8")
                    val conn = com.rescue.alert.network.SecureGateway.open(app, URL(endpoint))
                    try {
                        conn.requestMethod = if (payload != null) "POST" else "GET"
                        conn.doOutput = payload != null
                        conn.connectTimeout = 5000; conn.readTimeout = 5000
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        if (payload != null) conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                        if (conn.responseCode in 200..299) {
                            val result = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                            if (result.optString("status") == "SUCCESS" && result.optString("case_id") == caseId) {
                                applyStatus(app, caseId, result.optString("case_status", "PENDING"))
                            }
                        } else if (payload == null && conn.responseCode == 404) {
                            markMissing(app, caseId)
                        }
                    } finally { conn.disconnect() }
                }
            } catch (_: Exception) {
                Log.w("GeneralSos", "Request remains pending until EOC acknowledges it")
            } finally { busy.set(false) }
        }.start()
    }
}
