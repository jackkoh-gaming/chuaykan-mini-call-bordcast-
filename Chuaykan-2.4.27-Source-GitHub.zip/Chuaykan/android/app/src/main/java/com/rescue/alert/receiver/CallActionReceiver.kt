package com.rescue.alert.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.rescue.alert.bluetooth.BluetoothMeshManager
import com.rescue.alert.ui.MainActivity

/**
 * BroadcastReceiver handling interactive notification actions for Incoming and Active Calls
 * from rescue officers and EOC command center.
 * Actions:
 * - ACTION_ANSWER_CALL: Citizen answers incoming call (activates voice link & launches app)
 * - ACTION_DECLINE_CALL: Citizen declines incoming call
 * - ACTION_HANGUP_CALL: Citizen hangs up active call session
 */
class CallActionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "CallActionReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        Log.i(TAG, "Received call action intent: $action")

        val meshManager = BluetoothMeshManager.getInstance(context)
        val callerName = intent.getStringExtra(BluetoothMeshManager.EXTRA_CALLER_NAME) ?: "เจ้าหน้าที่ศูนย์สั่งการ EOC"
        val callerNodeId = intent.getStringExtra(BluetoothMeshManager.EXTRA_CALLER_NODE_ID) ?: BluetoothMeshManager.EOC_GATEWAY_NODE_ID

        when (action) {
            BluetoothMeshManager.ACTION_ANSWER_CALL -> {
                Log.i(TAG, "Citizen clicked ANSWER call action for $callerName ($callerNodeId)")
                // BUG-05 FIX: Android 11+ blocks microphone from BroadcastReceiver background.
                // Launch MainActivity with ACTION_ANSWER_CALL to acquire mic via foreground context.
                val launchIntent = Intent(context, MainActivity::class.java).apply {
                    setAction(BluetoothMeshManager.ACTION_ANSWER_CALL)
                    putExtra(BluetoothMeshManager.EXTRA_CALLER_NAME, callerName)
                    putExtra(BluetoothMeshManager.EXTRA_CALLER_NODE_ID, callerNodeId)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(launchIntent)
            }

            BluetoothMeshManager.ACTION_DECLINE_CALL -> {
                Log.i(TAG, "Citizen clicked DECLINE call action for $callerName ($callerNodeId)")
                meshManager.declineIncomingCall(callerNodeId, callerName)
            }

            BluetoothMeshManager.ACTION_HANGUP_CALL -> {
                Log.i(TAG, "Citizen clicked HANGUP call action for $callerName ($callerNodeId)")
                meshManager.hangupCurrentCall()
            }
        }
    }
}
