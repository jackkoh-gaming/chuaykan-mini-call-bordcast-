# Chuaykan (Mini Call Broadcast)

ช่วยกัน (มินิ คอลบอร์ดเคส) — release 2.4.27 / Android versionCode 35

ชุดนี้รวมซอร์ส Android, คอม EOC และเกตเวย์สำหรับนักพัฒนา อนุญาตให้ใช้
แก้ไข และเผยแพร่โค้ดของโครงการภายใต้ MIT License โดยคงข้อความลิขสิทธิ์
และสัญญาอนุญาตไว้ ส่วนไลบรารี แผนที่ และข้อมูลต้นทางคงสิทธิ์เดิม
อ่าน LICENSE และ THIRD_PARTY_NOTICES.md

## APK สำหรับผู้ใช้

ดาวน์โหลด APK แยกจาก GitHub Releases และตรวจ SHA256SUMS.txt ก่อนติดตั้ง
APK 2.4.27 ที่จัดทำคู่กับซอร์สชุดนี้ยังเชื่อม Oracle ของผู้ดูแลเดิม แต่ไม่ได้
ฝังคีย์เจ้าหน้าที่หรือ private key ลง APK เครื่องแต่ละเครื่องลงทะเบียนกับ
เกตเวย์เพื่อรับ token ของตนเองเมื่อใช้งาน

APK ใช้คีย์เผยแพร่ใหม่ ไม่ใช่ debug key จึงติดตั้งทับ APK เดิมที่ลงนามด้วย
คีย์ debug ไม่ได้ ต้องถอนรุ่นเดิมก่อนติดตั้ง การถอนทำให้ข้อมูลส่วนตัว
การตั้งค่าและสถานะ SOS ในเครื่องหาย ให้เก็บข้อมูลที่ต้องการด้วยตนเองก่อน
ติดตั้งใหม่ หากไม่มีแอพเดิม การติดตั้งเริ่มด้วยข้อมูลผู้ใช้ว่าง
ห้ามนำ keystore หรือรหัสผ่านของผู้ดูแลไปใส่ใน release หรือ GitHub
การอัปเดตหลังจาก 2.4.27 ต้องใช้คีย์เผยแพร่เดิมและเพิ่ม versionCode

Android ขั้นต่ำ 5.0 (API 21) ไม่ได้หมายความว่าทดสอบครบทุกยี่ห้อ/รุ่น
การโทรกลับพร้อมเสียงจริงทั้งสองฝั่งยังต้องตรวจบนอุปกรณ์จริง
ก่อนยืนยันความพร้อมใช้งานภาคสนาม ไม่มีการรับรองว่าไม่มีบั๊กหรือรองรับ
100/200 เคสพร้อมกันได้โดยไม่ต้องลองใหม่

ข้อมูลส่วนตัวกรอกและเก็บในมือถือ ส่งให้เจ้าหน้าที่เฉพาะเมื่อผู้ใช้กด
ขอความช่วยเหลือเอง ไม่ได้รวมอยู่ใน APK หรือซอร์สชุดนี้
สถานะ SOS ที่ช่วยเหลือแล้วล็อก 72 ชั่วโมงตามพฤติกรรมเดิม
ปุ่ม SOS ยังขึ้นกับ GPS และพื้นที่คุม ไม่ได้เปิดปุ่มด้วยข้อมูลตำแหน่งจำลอง

## ซอร์ส Android

ต้องมี JDK 17+, Android SDK 34 และ Build Tools 34.0.0
ไม่มี google-services.json, private key, ข้อมูลเคสหรือ endpoint ของผู้ดูแล
ในชุดซอร์สนี้ API implementation ยังอยู่ครบเพื่อให้นักพัฒนาตั้งระบบเอง

1. สร้าง Firebase Android app ของตนเอง package com.rescue.alert แล้วนำ
   google-services.json มาใส่ android/app/ เก็บไฟล์นี้นอก Git
2. สร้าง android/local.properties ระบุ sdk.dir ของเครื่องตนเอง
3. ตั้ง HTTPS gateway ของตนเอง หาค่า SHA-256 ของใบรับรองเกตเวย์
   โดย hash DER certificate ไม่ใช่ SPKI และไม่ใช่ private key
4. สำหรับการแจ้งเตือนที่ลงนาม ให้สร้างคู่คีย์ ECDSA P-256 ของตนเอง เก็บ
   private key บนเซิร์ฟเวอร์ และตั้ง EC_PUBLIC_KEY_X509_BASE64 ใน
   android/app/src/main/java/com/rescue/alert/security/AlertVerifier.kt
   เป็น public key ของตนเองแบบ X.509 SPKI Base64 ค่าว่างในซอร์สชุดนี้
   จะปฏิเสธประกาศที่ตรวจลายเซ็นไม่ได้ ไม่ได้ bypass การตรวจ
5. ส่งค่าผ่าน Gradle properties gatewayUrl และ gatewayCertSha256
   โดยเก็บใน private Gradle properties หรือส่ง -P ตอนบิลด์
   ตัวอย่างชื่อโดเมนอยู่ใน gradle.properties.example เป็นโดเมนตัวอย่าง
   ห้ามใช้ตัวอย่างนั้นส่ง SOS จริง

```sh
cd android
./gradlew assembleDebug -PgatewayUrl=https://YOUR-GATEWAY -PgatewayCertSha256=YOUR-CERT-SHA256
```

release ไม่มี fallback ไปใช้ debug signing key ตั้งค่าต่อไปนี้จากไฟล์
ส่วนตัวหรือ secret store ของเครื่อง/CI ก่อน ./gradlew assembleRelease:
RELEASE_KEYSTORE_PATH, RELEASE_STORE_PASSWORD, RELEASE_KEY_ALIAS และถ้า
key password ต่างกันให้ตั้ง RELEASE_KEY_PASSWORD ด้วย
ห้าม commit ค่าเหล่านี้ และอย่าเผยแพร่ unsigned APK เป็นไฟล์ติดตั้ง
ต้องตั้ง gatewayUrl/gatewayCertSha256 จริงก่อนสร้าง APK สำหรับใช้งาน
ไม่ระบุ endpoint/pin จะไม่มีระบบเซิร์ฟเวอร์ที่พร้อมเชื่อมต่อ
ชุดทดสอบที่ใช้เครือข่ายจริงต้องตั้งค่าเกตเวย์ทดสอบแยกและ credentials เอง
อย่าทดสอบสร้างเคสกับเกตเวย์ใช้งานจริงโดยไม่ตั้งใจ

## คอม EOC / เกตเวย์

คอม: desktop/main.py และ desktop/run.sh (Linux)
ติดตั้ง dependencies ใน desktop/requirements.txt รวมถึง BlueZ, dbus,
GObject ของระบบปฏิบัติการก่อนเปิดโปรแกรม ต้องมีอุปกรณ์เสียงและ Bluetooth
จริงสำหรับตรวจสายและ mesh ไม่ใช่ผลยืนยันจากการ build

เกตเวย์ headless: desktop/deploy/oracle/run_gateway.py
ไฟล์ service: desktop/deploy/oracle/chuaykan-eoc.service
ตั้ง PYTHONPATH ให้ตรงกับ desktop และสร้าง user/path ตามไฟล์ service
ค่า EOC_DATA_DIR, EOC_RECORDINGS_DIR, EOC_SECURITY_DIR และ EOC_PORT ใช้
เปลี่ยนที่เก็บข้อมูล/credentials/พอร์ต ค่าเริ่มต้นของ service อยู่ใน
/opt/chuaykan-eoc, /var/lib/chuaykan-eoc และ /etc/chuaykan-eoc
สร้าง TLS identity และ officer-token ใหม่ด้วยค่าที่สุ่มอย่างปลอดภัย
การรัน public gateway ต้องมี officer-token ไม่ได้แจกคีย์ของผู้ดูแลเดิม
เปิด HTTPS และตั้ง firewall ของผู้ให้บริการกับเครื่องให้ถูกต้อง

คอมใช้ .secrets/gateway-network/cloud.json เพื่อระบุ URL เกตเวย์ของตนเอง
ดู cloud.example.json; ต้อง provision TLS identity ที่ตรงกับใบรับรองที่ใช้
และ officer-token ผ่านช่องทางส่วนตัว พร้อมทดสอบการตรวจ TLS ก่อนใช้งาน
อย่าคัดลอกตัวอย่าง credentials เข้า production และอย่าปิด TLS validation

ประกาศจากแหล่งทางการ: android/gateway/official_push_monitor.py
อ่าน android/gateway/deploy/oracle/README.md และใช้ Firebase service account
ของตนเองส่งผ่านช่องทางส่วนตัว ตั้ง FIREBASE_CREDENTIALS_PATH ให้ถูกต้อง
คอมที่ใช้ gateway modules ตั้ง RESCUE_GATEWAY_DIR เป็น android/gateway
ผู้ดูแลต้องสร้างและจัดเก็บคีย์ลงนาม/credentials ของระบบตนเองนอก Git
ไม่มีการติดตั้งบริการหรือเปลี่ยนเซิร์ฟเวอร์ใดจากการแตก ZIP นี้

## สิ่งที่ตัดออกจาก ZIP

ไม่รวม debug/release APK, build cache, .gradle, .idea, keystore, service-account,
google-services.json, .secrets, .keys, access/officer tokens, cloud.json จริง,
ฐานข้อมูล, เคส SOS, cache, recordings, logs, reports และข้อมูลในมือถือ
เสียง ringtone.wav เป็นเสียงเรียกของแอพ ไม่ใช่เสียงบันทึกผู้ใช้
ติดตั้ง dependencies จากต้นทางเอง รักษา attribution ของแผนที่และเงื่อนไข
ไลบรารีภายนอกไว้เมื่อแจกจ่ายรุ่นที่แก้ไข
