"""Authenticated online dispatch of EOC risk areas to RescueAlert phones via FCM."""
from __future__ import annotations
import json
from dataclasses import dataclass
from datetime import date, datetime
from zoneinfo import ZoneInfo
from urllib.request import Request, urlopen

import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from src.core.models import DisasterZone


@dataclass(frozen=True)
class OfficialCellBroadcastAlert:
    """Read-only public Cell Broadcast record published by NDWC/DPM."""
    alert_id: str
    issued_at: str
    title: str
    message: str
    sender: str
    event_type: str
    disaster_type: str
    area_summary: str
    affected_provinces: List[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_id": self.alert_id,
            "issued_at": self.issued_at,
            "title": self.title,
            "message": self.message,
            "sender": self.sender,
            "event_type": self.event_type,
            "disaster_type": self.disaster_type,
            "area_summary": self.area_summary,
            "affected_provinces": self.affected_provinces or [],
        }


class OfficialCellBroadcastFeed:
    """Reads the public NDWC Cell Broadcast dashboard without credentials."""
    SNAPSHOT_URL = "https://academicndwc.github.io/CBS-DashBoard/data/data.json"
    API_URL = "https://script.google.com/macros/s/AKfycbypPalKcGpXQXvrGqo3-NFTRfGdhShklY_vrGMwLRsAvQugFaV6-gApi6M-S6MBI5hE6Q/exec?type=data"
    URL = SNAPSHOT_URL

    @staticmethod
    def current_day() -> date:
        return datetime.now(ZoneInfo("Asia/Bangkok")).date()

    @classmethod
    def fetch_recent(cls, max_age_days: int = 0) -> List[OfficialCellBroadcastAlert]:
        payload = None
        last_error = None
        for endpoint in [cls.SNAPSHOT_URL, cls.API_URL]:
            try:
                request = Request(endpoint, headers={"User-Agent": "ThaiDisasterMonitor/2.2", "Accept": "application/json"})
                with urlopen(request, timeout=12) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                    if payload and "fact_cb" in payload:
                        break
            except Exception as exc:
                last_error = exc
        if not payload:
            raise RuntimeError(f"ไม่สามารถเชื่อมต่อแหล่งข้อมูล ปภ. ({last_error})")
        messages = {row.get("message_id"): row for row in payload.get("dim_message", [])}
        senders = {row.get("sender_id"): row for row in payload.get("dim_sender", [])}
        events = {row.get("event_id"): row for row in payload.get("dim_event", [])}
        disasters = {row.get("disaster_id"): row for row in payload.get("dim_disaster", [])}
        dim_provinces = {str(row.get("province_code")): row for row in payload.get("dim_province", [])}
        locations: Dict[str, List[Dict[str, Any]]] = {}
        for row in payload.get("bridge_alert_location", []):
            aid = str(row.get("alert_id", ""))
            if not aid:
                continue
            pcode = str(row.get("province_code", ""))
            pinfo = dim_provinces.get(pcode, {})
            entry = {
                "province_code": pcode,
                "province_name_th": str(pinfo.get("province_name_th") or pcode),
                "province_name_en": str(pinfo.get("province_name_en") or ""),
                "level": str(row.get("level") or "province"),
            }
            if aid not in locations:
                locations[aid] = []
            if not any(x["province_code"] == pcode for x in locations[aid]):
                locations[aid].append(entry)
        recent: List[OfficialCellBroadcastAlert] = []
        today = cls.current_day()
        for row in payload.get("fact_cb", []):
            alert_id = str(row.get("alert_id", ""))
            raw_date = str(row.get("date_id", "")).replace("D-", "")
            try:
                issued_date = datetime.strptime(raw_date, "%Y%m%d").date()
            except ValueError:
                continue
            age = (today - issued_date).days
            if age < 0 or age > max_age_days or not alert_id:
                continue
            message = messages.get(row.get("message_id"), {})
            sender = senders.get(row.get("sender_id"), {})
            event = events.get(row.get("event_id"), {})
            disaster = disasters.get(row.get("disaster_id"), {})
            prov_list = locations.get(alert_id, [])
            if prov_list:
                prov_names = [p["province_name_th"] for p in prov_list[:3]]
                summary_str = ", ".join(prov_names)
                if len(prov_list) > 3:
                    summary_str += f" และอีก {len(prov_list) - 3} จังหวัด"
                area_summary = f"พื้นที่: {summary_str} ({len(prov_list)} จังหวัด)"
            else:
                area_summary = "พื้นที่ตามประกาศ ปภ."
            recent.append(OfficialCellBroadcastAlert(
                alert_id=alert_id,
                issued_at=f"{issued_date.isoformat()} {row.get('time', '')}".strip(),
                title=str(row.get("title") or "ประกาศเตือนภัย ปภ."),
                message=str(message.get("message_th") or row.get("title") or ""),
                sender=str(sender.get("sender_name") or "กรมป้องกันและบรรเทาสาธารณภัย"),
                event_type=str(event.get("event_th") or "การแจ้งเตือนภัย"),
                disaster_type=str(disaster.get("disaster_name") or "สาธารณภัย"),
                area_summary=area_summary,
                affected_provinces=prov_list,
            ))
        return sorted(recent, key=lambda item: item.issued_at, reverse=True)


class ZoneCloudDispatcher:
    """Uses the RescueAlert signing key and Firebase service account already provisioned for this deployment."""

    @staticmethod
    def _gateway_dir() -> Path:
        configured = os.environ.get("RESCUE_GATEWAY_DIR", "").strip()
        if configured:
            return Path(configured).expanduser().resolve()
        from src.core.config import PROJECT_ROOT
        return PROJECT_ROOT / "gateway"

    @classmethod
    def dispatch_active_zones(cls, zones: Iterable[DisasterZone]) -> List[Dict[str, Any]]:
        active = [zone for zone in zones if zone.is_active][:10]
        if not active:
            return []

        gateway_dir = cls._gateway_dir()
        from src.core.config import USER_DATA_ROOT
        eoc_secret = USER_DATA_ROOT / ".secrets" / "firebase-service-account.json"
        credentials_path = Path(
            os.environ.get("FIREBASE_CREDENTIALS_PATH", eoc_secret)
        )
        if not credentials_path.is_file():
            credentials_path = gateway_dir / "serviceAccountKey.json"
        signing_path = Path(
            os.environ.get("RESCUE_ECDSA_KEY_PATH", gateway_dir / ".keys" / "ecdsa_p256_private.pem")
        )
        if not gateway_dir.is_dir():
            return [{"status": "error", "error": f"ไม่พบ RescueAlert gateway: {gateway_dir}"}]
        if not credentials_path.is_file():
            return [{"status": "error", "error": "ไม่พบ Firebase service account credential"}]
        if not signing_path.is_file():
            return [{"status": "error", "error": "ไม่พบ ECDSA signing key สำหรับแอปมือถือ"}]

        gateway_parent = str(gateway_dir.parent)
        if gateway_parent not in sys.path:
            sys.path.insert(0, gateway_parent)
        os.environ.setdefault("FIREBASE_CREDENTIALS_PATH", str(credentials_path))
        os.environ.setdefault("RESCUE_ECDSA_KEY_PATH", str(signing_path))

        try:
            from gateway.dispatcher import FCMDispatcher
            from gateway.models import DisasterAlert
        except Exception as exc:
            return [{"status": "error", "error": f"ไม่สามารถโหลด FCM dispatcher: {exc}"}]

        results: List[Dict[str, Any]] = []
        for zone in active:
            alert = DisasterAlert(
                alert_id=f"EOC_{zone.zone_id}_{int(time.time() * 1000)}",
                title=zone.title,
                instruction=zone.instruction,
                severity=zone.severity,
                center_lat=zone.center_lat,
                center_lng=zone.center_lng,
                radius_km=zone.radius_km,
                is_muted=False,
                sender="Thai Disaster EOC",
                event_type="AREA_EMERGENCY",
                area_desc=zone.title,
            )
            result = FCMDispatcher.dispatch_topic(
                alert=alert,
                topic="emergency_alerts",
                is_muted=False,
                cred_path=str(credentials_path),
            )
            result["zone_id"] = zone.zone_id
            result["zone_title"] = zone.title
            results.append(result)
        return results
