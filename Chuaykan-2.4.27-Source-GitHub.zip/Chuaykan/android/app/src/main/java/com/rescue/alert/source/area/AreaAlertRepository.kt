package com.rescue.alert.source.area

import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.rescue.alert.engine.AlertProcessingEngine
import com.rescue.alert.model.DisasterStateManager

/** One serialized path for foreground monitoring and WorkManager. */
object AreaAlertRepository {
    @Synchronized fun refresh(context: Context, force: Boolean = false) {
        clearLegacyAlerts(context)
        val feed = OfficialAreaFeed.fetch(context, force)
        val prefs = context.getSharedPreferences("official_cell_broadcast", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!prefs.getBoolean("initialized", false)) {
            // Establish a quiet baseline on first install; no historical alarm storm.
            val baseline = prefs.edit().putBoolean("initialized", true)
            feed.bulletins.forEach { baseline.putLong("seen_${it.id}", now) }
            baseline.commit()
            return
        }
        val device = AreaLocation.resolve(context, feed.provinces)
        if (device == null || (DisasterStateManager.getAlertId(context).startsWith("DPM_") &&
                !DisasterStateManager.isDeviceInRiskArea(context, 0.0, 0.0))) {
            clearOfficialNotifications(context)
        }
        if (device == null) {
            Log.i("AreaAlerts", "WAITING_FOR_GPS: no verified fresh administrative area; silent")
            return
        }
        var matching = 0
        for (bulletin in feed.bulletins) {
            if (!AreaAlertPolicy.isCurrent(bulletin.issuedAt, now) || bulletin.kind != BulletinKind.WARNING) continue
            if (!bulletin.isFor(device)) continue
            matching++
            val key = "seen_${bulletin.id}"
            if (!AreaAlertPolicy.canNotify(bulletin, device, now, prefs.contains(key))) continue
            val result = AlertProcessingEngine.processOfficialCellBroadcast(context, bulletin, feed.provinces)
            if (result == AlertProcessingEngine.ProcessResult.TRIGGERED_CRITICAL) {
                prefs.edit().putLong(key, now).commit()
            }
            // Unresolved or nonmatching records remain eligible for a later GPS fix.
        }
        val expiredKeys = prefs.all.filter { it.key.startsWith("seen_") &&
            (it.value as? Long)?.let { time -> now - time > AreaAlertPolicy.HISTORY_WINDOW_MS } == true }.keys
        if (expiredKeys.isNotEmpty()) {
            val edit = prefs.edit()
            expiredKeys.forEach { edit.remove(it) }
            edit.apply()
        }
        Log.i("AreaAlerts", "GPS_AREA=${device.label} currentMatching=$matching; unmatched records silent")
    }

    private fun clearLegacyAlerts(context: Context) {
        val prefs = context.getSharedPreferences("official_cell_broadcast", Context.MODE_PRIVATE)
        if (prefs.getBoolean("strict_gps_v1", false)) return
        clearOfficialNotifications(context, legacy = true)
        if (DisasterStateManager.getAlertId(context).startsWith("DPM_")) DisasterStateManager.setDisasterResolved(context)
        prefs.edit().putBoolean("strict_gps_v1", true).commit()
    }

    private fun clearOfficialNotifications(context: Context, legacy: Boolean = false) {
        if (Build.VERSION.SDK_INT < 23) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.activeNotifications.filter {
            it.notification.extras.getString("official_alert_id") != null ||
                (legacy && Build.VERSION.SDK_INT >= 26 && it.notification.channelId in setOf(
                    AlertProcessingEngine.CHANNEL_ID_CRITICAL, AlertProcessingEngine.CHANNEL_ID_CRITICAL_SILENT))
        }.forEach { manager.cancel(it.tag, it.id) }
    }
}
