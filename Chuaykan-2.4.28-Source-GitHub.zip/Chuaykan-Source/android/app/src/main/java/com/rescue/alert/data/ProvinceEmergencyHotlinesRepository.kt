package com.rescue.alert.data

import android.content.Context
import android.location.Geocoder
import com.rescue.alert.model.ContactCategory
import com.rescue.alert.model.EmergencyContactItem
import java.util.Locale
import kotlin.math.*

/**
 * Thailand Complete 77-Province Emergency Hotlines & Rescue Foundations Directory.
 * Source Attribution:
 * - Department of Disaster Prevention and Mitigation (DDPM 1784)
 * - National Emergency Medical Institute (NEMS 1669)
 * - Provincial Police Headquarters (191)
 * - Fire & Rescue Departments (199)
 * Local entries are a directory, not certified emergency dispatch lines.
 * Audit: 2026-10-04. Unverified local entries must be labelled in the UI.
 */
object ProvinceEmergencyHotlinesRepository {

    const val DATA_SOURCE_ATTRIBUTION = "ปรับปรุง 4 ต.ค. 2569: ถอดเบอร์ผิดที่พบแล้ว เบอร์ท้องถิ่นยังยืนยันบริการไม่ครบ เหตุแพทย์ฉุกเฉินโทร 1669 ภัยพิบัติโทร 1784"

    // Centroid coordinates of all 77 provinces in Thailand for rapid offline matching
    private val PROVINCE_CENTROIDS = mapOf(
        "เชียงราย" to Pair(19.9086, 99.8325),
        "เชียงใหม่" to Pair(18.7904, 98.9847),
        "น่าน" to Pair(18.7833, 100.7833),
        "พะเยา" to Pair(19.1667, 99.9000),
        "แพร่" to Pair(18.1446, 100.1410),
        "ลำปาง" to Pair(18.2888, 99.4928),
        "ลำพูน" to Pair(18.5772, 99.0087),
        "แม่ฮ่องสอน" to Pair(19.3021, 97.9654),
        "อุตรดิตถ์" to Pair(17.6256, 100.0993),
        "สุโขทัย" to Pair(17.0056, 99.8264),
        "พิษณุโลก" to Pair(16.8211, 100.2659),
        "ตาก" to Pair(16.8839, 99.1258),
        "กำแพงเพชร" to Pair(16.4828, 99.5227),
        "พิจิตร" to Pair(16.4419, 100.3488),
        "เพชรบูรณ์" to Pair(16.4190, 101.1557),
        "นครสวรรค์" to Pair(15.6987, 100.1199),
        "อุทัยธานี" to Pair(15.3833, 100.0247),
        "กรุงเทพมหานคร" to Pair(13.7563, 100.5018),
        "นนทบุรี" to Pair(13.8621, 100.5144),
        "ปทุมธานี" to Pair(14.0208, 100.5250),
        "สมุทรปราการ" to Pair(13.5991, 100.5998),
        "สมุทรสาคร" to Pair(13.5475, 100.2744),
        "สมุทรสงคราม" to Pair(13.4098, 99.9989),
        "นครปฐม" to Pair(13.8196, 100.0443),
        "สุพรรณบุรี" to Pair(14.4745, 100.1177),
        "พระนครศรีอยุธยา" to Pair(14.3532, 100.5684),
        "สระบุรี" to Pair(14.5289, 100.9108),
        "ลพบุรี" to Pair(14.7995, 100.6534),
        "สิงห์บุรี" to Pair(14.8879, 100.4042),
        "อ่างทอง" to Pair(14.5896, 100.4550),
        "ชัยนาท" to Pair(15.1852, 100.1251),
        "กาญจนบุรี" to Pair(14.0228, 99.5328),
        "ราชบุรี" to Pair(13.5283, 99.8134),
        "เพชรบุรี" to Pair(13.1119, 99.9398),
        "ประจวบคีรีขันธ์" to Pair(11.8124, 99.7974),
        "ชลบุรี" to Pair(13.3611, 100.9847),
        "ระยอง" to Pair(12.6814, 101.2816),
        "จันทบุรี" to Pair(12.6114, 102.1039),
        "ตราด" to Pair(12.2428, 102.5175),
        "ฉะเชิงเทรา" to Pair(13.6904, 101.0779),
        "ปราจีนบุรี" to Pair(14.0510, 101.3719),
        "นครนายก" to Pair(14.2069, 101.2131),
        "สระแก้ว" to Pair(13.8140, 102.0583),
        "นครราชสีมา" to Pair(14.9707, 102.0978),
        "ขอนแก่น" to Pair(16.4419, 102.8359),
        "อุบลราชธานี" to Pair(15.2448, 104.8473),
        "อุดรธานี" to Pair(17.4138, 102.7872),
        "ชัยภูมิ" to Pair(15.8105, 102.0289),
        "บุรีรัมย์" to Pair(14.9930, 103.1029),
        "สุรินทร์" to Pair(14.8818, 103.4936),
        "ศรีสะเกษ" to Pair(15.1186, 104.3220),
        "มหาสารคาม" to Pair(16.1852, 103.3007),
        "ร้อยเอ็ด" to Pair(16.0538, 103.6520),
        "ยโสธร" to Pair(15.7926, 104.1451),
        "อำนาจเจริญ" to Pair(15.8628, 104.6288),
        "กาฬสินธุ์" to Pair(16.4322, 103.5063),
        "สกลนคร" to Pair(17.1546, 104.1486),
        "นครพนม" to Pair(17.4081, 104.7788),
        "มุกดาหาร" to Pair(16.5436, 104.7235),
        "เลย" to Pair(17.4860, 101.7223),
        "หนองบัวลำภู" to Pair(17.2037, 102.4407),
        "หนองคาย" to Pair(17.8783, 102.7420),
        "บึงกาฬ" to Pair(18.3633, 103.6528),
        "สุราษฎร์ธานี" to Pair(9.1382, 99.3215),
        "นครศรีธรรมราช" to Pair(8.4304, 99.9631),
        "สงขลา" to Pair(7.1898, 100.5954),
        "ภูเก็ต" to Pair(7.8804, 98.3923),
        "กระบี่" to Pair(8.0863, 98.9063),
        "พังงา" to Pair(8.4509, 98.5303),
        "ตรัง" to Pair(7.5563, 99.6114),
        "พัทลุง" to Pair(7.6167, 100.0833),
        "ชุมพร" to Pair(10.4930, 99.1800),
        "ระนอง" to Pair(9.9658, 98.6348),
        "สตูล" to Pair(6.6238, 100.0674),
        "ปัตตานี" to Pair(6.8675, 101.2501),
        "ยะลา" to Pair(6.5411, 101.2804),
        "นราธิวาส" to Pair(6.4255, 101.8253),
    )

    fun detectProvince(lat: Double?, lng: Double?, context: Context?): String {
        if (lat == null || lng == null) {
            return "กรุงเทพมหานคร"
        }

        // Attempt 1: Android Geocoder (if network is available)
        if (context != null) {
            try {
                val geocoder = Geocoder(context, Locale("th", "TH"))
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(lat, lng, 1)
                if (!addresses.isNullOrEmpty()) {
                    val adminArea = addresses[0].adminArea ?: ""
                    val locality = addresses[0].locality ?: ""
                    for (p in PROVINCE_CENTROIDS.keys) {
                        if (adminArea.contains(p) || locality.contains(p)) {
                            return p
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // Attempt 2: Precise Offline Haversine Centroid Distance Matching
        var minDistance = Double.MAX_VALUE
        var closestProvince = "กรุงเทพมหานคร" // Default center if matching fails

        for ((province, coords) in PROVINCE_CENTROIDS) {
            val dist = calculateDistanceKm(lat, lng, coords.first, coords.second)
            if (dist < minDistance) {
                minDistance = dist
                closestProvince = province
            }
        }
        return closestProvince
    }

    private fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    fun getAllProvinces(): List<String> {
        return PROVINCE_CENTROIDS.keys.sorted()
    }

    fun getContactsForProvince(provinceName: String): List<EmergencyContactItem> {
        val list = mutableListOf<EmergencyContactItem>()

        // 1. Specific contacts for each province
        when (provinceName) {
            "เชียงราย" -> {
                list.add(EmergencyContactItem(
                    id = "เชียงราย_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดเชียงราย",
                    phoneNumber = "053-177-318",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงราย",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "เชียงราย_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.เชียงรายประชานุเคราะห์)",
                    phoneNumber = "053-910-600",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงราย",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 053-910-600)"
                ))
                list.add(EmergencyContactItem(
                    id = "CR_FND_SIRIKORN",
                    name = "สมาคมศิริกรณ์เชียงรายบรรเทาสาธารณภัย",
                    phoneNumber = "053-711-776",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงราย",
                    description = "ศูนย์กู้ภัยศิริกรณ์เชียงราย ชุดปฏิบัติการทางน้ำ เรือท้องแบน กู้ชีพกู้ภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CR_FND_1",
                    name = "สมาคมแสงธรรมสาธารณกุศลเชียงราย",
                    phoneNumber = "053-711-881",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงราย",
                    description = "กู้ภัยกู้ชีพฉุกเฉิน แจกจ่ายถุงยังชีพ และลำเลียงประชาชนออกจากจุดอันตราย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CR_FND_2",
                    name = "มูลนิธิสยามรวมใจ (ปู่อินทร์) เชียงราย",
                    phoneNumber = "053-600-177",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงราย",
                    description = "หน่วยกู้ภัยกู้ชีพทางน้ำ อพยพผู้ป่วยติดเตียง และค้นหาผู้สูญหาย"
                ))
                list.add(EmergencyContactItem(
                    id = "CR_FND_3",
                    name = "งานป้องกันและบรรเทาสาธารณภัย ทต.แม่สาย",
                    phoneNumber = "053-733-123",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงราย",
                    description = "ศูนย์ประสานงานช่วยเหลือฉุกเฉินพื้นที่ อ.แม่สาย และแนวแม่น้ำสาย",
                    subDistrict = "อ.แม่สาย"
                ))
                list.add(EmergencyContactItem(
                    id = "CR_GOV_ARMY",
                    name = "ศูนย์บรรเทาสาธารณภัย มทบ.37 (ค่ายเม็งรายมหาราช)",
                    phoneNumber = "053-711-200",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงราย",
                    description = "กำลังพลทหาร รถยกสูง อากาศยาน และยุทโธปกรณ์เข้าพื้นที่น้ำท่วมสูง"
                ))
                list.add(EmergencyContactItem(
                    id = "CR_GOV_RID",
                    name = "โครงการชลประทานเชียงราย",
                    phoneNumber = "053-713-679",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงราย",
                    description = "เฝ้าระวังระดับน้ำแม่น้ำกก แม่น้ำสาย และประตูระบายน้ำหลัก"
                ))
            }

            "เชียงใหม่" -> {
                list.add(EmergencyContactItem(
                    id = "เชียงใหม่_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดเชียงใหม่",
                    phoneNumber = "053-221-470",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงใหม่",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "เชียงใหม่_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.นครพิงค์ (ศูนย์กู้ชีพเวียงพิงค์))",
                    phoneNumber = "053-999-200",
                    category = ContactCategory.GOVERNMENT,
                    province = "เชียงใหม่",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 053-999-200)"
                ))
                list.add(EmergencyContactItem(
                    id = "CM_FND_1",
                    name = "มูลนิธิรวมใจเชียงใหม่ (กู้ภัยรวมใจ)",
                    phoneNumber = "053-272-212",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงใหม่",
                    description = "ชุดปฏิบัติการช่วยเหลือทางน้ำและกู้ชีพฉุกเฉินทั่วเมืองเชียงใหม่ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CM_FND_2",
                    name = "มูลนิธิสว่างสำเร็จเชียงใหม่",
                    phoneNumber = "053-867-641",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงใหม่",
                    description = "ทีมตอบโต้สาธารณภัยและเรือท้องแบนช่วยเหลือผู้ประสบอุทกภัย"
                ))
                list.add(EmergencyContactItem(
                    id = "CM_FND_3",
                    name = "ศูนย์บรรเทาสาธารณภัย มทบ.33 (ค่ายกาวิละ)",
                    phoneNumber = "053-245-349",
                    category = ContactCategory.FOUNDATION,
                    province = "เชียงใหม่",
                    description = "กำลังพลกู้ภัยทหารบก พร้อมรถบรรทุกยกสูงอพยพผู้ประสบภัย"
                ))
            }

            "น่าน" -> {
                list.add(EmergencyContactItem(
                    id = "น่าน_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดน่าน",
                    phoneNumber = "054-716-174",
                    category = ContactCategory.GOVERNMENT,
                    province = "น่าน",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "น่าน_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.น่าน)",
                    phoneNumber = "054-771-620",
                    category = ContactCategory.GOVERNMENT,
                    province = "น่าน",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 054-771-620)"
                ))
                list.add(EmergencyContactItem(
                    id = "NN_FND_1",
                    name = "สมาคมสว่างนครน่านรวมใจ",
                    phoneNumber = "054-052-215",
                    category = ContactCategory.FOUNDATION,
                    province = "น่าน",
                    description = "ชุดกู้ภัยทางน้ำ อพยพผู้ประสบภัยริมแม่น้ำน่าน 24 ชั่วโมง"
                ))
                list.add(EmergencyContactItem(
                    id = "NN_FND_2",
                    name = "มูลนิธิเพชรเกษมน่าน (สนง.ใหญ่ท่าวังผา)",
                    phoneNumber = "054-719-555",
                    category = ContactCategory.FOUNDATION,
                    province = "น่าน",
                    description = "ทีมกู้ชีพกู้ภัย สนับสนุนเรือท้องแบนและโรงครัวช่วยเหลือผู้ประสบภัย"
                ))
            }

            "พะเยา" -> {
                list.add(EmergencyContactItem(
                    id = "พะเยา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพะเยา",
                    phoneNumber = "054-449-644",
                    category = ContactCategory.GOVERNMENT,
                    province = "พะเยา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พะเยา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พะเยา)",
                    phoneNumber = "054-409-300",
                    category = ContactCategory.GOVERNMENT,
                    province = "พะเยา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 054-409-300)"
                ))
                list.add(EmergencyContactItem(
                    id = "PY_FND_1",
                    name = "มูลนิธิสยามพะเยา (สำนักงานใหญ่)",
                    phoneNumber = "062-207-7080",
                    category = ContactCategory.FOUNDATION,
                    province = "พะเยา",
                    description = "ชุดกู้ภัยทางน้ำและช่วยเหลือผู้ประสบภัยรอบกว๊านพะเยา 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PY_FND_2",
                    name = "สมาคมกู้ภัยกลางพะเยา",
                    phoneNumber = "054-449-644",
                    category = ContactCategory.FOUNDATION,
                    province = "พะเยา",
                    description = "ทีมสนับสนุนอพยพผู้ประสบภัยน้ำท่วมฉับพลัน (ประสาน ปภ.)"
                ))
            }

            "แพร่" -> {
                list.add(EmergencyContactItem(
                    id = "แพร่_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดแพร่",
                    phoneNumber = "054-533-680",
                    category = ContactCategory.GOVERNMENT,
                    province = "แพร่",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "แพร่_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.แพร่)",
                    phoneNumber = "054-533-500",
                    category = ContactCategory.GOVERNMENT,
                    province = "แพร่",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 054-533-500)"
                ))
                list.add(EmergencyContactItem(
                    id = "PR_FND_1",
                    name = "สมาคมอาสาสมัครกู้ภัยจังหวัดแพร่",
                    phoneNumber = "054-521-929",
                    category = ContactCategory.FOUNDATION,
                    province = "แพร่",
                    description = "หน่วยกู้ภัยแม่น้ำยม เรือท้องแบนช่วยเหลือชาวบ้านติดค้างในบ้านเรือน 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PR_FND_2",
                    name = "มูลนิธิร่วมใจแพร่",
                    phoneNumber = "081-473-6999",
                    category = ContactCategory.FOUNDATION,
                    province = "แพร่",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพและสาธารณกุศลจังหวัดแพร่"
                ))
            }

            "ลำปาง" -> {
                list.add(EmergencyContactItem(
                    id = "ลำปาง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดลำปาง",
                    phoneNumber = "054-265-072",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลำปาง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ลำปาง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ลำปาง)",
                    phoneNumber = "054-237-400",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลำปาง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 054-237-400)"
                ))
                list.add(EmergencyContactItem(
                    id = "LP_FND_1",
                    name = "สมาคมกู้ภัยสว่างนครลำปางธรรมสถาน",
                    phoneNumber = "054-221-666",
                    category = ContactCategory.FOUNDATION,
                    province = "ลำปาง",
                    description = "ชุดปฏิบัติการตอบโต้ภัยพิบัติทางน้ำและอพยพผู้ประสบภัย 24 ชม. (หรือ 054-221-888)"
                ))
                list.add(EmergencyContactItem(
                    id = "LP_FND_2",
                    name = "สมาคมกู้ภัยอัมรินทร์ลำปาง",
                    phoneNumber = "054-237-400",
                    category = ContactCategory.FOUNDATION,
                    province = "ลำปาง",
                    description = "หน่วยกู้ชีพฉุกเฉินและบรรเทาสาธารณภัย"
                ))
            }

            "ลำพูน" -> {
                list.add(EmergencyContactItem(
                    id = "ลำพูน_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดลำพูน",
                    phoneNumber = "053-562-963",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลำพูน",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ลำพูน_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ลำพูน)",
                    phoneNumber = "053-569-100",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลำพูน",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 053-569-100)"
                ))
                list.add(EmergencyContactItem(
                    id = "LN_FND_1",
                    name = "สมาคมกู้ภัยสว่างนครลำพูน",
                    phoneNumber = "053-569-100",
                    category = ContactCategory.FOUNDATION,
                    province = "ลำพูน",
                    description = "ชุดปฏิบัติการกู้ภัยทางบกทางน้ำประจำจังหวัดลำพูน 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "LN_FND_2",
                    name = "สมาคมกู้ภัยคนเมืองลำพูน",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ลำพูน",
                    description = "หน่วยกู้ชีพฉุกเฉินและช่วยเหลือประชาชนประสบภัย"
                ))
            }

            "แม่ฮ่องสอน" -> {
                list.add(EmergencyContactItem(
                    id = "แม่ฮ่องสอน_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดแม่ฮ่องสอน",
                    phoneNumber = "053-614-313",
                    category = ContactCategory.GOVERNMENT,
                    province = "แม่ฮ่องสอน",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "แม่ฮ่องสอน_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ศรีสังวาลย์)",
                    phoneNumber = "053-611-378",
                    category = ContactCategory.GOVERNMENT,
                    province = "แม่ฮ่องสอน",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 053-611-378)"
                ))
                list.add(EmergencyContactItem(
                    id = "MS_FND_1",
                    name = "สมาคมกู้ภัยแม่ฮ่องสอน",
                    phoneNumber = "053-611-378",
                    category = ContactCategory.FOUNDATION,
                    province = "แม่ฮ่องสอน",
                    description = "ชุดปฏิบัติการกู้ภัยพื้นที่ภูเขาสูง ดินถล่ม และลำเลียงผู้ป่วยฉุกเฉิน"
                ))
                list.add(EmergencyContactItem(
                    id = "MS_FND_2",
                    name = "มูลนิธิบรรเทาสาธารณภัยแม่ฮ่องสอน",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "แม่ฮ่องสอน",
                    description = "หน่วยกู้ชีพช่วยเหลือประชาชนในพื้นที่ห่างไกล"
                ))
            }

            "อุตรดิตถ์" -> {
                list.add(EmergencyContactItem(
                    id = "UT_FND_2",
                    name = "สมาคมกู้ภัยวัดหมอนไม้",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "อุตรดิตถ์",
                    description = "ทีมตอบโต้ภัยพิบัติฉุกเฉินจังหวัดอุตรดิตถ์"
                ))
            }

            "สุโขทัย" -> {
                list.add(EmergencyContactItem(
                    id = "สุโขทัย_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสุโขทัย",
                    phoneNumber = "055-612-415",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุโขทัย",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สุโขทัย_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สุโขทัย)",
                    phoneNumber = "055-611-333",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุโขทัย",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 055-611-333)"
                ))
                list.add(EmergencyContactItem(
                    id = "SK_FND_1",
                    name = "สมาคมกู้ภัยข่าวภาพสุโขทัย",
                    phoneNumber = "055-611-333",
                    category = ContactCategory.FOUNDATION,
                    province = "สุโขทัย",
                    description = "ทีมกู้ภัยทางน้ำ เรือยางติดเครื่องยนต์ ช่วยเหลือประชาชนริมแม่น้ำยม"
                ))
                list.add(EmergencyContactItem(
                    id = "SK_FND_2",
                    name = "สมาคมกู้ภัยบางแก้วสุโขทัย",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สุโขทัย",
                    description = "ชุดปฏิบัติการกู้ภัยอพยพผู้ประสบภัยน้ำท่วม"
                ))
            }

            "พิษณุโลก" -> {
                list.add(EmergencyContactItem(
                    id = "พิษณุโลก_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพิษณุโลก",
                    phoneNumber = "055-230-398",
                    category = ContactCategory.GOVERNMENT,
                    province = "พิษณุโลก",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พิษณุโลก_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พุทธชินราช)",
                    phoneNumber = "055-270-300",
                    category = ContactCategory.GOVERNMENT,
                    province = "พิษณุโลก",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 055-270-300)"
                ))
                list.add(EmergencyContactItem(
                    id = "PL_FND_1",
                    name = "สมาคมกู้ภัยข่าวภาพพิษณุโลก",
                    phoneNumber = "055-334-191",
                    category = ContactCategory.FOUNDATION,
                    province = "พิษณุโลก",
                    description = "กู้ภัยกู้ชีพฉุกเฉิน เรือท้องแบน และทีมอพยพผู้ประสบภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PL_FND_2",
                    name = "หน่วยกู้ภัยพิษณุโลก (มูลนิธิประสาทบุญสถาน)",
                    phoneNumber = "055-210-270",
                    category = ContactCategory.FOUNDATION,
                    province = "พิษณุโลก",
                    description = "ชุดปฏิบัติการทางน้ำและลำเลียงผู้ป่วยติดเตียง"
                ))
                list.add(EmergencyContactItem(
                    id = "PL_FND_3",
                    name = "หน่วยกู้ภัยบูรพา (สมาคมพิษณุโลกการกุศลสงเคราะห์)",
                    phoneNumber = "055-313-530",
                    category = ContactCategory.FOUNDATION,
                    province = "พิษณุโลก",
                    description = "ศูนย์ปฏิบัติการกู้ภัยฉุกเฉิน (หรือ 091-025-5858)"
                ))
            }

            "ตาก" -> {
                list.add(EmergencyContactItem(
                    id = "ตาก_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดตาก",
                    phoneNumber = "055-515-975",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตาก",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ตาก_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมเด็จพระเจ้าตากสินมหาราช)",
                    phoneNumber = "055-511-024",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตาก",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 055-511-024)"
                ))
                list.add(EmergencyContactItem(
                    id = "TK_FND_1",
                    name = "มูลนิธิตากร่วมใจสงเคราะห์",
                    phoneNumber = "055-511-024",
                    category = ContactCategory.FOUNDATION,
                    province = "ตาก",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพทางน้ำแม่น้ำปิงและพื้นที่ภูเขา"
                ))
                list.add(EmergencyContactItem(
                    id = "TK_FND_2",
                    name = "สมาคมกู้ภัยนครแม่สอด",
                    phoneNumber = "055-532-222",
                    category = ContactCategory.FOUNDATION,
                    province = "ตาก",
                    description = "หน่วยกู้ภัยฉุกเฉินพื้นที่ชายแดนและ อ.แม่สอด"
                ))
            }

            "กำแพงเพชร" -> {
                list.add(EmergencyContactItem(
                    id = "กำแพงเพชร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดกำแพงเพชร",
                    phoneNumber = "055-705-048",
                    category = ContactCategory.GOVERNMENT,
                    province = "กำแพงเพชร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "กำแพงเพชร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.กำแพงเพชร)",
                    phoneNumber = "055-058-900",
                    category = ContactCategory.GOVERNMENT,
                    province = "กำแพงเพชร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 055-058-900)"
                ))
                list.add(EmergencyContactItem(
                    id = "KP_FND_1",
                    name = "สมาคมกู้ภัยสว่างกำแพงเพชรธรรมสถาน",
                    phoneNumber = "055-058-900",
                    category = ContactCategory.FOUNDATION,
                    province = "กำแพงเพชร",
                    description = "ชุดกู้ภัยทางน้ำริมแม่น้ำปิงและอพยพผู้ประสบอุทกภัย"
                ))
                list.add(EmergencyContactItem(
                    id = "KP_FND_2",
                    name = "สมาคมกู้ภัยข่าวภาพกำแพงเพชร",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "กำแพงเพชร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน 24 ชั่วโมง"
                ))
            }

            "พิจิตร" -> {
                list.add(EmergencyContactItem(
                    id = "พิจิตร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพิจิตร",
                    phoneNumber = "056-611-665",
                    category = ContactCategory.GOVERNMENT,
                    province = "พิจิตร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พิจิตร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พิจิตร)",
                    phoneNumber = "056-611-230",
                    category = ContactCategory.GOVERNMENT,
                    province = "พิจิตร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 056-611-230)"
                ))
                list.add(EmergencyContactItem(
                    id = "PC_FND_1",
                    name = "สมาคมกู้ภัยสรรเพชญพิจิตร",
                    phoneNumber = "056-611-230",
                    category = ContactCategory.FOUNDATION,
                    province = "พิจิตร",
                    description = "ชุดปฏิบัติการช่วยเหลือผู้ประสบภัยลุ่มน้ำยมและลุ่มน้ำน่าน"
                ))
                list.add(EmergencyContactItem(
                    id = "PC_FND_2",
                    name = "สมาคมกู้ภัยข่าวภาพพิจิตร",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "พิจิตร",
                    description = "ทีมกู้ภัยทางน้ำและช่วยเหลือประชาชน"
                ))
            }

            "เพชรบูรณ์" -> {
                list.add(EmergencyContactItem(
                    id = "เพชรบูรณ์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดเพชรบูรณ์",
                    phoneNumber = "056-729-793",
                    category = ContactCategory.GOVERNMENT,
                    province = "เพชรบูรณ์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "เพชรบูรณ์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.เพชรบูรณ์)",
                    phoneNumber = "056-717-600",
                    category = ContactCategory.GOVERNMENT,
                    province = "เพชรบูรณ์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 056-717-600)"
                ))
                list.add(EmergencyContactItem(
                    id = "PB_FND_1",
                    name = "สมาคมกู้ภัยสว่างเพชรบูรณ์ธรรมสถาน",
                    phoneNumber = "056-717-600",
                    category = ContactCategory.FOUNDATION,
                    province = "เพชรบูรณ์",
                    description = "หน่วยตอบโต้สาธารณภัย เรือกู้ภัย และช่วยเหลือผู้ประสบภัยน้ำป่า"
                ))
                list.add(EmergencyContactItem(
                    id = "PB_FND_2",
                    name = "มูลนิธิร่มโพธิ์เพชรบูรณ์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "เพชรบูรณ์",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉินประจำจังหวัดเพชรบูรณ์"
                ))
            }

            "นครสวรรค์" -> {
                list.add(EmergencyContactItem(
                    id = "นครสวรรค์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครสวรรค์",
                    phoneNumber = "056-256-027",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครสวรรค์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครสวรรค์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สวรรค์ประชารักษ์)",
                    phoneNumber = "056-219-888",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครสวรรค์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 056-219-888)"
                ))
                list.add(EmergencyContactItem(
                    id = "NW_FND_2",
                    name = "มูลนิธิการกุศลตาคลี",
                    phoneNumber = "056-261-199",
                    category = ContactCategory.FOUNDATION,
                    province = "นครสวรรค์",
                    description = "หน่วยกู้ภัยกู้ชีพพื้นที่ อ.ตาคลี และตอนใต้ของจังหวัด"
                ))
            }

            "อุทัยธานี" -> {
                list.add(EmergencyContactItem(
                    id = "อุทัยธานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดอุทัยธานี",
                    phoneNumber = "056-512-111",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุทัยธานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "อุทัยธานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.อุทัยธานี)",
                    phoneNumber = "056-511-081",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุทัยธานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 056-511-081)"
                ))
                list.add(EmergencyContactItem(
                    id = "UTI_FND_1",
                    name = "สมาคมกู้ภัยอุทัยธานี (จุดเมือง)",
                    phoneNumber = "056-511-081",
                    category = ContactCategory.FOUNDATION,
                    province = "อุทัยธานี",
                    description = "ชุดปฏิบัติการช่วยเหลือผู้ประสบภัยลุ่มน้ำสะแกกรัง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "UTI_FND_2",
                    name = "มูลนิธิกู้ภัยอุทัยธานี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "อุทัยธานี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉินจังหวัดอุทัยธานี"
                ))
            }

            "กรุงเทพมหานคร" -> {
                list.add(EmergencyContactItem(
                    id = "กรุงเทพมหานคร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดกรุงเทพมหานคร",
                    phoneNumber = "199",
                    category = ContactCategory.GOVERNMENT,
                    province = "กรุงเทพมหานคร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "กรุงเทพมหานคร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (ศูนย์เอราวัณ สำนักการแพทย์ กทม.)",
                    phoneNumber = "1669",
                    category = ContactCategory.GOVERNMENT,
                    province = "กรุงเทพมหานคร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 1669)"
                ))
                list.add(EmergencyContactItem(
                    id = "BKK_FND_1",
                    name = "มูลนิธิป่อเต็กตึ๊ง (สายด่วนกู้ภัย 1418)",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "กรุงเทพมหานคร",
                    description = "หน่วยกู้ภัยกู้ชีพทางบก-ทางน้ำ อุปกรณ์ตัดถ่าง และทีมอพยพน้ำท่วม (หรือ 02-226-4444)"
                ))
                list.add(EmergencyContactItem(
                    id = "BKK_FND_2",
                    name = "มูลนิธิร่วมกตัญญู",
                    phoneNumber = "02-751-0951",
                    category = ContactCategory.FOUNDATION,
                    province = "กรุงเทพมหานคร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน รถพยาบาล เรือกู้ภัย และกำลังพลช่วยเหลือ"
                ))
                list.add(EmergencyContactItem(
                    id = "BKK_FND_3",
                    name = "มูลนิธิสยามรวมใจ (ปู่อินทร์)",
                    phoneNumber = "02-540-0044",
                    category = ContactCategory.FOUNDATION,
                    province = "กรุงเทพมหานคร",
                    description = "ชุดปฏิบัติการกู้ชีพฉุกเฉินและสาธารณภัย"
                ))
                list.add(EmergencyContactItem(
                    id = "BKK_FND_4",
                    name = "ศูนย์ควบคุมระบบป้องกันน้ำท่วม กทม.",
                    phoneNumber = "02-248-5115",
                    category = ContactCategory.FOUNDATION,
                    province = "กรุงเทพมหานคร",
                    description = "เฝ้าระวังระดับน้ำเจ้าพระยา ประตูระบายน้ำ และน้ำท่วมขังถนนสายหลัก"
                ))
            }

            "นนทบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "นนทบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนนทบุรี",
                    phoneNumber = "02-580-0700",
                    category = ContactCategory.GOVERNMENT,
                    province = "นนทบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นนทบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พระนั่งเกล้า)",
                    phoneNumber = "02-528-4567",
                    category = ContactCategory.GOVERNMENT,
                    province = "นนทบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 02-528-4567)"
                ))
                list.add(EmergencyContactItem(
                    id = "NBI_FND_1",
                    name = "มูลนิธิร่วมกตัญญูนนทบุรี",
                    phoneNumber = "02-751-0951",
                    category = ContactCategory.FOUNDATION,
                    province = "นนทบุรี",
                    description = "ศูนย์กู้ชีพกู้ภัยฉุกเฉินและบรรเทาสาธารณภัยทางน้ำเจ้าพระยา"
                ))
                list.add(EmergencyContactItem(
                    id = "NBI_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งนนทบุรี",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "นนทบุรี",
                    description = "สายด่วนกู้ภัยช่วยเหลือน้ำท่วมและอุบัติเหตุ 24 ชม."
                ))
            }

            "ปทุมธานี" -> {
                list.add(EmergencyContactItem(
                    id = "ปทุมธานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดปทุมธานี",
                    phoneNumber = "02-581-7120",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปทุมธานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ปทุมธานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ปทุมธานี)",
                    phoneNumber = "02-598-8888",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปทุมธานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 02-598-8888)"
                ))
                list.add(EmergencyContactItem(
                    id = "PTE_FND_1",
                    name = "มูลนิธิร่วมกตัญญูปทุมธานี",
                    phoneNumber = "02-751-0951",
                    category = ContactCategory.FOUNDATION,
                    province = "ปทุมธานี",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำและอพยพน้ำท่วมลุ่มน้ำเจ้าพระยา"
                ))
                list.add(EmergencyContactItem(
                    id = "PTE_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งปทุมธานี",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "ปทุมธานี",
                    description = "สายด่วนกู้ภัยกู้ชีพฉุกเฉิน 24 ชม."
                ))
            }

            "สมุทรปราการ" -> {
                list.add(EmergencyContactItem(
                    id = "สมุทรปราการ_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสมุทรปราการ",
                    phoneNumber = "02-382-6040",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรปราการ",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สมุทรปราการ_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมุทรปราการ)",
                    phoneNumber = "02-701-8132",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรปราการ",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 02-701-8132)"
                ))
                list.add(EmergencyContactItem(
                    id = "SPK_FND_1",
                    name = "มูลนิธิร่วมกตัญญู (สำนักงานใหญ่บางพลี)",
                    phoneNumber = "02-751-0951",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรปราการ",
                    description = "ศูนย์วิทยุกู้ภัยใหญ่ ครอบคลุมกำลังพล เรือกู้ภัย และอุปกรณ์ตัดถ่าง"
                ))
                list.add(EmergencyContactItem(
                    id = "SPK_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งสมุทรปราการ",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรปราการ",
                    description = "สายด่วนกู้ภัยรับแจ้งอุบัติเหตุและภัยพิบัติ 24 ชม."
                ))
            }

            "สมุทรสาคร" -> {
                list.add(EmergencyContactItem(
                    id = "สมุทรสาคร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสมุทรสาคร",
                    phoneNumber = "034-427-019",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรสาคร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สมุทรสาคร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมุทรสาคร)",
                    phoneNumber = "034-427-099",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรสาคร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 034-427-099)"
                ))
                list.add(EmergencyContactItem(
                    id = "SKN_FND_1",
                    name = "มูลนิธิการกุศลสมุทรสาคร",
                    phoneNumber = "034-427-099",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรสาคร",
                    description = "ชุดกู้ภัยทางน้ำแม่น้ำท่าจีน ปากอ่าว และบรรเทาสาธารณภัย"
                ))
                list.add(EmergencyContactItem(
                    id = "SKN_FND_2",
                    name = "มูลนิธิร่วมกตัญญูสมุทรสาคร",
                    phoneNumber = "02-751-0951",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรสาคร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน 24 ชม."
                ))
            }

            "สมุทรสงคราม" -> {
                list.add(EmergencyContactItem(
                    id = "สมุทรสงคราม_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสมุทรสงคราม",
                    phoneNumber = "034-715-835",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรสงคราม",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สมุทรสงคราม_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมเด็จพระพุทธเลิศหล้า)",
                    phoneNumber = "034-711-205",
                    category = ContactCategory.GOVERNMENT,
                    province = "สมุทรสงคราม",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 034-711-205)"
                ))
                list.add(EmergencyContactItem(
                    id = "SKM_FND_1",
                    name = "สมาคมกู้ภัยสรรพราเชนทร์สมุทรสงคราม",
                    phoneNumber = "034-711-205",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรสงคราม",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำแม่น้ำแม่กลองและปากอ่าว"
                ))
                list.add(EmergencyContactItem(
                    id = "SKM_FND_2",
                    name = "มูลนิธิสว่างเบญจธรรมสมุทรสงคราม",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สมุทรสงคราม",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉินประจำจังหวัด"
                ))
            }

            "นครปฐม" -> {
                list.add(EmergencyContactItem(
                    id = "นครปฐม_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครปฐม",
                    phoneNumber = "034-340-270",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครปฐม",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครปฐม_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.นครปฐม)",
                    phoneNumber = "034-254-150",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครปฐม",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 034-254-150)"
                ))
                list.add(EmergencyContactItem(
                    id = "NPT_FND_1",
                    name = "มูลนิธิสุขศาลานุเคราะห์นครปฐม",
                    phoneNumber = "034-256-113",
                    category = ContactCategory.FOUNDATION,
                    province = "นครปฐม",
                    description = "ศูนย์กู้ภัยกู้ชีพหลัก เรือกู้ภัยน้ำท่วม และอุปกรณ์ตัดถ่าง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "NPT_FND_2",
                    name = "มูลนิธิหลวงพ่อสมหวังวัดกลางบางพระ",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "นครปฐม",
                    description = "หน่วยกู้ภัยช่วยเหลือประชาชน"
                ))
            }

            "สุพรรณบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "สุพรรณบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสุพรรณบุรี",
                    phoneNumber = "035-535-420",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุพรรณบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สุพรรณบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.เจ้าพระยายมราช)",
                    phoneNumber = "035-514-999",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุพรรณบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 035-514-999)"
                ))
                list.add(EmergencyContactItem(
                    id = "SPB_FND_1",
                    name = "มูลนิธิเสมอกันกู้ภัยสุพรรณบุรี",
                    phoneNumber = "035-525-444",
                    category = ContactCategory.FOUNDATION,
                    province = "สุพรรณบุรี",
                    description = "ศูนย์วิทยุกู้ภัยครอบคลุมทั้งจังหวัด เรือกู้ภัยลุ่มน้ำท่าจีน"
                ))
                list.add(EmergencyContactItem(
                    id = "SPB_FND_2",
                    name = "สมาคมเณรแก้วกู้ภัยทางหลวงสุพรรณบุรี",
                    phoneNumber = "035-525-500",
                    category = ContactCategory.FOUNDATION,
                    province = "สุพรรณบุรี",
                    description = "หน่วยกู้ภัยช่วยเหลืออุบัติเหตุและภัยพิบัติ"
                ))
            }

            "พระนครศรีอยุธยา" -> {
                list.add(EmergencyContactItem(
                    id = "พระนครศรีอยุธยา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพระนครศรีอยุธยา",
                    phoneNumber = "035-335-161",
                    category = ContactCategory.GOVERNMENT,
                    province = "พระนครศรีอยุธยา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พระนครศรีอยุธยา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พระนครศรีอยุธยา)",
                    phoneNumber = "035-211-888",
                    category = ContactCategory.GOVERNMENT,
                    province = "พระนครศรีอยุธยา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 035-211-888)"
                ))
                list.add(EmergencyContactItem(
                    id = "AY_FND_1",
                    name = "สมาคมอยุธยารวมใจ (หน่วยกู้ภัยอยุธยา)",
                    phoneNumber = "035-242-222",
                    category = ContactCategory.FOUNDATION,
                    province = "พระนครศรีอยุธยา",
                    description = "ชุดกู้ภัยทางน้ำ เรือยนต์ อพยพน้ำท่วมริมแม่น้ำเจ้าพระยา 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "AY_FND_2",
                    name = "มูลนิธิพุทไธสวรรย์ (กู้ภัยพุทไธสวรรย์)",
                    phoneNumber = "035-252-000",
                    category = ContactCategory.FOUNDATION,
                    province = "พระนครศรีอยุธยา",
                    description = "หน่วยกู้ชีพกู้ภัย อพยพผู้ป่วยติดเตียงและสัตว์เลี้ยง"
                ))
            }

            "สระบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "สระบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสระบุรี",
                    phoneNumber = "036-211-099",
                    category = ContactCategory.GOVERNMENT,
                    province = "สระบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สระบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สระบุรี)",
                    phoneNumber = "036-343-500",
                    category = ContactCategory.GOVERNMENT,
                    province = "สระบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 036-343-500)"
                ))
                list.add(EmergencyContactItem(
                    id = "SRB_FND_1",
                    name = "สมาคมกู้ภัยสว่างรัตนตรัยธรรมสถานสระบุรี",
                    phoneNumber = "036-221-666",
                    category = ContactCategory.FOUNDATION,
                    province = "สระบุรี",
                    description = "ศูนย์กู้ภัยสว่างรัตนตรัย เรือกู้ภัยลุ่มน้ำป่าสัก 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "SRB_FND_2",
                    name = "มูลนิธิร่วมกตัญญูสระบุรี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สระบุรี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ลพบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "ลพบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดลพบุรี",
                    phoneNumber = "036-770-199",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลพบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ลพบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมเด็จพระนารายณ์มหาราช)",
                    phoneNumber = "036-785-444",
                    category = ContactCategory.GOVERNMENT,
                    province = "ลพบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 036-785-444)"
                ))
                list.add(EmergencyContactItem(
                    id = "LBI_FND_1",
                    name = "มูลนิธิร่วมกตัญญูลพบุรี",
                    phoneNumber = "036-411-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ลพบุรี",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพฉุกเฉินและบรรเทาอุทกภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "LBI_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งลพบุรี",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "ลพบุรี",
                    description = "สายด่วนกู้ภัยรับแจ้งเหตุฉุกเฉิน"
                ))
            }

            "สิงห์บุรี" -> {
                list.add(EmergencyContactItem(
                    id = "สิงห์บุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสิงห์บุรี",
                    phoneNumber = "036-507-135",
                    category = ContactCategory.GOVERNMENT,
                    province = "สิงห์บุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สิงห์บุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สิงห์บุรี)",
                    phoneNumber = "036-511-060",
                    category = ContactCategory.GOVERNMENT,
                    province = "สิงห์บุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 036-511-060)"
                ))
                list.add(EmergencyContactItem(
                    id = "SBR_FND_1",
                    name = "สมาคมกู้ภัยสิงห์บุรีร่วมใจ",
                    phoneNumber = "036-511-060",
                    category = ContactCategory.FOUNDATION,
                    province = "สิงห์บุรี",
                    description = "ชุดกู้ภัยทางน้ำแม่น้ำเจ้าพระยาและช่วยเหลือประชาชนน้ำท่วม"
                ))
                list.add(EmergencyContactItem(
                    id = "SBR_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งสิงห์บุรี",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "สิงห์บุรี",
                    description = "สายด่วนกู้ภัยฉุกเฉิน 24 ชม."
                ))
            }

            "อ่างทอง" -> {
                list.add(EmergencyContactItem(
                    id = "อ่างทอง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดอ่างทอง",
                    phoneNumber = "035-611-235",
                    category = ContactCategory.GOVERNMENT,
                    province = "อ่างทอง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "อ่างทอง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.อ่างทอง)",
                    phoneNumber = "035-611-520",
                    category = ContactCategory.GOVERNMENT,
                    province = "อ่างทอง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 035-611-520)"
                ))
                list.add(EmergencyContactItem(
                    id = "ATG_FND_1",
                    name = "สมาคมกู้ภัยจังหวัดอ่างทอง",
                    phoneNumber = "035-611-520",
                    category = ContactCategory.FOUNDATION,
                    province = "อ่างทอง",
                    description = "หน่วยกู้ภัยรับมือน้ำท่วมแม่น้ำเจ้าพระยาและแม่น้ำน้อย"
                ))
                list.add(EmergencyContactItem(
                    id = "ATG_FND_2",
                    name = "มูลนิธิป่อเต็กตึ๊งอ่างทอง",
                    phoneNumber = "1418",
                    category = ContactCategory.FOUNDATION,
                    province = "อ่างทอง",
                    description = "สายด่วนกู้ภัยฉุกเฉิน 24 ชม."
                ))
            }

            "ชัยนาท" -> {
                list.add(EmergencyContactItem(
                    id = "ชัยนาท_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดชัยนาท",
                    phoneNumber = "056-411-008",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชัยนาท",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ชัยนาท_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ชัยนาทนเรนทร)",
                    phoneNumber = "056-411-055",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชัยนาท",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 056-411-055)"
                ))
                list.add(EmergencyContactItem(
                    id = "CNT_FND_1",
                    name = "สมาคมกู้ภัยร่วมใจชัยนาท",
                    phoneNumber = "056-411-055",
                    category = ContactCategory.FOUNDATION,
                    province = "ชัยนาท",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำท้ายเขื่อนเจ้าพระยา"
                ))
                list.add(EmergencyContactItem(
                    id = "CNT_FND_2",
                    name = "มูลนิธิร่วมกตัญญูชัยนาท",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ชัยนาท",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "กาญจนบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "กาญจนบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดกาญจนบุรี",
                    phoneNumber = "034-515-998",
                    category = ContactCategory.GOVERNMENT,
                    province = "กาญจนบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "กาญจนบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พหลพลพยุหเสนา)",
                    phoneNumber = "034-587-800",
                    category = ContactCategory.GOVERNMENT,
                    province = "กาญจนบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 034-587-800)"
                ))
                list.add(EmergencyContactItem(
                    id = "KRI_FND_1",
                    name = "มูลนิธิพิทักษ์กาญจน์ (สำนักงานใหญ่)",
                    phoneNumber = "034-515-157",
                    category = ContactCategory.FOUNDATION,
                    province = "กาญจนบุรี",
                    description = "ศูนย์กู้ภัยครอบคลุมทั้งจังหวัด เรือกู้ภัยแม่น้ำแคว และทีมกู้ภัยป่าเขา 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "KRI_FND_2",
                    name = "มูลนิธิมิราเคิลออฟไลฟ์กาญจนบุรี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "กาญจนบุรี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ราชบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "ราชบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดราชบุรี",
                    phoneNumber = "032-332-573",
                    category = ContactCategory.GOVERNMENT,
                    province = "ราชบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ราชบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ราชบุรี)",
                    phoneNumber = "032-719-600",
                    category = ContactCategory.GOVERNMENT,
                    province = "ราชบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 032-719-600)"
                ))
                list.add(EmergencyContactItem(
                    id = "RBR_FND_1",
                    name = "มูลนิธิประชานุกูลราชบุรี",
                    phoneNumber = "032-321-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ราชบุรี",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำแม่น้ำแม่กลองและบรรเทาอุทกภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "RBR_FND_2",
                    name = "มูลนิธิปฐมบรมราชานุสรณ์ราชบุรี",
                    phoneNumber = "032-311-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ราชบุรี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "เพชรบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "เพชรบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดเพชรบุรี",
                    phoneNumber = "032-426-230",
                    category = ContactCategory.GOVERNMENT,
                    province = "เพชรบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "เพชรบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พระจอมเกล้า)",
                    phoneNumber = "032-709-999",
                    category = ContactCategory.GOVERNMENT,
                    province = "เพชรบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 032-709-999)"
                ))
                list.add(EmergencyContactItem(
                    id = "PBI_FND_1",
                    name = "มูลนิธิสว่างสรรเพชญธรรมสถานเพชรบุรี",
                    phoneNumber = "032-425-187",
                    category = ContactCategory.FOUNDATION,
                    province = "เพชรบุรี",
                    description = "ศูนย์กู้ภัยสว่างสรรเพชญ เรือกู้ภัยลุ่มน้ำเพชรบุรี 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PBI_FND_2",
                    name = "สมาคมกู้ภัยเพชรเกษมเพชรบุรี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "เพชรบุรี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ประจวบคีรีขันธ์" -> {
                list.add(EmergencyContactItem(
                    id = "ประจวบคีรีขันธ์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดประจวบคีรีขันธ์",
                    phoneNumber = "032-602-061",
                    category = ContactCategory.GOVERNMENT,
                    province = "ประจวบคีรีขันธ์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ประจวบคีรีขันธ์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ประจวบคีรีขันธ์)",
                    phoneNumber = "032-601-060",
                    category = ContactCategory.GOVERNMENT,
                    province = "ประจวบคีรีขันธ์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 032-601-060)"
                ))
                list.add(EmergencyContactItem(
                    id = "PKN_FND_1",
                    name = "มูลนิธิสว่างหัวหินธรรมสถาน",
                    phoneNumber = "032-514-514",
                    category = ContactCategory.FOUNDATION,
                    province = "ประจวบคีรีขันธ์",
                    description = "ศูนย์กู้ภัยสว่างหัวหิน กู้ชีพทางบกทางทะเล 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PKN_FND_2",
                    name = "มูลนิธิสว่างประจวบธรรมสถาน",
                    phoneNumber = "032-611-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ประจวบคีรีขันธ์",
                    description = "หน่วยกู้ภัยกู้ชีพฉุกเฉินประจำ อ.เมืองประจวบฯ"
                ))
                list.add(EmergencyContactItem(
                    id = "PKN_FND_3",
                    name = "มูลนิธิสว่างเมศธรรมสถาน (ปราณบุรี)",
                    phoneNumber = "032-621-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ประจวบคีรีขันธ์",
                    description = "ชุดกู้ภัยบรรเทาสาธารณภัย อ.ปราณบุรี"
                ))
            }

            "ชลบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "ชลบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดชลบุรี",
                    phoneNumber = "038-278-031",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชลบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ชลบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ชลบุรี)",
                    phoneNumber = "038-931-000",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชลบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 038-931-000)"
                ))
                list.add(EmergencyContactItem(
                    id = "CBI_FND_1",
                    name = "มูลนิธิสว่างบริบูรณ์ธรรมสถาน (พัทยา)",
                    phoneNumber = "038-221-380",
                    category = ContactCategory.FOUNDATION,
                    province = "ชลบุรี",
                    description = "ศูนย์กู้ภัยสว่างบริบูรณ์พัทยา กู้ภัยทางบกทางทะเล 24 ชม. (สายด่วน 080-641-6161)"
                ))
                list.add(EmergencyContactItem(
                    id = "CBI_FND_2",
                    name = "หน่วยกู้ภัยสว่างประทีป (ศรีราชา)",
                    phoneNumber = "038-310-319",
                    category = ContactCategory.FOUNDATION,
                    province = "ชลบุรี",
                    description = "ชุดกู้ภัยกู้ชีพฉุกเฉิน อ.ศรีราชา (หรือ 094-094-1669)"
                ))
                list.add(EmergencyContactItem(
                    id = "CBI_FND_3",
                    name = "มูลนิธิไตรคุณธรรม (ชลบุรี)",
                    phoneNumber = "038-282-334",
                    category = ContactCategory.FOUNDATION,
                    province = "ชลบุรี",
                    description = "ศูนย์กู้ภัยไตรคุณธรรม อ.เมืองชลบุรี 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CBI_FND_4",
                    name = "มูลนิธิสว่างเหตุบ้านทุ่งเหียง (พนัสนิคม)",
                    phoneNumber = "038-461-340",
                    category = ContactCategory.FOUNDATION,
                    province = "ชลบุรี",
                    description = "ชุดกู้ภัยตอบโต้ภัยพิบัติ อ.พนัสนิคม และ อ.เกาะจันทร์"
                ))
            }

            "ระยอง" -> {
                list.add(EmergencyContactItem(
                    id = "ระยอง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดระยอง",
                    phoneNumber = "038-694-118",
                    category = ContactCategory.GOVERNMENT,
                    province = "ระยอง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ระยอง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ระยอง)",
                    phoneNumber = "038-611-104",
                    category = ContactCategory.GOVERNMENT,
                    province = "ระยอง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 038-611-104)"
                ))
                list.add(EmergencyContactItem(
                    id = "RYG_FND_1",
                    name = "มูลนิธิสว่างพรกุศลระยอง",
                    phoneNumber = "038-611-092",
                    category = ContactCategory.FOUNDATION,
                    province = "ระยอง",
                    description = "ศูนย์กู้ภัยสว่างพรระยอง กู้ชีพทางบกทางทะเล 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "RYG_FND_2",
                    name = "มูลนิธิสยามรวมใจระยอง",
                    phoneNumber = "038-617-617",
                    category = ContactCategory.FOUNDATION,
                    province = "ระยอง",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉินและสาธารณภัย"
                ))
            }

            "จันทบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "จันทบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดจันทบุรี",
                    phoneNumber = "039-312-100",
                    category = ContactCategory.GOVERNMENT,
                    province = "จันทบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "จันทบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พระปกเกล้า)",
                    phoneNumber = "039-324-975",
                    category = ContactCategory.GOVERNMENT,
                    province = "จันทบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 039-324-975)"
                ))
                list.add(EmergencyContactItem(
                    id = "CTI_FND_1",
                    name = "สมาคมสว่างกตัญญูธรรมสถาน จันทบุรี",
                    phoneNumber = "039-311-388",
                    category = ContactCategory.FOUNDATION,
                    province = "จันทบุรี",
                    description = "ศูนย์วิทยุกู้ภัยสว่างกตัญญู กู้ภัยน้ำท่วมและดินสไลด์ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CTI_FND_2",
                    name = "สมาคมกู้ภัยร่วมใจจันทบุรี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "จันทบุรี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ตราด" -> {
                list.add(EmergencyContactItem(
                    id = "ตราด_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดตราด",
                    phoneNumber = "039-512-460",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตราด",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ตราด_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ตราด)",
                    phoneNumber = "039-511-040",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตราด",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 039-511-040)"
                ))
                list.add(EmergencyContactItem(
                    id = "TRT_FND_1",
                    name = "สมาคมสว่างบุญช่วยเหลือธรรมสถาน ตราด",
                    phoneNumber = "039-511-111",
                    category = ContactCategory.FOUNDATION,
                    province = "ตราด",
                    description = "ศูนย์กู้ภัยสว่างบุญช่วยเหลือ กู้ภัยทางบกทางทะเล 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "TRT_FND_2",
                    name = "สมาคมกู้ภัยหลักเกาะตราด",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ตราด",
                    description = "หน่วยกู้ชีพกู้ภัยช่วยเหลือประชาชน"
                ))
            }

            "ฉะเชิงเทรา" -> {
                list.add(EmergencyContactItem(
                    id = "ฉะเชิงเทรา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดฉะเชิงเทรา",
                    phoneNumber = "038-511-404",
                    category = ContactCategory.GOVERNMENT,
                    province = "ฉะเชิงเทรา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ฉะเชิงเทรา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พุทธโสธร)",
                    phoneNumber = "038-511-023",
                    category = ContactCategory.GOVERNMENT,
                    province = "ฉะเชิงเทรา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 038-511-023)"
                ))
                list.add(EmergencyContactItem(
                    id = "CCO_FND_1",
                    name = "หน่วยกู้ภัยฉะเชิงเทรา (สมาคมสงเคราะห์การกุศล)",
                    phoneNumber = "038-511-410",
                    category = ContactCategory.FOUNDATION,
                    province = "ฉะเชิงเทรา",
                    description = "ศูนย์กู้ภัยฉะเชิงเทรา เรือกู้ภัยลุ่มน้ำบางปะกง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CCO_FND_2",
                    name = "มูลนิธิสว่างศรัทธาธรรมสถาน",
                    phoneNumber = "038-511-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ฉะเชิงเทรา",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ปราจีนบุรี" -> {
                list.add(EmergencyContactItem(
                    id = "ปราจีนบุรี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดปราจีนบุรี",
                    phoneNumber = "037-454-045",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปราจีนบุรี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ปราจีนบุรี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.เจ้าพระยาอภัยภูเบศร)",
                    phoneNumber = "037-211-088",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปราจีนบุรี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 037-211-088)"
                ))
                list.add(EmergencyContactItem(
                    id = "PRI_FND_1",
                    name = "มูลนิธิสว่างบำเพ็ญธรรมสถาน ปราจีนบุรี",
                    phoneNumber = "037-211-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ปราจีนบุรี",
                    description = "ชุดปฏิบัติการกู้ภัยลุ่มน้ำปราจีนบุรีและอุทกภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PRI_FND_2",
                    name = "มูลนิธิสัจจะพุทธธรรมแห่งประเทศไทย (กบินทร์บุรี)",
                    phoneNumber = "037-281-645",
                    category = ContactCategory.FOUNDATION,
                    province = "ปราจีนบุรี",
                    description = "ศูนย์กู้ภัยสัจจะกบินทร์บุรี รับมือน้ำท่วมแม่น้ำแควหนุมาน"
                ))
            }

            "นครนายก" -> {
                list.add(EmergencyContactItem(
                    id = "นครนายก_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครนายก",
                    phoneNumber = "037-314-555",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครนายก",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครนายก_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.นครนายก)",
                    phoneNumber = "037-311-151",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครนายก",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 037-311-151)"
                ))
                list.add(EmergencyContactItem(
                    id = "NYK_FND_1",
                    name = "สมาคมกู้ภัยสว่างอริยะธรรมสถาน นครนายก",
                    phoneNumber = "037-311-151",
                    category = ContactCategory.FOUNDATION,
                    province = "นครนายก",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำและน้ำป่าไหลหลากนครนายก"
                ))
                list.add(EmergencyContactItem(
                    id = "NYK_FND_2",
                    name = "มูลนิธิร่วมกตัญญูนครนายก",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "นครนายก",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "สระแก้ว" -> {
                list.add(EmergencyContactItem(
                    id = "สระแก้ว_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสระแก้ว",
                    phoneNumber = "037-425-121",
                    category = ContactCategory.GOVERNMENT,
                    province = "สระแก้ว",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สระแก้ว_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สมเด็จพระยุพราชสระแก้ว)",
                    phoneNumber = "037-241-012",
                    category = ContactCategory.GOVERNMENT,
                    province = "สระแก้ว",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 037-241-012)"
                ))
                list.add(EmergencyContactItem(
                    id = "SKW_FND_1",
                    name = "มูลนิธิสว่างสระแก้วธรรมสถาน",
                    phoneNumber = "037-241-012",
                    category = ContactCategory.FOUNDATION,
                    province = "สระแก้ว",
                    description = "ศูนย์กู้ภัยสว่างสระแก้ว บรรเทาสาธารณภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "SKW_FND_2",
                    name = "สมาคมกู้ภัยอรัญประเทศ",
                    phoneNumber = "037-231-199",
                    category = ContactCategory.FOUNDATION,
                    province = "สระแก้ว",
                    description = "หน่วยกู้ภัยพื้นที่ชายแดนและ อ.อรัญประเทศ"
                ))
            }

            "นครราชสีมา" -> {
                list.add(EmergencyContactItem(
                    id = "นครราชสีมา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครราชสีมา",
                    phoneNumber = "044-242-175",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครราชสีมา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครราชสีมา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.มหาราชนครราชสีมา)",
                    phoneNumber = "044-235-000",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครราชสีมา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 044-235-000)"
                ))
                list.add(EmergencyContactItem(
                    id = "NR_FND_1",
                    name = "มูลนิธิพุทธธรรม 31 นครราชสีมา (ฮุก 31)",
                    phoneNumber = "044-307-298",
                    category = ContactCategory.FOUNDATION,
                    province = "นครราชสีมา",
                    description = "ทีมตอบโต้ภัยพิบัติระดับประเทศ เรือกู้ภัย ชุดค้นหาผู้สูญหาย (แจ้งเหตุ 044-307-299)"
                ))
                list.add(EmergencyContactItem(
                    id = "NR_FND_2",
                    name = "มูลนิธิสว่างเมตตาธรรมสถาน",
                    phoneNumber = "044-252-199",
                    category = ContactCategory.FOUNDATION,
                    province = "นครราชสีมา",
                    description = "หน่วยกู้ภัยกู้ชีพ ลำเลียงผู้ประสบภัยและผู้ป่วยติดเตียง"
                ))
                list.add(EmergencyContactItem(
                    id = "NR_FND_3",
                    name = "มูลนิธิสว่างวิชชาธรรมสถาน (ปากช่อง)",
                    phoneNumber = "044-311-199",
                    category = ContactCategory.FOUNDATION,
                    province = "นครราชสีมา",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำและน้ำป่าไหลหลาก อ.ปากช่อง เขาใหญ่"
                ))
            }

            "ขอนแก่น" -> {
                list.add(EmergencyContactItem(
                    id = "ขอนแก่น_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดขอนแก่น",
                    phoneNumber = "043-331-358",
                    category = ContactCategory.GOVERNMENT,
                    province = "ขอนแก่น",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ขอนแก่น_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ขอนแก่น)",
                    phoneNumber = "043-009-900",
                    category = ContactCategory.GOVERNMENT,
                    province = "ขอนแก่น",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 043-009-900)"
                ))
                list.add(EmergencyContactItem(
                    id = "KK_FND_1",
                    name = "สมาคมกู้ภัยสว่างขอนแก่นสามัคคีอุทิศ",
                    phoneNumber = "043-222-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ขอนแก่น",
                    description = "ชุดกู้ภัยทางน้ำ ช่วยเหลือผู้ติดค้างในพื้นที่ลุ่มต่ำ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "KK_FND_2",
                    name = "สมาคมกู้ภัยมิตรภาพขอนแก่น",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ขอนแก่น",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "อุบลราชธานี" -> {
                list.add(EmergencyContactItem(
                    id = "อุบลราชธานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดอุบลราชธานี",
                    phoneNumber = "045-344-635",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุบลราชธานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "อุบลราชธานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สรรพสิทธิประสงค์)",
                    phoneNumber = "045-319-200",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุบลราชธานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 045-319-200)"
                ))
                list.add(EmergencyContactItem(
                    id = "UB_FND_1",
                    name = "มูลนิธิการกุศลอุบลราชธานี (จีตัมเกาะ)",
                    phoneNumber = "045-244-199",
                    category = ContactCategory.FOUNDATION,
                    province = "อุบลราชธานี",
                    description = "เรือกู้ภัยทางน้ำ โรงครัวช่วยเหลือ และทีมอพยพผู้ประสบภัยน้ำท่วม"
                ))
                list.add(EmergencyContactItem(
                    id = "UB_FND_2",
                    name = "สมาคมกู้ภัยสว่างบูชาธรรม (วารินชำราบ)",
                    phoneNumber = "045-323-199",
                    category = ContactCategory.FOUNDATION,
                    province = "อุบลราชธานี",
                    description = "ชุดปฏิบัติการกู้ชีพกู้ภัย อ.วารินชำราบ และลุ่มน้ำมูล"
                ))
            }

            "อุดรธานี" -> {
                list.add(EmergencyContactItem(
                    id = "อุดรธานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดอุดรธานี",
                    phoneNumber = "042-246-805",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุดรธานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "อุดรธานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.อุดรธานี)",
                    phoneNumber = "042-245-555",
                    category = ContactCategory.GOVERNMENT,
                    province = "อุดรธานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-245-555)"
                ))
                list.add(EmergencyContactItem(
                    id = "UDN_FND_1",
                    name = "มูลนิธิอุดรสว่างเมธาธรรมสถาน",
                    phoneNumber = "042-245-463",
                    category = ContactCategory.FOUNDATION,
                    province = "อุดรธานี",
                    description = "ศูนย์กู้ภัยสว่างเมธาธรรมสถาน กู้ภัยทางบกทางน้ำ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "UDN_FND_2",
                    name = "มูลนิธิส่งเสริมธรรมแห่งอุดรธานี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "อุดรธานี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ชัยภูมิ" -> {
                list.add(EmergencyContactItem(
                    id = "ชัยภูมิ_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดชัยภูมิ",
                    phoneNumber = "044-811-660",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชัยภูมิ",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ชัยภูมิ_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ชัยภูมิ)",
                    phoneNumber = "044-811-005",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชัยภูมิ",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 044-811-005)"
                ))
                list.add(EmergencyContactItem(
                    id = "CPM_FND_1",
                    name = "มูลนิธิสว่างคุณธรรมชัยภูมิ (เจ้าพ่อพญาแล)",
                    phoneNumber = "044-811-037",
                    category = ContactCategory.FOUNDATION,
                    province = "ชัยภูมิ",
                    description = "ศูนย์กู้ภัยสว่างคุณธรรม ช่วยเหลือน้ำท่วมลุ่มน้ำชี 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CPM_FND_2",
                    name = "สมาคมกู้ภัยร่วมใจชัยภูมิ",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ชัยภูมิ",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "บุรีรัมย์" -> {
                list.add(EmergencyContactItem(
                    id = "บุรีรัมย์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดบุรีรัมย์",
                    phoneNumber = "044-666-559",
                    category = ContactCategory.GOVERNMENT,
                    province = "บุรีรัมย์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "บุรีรัมย์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.บุรีรัมย์)",
                    phoneNumber = "044-615-002",
                    category = ContactCategory.GOVERNMENT,
                    province = "บุรีรัมย์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 044-615-002)"
                ))
                list.add(EmergencyContactItem(
                    id = "BRM_FND_1",
                    name = "มูลนิธิสว่างจรรยาธรรมสถาน บุรีรัมย์",
                    phoneNumber = "044-614-033",
                    category = ContactCategory.FOUNDATION,
                    province = "บุรีรัมย์",
                    description = "ศูนย์กู้ภัยสว่างจรรยาธรรม ช่วยเหลือผู้ประสบอุทกภัย 24 ชม. (หรือ 044-611-521)"
                ))
                list.add(EmergencyContactItem(
                    id = "BRM_FND_2",
                    name = "สมาคมกู้ภัยสยามรวมใจบุรีรัมย์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "บุรีรัมย์",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "สุรินทร์" -> {
                list.add(EmergencyContactItem(
                    id = "สุรินทร์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสุรินทร์",
                    phoneNumber = "044-514-490",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุรินทร์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สุรินทร์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สุรินทร์)",
                    phoneNumber = "044-511-757",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุรินทร์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 044-511-757)"
                ))
                list.add(EmergencyContactItem(
                    id = "SRN_FND_1",
                    name = "มูลนิธิจิบเต็กเซี่ยงตึ๊ง สุรินทร์",
                    phoneNumber = "044-511-757",
                    category = ContactCategory.FOUNDATION,
                    province = "สุรินทร์",
                    description = "หน่วยกู้ภัยกู้ชีพฉุกเฉินและบรรเทาสาธารณภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "SRN_FND_2",
                    name = "สมาคมกู้ภัยสุรินทร์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สุรินทร์",
                    description = "ทีมตอบโต้ภัยพิบัติฉุกเฉิน"
                ))
            }

            "ศรีสะเกษ" -> {
                list.add(EmergencyContactItem(
                    id = "ศรีสะเกษ_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดศรีสะเกษ",
                    phoneNumber = "045-612-589",
                    category = ContactCategory.GOVERNMENT,
                    province = "ศรีสะเกษ",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ศรีสะเกษ_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ศรีสะเกษ)",
                    phoneNumber = "045-611-503",
                    category = ContactCategory.GOVERNMENT,
                    province = "ศรีสะเกษ",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 045-611-503)"
                ))
                list.add(EmergencyContactItem(
                    id = "SSK_FND_1",
                    name = "สมาคมกู้ภัยสว่างจิตต์ศรีสะเกษธรรมสถาน",
                    phoneNumber = "045-611-503",
                    category = ContactCategory.FOUNDATION,
                    province = "ศรีสะเกษ",
                    description = "ชุดกู้ภัยทางน้ำและช่วยเหลือผู้ประสบอุทกภัยลุ่มน้ำมูล"
                ))
                list.add(EmergencyContactItem(
                    id = "SSK_FND_2",
                    name = "มูลนิธิสว่างศรีสะเกษ",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ศรีสะเกษ",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "มหาสารคาม" -> {
                list.add(EmergencyContactItem(
                    id = "มหาสารคาม_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดมหาสารคาม",
                    phoneNumber = "043-777-315",
                    category = ContactCategory.GOVERNMENT,
                    province = "มหาสารคาม",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "มหาสารคาม_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.มหาสารคาม)",
                    phoneNumber = "043-711-750",
                    category = ContactCategory.GOVERNMENT,
                    province = "มหาสารคาม",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 043-711-750)"
                ))
                list.add(EmergencyContactItem(
                    id = "MSK_FND_1",
                    name = "มูลนิธิคุณธรรมการกุศล (เต็กก่า จีเสียงเกาะ)",
                    phoneNumber = "043-711-750",
                    category = ContactCategory.FOUNDATION,
                    province = "มหาสารคาม",
                    description = "ศูนย์กู้ภัยจีเสียงเกาะ ช่วยเหลือผู้ประสบภัยน้ำท่วม 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "MSK_FND_2",
                    name = "สมาคมกู้ภัยจีเสียงเกาะ",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "มหาสารคาม",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ร้อยเอ็ด" -> {
                list.add(EmergencyContactItem(
                    id = "ร้อยเอ็ด_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดร้อยเอ็ด",
                    phoneNumber = "043-512-955",
                    category = ContactCategory.GOVERNMENT,
                    province = "ร้อยเอ็ด",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ร้อยเอ็ด_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ร้อยเอ็ด)",
                    phoneNumber = "043-518-200",
                    category = ContactCategory.GOVERNMENT,
                    province = "ร้อยเอ็ด",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 043-518-200)"
                ))
                list.add(EmergencyContactItem(
                    id = "RET_FND_1",
                    name = "สมาคมกู้ภัยนครสาเกต ร้อยเอ็ด",
                    phoneNumber = "043-518-200",
                    category = ContactCategory.FOUNDATION,
                    province = "ร้อยเอ็ด",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำลุ่มน้ำชีและน้ำยัง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "RET_FND_2",
                    name = "มูลนิธิเจ้าปู่กุดเป่งร้อยเอ็ด",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ร้อยเอ็ด",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ยโสธร" -> {
                list.add(EmergencyContactItem(
                    id = "ยโสธร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดยโสธร",
                    phoneNumber = "045-714-383",
                    category = ContactCategory.GOVERNMENT,
                    province = "ยโสธร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ยโสธร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ยโสธร)",
                    phoneNumber = "045-712-555",
                    category = ContactCategory.GOVERNMENT,
                    province = "ยโสธร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 045-712-555)"
                ))
                list.add(EmergencyContactItem(
                    id = "YST_FND_1",
                    name = "สมาคมกู้ภัยสว่างร่วมใจยโสธร",
                    phoneNumber = "045-712-555",
                    category = ContactCategory.FOUNDATION,
                    province = "ยโสธร",
                    description = "ชุดกู้ภัยช่วยเหลือประชาชนน้ำท่วมลุ่มน้ำชี"
                ))
                list.add(EmergencyContactItem(
                    id = "YST_FND_2",
                    name = "มูลนิธิยโสธรร่วมใจสงเคราะห์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ยโสธร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "อำนาจเจริญ" -> {
                list.add(EmergencyContactItem(
                    id = "อำนาจเจริญ_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดอำนาจเจริญ",
                    phoneNumber = "045-523-031",
                    category = ContactCategory.GOVERNMENT,
                    province = "อำนาจเจริญ",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "อำนาจเจริญ_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.อำนาจเจริญ)",
                    phoneNumber = "045-511-940",
                    category = ContactCategory.GOVERNMENT,
                    province = "อำนาจเจริญ",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 045-511-940)"
                ))
                list.add(EmergencyContactItem(
                    id = "ACR_FND_1",
                    name = "สมาคมกู้ภัยอำนาจเจริญ",
                    phoneNumber = "045-511-940",
                    category = ContactCategory.FOUNDATION,
                    province = "อำนาจเจริญ",
                    description = "หน่วยกู้ชีพกู้ภัยและช่วยเหลือผู้ประสบภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "ACR_FND_2",
                    name = "มูลนิธิสว่างอำนาจธรรมสถาน",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "อำนาจเจริญ",
                    description = "ทีมตอบโต้สาธารณภัยฉุกเฉิน"
                ))
            }

            "กาฬสินธุ์" -> {
                list.add(EmergencyContactItem(
                    id = "กาฬสินธุ์_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดกาฬสินธุ์",
                    phoneNumber = "043-814-998",
                    category = ContactCategory.GOVERNMENT,
                    province = "กาฬสินธุ์",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "กาฬสินธุ์_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.กาฬสินธุ์)",
                    phoneNumber = "043-812-714",
                    category = ContactCategory.GOVERNMENT,
                    province = "กาฬสินธุ์",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 043-812-714)"
                ))
                list.add(EmergencyContactItem(
                    id = "KSN_FND_1",
                    name = "มูลนิธิคุณธรรมสงเคราะห์ (เต็กก่า จีสิ่งเกาะ)",
                    phoneNumber = "043-812-714",
                    category = ContactCategory.FOUNDATION,
                    province = "กาฬสินธุ์",
                    description = "ศูนย์กู้ภัยจีสิ่งเกาะ ช่วยเหลือน้ำท่วมลุ่มน้ำปาว 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "KSN_FND_2",
                    name = "สมาคมกู้ภัยร่วมใจกาฬสินธุ์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "กาฬสินธุ์",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "สกลนคร" -> {
                list.add(EmergencyContactItem(
                    id = "สกลนคร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสกลนคร",
                    phoneNumber = "042-711-773",
                    category = ContactCategory.GOVERNMENT,
                    province = "สกลนคร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สกลนคร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สกลนคร)",
                    phoneNumber = "042-711-037",
                    category = ContactCategory.GOVERNMENT,
                    province = "สกลนคร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-711-037)"
                ))
                list.add(EmergencyContactItem(
                    id = "SKT_FND_1",
                    name = "สมาคมกู้ภัยสว่างสัจจะธรรมสถาน สกลนคร",
                    phoneNumber = "042-711-037",
                    category = ContactCategory.FOUNDATION,
                    province = "สกลนคร",
                    description = "ศูนย์กู้ภัยสว่างสัจจะ ช่วยเหลือน้ำท่วมหนองหาร 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "SKT_FND_2",
                    name = "มูลนิธิเมตตาธรรมสกลนคร",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สกลนคร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "นครพนม" -> {
                list.add(EmergencyContactItem(
                    id = "นครพนม_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครพนม",
                    phoneNumber = "042-511-024",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครพนม",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครพนม_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.นครพนม)",
                    phoneNumber = "042-511-422",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครพนม",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-511-422)"
                ))
                list.add(EmergencyContactItem(
                    id = "NPM_FND_1",
                    name = "สมาคมกู้ภัยสว่างนาวาธาตุพนม",
                    phoneNumber = "042-511-422",
                    category = ContactCategory.FOUNDATION,
                    province = "นครพนม",
                    description = "ชุดกู้ภัยทางน้ำแม่น้ำโขงและลุ่มน้ำก่ำ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "NPM_FND_2",
                    name = "สมาคมกู้ภัยนครพนม",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "นครพนม",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "มุกดาหาร" -> {
                list.add(EmergencyContactItem(
                    id = "มุกดาหาร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดมุกดาหาร",
                    phoneNumber = "042-633-101",
                    category = ContactCategory.GOVERNMENT,
                    province = "มุกดาหาร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "มุกดาหาร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.มุกดาหาร)",
                    phoneNumber = "042-611-204",
                    category = ContactCategory.GOVERNMENT,
                    province = "มุกดาหาร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-611-204)"
                ))
                list.add(EmergencyContactItem(
                    id = "MDH_FND_1",
                    name = "มูลนิธิการกุศลมุกดาหาร (เต็กก่า จีหมกเกาะ)",
                    phoneNumber = "042-611-204",
                    category = ContactCategory.FOUNDATION,
                    province = "มุกดาหาร",
                    description = "ศูนย์กู้ภัยจีหมกเกาะ กู้ภัยทางน้ำแม่น้ำโขง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "MDH_FND_2",
                    name = "สมาคมกู้ภัยมุกดาหาร",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "มุกดาหาร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "เลย" -> {
                list.add(EmergencyContactItem(
                    id = "เลย_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดเลย",
                    phoneNumber = "042-811-871",
                    category = ContactCategory.GOVERNMENT,
                    province = "เลย",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "เลย_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.เลย)",
                    phoneNumber = "042-862-123",
                    category = ContactCategory.GOVERNMENT,
                    province = "เลย",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-862-123)"
                ))
                list.add(EmergencyContactItem(
                    id = "LEI_FND_1",
                    name = "มูลนิธิสว่างคีรีธรรม เลย",
                    phoneNumber = "042-862-123",
                    category = ContactCategory.FOUNDATION,
                    province = "เลย",
                    description = "ศูนย์กู้ภัยสว่างคีรีธรรม ช่วยเหลือน้ำป่าและดินสไลด์ 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "LEI_FND_2",
                    name = "สมาคมกู้ภัยร่วมใจเลย",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "เลย",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "หนองบัวลำภู" -> {
                list.add(EmergencyContactItem(
                    id = "หนองบัวลำภู_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดหนองบัวลำภู",
                    phoneNumber = "042-312-643",
                    category = ContactCategory.GOVERNMENT,
                    province = "หนองบัวลำภู",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "หนองบัวลำภู_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.หนองบัวลำภู)",
                    phoneNumber = "042-311-999",
                    category = ContactCategory.GOVERNMENT,
                    province = "หนองบัวลำภู",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-311-999)"
                ))
                list.add(EmergencyContactItem(
                    id = "NBP_FND_1",
                    name = "สมาคมกู้ภัยนเรศวรหนองบัวลำภู",
                    phoneNumber = "042-311-999",
                    category = ContactCategory.FOUNDATION,
                    province = "หนองบัวลำภู",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพฉุกเฉินจังหวัดหนองบัวลำภู"
                ))
                list.add(EmergencyContactItem(
                    id = "NBP_FND_2",
                    name = "มูลนิธิคุณธรรมหนองบัวลำภู",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "หนองบัวลำภู",
                    description = "หน่วยกู้ภัยช่วยเหลือประชาชน"
                ))
            }

            "หนองคาย" -> {
                list.add(EmergencyContactItem(
                    id = "หนองคาย_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดหนองคาย",
                    phoneNumber = "042-411-778",
                    category = ContactCategory.GOVERNMENT,
                    province = "หนองคาย",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "หนองคาย_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.หนองคาย)",
                    phoneNumber = "042-413-456",
                    category = ContactCategory.GOVERNMENT,
                    province = "หนองคาย",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-413-456)"
                ))
                list.add(EmergencyContactItem(
                    id = "NKI_FND_1",
                    name = "มูลนิธิสว่างคงคาธรรมสถาน หนองคาย (วีรชน)",
                    phoneNumber = "042-413-456",
                    category = ContactCategory.FOUNDATION,
                    province = "หนองคาย",
                    description = "ศูนย์กู้ภัยสว่างคงคา กู้ภัยทางน้ำแม่น้ำโขง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "NKI_FND_2",
                    name = "สมาคมกู้ภัยประจักษ์หนองคาย",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "หนองคาย",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "บึงกาฬ" -> {
                list.add(EmergencyContactItem(
                    id = "บึงกาฬ_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดบึงกาฬ",
                    phoneNumber = "042-492-491",
                    category = ContactCategory.GOVERNMENT,
                    province = "บึงกาฬ",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "บึงกาฬ_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.บึงกาฬ)",
                    phoneNumber = "042-491-161",
                    category = ContactCategory.GOVERNMENT,
                    province = "บึงกาฬ",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 042-491-161)"
                ))
                list.add(EmergencyContactItem(
                    id = "BKN_FND_1",
                    name = "สมาคมกู้ภัยสว่างศรีวิไลธรรมสถาน บึงกาฬ",
                    phoneNumber = "042-491-161",
                    category = ContactCategory.FOUNDATION,
                    province = "บึงกาฬ",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำแม่น้ำโขงและบรรเทาสาธารณภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "BKN_FND_2",
                    name = "สมาคมกู้ภัยบึงกาฬ",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "บึงกาฬ",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "สุราษฎร์ธานี" -> {
                list.add(EmergencyContactItem(
                    id = "สุราษฎร์ธานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสุราษฎร์ธานี",
                    phoneNumber = "077-275-847",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุราษฎร์ธานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สุราษฎร์ธานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สุราษฎร์ธานี)",
                    phoneNumber = "077-915-600",
                    category = ContactCategory.GOVERNMENT,
                    province = "สุราษฎร์ธานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 077-915-600)"
                ))
                list.add(EmergencyContactItem(
                    id = "SNI_FND_1",
                    name = "มูลนิธิกุศลศรัทธาสุราษฎร์ธานี",
                    phoneNumber = "077-272-328",
                    category = ContactCategory.FOUNDATION,
                    province = "สุราษฎร์ธานี",
                    description = "ศูนย์กู้ภัยกุศลศรัทธา ครอบคลุมทั่วทั้งจังหวัด กู้ภัยทางบกทางทะเล 24 ชม. (หรือ 077-287-630)"
                ))
                list.add(EmergencyContactItem(
                    id = "SNI_FND_2",
                    name = "สมาคมกู้ภัยเกาะสมุย",
                    phoneNumber = "077-421-444",
                    category = ContactCategory.FOUNDATION,
                    province = "สุราษฎร์ธานี",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพฉุกเฉิน อ.เกาะสมุย และ อ.เกาะพะงัน"
                ))
            }

            "นครศรีธรรมราช" -> {
                list.add(EmergencyContactItem(
                    id = "นครศรีธรรมราช_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนครศรีธรรมราช",
                    phoneNumber = "075-358-440",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครศรีธรรมราช",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นครศรีธรรมราช_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.มหาราชนครศรีธรรมราช)",
                    phoneNumber = "075-340-250",
                    category = ContactCategory.GOVERNMENT,
                    province = "นครศรีธรรมราช",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 075-340-250)"
                ))
                list.add(EmergencyContactItem(
                    id = "NST_FND_1",
                    name = "มูลนิธิประชาร่วมใจ นครศรีธรรมราช",
                    phoneNumber = "075-345-599",
                    category = ContactCategory.FOUNDATION,
                    province = "นครศรีธรรมราช",
                    description = "ศูนย์วิทยุประชาร่วมใจ กู้ภัยทางน้ำ ดินถล่มเทือกเขาหลวง 24 ชม. (หรือ 075-318-833)"
                ))
                list.add(EmergencyContactItem(
                    id = "NST_FND_2",
                    name = "มูลนิธิใต้เต็กตึ๊ง นครศรีธรรมราช",
                    phoneNumber = "1163",
                    category = ContactCategory.FOUNDATION,
                    province = "นครศรีธรรมราช",
                    description = "สายด่วนกู้ภัย 1163 / สนง. 075-343-602 รับแจ้งอุบัติเหตุและภัยพิบัติ 24 ชม."
                ))
            }

            "สงขลา" -> {
                list.add(EmergencyContactItem(
                    id = "สงขลา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสงขลา",
                    phoneNumber = "074-316-380",
                    category = ContactCategory.GOVERNMENT,
                    province = "สงขลา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สงขลา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.หาดใหญ่)",
                    phoneNumber = "074-273-100",
                    category = ContactCategory.GOVERNMENT,
                    province = "สงขลา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 074-273-100)"
                ))
                list.add(EmergencyContactItem(
                    id = "SK_FND_1",
                    name = "มูลนิธิมิตรภาพสามัคคี (ท่งเซียเซี่ยงตึ๊ง หาดใหญ่)",
                    phoneNumber = "1163",
                    category = ContactCategory.FOUNDATION,
                    province = "สงขลา",
                    description = "ชุดปฏิบัติการทางน้ำ เรือกู้ภัย อพยพน้ำท่วมเมืองหาดใหญ่ (สายด่วน 1163 หรือ 074-250-250)"
                ))
                list.add(EmergencyContactItem(
                    id = "SK_FND_2",
                    name = "มูลนิธิสว่างสงขลาร่วมใจ",
                    phoneNumber = "074-311-199",
                    category = ContactCategory.FOUNDATION,
                    province = "สงขลา",
                    description = "หน่วยกู้ภัยกู้ชีพทางน้ำและทางบก 24 ชม."
                ))
            }

            "ภูเก็ต" -> {
                list.add(EmergencyContactItem(
                    id = "ภูเก็ต_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดภูเก็ต",
                    phoneNumber = "076-510-098",
                    category = ContactCategory.GOVERNMENT,
                    province = "ภูเก็ต",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ภูเก็ต_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.วชิระภูเก็ต)",
                    phoneNumber = "076-361-234",
                    category = ContactCategory.GOVERNMENT,
                    province = "ภูเก็ต",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 076-361-234)"
                ))
                list.add(EmergencyContactItem(
                    id = "PK_FND_1",
                    name = "มูลนิธิกุศลธรรมภูเก็ต",
                    phoneNumber = "076-246-216",
                    category = ContactCategory.FOUNDATION,
                    province = "ภูเก็ต",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพฉุกเฉินทางบกและทางทะเล (หรือ 076-211-706)"
                ))
                list.add(EmergencyContactItem(
                    id = "PK_FND_2",
                    name = "ศูนย์กู้ชีพกู้ภัยกุศลธรรม (สาขาเมืองใหม่)",
                    phoneNumber = "076-621-338",
                    category = ContactCategory.FOUNDATION,
                    province = "ภูเก็ต",
                    description = "หน่วยกู้ชีพกู้ภัยตอนเหนือของเกาะภูเก็ต"
                ))
            }

            "กระบี่" -> {
                list.add(EmergencyContactItem(
                    id = "กระบี่_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดกระบี่",
                    phoneNumber = "075-612-740",
                    category = ContactCategory.GOVERNMENT,
                    province = "กระบี่",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "กระบี่_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.กระบี่)",
                    phoneNumber = "075-626-700",
                    category = ContactCategory.GOVERNMENT,
                    province = "กระบี่",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 075-626-700)"
                ))
                list.add(EmergencyContactItem(
                    id = "KBI_FND_1",
                    name = "มูลนิธิกระบี่พิทักษ์ประชา",
                    phoneNumber = "075-656-115",
                    category = ContactCategory.FOUNDATION,
                    province = "กระบี่",
                    description = "ชุดปฏิบัติการกู้ภัยกู้ชีพฉุกเฉินทางบกทางทะเล 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "KBI_FND_2",
                    name = "มูลนิธิประชาสันติสุข กระบี่",
                    phoneNumber = "075-611-199",
                    category = ContactCategory.FOUNDATION,
                    province = "กระบี่",
                    description = "หน่วยกู้ภัยช่วยเหลือผู้ประสบภัย"
                ))
            }

            "พังงา" -> {
                list.add(EmergencyContactItem(
                    id = "พังงา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพังงา",
                    phoneNumber = "076-460-607",
                    category = ContactCategory.GOVERNMENT,
                    province = "พังงา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พังงา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พังงา)",
                    phoneNumber = "076-412-032",
                    category = ContactCategory.GOVERNMENT,
                    province = "พังงา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 076-412-032)"
                ))
                list.add(EmergencyContactItem(
                    id = "PNA_FND_1",
                    name = "สมาคมกู้ภัยพังงา (มูลนิธิสว่างพังงาธรรมสถาน)",
                    phoneNumber = "076-412-032",
                    category = ContactCategory.FOUNDATION,
                    province = "พังงา",
                    description = "ชุดกู้ภัยทางบกทางทะเลและพื้นที่ภูเขาดินสไลด์"
                ))
                list.add(EmergencyContactItem(
                    id = "PNA_FND_2",
                    name = "มูลนิธิกู้ภัยเขาหลัก",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "พังงา",
                    description = "หน่วยกู้ชีพกู้ภัยพื้นที่ท่องเที่ยวเขาหลักและอันดามัน"
                ))
            }

            "ตรัง" -> {
                list.add(EmergencyContactItem(
                    id = "ตรัง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดตรัง",
                    phoneNumber = "075-214-382",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตรัง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ตรัง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ตรัง)",
                    phoneNumber = "075-201-500",
                    category = ContactCategory.GOVERNMENT,
                    province = "ตรัง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 075-201-500)"
                ))
                list.add(EmergencyContactItem(
                    id = "TRG_FND_1",
                    name = "มูลนิธิกุศลสถานตรัง (บ้วนเต็กเซี่ยงตึ๊ง)",
                    phoneNumber = "075-215-554",
                    category = ContactCategory.FOUNDATION,
                    province = "ตรัง",
                    description = "ชุดกู้ชีพบรรเทาตรัง กู้ภัยทางน้ำแม่น้ำตรังและอพยพน้ำท่วม 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "TRG_FND_2",
                    name = "สมาคมกู้ภัยย่านตาขาว",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ตรัง",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "พัทลุง" -> {
                list.add(EmergencyContactItem(
                    id = "พัทลุง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดพัทลุง",
                    phoneNumber = "074-611-652",
                    category = ContactCategory.GOVERNMENT,
                    province = "พัทลุง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "พัทลุง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.พัทลุง)",
                    phoneNumber = "074-601-100",
                    category = ContactCategory.GOVERNMENT,
                    province = "พัทลุง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 074-601-100)"
                ))
                list.add(EmergencyContactItem(
                    id = "PLG_FND_1",
                    name = "มูลนิธิพัทลุงการกุศล (กู้ภัยพัทลุง)",
                    phoneNumber = "074-601-100",
                    category = ContactCategory.FOUNDATION,
                    province = "พัทลุง",
                    description = "ชุดกู้ภัยทางน้ำริมทะเลสาบสงขลา-พัทลุง 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PLG_FND_2",
                    name = "สมาคมกู้ภัยสว่างพัทลุงธรรมสถาน",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "พัทลุง",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ชุมพร" -> {
                list.add(EmergencyContactItem(
                    id = "ชุมพร_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดชุมพร",
                    phoneNumber = "077-501-207",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชุมพร",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ชุมพร_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ชุมพรเขตรอุดมศักดิ์)",
                    phoneNumber = "077-503-455",
                    category = ContactCategory.GOVERNMENT,
                    province = "ชุมพร",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 077-503-455)"
                ))
                list.add(EmergencyContactItem(
                    id = "CPN_FND_1",
                    name = "สมาคมนักข่าวและกู้ภัยสายชลชุมพร",
                    phoneNumber = "077-503-455",
                    category = ContactCategory.FOUNDATION,
                    province = "ชุมพร",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำลุ่มน้ำท่าตะเภาและคลื่นลมทะเล 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "CPN_FND_2",
                    name = "มูลนิธิชุมพรการกุศลสงเคราะห์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ชุมพร",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ระนอง" -> {
                list.add(EmergencyContactItem(
                    id = "ระนอง_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดระนอง",
                    phoneNumber = "077-810-199",
                    category = ContactCategory.GOVERNMENT,
                    province = "ระนอง",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ระนอง_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ระนอง)",
                    phoneNumber = "077-812-630",
                    category = ContactCategory.GOVERNMENT,
                    province = "ระนอง",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 077-812-630)"
                ))
                list.add(EmergencyContactItem(
                    id = "RNG_FND_1",
                    name = "สมาคมกู้ภัยระนองสงเคราะห์",
                    phoneNumber = "077-812-630",
                    category = ContactCategory.FOUNDATION,
                    province = "ระนอง",
                    description = "ชุดปฏิบัติการกู้ภัยพื้นที่ภูเขา ดินถล่ม และคลื่นลมมรสุม 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "RNG_FND_2",
                    name = "มูลนิธิระนองสงเคราะห์",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ระนอง",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "สตูล" -> {
                list.add(EmergencyContactItem(
                    id = "สตูล_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดสตูล",
                    phoneNumber = "074-722-121",
                    category = ContactCategory.GOVERNMENT,
                    province = "สตูล",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "สตูล_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.สตูล)",
                    phoneNumber = "074-723-500",
                    category = ContactCategory.GOVERNMENT,
                    province = "สตูล",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 074-723-500)"
                ))
                list.add(EmergencyContactItem(
                    id = "STN_FND_1",
                    name = "มูลนิธิธรรมรังสีสตูล",
                    phoneNumber = "074-723-500",
                    category = ContactCategory.FOUNDATION,
                    province = "สตูล",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำและช่วยเหลือผู้ประสบอุทกภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "STN_FND_2",
                    name = "สมาคมกู้ชีพกู้ภัยร่มไทรสตูล",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "สตูล",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ปัตตานี" -> {
                list.add(EmergencyContactItem(
                    id = "ปัตตานี_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดปัตตานี",
                    phoneNumber = "073-338-920",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปัตตานี",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ปัตตานี_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ปัตตานี)",
                    phoneNumber = "073-348-500",
                    category = ContactCategory.GOVERNMENT,
                    province = "ปัตตานี",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 073-348-500)"
                ))
                list.add(EmergencyContactItem(
                    id = "PTN_FND_1",
                    name = "สมาคมกู้ภัยปัตตานี",
                    phoneNumber = "073-348-500",
                    category = ContactCategory.FOUNDATION,
                    province = "ปัตตานี",
                    description = "ชุดกู้ภัยทางน้ำแม่น้ำปัตตานีและบรรเทาสาธารณภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "PTN_FND_2",
                    name = "สมาคมกู้ชีพกู้ภัยสันติปัตตานี",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "ปัตตานี",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน"
                ))
            }

            "ยะลา" -> {
                list.add(EmergencyContactItem(
                    id = "ยะลา_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดยะลา",
                    phoneNumber = "073-203-562",
                    category = ContactCategory.GOVERNMENT,
                    province = "ยะลา",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "ยะลา_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.ยะลา)",
                    phoneNumber = "073-244-711",
                    category = ContactCategory.GOVERNMENT,
                    province = "ยะลา",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 073-244-711)"
                ))
                list.add(EmergencyContactItem(
                    id = "YLA_FND_1",
                    name = "มูลนิธิกู้ภัยยาลอ ยะลา",
                    phoneNumber = "073-244-711",
                    category = ContactCategory.FOUNDATION,
                    province = "ยะลา",
                    description = "ชุดปฏิบัติการกู้ภัยทางน้ำแม่น้ำปัตตานีและกู้ชีพฉุกเฉิน 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "YLA_FND_2",
                    name = "สมาคมกู้ภัยสว่างเบตงธรรมสถาน",
                    phoneNumber = "073-231-199",
                    category = ContactCategory.FOUNDATION,
                    province = "ยะลา",
                    description = "หน่วยกู้ภัยประจำ อ.เบตง และพื้นที่ภูเขาสูง"
                ))
            }

            "นราธิวาส" -> {
                list.add(EmergencyContactItem(
                    id = "นราธิวาส_GOV_DDPM",
                    name = "สนง.ปภ. จังหวัดนราธิวาส",
                    phoneNumber = "073-532-122",
                    category = ContactCategory.GOVERNMENT,
                    province = "นราธิวาส",
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัย รับแจ้งเหตุภัยพิบัติ 24 ชม. (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "นราธิวาส_GOV_EMS",
                    name = "ศูนย์กู้ชีพ 1669 (รพ.นราธิวาสราชนครินทร์)",
                    phoneNumber = "073-510-999",
                    category = ContactCategory.GOVERNMENT,
                    province = "นราธิวาส",
                    description = "ศูนย์รับแจ้งเหตุและสั่งการแพทย์ฉุกเฉิน ลำเลียงผู้ป่วยวิกฤต (โทร 1669 หรือเบอร์ตรง 073-510-999)"
                ))
                list.add(EmergencyContactItem(
                    id = "NWT_FND_1",
                    name = "มูลนิธิเมตตาธรรมนราธิวาส",
                    phoneNumber = "073-510-999",
                    category = ContactCategory.FOUNDATION,
                    province = "นราธิวาส",
                    description = "ชุดปฏิบัติการกู้ภัยลุ่มน้ำโก-ลก ลุ่มน้ำบางนรา และบรรเทาอุทกภัย 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "NWT_FND_2",
                    name = "สมาคมกู้ภัยสุไหงโก-ลก",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = "นราธิวาส",
                    description = "หน่วยกู้ชีพกู้ภัยฉุกเฉิน อ.สุไหงโก-ลก"
                ))
            }

            else -> {
                list.add(EmergencyContactItem(
                    id = "${provinceName}_GOV_1",
                    name = "สนง.ป้องกันและบรรเทาสาธารณภัย จ.$provinceName",
                    phoneNumber = "1784",
                    category = ContactCategory.GOVERNMENT,
                    province = provinceName,
                    description = "ศูนย์อำนวยการป้องกันและบรรเทาสาธารณภัยจังหวัด (สายด่วน 1784)"
                ))
                list.add(EmergencyContactItem(
                    id = "${provinceName}_GOV_2",
                    name = "ศูนย์การแพทย์ฉุกเฉิน 1669 จ.$provinceName",
                    phoneNumber = "1669",
                    category = ContactCategory.GOVERNMENT,
                    province = provinceName,
                    description = "รับแจ้งเหตุกู้ชีพฉุกเฉิน บาดเจ็บ เจ็บป่วยวิกฤต ตลอด 24 ชม."
                ))
                list.add(EmergencyContactItem(
                    id = "${provinceName}_GOV_3",
                    name = "ตำรวจภูธรจังหวัด$provinceName",
                    phoneNumber = "191",
                    category = ContactCategory.GOVERNMENT,
                    province = provinceName,
                    description = "รับแจ้งเหตุด่วนเหตุร้ายและประสานงานความปลอดภัย (191)"
                ))
                list.add(EmergencyContactItem(
                    id = "${provinceName}_GOV_4",
                    name = "สถานีดับเพลิงและกู้ภัย จ.$provinceName",
                    phoneNumber = "199",
                    category = ContactCategory.GOVERNMENT,
                    province = provinceName,
                    description = "ดับเพลิง กู้ภัยอัคคีภัย และระบายน้ำฉุกเฉิน (199)"
                ))
                list.add(EmergencyContactItem(
                    id = "${provinceName}_FND_1",
                    name = "ศูนย์ประสานงานมูลนิธิกู้ภัย จ.$provinceName",
                    phoneNumber = "1669",
                    category = ContactCategory.FOUNDATION,
                    province = provinceName,
                    description = "เครือข่ายสมาคมกู้ภัยจิตอาสาและชุดช่วยเหลือผู้ประสบภัยประจำพื้นที่"
                ))
            }
        }

        // 2. Always append National Hotlines at bottom of list for completeness
        list.add(EmergencyContactItem(
            id = "NAT_1",
            name = "สถาบันการแพทย์ฉุกเฉินแห่งชาติ (สพฉ. 1669)",
            phoneNumber = "1669",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "สายด่วนกู้ชีพฉุกเฉินวิกฤตทั่วไทย โทรฟรี 24 ชม."
        ))
        list.add(EmergencyContactItem(
            id = "NAT_2",
            name = "สายด่วนนิรภัย กรมป้องกันและบรรเทาสาธารณภัย (ปภ. 1784)",
            phoneNumber = "1784",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "รับแจ้งภัยพิบัติน้ำท่วม ดินถล่ม วาตภัย ตลอด 24 ชม."
        ))
        list.add(EmergencyContactItem(
            id = "NAT_3",
            name = "ตำรวจทางหลวง (สายด่วน 1193)",
            phoneNumber = "1193",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "ช่วยเหลือเหตุฉุกเฉินบนทางหลวง สอบถามเส้นทางน้ำท่วมทางขาด"
        ))
        list.add(EmergencyContactItem(
            id = "NAT_4",
            name = "สายด่วนกรมชลประทาน (1460)",
            phoneNumber = "1460",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "สอบถามสถานการณ์น้ำในเขื่อน แม่น้ำหลัก และการระบายน้ำ"
        ))
        list.add(EmergencyContactItem(
            id = "NAT_5",
            name = "เหตุด่วนเหตุร้าย ตำรวจแห่งชาติ (191)",
            phoneNumber = "191",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "ศูนย์รับแจ้งเหตุด่วนเหตุร้ายและความปลอดภัยในชีวิตทรัพย์สิน"
        ))
        list.add(EmergencyContactItem(
            id = "NAT_6",
            name = "ดับเพลิงและกู้ภัย กทม. (199)",
            phoneNumber = "199",
            category = ContactCategory.GOVERNMENT,
            province = "ทั่วประเทศ",
            description = "ยืนยันบริการในกรุงเทพมหานคร พื้นที่อื่นโปรดตรวจเบอร์ดับเพลิงท้องถิ่น"
        ))

        return list.map { item ->
            when {
                item.phoneNumber == "199" -> item.copy(
                    name = "ดับเพลิงและกู้ภัย กทม. (199)", province = "กรุงเทพมหานคร",
                    description = "ยืนยันบริการในกรุงเทพมหานคร พื้นที่อื่นโปรดตรวจเบอร์ดับเพลิงท้องถิ่น"
                )
                item.phoneNumber == "1669" && !item.id.startsWith("NAT_") -> item.copy(
                    name = "สายด่วนการแพทย์ฉุกเฉิน (1669)",
                    category = ContactCategory.GOVERNMENT,
                    description = "สายด่วนกลางสำหรับเหตุเจ็บป่วยฉุกเฉิน ไม่ใช่เบอร์ตรงมูลนิธิ"
                )
                item.phoneNumber == "1418" -> item.copy(
                    name = "สายด่วนมูลนิธิป่อเต็กตึ๊ง (1418)",
                    description = "สายด่วนของมูลนิธิส่วนกลาง ไม่ยืนยันว่าเป็นเบอร์ตรงสาขาท้องถิ่น"
                )
                item.phoneNumber == "1163" -> item.copy(
                    name = "สายด่วนกู้ภัย (1163)",
                    description = "ยังไม่ยืนยันหน่วยรับสายและพื้นที่บริการตามจังหวัดที่เลือก"
                )
                item.id.endsWith("_GOV_EMS") -> item.copy(
                    name = item.name.replace("ศูนย์กู้ชีพ 1669", "ติดต่อโรงพยาบาล")
                        .replace(" (ศูนย์กู้ชีพเวียงพิงค์)", ""),
                    description = "เบอร์ตามทำเนียบ ยังไม่ยืนยันสายตรงศูนย์สั่งการหรือหมายเลขต่อ เหตุแพทย์ฉุกเฉินโทร 1669"
                )
                item.id.endsWith("_GOV_DDPM") -> item.copy(
                    description = "เบอร์สำนักงานตามทำเนียบ ยังไม่ยืนยันเวลารับสาย แจ้งภัยพิบัติโทรสายด่วน 1784"
                )
                item.phoneNumber == "1784" -> item.copy(
                    name = "สายด่วนนิรภัย ปภ. (1784)",
                    description = "สายด่วนกลางกรมป้องกันและบรรเทาสาธารณภัย"
                )
                item.phoneNumber == "191" -> item.copy(
                    name = "เหตุด่วนเหตุร้าย (191)",
                    description = "สายด่วนตำรวจรับแจ้งเหตุด่วนเหตุร้าย"
                )
                else -> item.copy(description = item.description
                    .replace("โทรฟรี 24 ชม.", "").replace("ตลอด 24 ชม.", "").replace("24 ชม.", "").trim())
            }
        }
    }
}
