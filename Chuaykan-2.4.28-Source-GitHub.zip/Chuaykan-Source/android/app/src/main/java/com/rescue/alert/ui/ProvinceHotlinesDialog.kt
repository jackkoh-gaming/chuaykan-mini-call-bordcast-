package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.rescue.alert.R
import com.rescue.alert.data.ProvinceEmergencyHotlinesRepository
import com.rescue.alert.model.ContactCategory
import com.rescue.alert.model.EmergencyContactItem

object ProvinceHotlinesDialog {

    fun show(context: Context, userLat: Double?, userLng: Double?) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_province_hotlines, null)
        dialog.setContentView(dialogView)

        dialog.window?.let { window ->
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val width = (context.resources.displayMetrics.widthPixels * 0.94).toInt()
            val height = (context.resources.displayMetrics.heightPixels * 0.88).toInt()
            window.setLayout(width, height)
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            window.setDimAmount(0.75f)
        }

        // View Bindings
        val tvCurrentProvinceName = dialogView.findViewById<TextView>(R.id.tvCurrentProvinceName)
        val btnChangeProvince = dialogView.findViewById<Button>(R.id.btnChangeProvince)
        val btnQuickCall1669 = dialogView.findViewById<Button>(R.id.btnQuickCall1669)
        val btnQuickCall1784 = dialogView.findViewById<Button>(R.id.btnQuickCall1784)
        val btnQuickCall199 = dialogView.findViewById<Button>(R.id.btnQuickCall199)
        val btnQuickCall191 = dialogView.findViewById<Button>(R.id.btnQuickCall191)

        val btnTabAll = dialogView.findViewById<Button>(R.id.btnTabAllContacts)
        val btnTabGov = dialogView.findViewById<Button>(R.id.btnTabGovContacts)
        val btnTabFnd = dialogView.findViewById<Button>(R.id.btnTabFoundationContacts)
        val cardsContainer = dialogView.findViewById<LinearLayout>(R.id.layoutHotlinesCardsContainer)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseHotlinesDialog)
        val tvAttribution = dialogView.findViewById<TextView>(R.id.tvHotlineAttribution)

        tvAttribution?.text = ProvinceEmergencyHotlinesRepository.DATA_SOURCE_ATTRIBUTION

        // State
        var detectedProvince = ProvinceEmergencyHotlinesRepository.detectProvince(userLat, userLng, context)
        var selectedProvince = detectedProvince
        var activeCategory: ContactCategory = ContactCategory.ALL

        fun dialNumber(phoneRaw: String) {
            try {
                val clean = phoneRaw.replace("-", "").replace(" ", "").trim()
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$clean")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "ไม่สามารถโทรออกได้: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        // Quick National Buttons (Crisp Rectangular Tactical Dispatch Switches)
        btnQuickCall1669.setOnClickListener { dialNumber("1669") }
        btnQuickCall1784.setOnClickListener { dialNumber("1784") }
        btnQuickCall199.setOnClickListener { dialNumber("199") }
        btnQuickCall191.setOnClickListener { dialNumber("191") }

        fun renderCards() {
            cardsContainer.removeAllViews()
            val allContacts = ProvinceEmergencyHotlinesRepository.getContactsForProvince(selectedProvince)

            val filtered = when (activeCategory) {
                ContactCategory.ALL -> allContacts
                ContactCategory.GOVERNMENT -> allContacts.filter { it.category == ContactCategory.GOVERNMENT }
                ContactCategory.FOUNDATION -> allContacts.filter { it.category == ContactCategory.FOUNDATION }
            }

            if (filtered.isEmpty()) {
                val tvEmpty = TextView(context).apply {
                    text = "ไม่พบรายการเบอร์ฉุกเฉินในหมวดหมู่นี้สำหรับจังหวัด$selectedProvince"
                    textSize = 13.5f
                    setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
                    gravity = android.view.Gravity.CENTER
                    setPadding(0, 48, 0, 48)
                }
                cardsContainer.addView(tvEmpty)
                return
            }

            for (item in filtered) {
                val card = inflater.inflate(R.layout.item_province_hotline_card, cardsContainer, false)

                val tvCategoryBadge = card.findViewById<TextView>(R.id.tvHotlineCategoryBadge)
                val tvProvince = card.findViewById<TextView>(R.id.tvHotlineProvince)
                val tvName = card.findViewById<TextView>(R.id.tvHotlineName)
                val tvDesc = card.findViewById<TextView>(R.id.tvHotlineDesc)
                val tvPhone = card.findViewById<TextView>(R.id.tvHotlinePhone)
                val btnCall = card.findViewById<Button>(R.id.btnCallHotline)

                // Category Badge Styling
                if (item.category == ContactCategory.GOVERNMENT) {
                    tvCategoryBadge.text = "หน่วยงานรัฐ"
                    tvCategoryBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#38BDF8"))
                    tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_gov)
                } else {
                    tvCategoryBadge.text = "มูลนิธิและกู้ภัย"
                    tvCategoryBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#34D399"))
                    tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_foundation)
                }

                tvProvince.text = if (item.province == "ทั่วประเทศ") "ทั่วประเทศ" else "จ.${item.province}"
                tvName.text = item.name
                tvDesc.text = if (item.phoneNumber.length > 4) {
                    item.description + "\nข้อมูลท้องถิ่น: ยังยืนยันหน่วยรับสายและบริการไม่ครบ"
                } else {
                    item.description
                }
                tvPhone.text = item.phoneNumber

                btnCall.setOnClickListener {
                    dialNumber(item.phoneNumber)
                }

                card.setOnClickListener {
                    dialNumber(item.phoneNumber)
                }

                cardsContainer.addView(card)
            }
        }

        fun updateTabs(category: ContactCategory) {
            activeCategory = category
            btnTabAll.setBackgroundResource(if (category == ContactCategory.ALL) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabGov.setBackgroundResource(if (category == ContactCategory.GOVERNMENT) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)
            btnTabFnd.setBackgroundResource(if (category == ContactCategory.FOUNDATION) R.drawable.bg_tactical_tab_active else R.drawable.bg_tactical_tab_inactive)

            btnTabAll.setTextColor(if (category == ContactCategory.ALL) Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            btnTabGov.setTextColor(if (category == ContactCategory.GOVERNMENT) Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))
            btnTabFnd.setTextColor(if (category == ContactCategory.FOUNDATION) Color.WHITE else com.rescue.alert.util.ThemePalette.color("#94A3B8"))

            renderCards()
        }

        fun updateProvinceView() {
            val suffix = if (selectedProvince == detectedProvince) " (พิกัดปัจจุบัน)" else " (เลือกเอง)"
            tvCurrentProvinceName.text = "จังหวัด$selectedProvince$suffix"
            renderCards()
        }

        // Tab click listeners
        btnTabAll.setOnClickListener { updateTabs(ContactCategory.ALL) }
        btnTabGov.setOnClickListener { updateTabs(ContactCategory.GOVERNMENT) }
        btnTabFnd.setOnClickListener { updateTabs(ContactCategory.FOUNDATION) }

        // Professional Tactical Province Picker (Zero Circles, Zero Ovals)
        btnChangeProvince.setOnClickListener {
            val pickerDialog = Dialog(context)
            pickerDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

            val pickerView = inflater.inflate(R.layout.dialog_province_picker, null)
            pickerDialog.setContentView(pickerView)

            pickerDialog.window?.let { window ->
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val width = (context.resources.displayMetrics.widthPixels * 0.90).toInt()
                val height = (context.resources.displayMetrics.heightPixels * 0.82).toInt()
                window.setLayout(width, height)
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                window.setDimAmount(0.80f)
            }

            val listContainer = pickerView.findViewById<LinearLayout>(R.id.layoutProvinceListContainer)
            val btnCancel = pickerView.findViewById<Button>(R.id.btnCancelProvincePicker)

            val provinces = ProvinceEmergencyHotlinesRepository.getAllProvinces()
            for (p in provinces) {
                val itemView = inflater.inflate(R.layout.item_province_picker, listContainer, false)
                val tvName = itemView.findViewById<TextView>(R.id.tvPickerProvinceName)
                val tvStatus = itemView.findViewById<TextView>(R.id.tvPickerStatusTag)

                tvName.text = p
                if (p == selectedProvince) {
                    itemView.setBackgroundResource(R.drawable.bg_picker_item_selected)
                    tvName.setTextColor(Color.WHITE)
                    tvName.setTypeface(null, Typeface.BOLD)
                    tvStatus.visibility = View.VISIBLE
                } else {
                    itemView.setBackgroundResource(R.drawable.bg_picker_item_unselected)
                    tvName.setTextColor(com.rescue.alert.util.ThemePalette.color("#CBD5E1"))
                    tvName.setTypeface(null, Typeface.NORMAL)
                    tvStatus.visibility = View.GONE
                }

                itemView.setOnClickListener {
                    selectedProvince = p
                    updateProvinceView()
                    pickerDialog.dismiss()
                }

                listContainer.addView(itemView)
            }

            btnCancel.setOnClickListener {
                pickerDialog.dismiss()
            }

            pickerDialog.show()
        }

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        // Initial setup
        updateProvinceView()
        dialog.show()
    }
}
