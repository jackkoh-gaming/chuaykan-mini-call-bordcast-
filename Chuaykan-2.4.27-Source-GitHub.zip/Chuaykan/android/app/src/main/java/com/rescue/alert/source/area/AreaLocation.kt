package com.rescue.alert.source.area

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AreaLocation {
    const val MAX_AGE_MS = 5 * 60 * 1000L
    private const val MAX_ACCURACY_METERS = 250f
    @Volatile private var latest: Location? = null
    @Volatile private var resolved: Pair<Location, DeviceArea>? = null

    fun accept(location: Location) {
        if (usable(location)) latest = Location(location)
    }

    fun usable(location: Location): Boolean {
        @Suppress("DEPRECATION")
        if (location.isFromMockProvider) return false
        val age = (SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos) / 1_000_000
        return age in 0..MAX_AGE_MS && location.hasAccuracy() &&
            location.accuracy in 0f..MAX_ACCURACY_METERS &&
            location.latitude.isFinite() && location.latitude in -90.0..90.0 &&
            location.longitude.isFinite() && location.longitude in -180.0..180.0
    }

    fun current(context: Context): Location? {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) return null
        val candidates = mutableListOf<Location>()
        latest?.let { candidates.add(it) }
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!androidx.core.location.LocationManagerCompat.isLocationEnabled(manager)) return null
        for (provider in listOf("fused", "gps", "network", "passive")) {
            try { manager.getLastKnownLocation(provider)?.let { candidates.add(it) } }
            catch (_: SecurityException) { return null }
            catch (_: IllegalArgumentException) { }
        }
        return candidates.filter { usable(it) }.maxByOrNull { it.elapsedRealtimeNanos }
    }

    fun cached(context: Context): DeviceArea? {
        val location = current(context) ?: return null
        val cached = resolved ?: return null
        return cached.second.takeIf { location.distanceTo(cached.first) < 25f }
    }

    /** Called only on an IO worker. No nearest-province or text-substring fallback. */
    fun resolve(context: Context, provinces: JSONArray): DeviceArea? {
        val location = current(context) ?: return null
        cached(context)?.let { return it }
        if (!Geocoder.isPresent()) return null
        val geocoder = Geocoder(context, Locale("th", "TH"))
        val addresses: List<Address> = try {
            if (Build.VERSION.SDK_INT >= 33) {
                val done = CountDownLatch(1)
                var result: List<Address> = emptyList()
                geocoder.getFromLocation(location.latitude, location.longitude, 1, object : Geocoder.GeocodeListener {
                    override fun onGeocode(found: MutableList<Address>) { result = found; done.countDown() }
                    override fun onError(errorMessage: String?) { done.countDown() }
                })
                if (!done.await(12, TimeUnit.SECONDS)) return null
                result
            } else {
                @Suppress("DEPRECATION")
                geocoder.getFromLocation(location.latitude, location.longitude, 1).orEmpty()
            }
        } catch (e: Exception) { Log.w("AreaLocation", "Cannot resolve administrative area: ${e.message}"); return null }
        val address = addresses.firstOrNull() ?: return null
        val province = rows(provinces).singleOrNull {
            same(address.adminArea, it.optString("province_name_th")) ||
                same(address.adminArea, it.optString("province_name_en"))
        } ?: return null
        val provinceCode = province.optString("province_code")
        val geo = geo(context)
        val districtCandidates = listOfNotNull(address.subAdminArea, address.locality)
        val district = rows(geo.getJSONArray("dim_amphoe")).filter { it.optString("province_code") == provinceCode }
            .singleOrNull { row -> districtCandidates.any { same(it, row.optString("amphoe_name_th")) || same(it, row.optString("amphoe_name_en")) } }
        val districtCode = district?.optString("amphoe_code")
        val subdistrictCandidates = listOfNotNull(address.subLocality, address.locality)
        val subdistrict = if (districtCode == null) null else rows(geo.getJSONArray("dim_tambon"))
            .filter { it.optString("amphoe_code") == districtCode }
            .singleOrNull { row -> subdistrictCandidates.any { same(it, row.optString("tambon_name_th")) || same(it, row.optString("tambon_name_en")) } }
        val area = DeviceArea(provinceCode, districtCode, subdistrict?.optString("tambon_code"),
            listOfNotNull(subdistrict?.optString("tambon_name_th"), district?.optString("amphoe_name_th"), province.optString("province_name_th")).joinToString(" / "))
        resolved = Location(location) to area
        Log.i("AreaLocation", "Resolved codes=${area.province}/${area.district}/${area.subdistrict} accuracy=${location.accuracy}m label=${area.label}")
        return area
    }

    private var geoData: JSONObject? = null
    @Synchronized private fun geo(context: Context): JSONObject {
        return geoData ?: JSONObject(context.assets.open("official_cb_geo.json").bufferedReader().use { it.readText() }).also { geoData = it }
    }
    private fun rows(array: JSONArray) = (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    private fun same(a: String?, b: String): Boolean = !a.isNullOrBlank() && b.isNotBlank() && normalize(a) == normalize(b)
    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)
        .replace(Regex("^(จังหวัด|อำเภอ|ตำบล|แขวง|เขต|จ\\.|อ\\.|ต\\.|changwat |amphoe |tambon |khet |khwaeng )"), "")
        .replace(Regex(" (province|district|subdistrict)$"), "")
        .replace(" ", "").replace("กรุงเทพฯ", "กรุงเทพมหานคร").replace("bangkok", "กรุงเทพมหานคร")
}
