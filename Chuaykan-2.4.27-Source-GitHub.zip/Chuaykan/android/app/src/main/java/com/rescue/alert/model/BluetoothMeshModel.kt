package com.rescue.alert.model

enum class MeshNodeType {
    SELF,
    DIRECT_NEIGHBOR,
    RELAY_NODE,
    RESCUE_POST
}

data class MeshNode(
    val nodeId: String,
    val houseName: String,
    var distanceMeters: Int,
    var rssi: Int,
    val hopCount: Int,
    val relayVia: String?,
    val nodeType: MeshNodeType,
    var batteryPercent: Int = -1,
    var isOnline: Boolean = true,
    var lastSeenMs: Long = System.currentTimeMillis(),
    val isAppVerified: Boolean = true,
    val appProtocolVersion: String = "THAI_DISASTER_v2.1",
    val deviceAddress: String = ""
)

data class MeshVoicePacket(
    val packetId: String,
    val appMagic: String = "RESCUE_ALERT_THAI_DISASTER_MESH_v2",
    val sourceNodeId: String,
    val sourceHouseName: String,
    val targetNodeId: String,
    var hopCount: Int,
    var ttl: Int,
    val audioData: ByteArray,
    val timestamp: Long = System.currentTimeMillis(),
    val isSosEmergency: Boolean = false,
    val isAppCertified: Boolean = true
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MeshVoicePacket
        return packetId == other.packetId
    }

    override fun hashCode(): Int {
        return packetId.hashCode()
    }
}
