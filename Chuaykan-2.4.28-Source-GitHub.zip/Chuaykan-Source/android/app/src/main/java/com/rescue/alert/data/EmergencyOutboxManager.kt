package com.rescue.alert.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Manages reliable offline emergency SOS outbox queue.
 * Prevents false-success reporting: If network is offline, stores payloads in
 * isolated internal disk storage (avoiding SharedPreferences memory bloating with large Base64 voice audio)
 * and retries transmission automatically when connectivity returns.
 */
object EmergencyOutboxManager {

    private const val TAG = "EmergencyOutboxManager"
    private const val PREFS_NAME = "emergency_outbox_prefs"
    private const val KEY_PENDING_QUEUE = "pending_sos_metadata_queue"
    private const val OUTBOX_DIR = "sos_outbox"
    private const val MAX_RETRIES = 50
    private const val MAX_AGE_MS = 48 * 60 * 60 * 1000L // 48 hours retention

    // Configurable SOS Endpoints (Gateway /api/sos/report)
    const val PRIMARY_SOS_PATH = "/api/sos/report"

    fun getPrimarySosUrl(context: Context? = null): String {
        val base = if (context != null) com.rescue.alert.util.AppSettings.getGatewayBaseUrl(context) else com.rescue.alert.util.AppSettings.DEFAULT_GATEWAY_URL
        return "$base$PRIMARY_SOS_PATH"
    }


    private fun getOutboxDir(context: Context): File {
        val dir = File(context.filesDir, OUTBOX_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    @Synchronized
    fun enqueueSos(context: Context, payloadJson: String) {
        try {
            val dir = getOutboxDir(context)
            val fileId = "sos_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
            val payloadFile = File(dir, "$fileId.json")
            payloadFile.writeText(payloadJson, Charsets.UTF_8)

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val currentQueueStr = prefs.getString(KEY_PENDING_QUEUE, "[]") ?: "[]"
            val jsonArray = try { JSONArray(currentQueueStr) } catch (e: Exception) { JSONArray() }

            val metaEntry = JSONObject().apply {
                put("id", fileId)
                put("queued_at", System.currentTimeMillis())
                put("file_path", payloadFile.absolutePath)
                put("retry_count", 0)
            }
            jsonArray.put(metaEntry)

            prefs.edit().putString(KEY_PENDING_QUEUE, jsonArray.toString()).apply()
            Log.i(TAG, "Queued SOS payload to disk (${payloadFile.length()} bytes). Total pending: ${jsonArray.length()}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enqueue SOS to disk", e)
        }
    }

    fun getPendingCount(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentQueueStr = prefs.getString(KEY_PENDING_QUEUE, "[]") ?: "[]"
        return try {
            JSONArray(currentQueueStr).length()
        } catch (e: Exception) {
            0
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = cm.activeNetwork ?: return false
            val cap = cm.getNetworkCapabilities(network) ?: return false
            return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            val netInfo = cm.activeNetworkInfo
            @Suppress("DEPRECATION")
            return netInfo?.isConnected == true
        }
    }

    /**
     * Attempts to send a single SOS payload to backend.
     * Throws Exception on failure.
     */
    /** Normalize this phone's legacy model identifier; preserve the request and image. */
    fun prepareSosPayload(payloadJson: String, nodeId: String, model: String): JSONObject {
        val payload = JSONObject(payloadJson)
        val device = payload.optString("device_id")
        require(device == nodeId || device == model) { "คำขอไม่ตรงกับเครื่องนี้" }
        payload.put("device_id", nodeId)
        if (payload.optString("case_id").isBlank()) {
            val digest = java.security.MessageDigest.getInstance("SHA-256").digest(payloadJson.toByteArray(Charsets.UTF_8))
            val stable = digest.take(16).joinToString("") { "%02x".format(it.toInt() and 0xff) }
            payload.put("case_id", "CRITICAL_$stable")
        }
        return payload
    }

    fun sendSosPayload(payloadJson: String, targetUrl: String? = null, context: Context? = null): Boolean {
        val effectivePrimary = targetUrl ?: getPrimarySosUrl(context)
        val urlsToTry = mutableListOf(effectivePrimary)
        for (urlStr in urlsToTry) {
            var conn: HttpURLConnection? = null
            try {
                require(context != null)
                val payload = prepareSosPayload(payloadJson,
                    com.rescue.alert.bluetooth.BluetoothMeshManager.getInstance(context).myNodeId, android.os.Build.MODEL)
                val url = URL(urlStr)
                conn = com.rescue.alert.network.SecureGateway.open(context, url)
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.doOutput = true
                conn.connectTimeout = 6000
                conn.readTimeout = 6000

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload.toString())
                    writer.flush()
                }

                val code = conn.responseCode
                if (code in 200..299) {
                    val receipt = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    if (receipt.optString("status") == "SUCCESS" && receipt.optString("case_id") == payload.optString("case_id")) {
                        GeneralSosOutbox.acknowledgeCritical(context, payload.getString("case_id"), receipt.optString("case_status", "PENDING"))
                        Log.i(TAG, "SOS gateway confirmed receipt (HTTP $code)")
                        return true
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed sending SOS to $urlStr: ${e.message}")
            } finally {
                conn?.disconnect()
            }
        }
        return false
    }

    /**
     * Flushes the local offline outbox queue when internet is available.
     * Deletes transmitted payload files from disk upon HTTP success.
     */
    @Synchronized
    fun flushOutbox(context: Context, onComplete: ((successCount: Int, remainingCount: Int) -> Unit)? = null) {
        Thread {
            if (!isNetworkAvailable(context)) {
                onComplete?.invoke(0, getPendingCount(context))
                return@Thread
            }

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val queueStr = prefs.getString(KEY_PENDING_QUEUE, "[]") ?: "[]"
            val jsonArray = try { JSONArray(queueStr) } catch (e: Exception) { JSONArray() }

            if (jsonArray.length() == 0) {
                onComplete?.invoke(0, 0)
                return@Thread
            }

            val remainingList = JSONArray()
            var successCount = 0
            val now = System.currentTimeMillis()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(i) ?: continue
                val filePath = item.optString("file_path", "")
                val queuedAt = item.optLong("queued_at", now)
                val retries = item.optInt("retry_count", 0)

                val file = if (filePath.isNotBlank()) File(filePath) else null
                if (file == null || !file.exists()) {
                    // Stale or missing file, skip
                    continue
                }

                // Check retention timeout or retry limit
                if (now - queuedAt > MAX_AGE_MS || retries >= MAX_RETRIES) {
                    Log.w(TAG, "Dropping expired SOS payload: ${file.name}")
                    try { file.delete() } catch (e: Exception) {}
                    continue
                }

                val payload = try { file.readText(Charsets.UTF_8) } catch (e: Exception) { "" }
                if (payload.isNotBlank()) {
                    val sent = sendSosPayload(payload, context = context)
                    if (sent) {
                        successCount++
                        // Clean up file immediately after verified transmission
                        try { file.delete() } catch (e: Exception) {}
                        Log.i(TAG, "Successfully flushed & deleted queued SOS: ${file.name}")
                    } else {
                        item.put("retry_count", retries + 1)
                        remainingList.put(item)
                    }
                }
            }

            prefs.edit().putString(KEY_PENDING_QUEUE, remainingList.toString()).apply()
            Log.i(TAG, "Flush completed. Success: $successCount, Remaining: ${remainingList.length()}")
            onComplete?.invoke(successCount, remainingList.length())
        }.start()
    }
}
