#!/usr/bin/env python3
"""
Configuration & Constants for Thailand Disaster EOC Command Center
Project: Chuaykan-EOC
"""
import os
import sys
from pathlib import Path

# Paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
ASSETS_DIR = PROJECT_ROOT / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
WEB_DIR = ASSETS_DIR / "web"
RINGTONE_PATH = ASSETS_DIR / "ringtone.wav"
USER_DATA_ROOT = (Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData/Local"))) / "Chuaykan") if sys.platform == "win32" else PROJECT_ROOT
DATA_DIR = Path(os.environ.get("EOC_DATA_DIR", USER_DATA_ROOT / "data"))
RECORDINGS_DIR = Path(os.environ.get("EOC_RECORDINGS_DIR", USER_DATA_ROOT / "recordings"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

# Database
DATABASE_PATH = DATA_DIR / "eoc_dispatch.db"

# Server configuration
DEFAULT_SERVER_HOST = "0.0.0.0"
DEFAULT_SERVER_PORT = int(os.environ.get("EOC_PORT", "8443"))

# Default Disaster Presets (Official Incident Templates)
DISASTER_PRESETS = [
    {
        "id": "chiang_rai_flood",
        "title": "อุทกภัยน้ำป่าไหลหลากล้นตลิ่งแม่น้ำกก อ.เมือง จ.เชียงราย",
        "hazard_type": "FLOOD",
        "severity": "CRITICAL",
        "center_lat": 19.9072,
        "center_lng": 99.8325,
        "radius_km": 12.0,
        "instruction": "ระดับน้ำแม่น้ำกกวิกฤตล้นตลิ่ง ขอให้ประชาชนยกของขึ้นที่สูง ตัดกระแสไฟฟ้า และเตรียมอพยพผู้ป่วยติดเตียงทันที",
        "agency": "ศูนย์ปฏิบัติการร่วมกู้ชีพกู้ภัย ปภ. เขต 15 / เทศบาลนครเชียงราย"
    },
    {
        "id": "mae_sai_flood",
        "title": "น้ำสายทะลักท่วมฉับพลัน ตลาดสายลมจอย อ.แม่สาย จ.เชียงราย",
        "hazard_type": "FLASH_FLOOD",
        "severity": "CRITICAL",
        "center_lat": 20.4335,
        "center_lng": 99.8805,
        "radius_km": 8.0,
        "instruction": "น้ำสายทะลักสูงระดับ 1.5-2 เมตร กระแสน้ำเชี่ยวกราก ห้ามลงน้ำและให้อยู่บนอาคารชั้น 2 ขึ้นไป",
        "agency": "กองอำนวยการร่วมกู้ชีพฉุกเฉิน อ.แม่สาย"
    },
    {
        "id": "chiang_mai_flood",
        "title": "มวลน้ำแม่น้ำปิงล้นตลิ่ง P.1 สะพานนวรัฐ อ.เมือง จ.เชียงใหม่",
        "hazard_type": "FLOOD",
        "severity": "WARNING",
        "center_lat": 18.7883,
        "center_lng": 99.0022,
        "radius_km": 15.0,
        "instruction": "ระดับน้ำแม่น้ำปิงแตะระดับวิกฤตสีแดง ชุมชนป่าพร้าวนอกและช้างคลานเร่งขนย้ายทรัพย์สิน",
        "agency": "ศูนย์บริหารจัดการน้ำอัจฉริยะ จ.เชียงใหม่"
    },
    {
        "id": "sukhothai_flood",
        "title": "แม่น้ำยมเอ่อล้นคันกั้นน้ำ อ.สวรรคโลก จ.สุโขทัย",
        "hazard_type": "FLOOD",
        "severity": "CRITICAL",
        "center_lat": 17.3167,
        "center_lng": 99.8333,
        "radius_km": 20.0,
        "instruction": "คันดินแม่น้ำยมชำรุด มวลน้ำหลากเข้าท่วมบ้านเรือนริมฝั่ง ขอให้ประชาชนอพยพมายังศูนย์พักพิงชั่วคราว",
        "agency": "ศูนย์ช่วยเหลือผู้ประสบภัย อุทกภัยสุโขทัย"
    }
]

# Tactical Color Palette (Unified Slate Navy & Cyber Accent System)
COLOR_BG_DARK = "#0B1120"          # Main Window Base (Tactical Deep Navy Slate)
COLOR_CARD_BG = "#131D31"          # Card & Panel Surface
COLOR_CARD_ELEVATED = "#17233B"    # Elevated Headers & HUD
COLOR_INPUT_BG = "#1A2844"         # Input Fields & Controls (Never pitch black!)
COLOR_BTN_SURFACE = "#202F4D"      # Unified Standard Button Surface
COLOR_BTN_HOVER = "#2B3E64"        # Button Hover Surface
COLOR_BORDER = "#253554"           # Clean Panel & Control Border
COLOR_BORDER_FOCUS = "#00F2FE"     # Focus & Glow Border

COLOR_EMERGENCY_RED = "#EF4444"    # Emergency / Danger Red
COLOR_EMERGENCY_RED_PULSE = "#DC2626"
COLOR_FLOOD_BLUE = "#0284C7"       # Primary Tactical Blue
COLOR_FLOOD_CYAN = "#00F2FE"       # Laser Cyan Indicator
COLOR_ALERT_AMBER = "#F59E0B"      # Warning / Dispatched Amber
COLOR_SIGNAL_GREEN = "#10B981"     # Safe / Operational Emerald

COLOR_TEXT_WHITE = "#FFFFFF"
COLOR_TEXT_SECONDARY = "#94A3B8"
COLOR_TEXT_MUTED = "#64748B"
