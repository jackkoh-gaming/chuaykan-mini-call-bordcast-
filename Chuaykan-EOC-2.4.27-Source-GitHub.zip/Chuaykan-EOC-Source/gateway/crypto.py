"""
Disaster Alert Gateway - Security & Cryptographic Module
Ensures alert authenticity via Asymmetric Public-Key ECDSA (NIST P-256 / SHA256withECDSA).
Client strictly verifies using embedded EC Public Key.
Private signing key is loaded strictly from environment or secure local key store.
"""
import os
import base64
import time
import logging
from pathlib import Path
from typing import Tuple, Optional

logger = logging.getLogger("GatewayCrypto")

# Public Key (X.509 SubjectPublicKeyInfo in Base64) - Matches Android AlertVerifier.kt
EC_PUBLIC_KEY_B64 = (
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAENQbMy0oGuOX/S7eJX6WUkwDfPma0AZV1QwqvqqSj1Ozw"
    "KZM9y+r6D6zwrdST/ZTpYp07GW1t9yQd2L/bZ5j2og=="
)

MAX_ALERT_AGE_MILLIS = 30 * 60 * 1000  # 30 minutes

_ec_private_key = None
_ec_public_key = None


def _get_ec_private_key():
    global _ec_private_key
    if _ec_private_key is not None:
        return _ec_private_key

    from cryptography.hazmat.primitives import serialization
    pem_data = os.environ.get("RESCUE_ECDSA_PRIVATE_KEY", "").strip()
    if not pem_data:
        pem_path = os.environ.get("RESCUE_ECDSA_KEY_PATH", "")
        if pem_path and os.path.isfile(pem_path):
            with open(pem_path, "r", encoding="utf-8") as f:
                pem_data = f.read()

    if not pem_data:
        # Check standard secure local path (gitignored)
        default_local_key = Path(__file__).resolve().parent / ".keys" / "ecdsa_p256_private.pem"
        if default_local_key.is_file():
            with open(default_local_key, "r", encoding="utf-8") as f:
                pem_data = f.read()

    if not pem_data:
        logger.error("No ECDSA private key provided in environment or secure path!")
        return None

    try:
        _ec_private_key = serialization.load_pem_private_key(
            pem_data.encode("utf-8"), password=None
        )
    except Exception as e:
        logger.error(f"Failed to load EC private key: {e}")
        _ec_private_key = None
    return _ec_private_key


def _get_ec_public_key():
    global _ec_public_key
    if _ec_public_key is not None:
        return _ec_public_key

    from cryptography.hazmat.primitives import serialization
    try:
        pub_der = base64.b64decode(EC_PUBLIC_KEY_B64)
        _ec_public_key = serialization.load_der_public_key(pub_der)
    except Exception as e:
        logger.error(f"Failed to load EC public key: {e}")
        _ec_public_key = None
    return _ec_public_key


def sign_alert_ecdsa(alert_id: str, sent_time_millis: int) -> str:
    """
    Computes Asymmetric ECDSA signature (SHA256withECDSA) for "{alert_id}:{sent_time_millis}".
    Returns signature with "SIG_EC:" prefix in standard DER Base64 format.
    """
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import hashes

    message = f"{alert_id}:{sent_time_millis}".encode("utf-8")
    priv_key = _get_ec_private_key()
    if priv_key is None:
        raise RuntimeError("ECDSA private key unavailable for signing.")

    der_sig = priv_key.sign(message, ec.ECDSA(hashes.SHA256()))
    sig_b64 = base64.b64encode(der_sig).decode("utf-8")
    return f"SIG_EC:{sig_b64}"


def sign_alert(alert_id: str, sent_time_millis: int, **kwargs) -> str:
    """
    Main signing entrypoint:
    Strictly uses Asymmetric ECDSA (NIST P-256) for production security.
    """
    return sign_alert_ecdsa(alert_id, sent_time_millis)


def verify_alert_signature(
    alert_id: str,
    sent_time_millis: int,
    signature: str,
    **kwargs
) -> bool:
    """
    Verifies that the provided signature is a valid ECDSA NIST P-256 signature.
    Strictly rejects non-ECDSA and downgrade signatures.
    """
    if not signature or not signature.startswith("SIG_EC:"):
        return False

    message = f"{alert_id}:{sent_time_millis}".encode("utf-8")

    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import hashes

    sig_b64 = signature[7:].strip()
    pub_key = _get_ec_public_key()
    if pub_key is None:
        return False
    try:
        sig_bytes = base64.b64decode(sig_b64)
        pub_key.verify(sig_bytes, message, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


def create_signed_timestamps(validity_minutes: int = 60) -> Tuple[int, int]:
    """Generates (sent_time, expires_at) in epoch milliseconds."""
    now_ms = int(time.time() * 1000)
    expires_ms = now_ms + (validity_minutes * 60 * 1000)
    return now_ms, expires_ms
