#!/usr/bin/env bash
# Install the existing sender on an Ubuntu Oracle VM. Does not start it.
set -euo pipefail
if [[ $EUID -ne 0 || $# -ne 1 || ! -f "$1" ]]; then
    echo "Usage: sudo bash install.sh /path/to/firebase-service-account.json" >&2
    exit 2
fi
DEPLOY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends python3-venv ca-certificates
if ! id rescuealert >/dev/null 2>&1; then
    useradd --system --user-group --no-create-home --shell /usr/sbin/nologin rescuealert
fi
install -d -m 0755 /opt/rescuealert-push/gateway
for source in official_push_monitor.py dispatcher.py models.py crypto.py; do
    install -m 0644 "$DEPLOY_ROOT/gateway/$source" "/opt/rescuealert-push/gateway/$source"
done
python3 -m venv /opt/rescuealert-push/venv
/opt/rescuealert-push/venv/bin/python -m pip install 'firebase-admin==7.5.0'
install -d -o root -g rescuealert -m 0750 /etc/rescuealert
install -o root -g rescuealert -m 0640 "$1" /etc/rescuealert/firebase-service-account.json
install -d -o rescuealert -g rescuealert -m 0700 /var/lib/rescuealert-push
install -m 0644 "$DEPLOY_ROOT/gateway/deploy/oracle/rescuealert-official-push.service" /etc/systemd/system/rescuealert-official-push.service
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/rescuealert-official-push.service
echo "Installed. Service is not started; transfer state and verify push before cutover."
