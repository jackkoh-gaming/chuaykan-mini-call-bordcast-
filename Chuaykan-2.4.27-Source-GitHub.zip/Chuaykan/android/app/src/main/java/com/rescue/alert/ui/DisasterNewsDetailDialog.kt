package com.rescue.alert.ui

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import com.rescue.alert.R
import com.rescue.alert.model.DisasterNewsItem
import com.rescue.alert.util.WebLinkHelper

/**
 * Full in-app bulletin reader dialog.
 * Enables users to read 100% of the news bulletin text and instructions offline or online,
 * with verified direct links, hotline dialing, and clipboard copying.
 */
object DisasterNewsDetailDialog {

    fun show(context: Context, item: DisasterNewsItem) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_news_detail, null)
        dialog.setContentView(dialogView)

        dialog.window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.94).toInt(),
            (context.resources.displayMetrics.heightPixels * 0.88).toInt()
        )

        val tvSourceBadge = dialogView.findViewById<TextView>(R.id.tvDetailSourceBadge)
        val tvCategoryBadge = dialogView.findViewById<TextView>(R.id.tvDetailCategoryBadge)
        val tvDate = dialogView.findViewById<TextView>(R.id.tvDetailDate)
        val btnCloseX = dialogView.findViewById<ImageButton>(R.id.btnDetailCloseX)
        val tvTitle = dialogView.findViewById<TextView>(R.id.tvDetailTitle)
        val tvBody = dialogView.findViewById<TextView>(R.id.tvDetailBody)
        val tvSourceFull = dialogView.findViewById<TextView>(R.id.tvDetailSourceFull)
        val tvUrlText = dialogView.findViewById<TextView>(R.id.tvDetailUrlText)
        val btnCallHotline = dialogView.findViewById<Button>(R.id.btnDetailCallHotline)
        val btnCopyUrl = dialogView.findViewById<Button>(R.id.btnDetailCopyUrl)
        val btnOpenBrowser = dialogView.findViewById<Button>(R.id.btnDetailOpenBrowser)
        val btnDismiss = dialogView.findViewById<Button>(R.id.btnDetailDismiss)

        // Source badge styling
        if (item.sourceCode.equals("DDPM", ignoreCase = true)) {
            tvSourceBadge.text = "ปภ. 1784"
            tvSourceBadge.setBackgroundResource(R.drawable.bg_badge_ddpm)
        } else {
            tvSourceBadge.text = "กรมอุตุฯ (TMD)"
            tvSourceBadge.setBackgroundResource(R.drawable.bg_badge_tmd)
        }

        // Category styling
        tvCategoryBadge.text = item.category
        if (item.severity == "CRITICAL") {
            tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_critical)
            tvCategoryBadge.setTextColor(Color.WHITE)
        } else if (item.severity == "EARLY_WARNING") {
            tvCategoryBadge.setBackgroundResource(R.drawable.bg_badge_early_warning)
            tvCategoryBadge.setTextColor(Color.WHITE)
        } else {
            tvCategoryBadge.setBackgroundResource(R.drawable.bg_status_chip)
            tvCategoryBadge.setTextColor(com.rescue.alert.util.ThemePalette.color("#94A3B8"))
        }

        val liveTag = "[ประกาศต้นทาง] "
        tvDate.text = "$liveTag${item.dateStr}"
        tvTitle.text = item.title

        tvBody.text = item.details.ifBlank { item.summary }

        tvSourceFull.text = item.source
        tvUrlText.text = if (item.id.startsWith("TMD_"))
            "${item.webUrl}\nเอกสารประกาศต้นทางกรมอุตุฯ • ${item.id.removePrefix("TMD_")}"
        else "${item.webUrl}\nรหัสประกาศ: ${item.id.removePrefix("OFFICIAL_")}\nต้นทางไม่มีลิงก์รายบทความ • เปิดหน้ารวมประกาศเพื่อตรวจสอบ"

        // Hotlines
        if (item.sourceCode.equals("DDPM", ignoreCase = true)) {
            btnCallHotline.visibility = View.VISIBLE
            btnCallHotline.text = "โทรสายด่วนนิรภัย ปภ. 1784"
            btnCallHotline.setOnClickListener {
                try {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:1784")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {}
            }
        } else if (item.sourceCode.equals("TMD", ignoreCase = true)) {
            btnCallHotline.visibility = View.VISIBLE
            btnCallHotline.text = "โทรสายด่วนกรมอุตุนิยมวิทยา 1182"
            btnCallHotline.setOnClickListener {
                try {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:1182")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {}
            }
        } else {
            btnCallHotline.visibility = View.GONE
        }

        btnCopyUrl.setOnClickListener {
            WebLinkHelper.copyToClipboard(context, item.webUrl)
        }

        btnOpenBrowser.text = "เปิดแหล่งประกาศ"
        btnOpenBrowser.setOnClickListener {
            WebLinkHelper.openUrl(context, item.webUrl)
        }

        btnCloseX.setOnClickListener { dialog.dismiss() }
        btnDismiss.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }
}
